﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Public Class cargoprocessing
    Inherits System.Web.UI.Page

    Friend JobId As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

            JobId = Request.QueryString("jobid")

            Call LoadAgents()
            Call LoadClients()
            Call LoadImporters("")
            Call LoadTransporters()
            Call LoadJobStatuses()
            Call LoadJobTypes()
            Call LoadCFS()
            Call LoadShippingVessels()

            Call LoadCargoProcessing("")

        End If

    End Sub

    Private Sub LoadCargoProcessing(ByVal SortBy As String)


        Dim sqlstr As String =
            "Select JobCargo.JobId," &
            "ContainerNo,Payload,JobCargo.Weight,VehicleNo," &
            "Transporter,JobCargo.PortExitDate," &
            "JobCargo.CrossBorderDate,DestinationArrivalDate," &
            "Jobs.JobDate,ReferenceNo," &
            "Jobs.Importer,EntryStatus,T812No," &
            "EntryRegistrationDate,EntryPassDate, " &
            "DeliveryOrderStatus,DeliveryOrderCharges," &
            "DeliveryOrderDate,Jobs.ReleaseOrderStatus," &
            "ReleaseOrderDate,PortCharges," &
            "Jobs.ShippingVessel,Jobs.VoyageNo," &
            "PortChargesStatus,PortChargesPaidDate, " &
            "Jobs.Client,Jobs.JobStatus,Jobs.VesselETA," &
            "Jobs.BerthingDate,CFS," &
            "Shipper,Agent, " &
            "Jobs.JobType,Jobs.KeepVisible,JobCargo.ID " &
            "From JobCargo, Jobs " &
            "Where JobCargo.JobId  = Jobs.JobId " &
            "And JobCargo.jobId = " & JobId

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col1 As New DataColumn("T810", Type.GetType("System.String"))
        Dim col2 As New DataColumn("T812", Type.GetType("System.String"))
        Dim col3 As New DataColumn("DO", Type.GetType("System.String"))
        Dim col4 As New DataColumn("RO", Type.GetType("System.String"))
        Dim col5 As New DataColumn("Port", Type.GetType("System.String"))
        Dim col6 As New DataColumn("Trans", Type.GetType("System.String"))
        Dim col7 As New DataColumn("Consignee", Type.GetType("System.String"))
        Dim col8 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
        Dim col9 As New DataColumn("Arrived", Type.GetType("System.Boolean"))
        Dim col10 As New DataColumn("Status", Type.GetType("System.String"))

        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)
        tmptable.Columns.Add(col8)
        tmptable.Columns.Add(col9)
        tmptable.Columns.Add(col10)

        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)

            Dim tmpstr5() As String = drow("Importer").ToString.Split(vbCrLf)
            ReDim Preserve tmpstr5(0)
            drow("Importer") = tmpstr5(0)
            drow("Consignee") = Mid(tmpstr5(0), 1, 20)

            If CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                drow("CrossedBorder") = CBool(1)
            End If

            If CDate(drow("DestinationArrivalDate")) = CDate("1-Jan-1800") Then
                drow("Arrived") = CBool(1)
            End If

            drow("T810") = "-"

            If Trim(LCase(drow("EntryStatus"))) = "lodged" Then
                drow("T810") = "OK"
            End If

            If Trim(LCase(drow("EntryStatus"))) = "passed" Then
                drow("T810") = "OK"
            End If


            If Not CDate(Trim(drow("EntryRegistrationDate"))) = CDate("1-Jan-1800") Then
                drow("T810") = "OK"
            End If

            If Not CDate(Trim(drow("EntryRegistrationDate"))) = CDate("1-Jan-1800") Then
                drow("T810") = "OK"
            End If

            '----------
            drow("T812") = "-"

            If Not Trim(LCase(drow("T812No"))) = "" Then
                drow("T812") = "OK"
            End If

            '----------

            drow("DO") = "-"

            If Trim(LCase(drow("DeliveryOrderStatus"))) = "secured" Then
                drow("DO") = "OK"
            End If

            If Not CDate(Trim(drow("DeliveryOrderDate"))) = CDate("1-Jan-1800") Then
                drow("DO") = "OK"
            End If

            If Val(drow("DeliveryOrderCharges")) > 0 Then
                drow("DO") = "OK"
            End If

            '----------

            drow("RO") = "-"

            If Trim(LCase(drow("ReleaseOrderStatus"))) = "secured" Then
                drow("RO") = "OK"
            End If

            If Not CDate(Trim(drow("ReleaseOrderDate"))) = CDate("1-Jan-1800") Then
                drow("RO") = "OK"
            End If


            '----------

            drow("PORT") = "-"

            If Trim(LCase(drow("PortChargesStatus"))) = "paid" Then
                drow("PORT") = "OK"
            End If

            If Not CDate(Trim(drow("PortChargesPaidDate"))) = CDate("1-Jan-1800") Then
                drow("PORT") = "OK"
            End If


            If Val(drow("PortCharges")) > 0 Then
                drow("Port") = "OK"
            End If


            drow("Trans") = "-"

            If Not Trim(LCase(drow("VehicleNo"))) = "" Then
                drow("Trans") = "OK"
            End If

            If Not Trim(LCase(drow("Transporter"))) = "" Then
                drow("Trans") = "OK"
            End If

            a = a + 1
        Next

        GridCargoProcessing.DataSource = tmptable
        GridCargoProcessing.DataBind()

        LabelCargoProcessing.Text = "CARGO PROCESSING SUMMARY: " & tmptable.Rows.Count & " Cargo Items | " & TextFromDate.Text & " - " & TextToDate.Text
    End Sub

    Private Sub LoadAgents()
        Dim sqlstr As String =
        "Select Agent From Agents " &
        "Order By Agent Asc;"
        ComboAgents.Items.Clear()
        Call clsData.PopCombo(ComboAgents, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadClients()
        Dim sqlstr As String =
        "Select Client From Clients " &
        "Order By Client Asc;"
        ComboClients.Items.Clear()
        Call clsData.PopCombo(ComboClients, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadImporters(ByVal filterstr As String)
        Dim sqlstr As String =
        "Select Importer From Importers " &
        "Order By Importer Asc;"
        ComboConsignees.Items.Clear()
        Call clsData.PopCombo(ComboConsignees, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadTransporters()
        Dim sqlstr As String =
        "Select Transporter From Transporters " &
        "Order By Transporter Asc;"
        Call clsData.PopCombo(ComboTransporters, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadShippingVessels()
        Dim sqlstr As String =
            "Select Vessel, VoyageNo " &
            "From  ShippingVessels " &
            "Where Active = " & 1 & " " &
            "Order By Vessel Asc;"

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        Dim a As Integer
        ComboShippingVessels.Items.Clear()
        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)
            ComboShippingVessels.Items.Add(drow("Vessel") & ": " & drow("VoyageNo"))
            a = a + 1
        Next
    End Sub

    Private Sub LoadJobStatuses()
        Dim sqlstr As String =
         "Select Status " &
         "From JobStatuses "
        ComboJobStatus.Items.Clear()
        Call clsData.PopCombo(ComboJobStatus, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadJobTypes()
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes "
        ComboJobType.Items.Clear()
        Call clsData.PopCombo(ComboJobType, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadCFS()
        Dim sqlstr As String =
        "Select CFS " &
        "From CFS"
        ComboCFS.Items.Clear()
        Call clsData.PopCombo(ComboCFS, sqlstr, clsData.constr, 0)
    End Sub
End Class