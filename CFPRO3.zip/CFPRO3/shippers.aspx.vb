﻿Imports System.Drawing
Imports System.IO
Imports OfficeOpenXml

Public Class shippers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID


            Call LoadShippers(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadShippers(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Shipper  Like '%" & TextSearch.Text & "%' "
        End If


        Dim sqlstr As String =
              "Select ShipperID, Shipper," &
              "Box,Telephone,Email," &
              "Town,Country,Id " &
              "From  Shippers " &
              "Where  CFPROID = '" & CFPROID & "' " & _
                tmpstr &
              "Order By ID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next


        GridShippers.DataSource = tmptable
        GridShippers.DataBind()

        If GridShippers.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If
            GridShippers.SelectedIndex = Rowindex
            Call ShowShipper(CFPROID, GridShippers.SelectedValue.ToString)
            Dim row As GridViewRow = GridShippers.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If


        If Not Trim(SearchStr) = "" Then
            LabelItemsCount.Text = tmptable.Rows.Count & " Shippers found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsCount.Text = tmptable.Rows.Count & " Shippers"
        End If

    End Sub



    Private Sub ShowShipper(CFPROID As String, ShipperID As String)

        Dim sqlstr As String =
             "Select ShipperID, Shipper," &
             "Box,Telephone,Email," &
             "Town,Country " &
             "From  Shippers " &
              "Where  CFPROID = '" & CFPROID & "' " & _
             "And ShipperID = '" & ShipperID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextShipper.Text = drow("Shipper")
            TextAddress.Text = drow("Box")
            TextTelephone.Text = drow("Telephone")
            TextEmail.Text = drow("Email")
            TextTown.Text = drow("Town")
            TextCountry.Text = drow("Country")
        End If



    End Sub



    Private Sub NewShipper(CFPROID As String)
        Try


            Dim sqlstr As String =
                  "Select ShipperID, Shipper," &
                  "CFPROID, Id " &
                  "From  Shippers " & _
                  "Where  CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow
            Drow("CFPROID") = CFPROID
            Drow("ShipperID") = GetShipperID()
            Drow("Shipper") = "New Shipper " & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Shippers", tmptable, sqlstr, False, clsData.constr)
            Call LoadShippers(CFPROID, 0, "")


            TextShipper.Focus()



        Catch exp As Exception
            MsgBox(exp.Message, , "AddShipper")
        End Try
    End Sub


    Private Function GetShipperID() As String
        Try

            Dim tmpShipperID As Integer

            Dim sqlstr As String =
             "Select top 1 Id " &
             "From Shippers " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpShipperID = drow("ID")
                tmpShipperID = tmpShipperID + 1
                tmpstr = Format(tmpShipperID, "00000000#")
            Else
                tmpstr = Format(tmpShipperID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetShipperID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridShippers, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridShippers.SelectedIndexChanged
        Dim row As GridViewRow = GridShippers.Rows(GridShippers.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowShipper(LabelCFPROID.Text, GridShippers.SelectedValue.ToString)

        For a As Integer = 0 To GridShippers.Rows.Count - 1
            row = GridShippers.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridShippers.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewShipper(LabelCFPROID.Text)
    End Sub


    Private Sub SaveShipper(CFPROID As String, ShipperID As String)
        Try


            Dim sqlstr As String =
            "Select ShipperID, Shipper," &
            "Box,Telephone,Email," &
            "Town,Country,ID " &
            "From  Shippers " &
            "Where  CFPROID = '" & CFPROID & "' " &
            "And ShipperID = '" & ShipperID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Shipper") = Trim(TextShipper.Text)
                drow("Box") = Trim(TextAddress.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmail.Text)
                drow("Town") = Trim(TextTown.Text)
                drow("Country") = Trim(TextCountry.Text)
            End If

            Call clsData.SaveData("Shippers", tmptable, sqlstr, False, clsData.constr)


            Call LoadShippers(CFPROID, GridShippers.SelectedIndex, TextSearch.Text)

        Catch exp As Exception
            MsgBox(exp.Message, , "AddShipper")
        End Try
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveShipper(LabelCFPROID.Text, GridShippers.SelectedValue.ToString)
    End Sub

    Private Sub DeleteShipper(CFPROID As String, ShipperID As String)


        Dim sqlstr As String =
        "Select ID " &
        "From  Shippers " &
        "Where  CFPROID = '" & CFPROID & "' " &
        "And ShipperID = '" & ShipperID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Shippers", tmptable, sqlstr, True, clsData.constr)
        Call LoadShippers(CFPROID, GridShippers.SelectedIndex - 1, TextSearch.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteShipper(LabelCFPROID.Text, GridShippers.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadShippers(LabelCFPROID.Text, 0, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click

        Call LoadShippers(LabelCFPROID.Text, -1, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click
        Call ContactListExcel(LabelCFPROID.Text)
    End Sub

    Private Sub ContactListExcel(CFPROID As String)
        Dim sqlstr As String =
            "Select ShipperID, Shipper," &
            "Box,Telephone,Email," &
            "Town,Country " &
            "From  Shippers " &
             "Where  CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = tmptable.Columns.Count
        Dim totalRows = tmptable.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = tmptable.Columns(col1 - 2).ColumnName
        Next

        workSheet.Cells("B3:H3").Merge = True
        workSheet.Cells("B4:H4").Merge = True

        workSheet.Cells("B3:H3").Style.Font.Size = 14
        workSheet.Cells("B4:H4").Style.Font.Size = 9
        workSheet.Cells("B3:H4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = "Shippers Contacts List"
        workSheet.Cells(4, 2).Value = "Shippers " & Now.ToString("dd MMM yyyy hh:mm:ss tt")

        Dim row1 As DataRow
        Dim row As Integer
        For row = 5 To totalRows + 4
            row1 = tmptable.Rows(row - 5)
            For col1 As Integer = 1 To totalCols
                workSheet.Cells(row + 1, col1 + 1).Value = row1(col1 - 1).ToString()
                If row1(col1 - 1).ToString() = "" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next


        Next

        Using rng As ExcelRange = workSheet.Cells("B5:H" & tmptable.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:H5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":H" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        'workSheet.Cells("C" & row & ":D" & row).Merge = True
        'workSheet.Cells("E" & row & ":F" & row).Merge = True
        'workSheet.Cells("G" & row & ":H" & row).Merge = True

        'workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        'workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        'workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        'workSheet.Cells("J" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Shippers Contacts " & Format(Now, "dd MMM yyyy hh:mm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub
End Class