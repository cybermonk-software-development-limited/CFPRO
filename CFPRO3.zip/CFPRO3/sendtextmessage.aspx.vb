﻿Public Class sendtextmessage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFAgentName As String = ""
            Dim UserID As String = ""
            Dim ClientID As String = Request.QueryString("clientid")
            Dim ImporterID As String = Request.QueryString("importerid")
            Dim JobID As String = Request.QueryString("jobid")

            Call clsAuth.UserLogin("", CFPROID, UserID, "", CFAgentName, "", "", "", True, "", False)


            LabelCFPROID.Text = CFPROID
            LabelCFAgentName.Text = CFAgentName
            LabelClientID.Text = ClientID

            LabelImporterID.Text = ImporterID
            LabelJobID.Text = JobID
            LabelUserID.Text = UserID

            Call LoadAdditionalMessage()

        End If




    End Sub

    Private Sub LoadAdditionalMessage()
        If Not IsNothing(Request.Cookies("AdditionalMessage")) Then
            TextAddMessage.Text = Request.Cookies("AdditionalMessage").Value
        End If

    End Sub



    Private Sub SetDestination(CFPROID As String, ClientID As String, ImporterID As String, Destination As String)
        Try
            Dim ClientDetails() As String = clsProgressUpdates.GetClientDetails(CFPROID, ClientID)
            ReDim Preserve ClientDetails(0)

            Dim ImporterDetails() As String = clsProgressUpdates.GetImporterDetails(CFPROID, ImporterID)
            ReDim Preserve ImporterDetails(0)

            TextSendTo.Text = ""

            If Trim(TextSendTo.Text) = "" Then

                If Destination = 1 Then
                    TextSendTo.Text = ClientDetails(0)
                ElseIf Destination = 2 Then
                    TextSendTo.Text = ImporterDetails(0)
                ElseIf Destination = 3 Then
                    TextSendTo.Text = ClientDetails(0) & ", " & ImporterDetails(0)
                End If

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub



    Private Sub SetMessage(CFPROID As String, JobID As String, ClientID As String, ImporterID As String,
                           UserID As String, MessageType As String)
        Try

            TextMessage.Text = ""
            Dim Message As String = ""

            If MessageType = 1 Then
                Message = clsProgressUpdates.StatusUpdateText(JobID, ClientID, Trim(TextAddMessage.Text), LabelMessage1.Text)

            ElseIf MessageType = 2 Then
                Message = clsProgressUpdates.CargoStatusUpdate(CFPROID, JobID, UserID, Trim(TextAddMessage.Text), TodaysDate.Value, LabelMessage1.Text)
                LabelMessage1.Text = TodaysDate.Value
            End If


            TextMessage.Text = Message
            LabelMessage.Text = "Message (" & Message.Length & ")"

            If Not Trim(TextAddMessage.Text) = "" Then
                Response.Cookies("AdditionalMessage").Value = Trim(TextAddMessage.Text)
                Response.Cookies("AdditionalMessage").Expires = Now.AddDays(30)
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub
    Protected Sub ButtonSendtText_Click(sender As Object, e As EventArgs) Handles ButtonSendText.Click


        Dim Result As String = ""

        Call ATSendText.SendText(TextSendTo.Text, TextMessage.Text, LabelCFPROID.Text, Result)

        PanelPhoneNos.Visible = False
        PanelMessage.Visible = False
        PanelSenderControls.Visible = False
        PanelSendResult.Visible = True

        If Result = "Success!" Then
            ImageResult.ImageUrl = "messagesent1.png"
        Else
            ImageResult.ImageUrl = "messagenotsent1.png"
        End If


    End Sub


    Protected Sub ButtonButtonRefreshText_Click(sender As Object, e As EventArgs) Handles ButtonRefreshText.Click
        Call SetMessage(LabelCFPROID.Text, LabelJobID.Text, LabelClientID.Text, LabelImporterID.Text, LabelUserID.Text,
                                                                    ComboMessageType.SelectedIndex)
    End Sub

    Protected Sub ComboMessageType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboMessageType.SelectedIndexChanged
        Call SetMessage(LabelCFPROID.Text, LabelJobID.Text, LabelClientID.Text, LabelImporterID.Text, LabelUserID.Text,
                                                                      ComboMessageType.SelectedIndex)
    End Sub

    Protected Sub ComboDestination_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDestination.SelectedIndexChanged
        Call SetDestination(LabelCFPROID.Text, LabelClientID.Text, LabelImporterID.Text, ComboDestination.SelectedIndex)
    End Sub
End Class

