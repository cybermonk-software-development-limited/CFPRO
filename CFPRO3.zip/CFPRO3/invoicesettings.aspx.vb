﻿Imports System.Drawing

Public Class invoicesettings
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""



            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            Call LoadInvoiceTypes(CFPROID, 0)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
           
        End If

    End Sub

    Private Sub LoadInvoiceTypes(ByVal CFPROID As String, ByVal Rowindex As Integer)

        Try

            Dim sqlstr As String =
               "SELECT InvoiceTypeID," &
               "InvoiceType, CFPROID, ID " &
               "FROM InvoiceTypes " &
               "Where CFPROID = '" & CFPROID & "' " &
               "Order By ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then
                Call clsSubs.CreateAccountInvoiceTypes(CFPROID, tmptable)
            End If

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridInvoiceTypes.DataSource = tmptable
            GridInvoiceTypes.DataBind()

            If GridInvoiceTypes.Rows.Count > 0 Then
                Dim row As GridViewRow = GridInvoiceTypes.Rows(Rowindex)


                If Rowindex < 0 Then
                    Rowindex = 0
                End If

                If Rowindex > GridInvoiceTypes.Rows.Count - 1 Then
                    Rowindex = GridInvoiceTypes.Rows.Count - 1
                End If

                GridInvoiceTypes.SelectedIndex = Rowindex


                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")


                Dim InvoiceTypeID As String = GridInvoiceTypes.SelectedDataKey(0).ToString
                LabelInvoiceTypeID.Text = InvoiceTypeID


                Dim LabelInvoiceType As Label = CType(row.FindControl("LabelInvoiceType"), Label)


                Call LoadInvoiceTypeItems(CFPROID, InvoiceTypeID, LabelInvoiceType.Text, 0)
                LabelCaptionInvoiceTypes.Text = tmptable.Rows.Count & "  Invoice Types"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadInvoiceTypeItems(CFPROID As String, InvoiceTypeID As String, InvoiceType As String, Rowindex As Integer)

        Try

            Dim sqlstr As String =
                "SELECT InvoiceTypeItems.ItemID," &
                "Item, Cost, Amount," &
                "ApplyTax,TaxPercent," &
                "TaxAmount,TaxType," &
                "Total,InvoiceTypeItems.ID  " &
                "FROM InvoiceTypeItems, InvoiceItems, InvoiceTypes " &
                "Where InvoiceTypeItems.InvoiceTypeID ='" & InvoiceTypeID & "' " &
                "And InvoiceTypeItems.CFPROID ='" & CFPROID & "' " &
                "And InvoiceItems.CFPROID ='" & CFPROID & "' " &
                "And InvoiceTypeItems.CFPROID = InvoiceTypes.CFPROID " &
                "And InvoiceTypeItems.ItemID = InvoiceItems.ItemID " &
                "And InvoiceTypeItems.InvoiceTypeID = InvoiceTypes.InvoiceTypeID " &
                "Order By InvoiceTypeItems.ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                        If drow("ApplyTax") Then
                            drow("TaxAmount") = drow("Amount") * (drow("TaxPercent") / 100)
                        Else
                            drow("TaxAmount") = 0
                        End If

                        drow("Total") = drow("Amount") + drow("TaxAmount")
                        a = a + 1
                Next
            End If

            LabelCaptionInvoiceItems.Text = tmptable.Rows.Count & "  Invoice Items  Set For " & InvoiceType

            Call Calctotal(tmptable)

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Item") = "Invoice Type Items Not Set"
                tmptable.Rows.Add(drow)
            End If


            Session("InvoiceSettingTable") = tmptable

            GridInvoiceTypeItems.DataSource = tmptable
            GridInvoiceTypeItems.DataBind()

            If GridInvoiceTypeItems.Rows.Count > 0 Then
                If Rowindex < 0 Then
                    Rowindex = 0
                End If

                If Rowindex > GridInvoiceTypeItems.Rows.Count - 1 Then
                    Rowindex = GridInvoiceTypeItems.Rows.Count - 1
                End If

                GridInvoiceTypeItems.SelectedIndex = Rowindex
                Dim row As GridViewRow = GridInvoiceTypeItems.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Private Sub Calctotal(tmptable As DataTable)
        Try


            Dim a As Integer
            Dim Cost, Amount, TotalTax, Total As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Cost = Cost + drow("Cost")
                Amount = Amount + drow("Amount")
                TotalTax = TotalTax + drow("TaxAmount")
                Total = Total + drow("Total")

                a = a + 1

            Next

            TextTotalCost.Text = Format(Cost, "#,##0.00")
            TextSubTotal.Text = Format(Amount, "#,##0.00")
            TextTaxAmount.Text = Format(TotalTax, "#,##0.00")

            TextTotal.Text = Format(Total, "#,##0.00")

           

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Protected Sub GridInvoiceTypes_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridInvoiceTypes.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridInvoiceTypes, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub GridInvoiceTypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridInvoiceTypes.SelectedIndexChanged


        Dim row As GridViewRow = GridInvoiceTypes.Rows(GridInvoiceTypes.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        Dim InvoiceTypeID As String = GridInvoiceTypes.SelectedDataKey(0).ToString
        LabelInvoiceTypeID.Text = InvoiceTypeID
        Dim LabelInvoiceType As Label = CType(row.FindControl("LabelInvoiceType"), Label)

        Call LoadInvoiceTypeItems(LabelCFPROID.Text, InvoiceTypeID, LabelInvoiceType.Text, 0)

        For a As Integer = 0 To GridInvoiceTypes.Rows.Count - 1
            row = GridInvoiceTypes.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridInvoiceTypes.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next


    End Sub

    Protected Sub GridInvoiceTypeItems_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridInvoiceTypeItems.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridInvoiceTypeItems, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub GridInvoiceItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridInvoiceTypeItems.SelectedIndexChanged
        Dim row As GridViewRow = GridInvoiceTypeItems.Rows(GridInvoiceTypeItems.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridInvoiceTypeItems.Rows.Count - 1
            row = GridInvoiceTypeItems.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridInvoiceTypeItems.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub



    Private Sub AddEditInvoiceType(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then

                LabelAddEdit.Text = "Edit InvoiceType"
                Dim ID As Integer = GridInvoiceTypes.SelectedDataKey(1)

                Dim sqlstr As String = "SELECT InvoiceType,ID " &
                                        "From  InvoiceTypes " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)

                    TextAddEdit.Text = drow("InvoiceType")

                End If

            Else
                LabelAddEdit.Text = "Add Invoice Type"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub




    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditInvoiceType(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditInvoiceType(LabelCFPROID.Text, True)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveInvoiceType(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveInvoiceType(CFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If InvoiceTypeExists(CFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridInvoiceTypes.SelectedIndex >= 0 Then
                    ID = GridInvoiceTypes.SelectedValue
                End If
            End If

            Dim sqlstr As String = "SELECT InvoiceTypeID, " &
                                    "InvoiceType, CFPROID, ID " &
                                    "From  InvoiceTypes " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("InvoiceTypeID") = clsSubs.GetInvoiceTypeID(LabelMessage1.Text)
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("InvoiceType") = Trim(TextAddEdit.Text)


            Call clsData.SaveData("InvoiceTypes", tmptable, sqlstr, False, clsData.constr)

            Call LoadInvoiceTypes(CFPROID, GridInvoiceTypes.SelectedIndex)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function InvoiceTypeExists(CFPROID As String, InvoiceType As String) As Boolean


        Dim sqlstr As String = "SELECT InvoiceType " &
                                "From  InvoiceTypes " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And InvoiceType = '" & Trim(InvoiceType) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function



    Protected Sub ButtonDeleteInvoiceType_Click(sender As Object, e As EventArgs) Handles ButtonDeleteInvoiceType.Click
        Call PromptDeleteInvoiceType(LabelCFPROID.Text)
    End Sub



    Private Sub PromptDeleteInvoiceType(CFPROID As String)

        Dim row As GridViewRow = GridInvoiceTypes.Rows(GridInvoiceTypes.SelectedIndex)
        Dim LabelInvoiceType As Label = CType(row.FindControl("LabelInvoiceType"), Label)

        LabelDeleteMessage.Text = "Delete " & LabelInvoiceType.Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteInvoiceType(GridInvoiceTypes.SelectedDataKey(0), GridInvoiceTypes.SelectedDataKey(1), LabelCFPROID.Text)
    End Sub
    Private Sub DeleteInvoiceType(InvoiceTypeID As String, ID As Integer, CFPROID As String)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From InvoiceTypes  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("InvoiceTypes", tmptable, sqlstr, True, clsData.constr)


            Dim sqlstr1 As String = _
                "Select  ID " & _
                 "From InvoiceTypeItems  " & _
                 "Where InvoiceTypeID = '" & InvoiceTypeID & "' " &
                 "And CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim drow1 As DataRow
            For a = 0 To tmptable1.Rows.Count - 1
                drow1 = tmptable1.Rows(a)
                drow1.Delete()
            Next
            Call clsData.SaveData("InvoiceTypeItems", tmptable1, sqlstr1, True, clsData.constr)

            Call LoadInvoiceTypes(LabelCFPROID.Text, GridInvoiceTypes.SelectedIndex - 1)

        End If

        ModalPopupExtender3.Hide()

    End Sub



    Protected Sub ButtonDeleteInvoiceTypeItem_Click(sender As Object, e As EventArgs) Handles ButtonDeleteInvoiceTypeItem.Click

        If GridInvoiceTypeItems.SelectedIndex >= 0 Then
            LabelMessage.Text = ""
            LabelMessage.ForeColor = Color.Gray
            Call DeleteInvoiceTypeItem(GridInvoiceTypeItems.SelectedValue)
        Else
            LabelMessage.Text = "Select Item to Remove"
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub
    Private Sub DeleteInvoiceTypeItem(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From InvoiceTypeItems  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("InvoiceTypeItems", tmptable, sqlstr, True, clsData.constr)

            Dim row As GridViewRow = GridInvoiceTypes.Rows(GridInvoiceTypes.SelectedIndex)
            Dim LabelInvoiceType As Label = CType(row.FindControl("LabelInvoiceType"), Label)

            Call LoadInvoiceTypeItems(LabelCFPROID.Text, GridInvoiceTypes.SelectedDataKey(0).ToString, LabelInvoiceType.Text, GridInvoiceTypeItems.SelectedIndex - 1)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    Protected Sub ButtonSetInvoiceTypeItems_Click(sender As Object, e As EventArgs) Handles ButtonSetInvoiceTypeItems.Click
        Call LoadInvoiceItems(LabelCFPROID.Text, LabelInvoiceTypeID.Text)
    End Sub


    Private Sub LoadInvoiceItems(CFPROID As String, InvoiceTypeID As String)

        Try
            Dim sqlstr As String =
                "SELECT  Item," &
                "ItemID, CFPROID, ID " &
                "FROM  InvoiceItems " &
                "Where CFPROID = '" & CFPROID & "' " &
                "Order By Item Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If


            If tmptable.Rows.Count = 0 Then
                Call clsSubs.CreateAccountInvoiceItems(CFPROID, tmptable, False)
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()



            Dim sqlstr1 As String =
                "SELECT  ItemID, ID " &
                "From  InvoiceTypeItems " &
                "Where CFPROID ='" & CFPROID & "' " &
                "And InvoiceTypeID ='" & InvoiceTypeID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim b As Integer
            If tmptable1.Rows.Count > 0 Then

                Dim chkbox As CheckBox
                Dim nFieldItemID As HiddenField

                For Each item As DataListItem In DataList1.Items
                    a = 0

                    chkbox = DirectCast(item.FindControl("CheckInvoiceItem"), CheckBox)
                    nFieldItemID = DirectCast(item.FindControl("FieldItemID"), HiddenField)

                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, a)

                        If drow1("ItemID") = nFieldItemID.Value Then
                            chkbox.Checked = True
                            b = b + 1
                            Exit For
                        End If
                        a = a + 1
                    Next

                Next
            End If



            LabelItemypeCount.Text = b & " / " & DataList1.Items.Count & "Invoice Items"
            ModalPopupExtender4.Show()



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveInvoiceTypeItems_Click(sender As Object, e As EventArgs) Handles ButtonSaveInvoiceTypeItems.Click
        ModalPopupExtender4.Hide()
        Call SaveInvoiceTypeItems(LabelCFPROID.Text, LabelInvoiceTypeID.Text)
    End Sub


    Protected Sub CheckInvoiceItem_CheckedChanged(sender As Object, e As EventArgs)

        Dim chkbox As CheckBox
        Dim a As Integer

        For Each item As DataListItem In DataList1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                chkbox = TryCast(item.FindControl("CheckInvoiceItem"), CheckBox)
                If chkbox IsNot Nothing Then
                    If chkbox.Checked Then
                        a = a + 1
                    End If
                End If

            End If
        Next

        LabelItemypeCount.Text = a & " / " & DataList1.Items.Count & " Invoice Items"
        ModalPopupExtender4.Show()

    End Sub
    Private Sub SaveInvoiceTypeItems(CFPROID As String, InvoiceTypeID As String)

        Try

            Dim sqlstr As String = "SELECT InvoiceTypeID, ItemID," &
                                    "CFPROID, ID " &
                                    "From  InvoiceTypeItems " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And InvoiceTypeID ='" & InvoiceTypeID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            Dim chkbox As CheckBox
            Dim nFieldItemID As HiddenField
            Dim found As Boolean
            Dim a As Integer

            For Each item As DataListItem In DataList1.Items

                If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                    chkbox = DirectCast(item.FindControl("CheckInvoiceItem"), CheckBox)
                    nFieldItemID = DirectCast(item.FindControl("FieldItemID"), HiddenField)


                    If chkbox IsNot Nothing Then
                        If chkbox.Checked Then
                            a = 0
                            found = False

                            For Each drow In tmptable.Rows
                                Call clsData.NullChecker(tmptable, a)
                                If drow("ItemID") = nFieldItemID.Value Then
                                    found = True
                                    Exit For
                                End If
                                a = a + 1
                            Next

                            If Not found Then
                                Dim drow1 As DataRow = tmptable.NewRow
                                drow1("CFPROID") = CFPROID
                                drow1("ItemID") = nFieldItemID.Value
                                drow1("InvoiceTypeID") = InvoiceTypeID
                                tmptable.Rows.Add(drow1)
                            End If

                        End If
                    End If
                End If


            Next
            Call clsData.SaveData("InvoiceTypeItems", tmptable, sqlstr, False, clsData.constr)

            Dim row1 As GridViewRow = GridInvoiceTypes.Rows(GridInvoiceTypes.SelectedIndex)
            Dim LabelInvoiceType As Label = CType(row1.FindControl("LabelInvoiceType"), Label)

            Call LoadInvoiceTypeItems(LabelCFPROID.Text, LabelInvoiceTypeID.Text, LabelInvoiceType.Text, GridInvoiceTypeItems.SelectedIndex)

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonEditInvoiceTypeItem_Click(sender As Object, e As EventArgs) Handles ButtonEditInvoiceTypeItem.Click

        Call EditInvoiceItem(LabelCFPROID.Text)
    End Sub
    Private Sub EditInvoiceItem(CFPROID As String)
        Try

            LabelMessage.Text = ""
            LabelMessage.ForeColor = Color.Gray


            If GridInvoiceTypeItems.SelectedIndex < 0 Then
                LabelMessage.Text = "Please SELECT Invoice Item."
                LabelMessage.ForeColor = Color.Red
                Exit Sub
            End If

            LabelAddEdit.Text = "Edit Invoice Item"
            Dim ID As Integer = GridInvoiceTypeItems.SelectedValue
            Dim sqlstr As String =
                     "SELECT  ItemID,Cost, " &
                      "CFPROID,ID " &
                     "FROM  InvoiceTypeItems " &
                     "Where ID = " & ID & " "
            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                TextCost.Text = drow("Cost")
                
            End If



            ModalPopupExtender7.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSaveItem_Click(sender As Object, e As EventArgs) Handles ButtonSaveItem.Click
        Call SaveInvoiceTypeItem()
    End Sub
    Private Sub SaveInvoiceTypeItem()

        Dim ID As Integer = GridInvoiceTypeItems.SelectedDataKey(0)

        Dim CFPROID As String = LabelCFPROID.Text


        Try

            Dim sqlstr As String =
                    "SELECT  ItemID, Cost," &
                    "CFPROID,ID " &
                    "FROM  InvoiceTypeItems " &
                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                drow("Cost") = Trim(TextCost.Text)
            End If


            Call clsData.SaveData("InvoiceTypeItems", tmptable, sqlstr, False, clsData.constr)

            Dim row As GridViewRow = GridInvoiceTypes.Rows(GridInvoiceTypes.SelectedIndex)
            Dim LabelInvoiceType As Label = CType(row.FindControl("LabelInvoiceType"), Label)

            Call LoadInvoiceTypeItems(CFPROID, LabelInvoiceTypeID.Text, LabelInvoiceType.Text, GridInvoiceTypeItems.SelectedIndex)

            ModalPopupExtender7.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonItemTypes_Click(sender As Object, e As EventArgs) Handles ButtonItemTypes.Click
        Dim sourcepage As String = "invoiceitems.aspx"
        Call LoadDialog(sourcepage, "Invoice items", 730, 455)
    End Sub


    Private Sub LoadDialog(sourcepage As String, dialogtitle As String, width As Integer, height As Integer)


        Dim iframebg As String = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit;" &
                "background-position-y: center; background-position-x: center;"

        PanelDialog.Attributes("style") = "width:" & width + 10 & "px; height:" & height + 72 & "px;"
        PanelDrag.Attributes("style") = "width:100%;"
        iframe1.Attributes("style") = "width:" & width & "px ; height:" & height & "px;" & iframebg

        LabelDialogTitle.Text = dialogtitle
        iframe1.Attributes("src") = sourcepage

        ModalPopupExtender5.Show()
    End Sub


    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

   
    
    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExcelInvoiceSettings()
    End Sub

    Private Sub ExcelInvoiceSettings()

        Dim totals(5) As String

        totals(0) = "Total Cost: " & TextTotalCost.Text
        totals(1) = "Sub Total: " & TextSubTotal.Text
        totals(2) = "Total Tax: " & TextTaxAmount.Text
        totals(3) = "Total : " & TextTotal.Text



        Dim tmpfields(8) As String
        tmpfields(0) = "ItemID"
        tmpfields(1) = "Item"
        tmpfields(2) = "Cost"
        tmpfields(3) = "Amount"
        tmpfields(4) = "ApplyTax"
        tmpfields(5) = "TaxPercent"
        tmpfields(6) = "TaxAmount"
        tmpfields(7) = "TaxType"
        tmpfields(8) = "Total"



        'Dim tmptable As New DataTable("InvoiceSettingTable")
        'tmptable = DirectCast(Session("InvoiceSettingTable"), DataTable)

        Dim tmptable As DataTable = Session("InvoiceSettingTable")


        Call clsExportToExcel.ExportToExcel("", "", "", "Invoice Items", "Invoice Items",
                                             LabelCaptionInvoiceItems.Text, True, totals, 0, "", tmpfields, Nothing, tmptable, False)


    End Sub
End Class