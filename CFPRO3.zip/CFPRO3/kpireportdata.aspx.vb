﻿
Imports System.Drawing
Public Class kpireportdata
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""


            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Call LoadCFAgentUsers(CFPROID)

            Call LoadKPIData(CFPROID, CFPROUserID)
        End If
    End Sub
    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboPersonnel, sqlstr, clsData.constr, 0, 1)

        ComboPersonnel.Items.Insert(0, "")

    End Sub
    Private Sub LoadKPIData(CFPROID As String, CFPROUserID As String)

        Try


            Dim JobID As String = Request.QueryString("jobId")
            Dim ClientID As String = Request.QueryString("clientid")

            Dim sqlstr As String =
                       "SELECT JobID, DocReceivedDate," &
                        "TaxEstimatesDate," &
                        "EntryRegConfirm, TaxesPaidDate," &
                        "TreoApprovedDate, PreVerificationDate," &
                        "ClearanceRemarks, ATAClientsPremises, " &
                        "DeliveryRemarks, DownPaymentDate," &
                        "InvoicingDate,AgreedKPIDays,FullPaymentDate," &
                        "CFPROID,UserID, ID " &
                        "FROM  KPIData " &
                        "Where CFPROID = '" & CFPROID & "' " &
                        "And JobId ='" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("JobID") = JobID
                tmptable.Rows.Add(drow)
            End If

            Call clsData.NullChecker(tmptable, 0)


            TextDocReceivedDate.Text = Format(drow("DocReceivedDate"), "dd MMM yyyy")
            TextTaxEstimatesDate.Text = Format(drow("TaxEstimatesDate"), "dd MMM yyyy")
            TextEntryRegConfirm.Text = Format(drow("EntryRegConfirm"), "dd MMM yyyy")
            TextTaxesPaid.Text = Format(drow("TaxesPaidDate"), "dd MMM yyyy")
            TextTreoApprovedDate.Text = Format(drow("TreoApprovedDate"), "dd MMM yyyy")
            TextPrevericationDate.Text = Format(drow("PreVerificationDate"), "dd MMM yyyy")
            TextDownpaymentDate.Text = Format(drow("DownPaymentDate"), "dd MMM yyyy")

            TextInvoicingDate.Text = Format(drow("InvoicingDate"), "dd MMM yyyy")
            TextFullPaymentDate.Text = Format(drow("FullPaymentDate"), "dd MMM yyyy")

            TextATAClientsPremises.Text = Format(drow("ATAClientsPremises"), "dd MMM yyyy")
            TextClearanceRemarks.Text = drow("ClearanceRemarks")
            TextDeliveryRemarks.Text = drow("DeliveryRemarks")

            TextAgreedKPIDays.Text = drow("AgreedKPIDays")

            If drow("AgreedKPIDays") = 0 Then
                Call AgreedKPIDays(ClientID, CFPROID)
            End If

            Call DaysatCFS(JobID, CFPROID)

            Call CalcKPI(drow)


            If drow("UserID") = "" Then
                ComboPersonnel.Text = CFPROUserID
            Else
                ComboPersonnel.Text = drow("UserID")
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Private Sub AgreedKPIDays(ClientID, CFPROID)
        Dim sqlstr As String = _
                 "Select AgreedKPIDays, ID " & _
                 "From  Clients " & _
                 "Where ClientID = '" & ClientID & "' " & _
                 "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextAgreedKPIDays.Text = drow("AgreedKPIDays")
        End If

    End Sub

    Private Sub DaysatCFS(JobID As String, CFPROID As String)

        Dim sqlstr As String =
           "Select CFSEntryDate,DateClearedOut," &
           "DispatchDate, ID " &
           "From Jobs " &
           "Where JobID='" & JobID & "' " &
           "And CFPROID ='" & CFPROID & "' "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            TextDispatchDate.Text = Format(drow("DispatchDate"), "dd MMM yyyy")

            Dim ts As TimeSpan
            If Not CDate(drow("DateClearedOut")) = CDate("1-Jan-1800") And Not CDate(drow("CFSEntryDate")) = CDate("1-Jan-1800") Then
                ts = CDate(drow("DateClearedOut")).Subtract(drow("CFSEntryDate"))
                TextDaysatCFS.Text = ts.Days
            Else
                TextDaysatCFS.Text = -1
            End If
        End If


    End Sub
    Private Sub CalcKPI(drow As DataRow)

        Dim datemissing As Boolean
        Dim ts As TimeSpan
        If Not CDate(TextDispatchDate.Text) = CDate("1-Jan-1800") And Not CDate(drow("DocReceivedDate")) = CDate("1-Jan-1800") Then
            ts = CDate(TextDispatchDate.Text).Subtract(drow("DocReceivedDate"))
            TextClearanceDays.Text = ts.Days
        Else
            TextClearanceDays.Text = -1
            datemissing = True
        End If


        If Not CDate(drow("ATAClientsPremises")) = CDate("1-Jan-1800") And Not CDate(TextDispatchDate.Text) = CDate("1-Jan-1800") Then
            ts = CDate(drow("ATAClientsPremises")).Subtract(TextDispatchDate.Text)
            TextTransitDays.Text = ts.Days
        Else
            TextTransitDays.Text = -1
            datemissing = True
        End If


        If Not CDate(drow("ATAClientsPremises")) = CDate("1-Jan-1800") And Not CDate(drow("DocReceivedDate")) = CDate("1-Jan-1800") Then
            ts = CDate(drow("ATAClientsPremises")).Subtract(drow("DocReceivedDate"))
            TextTotalDays.Text = ts.Days
        Else
            TextTotalDays.Text = -1
            datemissing = True
        End If

        If Not datemissing Then
            TextVariance.Text = CDbl(TextAgreedKPIDays.Text) - CDbl(TextTotalDays.Text)

            If CDbl(TextVariance.Text) < 0 Then
                TextResult.Text = "FAIL"
                TextResult.ForeColor = Color.Red
            Else
                TextResult.Text = "SUCCESS"
                TextResult.ForeColor = Color.Green
            End If
        Else
            TextResult.Text = "N/A"
        End If


    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveKPIData(LabelCFPROID.Text)
    End Sub

    Private Sub SaveKPIData(CFPROID As String)

        Try


            Dim JobID As String = Request.QueryString("jobId")
            Dim ClientID As String = Request.QueryString("clientid")

            Dim sqlstr As String =
                      "SELECT JobID, DocReceivedDate," &
                       "TaxEstimatesDate," &
                       "EntryRegConfirm, TaxesPaidDate," &
                       "TreoApprovedDate, PreVerificationDate," &
                       "ClearanceRemarks, ATAClientsPremises, " &
                       "DeliveryRemarks, DownPaymentDate," &
                       "InvoicingDate,FullPaymentDate,AgreedKPIDays," &
                       "CFPROID,UserID, ID " &
                       "FROM  KPIData " &
                       "Where CFPROID = '" & CFPROID & "' " &
                       "And JobID ='" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("JobID") = JobID
                tmptable.Rows.Add(drow)
            End If

            drow("DocReceivedDate") = TextDocReceivedDate.Text
            drow("TaxEstimatesDate") = TextTaxEstimatesDate.Text
            drow("EntryRegConfirm") = TextEntryRegConfirm.Text
            drow("TaxesPaidDate") = TextTaxesPaid.Text
            drow("TreoApprovedDate") = TextTreoApprovedDate.Text
            drow("PreVerificationDate") = TextPrevericationDate.Text
            drow("DownPaymentDate") = TextDownpaymentDate.Text
            drow("InvoicingDate") = TextInvoicingDate.Text
            drow("FullPaymentDate") = TextFullPaymentDate.Text

            drow("AgreedKPIDays") = Val(TextAgreedKPIDays.Text)

            drow("ClearanceRemarks") = TextClearanceRemarks.Text
            drow("DeliveryRemarks") = TextDeliveryRemarks.Text

            drow("ATAClientsPremises") = TextATAClientsPremises.Text

            drow("UserID") = ComboPersonnel.Text

            Call AgreedKPIDays(ClientID, CFPROID)
            Call CalcKPI(drow)

            Call clsData.SaveData("KPIData", tmptable, sqlstr, False, clsData.constr)


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub


End Class