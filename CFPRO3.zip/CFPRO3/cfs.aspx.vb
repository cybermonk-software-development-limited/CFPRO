﻿Imports System.Drawing

Public Class cfs
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""


            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Call LoadCFS(CFPROID, 0, "")


        End If
    End Sub


    Private Sub LoadCFS(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not SearchStr = "" Then
            tmpstr = "And CFS  Like '%" & Trim(TextSearch.Text) & "%' "
        End If

        Dim sqlstr As String =
              "Select CFSID,CFS," &
              "TransitFreeDays," &
              "LocalFreeDays, ID " &
              "From CFS " &
              "Where CFPROID = '" & CFPROID & "' " &
              tmpstr &
              "Order By ID Desc; "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next

        Session("CFSTable") = tmptable

        GridCFS.DataSource = tmptable
        GridCFS.DataBind()

        If GridCFS.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If
            If Rowindex > GridCFS.Rows.Count - 1 Then
                Rowindex = GridCFS.Rows.Count - 1
            End If

            GridCFS.SelectedIndex = Rowindex
            Call ShowCFS(GridCFS.SelectedValue)
            Dim row As GridViewRow = GridCFS.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If


        If SearchStr = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " CFS "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " CFS Found Matching  '" & SearchStr & "' "
        End If

    End Sub



    Private Sub ShowCFS(ID As Integer)

        Dim sqlstr As String =
            "Select CFSID,CFS," &
            "TransitFreeDays,LocalFreeDays, ID " &
            "From CFS " &
            "Where ID = " & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextCFS.Text = drow("CFS")
            TextLocalFreeDays.Text = drow("LocalFreeDays")
            TextTransitFreeDays.Text = drow("TransitFreeDays")

        End If



    End Sub



    Private Sub NewCFS(CFPROID As String)
        Try

            Dim CFSID As String = GetCFSID()

            Dim sqlstr As String =
                  "Select CFSID,CFS," &
                  "CFPROID, ID " &
                  "From  CFS " &
                  "Where CFPROID = '" & CFPROID & "' " &
                  "And CFSID = '" & CFSID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim Drow As DataRow = tmptable.NewRow

            Drow("CFSID") = CFSID
            Drow("CFS") = "New CFS" & tmptable.Rows.Count
            Drow("CFPROID") = CFPROID

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("CFS", tmptable, sqlstr, False, clsData.constr)
            Call LoadCFS(CFPROID, 0, "")


            TextCFS.Focus()



        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Private Function GetCFSID() As String
        Try

            Dim tmpCFSID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From CFS " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpCFSID = drow("ID")
                tmpCFSID = tmpCFSID + 1
                tmpstr = Format(tmpCFSID, "00000000#")
            Else
                tmpstr = Format(tmpCFSID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCFS, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridCFS.SelectedIndexChanged
        Dim row As GridViewRow = GridCFS.Rows(GridCFS.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowCFS(GridCFS.SelectedValue)

        For a As Integer = 0 To GridCFS.Rows.Count - 1
            row = GridCFS.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridCFS.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNewCFS.Click
        Call NewCFS(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveCFS(GridCFS.SelectedValue)
    End Sub

    Private Sub SaveCFS(ID As Integer)
        Try


            Dim sqlstr As String =
              "Select CFSID,CFS," &
              "TransitFreeDays,LocalFreeDays, Id " &
              "From CFS " &
              "Where ID = " & ID & " "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("CFS") = Trim(TextCFS.Text)
                drow("LocalFreeDays") = Trim(TextLocalFreeDays.Text)
                drow("TransitFreeDays") = Trim(TextTransitFreeDays.Text)

                Call clsData.SaveData("CFS", tmptable, sqlstr, False, clsData.constr)

                Call LoadCFS(LabelCFPROID.Text, GridCFS.SelectedIndex, Trim(TextSearch.Text))

                clsMSDynamicsNAVint.UpdateNAVVendor(LabelCFPROID.Text, "C-", drow("CFSID"), drow("CFS"), "-", "-", "-", "KE", "", LabelMessage1.Text)

            End If




        Catch exp As Exception
            MsgBox(exp.Message, , "SaveCFS")
        End Try
    End Sub



    Private Sub DeleteCFS(ID As Integer)


        Dim sqlstr As String =
        "Select ID " &
        "From  CFS " &
        "Where ID = " & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("CFS", tmptable, sqlstr, True, clsData.constr)
        Call LoadCFS(LabelCFPROID.Text, GridCFS.SelectedIndex - 1, Trim(TextSearch.Text))
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteCFS(GridCFS.SelectedValue)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadCFS(LabelCFPROID.Text, 0, Trim(TextSearch.Text))
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadCFS(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click

        Dim Fields(3) As String
        Fields(0) = "CFSID"
        Fields(1) = "CFS"
        Fields(2) = "LocalFreeDays"
        Fields(3) = "TransitFreeDays"


        Dim tmptable As DataTable = Session("CFSTable")

        Call clsExportToExcel.ExportToExcel("", "", "", "CFS", "CFS",
                                           LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)


    End Sub


End Class