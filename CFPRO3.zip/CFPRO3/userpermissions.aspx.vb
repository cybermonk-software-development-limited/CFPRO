﻿Public Class userpermissions
    Inherits System.Web.UI.Page

    Friend Shared TableUserPermissions As New DataTable

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim UserRole As String = Request.QueryString("userrole")
            Dim UserID As String = Request.QueryString("userid")

            Dim UserName As String = Request.QueryString("cfagentuser")
            Dim AccountIPAddress As String = Request.QueryString("accountipaddress")
            Dim AccountIPLock As String = Request.QueryString("iplock")

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", "", "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID
            LabelUserID.Text = UserID
            LabelUserRole.Text = UserRole

            If AccountIPAddress = "" Then
                LabelAccountIpAddress.Text = Request.UserAgent
                LabelIPLock.Text = CBool(0).ToString
            Else
                LabelAccountIpAddress.Text = AccountIPAddress
                LabelIPLock.Text = AccountIPLock
            End If


            LabelUserName.Text = UserName & " - " & UserRole

            Call LoadUserPermissions(CFPROID, UserID, UserRole)

        End If

    End Sub



    Private Sub LoadUserPermissions(CFPROID As String, UserID As String, UserRole As String)

        Try

            Dim sqlstr As String =
                "SELECT PermissionID," &
                "Permission, AllowNormalAdmin," &
                "AllowOperator,ID " &
                "FROM Permissions " &
                "Order By SortOrder Asc;"
            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
                    "SELECT PermissionID, CFPROID," &
                    "UserID,Allow,ID " &
                    "From  UserPermissions " &
                    "Where CFPROID ='" & CFPROID & "' " &
                    "And UserID = '" & UserID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim col1 As New DataColumn("Permission")
            Dim col2 As New DataColumn("Enable")

            tmptable1.Columns.Add(col1)
            tmptable1.Columns.Add(col2)

            Dim dv1 As New DataView(tmptable1)
            Dim a As Integer

            Dim drow1 As DataRow
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                dv1.RowFilter = "PermissionID = '" & drow("PermissionID") & "' "

                If dv1.Count = 0 Then
                    drow1 = tmptable1.NewRow
                    drow1("CFPROID") = CFPROID
                    drow1("UserID") = UserID
                    drow1("PermissionID") = drow("PermissionID")
                    drow1("Permission") = drow("Permission")

                    If UserRole = "Administrator" Then
                        drow1("Allow") = drow("AllowNormalAdmin")
                        drow1("Enable") = drow("AllowNormalAdmin")
                    ElseIf UserRole = "Operator" Then
                        drow1("Allow") = drow("AllowOperator")
                        drow1("Enable") = drow("AllowOperator")
                    ElseIf UserRole = "Super Administrator" Then
                        drow1("Allow") = 1
                        drow1("Enable") = 1
                    End If

                    tmptable1.Rows.Add(drow1)
                Else
                    dv1(0)("Permission") = drow("Permission")
                    If UserRole = "Operator" Then
                        dv1(0)("Enable") = drow("AllowOperator")
                    ElseIf UserRole = "Administrator" Then
                        dv1(0)("Enable") = drow("AllowNormalAdmin")
                    ElseIf UserRole = "Super Administrator" Then
                        dv1(0)("Enable") = 1
                    End If
                End If

                a = a + 1
            Next



            DataList1.DataSource = tmptable1
            DataList1.DataBind()

            TableUserPermissions = tmptable1

            LabelCaption.Text = tmptable.Rows.Count & "  User Permissions"

            Call UserIP(CFPROID, UserID, False)

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveUserPermissions(LabelCFPROID.Text, LabelUserID.Text)
    End Sub

    Private Sub SaveUserPermissions(ByVal CFPROID As String, UserID As String)

        Try

            Dim a As Integer


            Dim chkbox As CheckBox
            Dim drow, drow1 As DataRow

            If TableUserPermissions.Rows.Count > 0 Then
                For Each dli As DataListItem In DataList1.Items
                    chkbox = DirectCast(dli.FindControl("CheckAllow"), CheckBox)
                    drow = TableUserPermissions.Rows(a)
                    drow("Allow") = chkbox.Checked
                    a = a + 1
                Next
            End If

            Dim sqlstr As String =
                  "SELECT UserID,PermissionID, " &
                  "CFPROID,Allow,ID " &
                  "From  UserPermissions " &
                  "Where CFPROID ='" & CFPROID & "' " &
                  "And UserID = '" & UserID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim dv As New DataView(tmptable)

            a = 0
            For Each drow In TableUserPermissions.Rows
                Call clsData.NullChecker(TableUserPermissions, a)
                dv.RowFilter = "PermissionID = '" & drow("PermissionID") & "' "

                If dv.Count = 0 Then
                    drow1 = tmptable.NewRow
                    drow1("UserID") = UserID
                    drow1("CFPROID") = CFPROID
                    drow1("PermissionID") = drow("PermissionID")
                    drow1("Allow") = drow("Allow")
                    tmptable.Rows.Add(drow1)
                Else
                    dv(0)("Allow") = drow("Allow")
                End If
                a = a + 1
            Next

            Call clsData.SaveData("UserPermissions", tmptable, sqlstr, False, clsData.constr)

            Call UserIP(CFPROID, UserID, True)
            Call LoadUserPermissions(CFPROID, UserID, LabelUserRole.Text)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub
    Private Sub UserIP(CFPROID As String, UserID As String, Save As Boolean)
        Try
            Dim sqlstr As String =
                "SELECT  IPAddress, LockedToIP, ID " &
                "FROM CFAgentUsers " &
                 "Where CFPROID ='" & CFPROID & "' " &
                 "And UserID = '" & UserID & "'"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                If drow("IPAddress") = "" Then
                    drow("IPAddress") = LabelAccountIpAddress.Text
                    drow("LockedToIP") = CBool(LabelIPLock.Text)
                End If

                If Not Save Then
                    TextUserIPAddress.Text = drow("IPAddress")
                    CheckLockToIP.Checked = drow("LockedToIP")
                Else
                    drow("IPAddress") = Trim(TextUserIPAddress.Text)
                    drow("LockedToIP") = CheckLockToIP.Checked
                    Call clsData.SaveData("CFAgentUsers", tmptable, sqlstr, False, clsData.constr)
                End If

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub ButtonResetUserIP_Click(sender As Object, e As EventArgs) Handles ButtonResetUserIP.Click
        TextUserIPAddress.Text = Request.UserHostAddress
    End Sub
End Class