﻿Imports System.Drawing

Public Class emailaddresses
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



        If Not IsPostBack Then



            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Dim OwnerID As String = Request.QueryString("ownerid")
            Dim OwnerType As String = Request.QueryString("ownertype")

            LabelOwnerID.Text = OwnerID
            LabelOwnerType.Text = OwnerType

            Call LoadEmailAddresses(CFPROID, OwnerID, OwnerType, "")

        End If

    End Sub

    Private Sub LoadEmailAddresses(ByVal CFPROID As String, OwnerID As String, OwnerType As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And EmailAddress Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select OwnerID, EmailAddress," &
                                      "OwnerType, CFPROID,ID " &
                                      "From  EmailAddresses " &
                                      "Where OwnerID ='" & OwnerID & "' " &
                                      "And OwnerType ='" & OwnerType & "' " &
                                      "And CFPROID ='" & CFPROID & "' " &
                                      tmpstr &
                                      "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridEmailAddresses.DataSource = tmptable
            GridEmailAddresses.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Email Addresses"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingEmailAddresses_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridEmailAddresses.SelectedIndexChanged
        Dim row As GridViewRow = GridEmailAddresses.Rows(GridEmailAddresses.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridEmailAddresses.Rows.Count - 1
            row = GridEmailAddresses.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridEmailAddresses.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingEmailAddresses_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridEmailAddresses.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridEmailAddresses, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditEmailAddress(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditEmailAddress(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridEmailAddresses.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select Email Addresses."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit EmailAddress"
                Dim ID As Integer = GridEmailAddresses.SelectedValue

                Dim sqlstr As String = "SELECT OwnerID, EmailAddress," &
                                        "OwnerType, CFPROID,ID " &
                                        "From  EmailAddresses " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("EmailAddress")
                End If

            Else
                LabelAddEdit.Text = "Add Email Address"
                TextAddEdit.Text = ""

            End If


            ModalPopupExtender2.Show()
            TextAddEdit.Focus()



        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditEmailAddress(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveEmailAddress(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, Edit)
    End Sub

    Private Sub SaveEmailAddress(CFPROID As String, OwnerID As String, OwnerType As String, Edit As Boolean)

        Dim ID As Integer = -1

        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Black


        If Not Trim(UCase(TextAddEdit.Text)).Contains("@") Then
            LabelMessage.Text = "Email Address is not Valid"
            LabelMessage.ForeColor = Color.Red
            ModalPopupExtender2.Show()
            Exit Sub
        End If

        If Not Edit Then
            If EmailAddressExists(CFPROID, OwnerID, OwnerType, TextAddEdit.Text) Then
                LabelMessage.Text = "Email Address Exists"
                LabelMessage.ForeColor = Color.Red
                ModalPopupExtender2.Show()
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridEmailAddresses.SelectedIndex >= 0 Then
                    ID = GridEmailAddresses.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT OwnerID, EmailAddress," &
                                    "OwnerType, CFPROID, ID " &
                                    "From  EmailAddresses " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("OwnerID") = OwnerID
                drow("OwnerType") = OwnerType
                tmptable.Rows.Add(drow)
            End If

            drow("EmailAddress") = Trim(LCase(TextAddEdit.Text))


            Call clsData.SaveData("EmailAddresses", tmptable, sqlstr, False, clsData.constr)

            Call LoadEmailAddresses(CFPROID, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function EmailAddressExists(CFPROID As String, OwnerID As String, OwnerType As String, EmailAddress As String) As Boolean


        Dim sqlstr As String = "OwnerID, EmailAddress," &
                                        "OwnerType, CFPROID,ID " &
                                        "From  EmailAddresses " &
                                        "Where OwnerID ='" & OwnerID & "' " &
                                        "And OwnerType ='" & OwnerType & "' " &
                                        "And CFPROID ='" & CFPROID & "' " &
                                         "And EmailAddress = " & Trim(EmailAddress) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridEmailAddresses.SelectedIndex >= 0 Then
            Call PromptDeleteEmailAddress(GridEmailAddresses.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Email Address to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteEmailAddress(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridEmailAddresses.Rows(GridEmailAddresses.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteEmailAddress(GridEmailAddresses.SelectedValue)
    End Sub
    Private Sub DeleteEmailAddress(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From EmailAddresses  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("EmailAddresses", tmptable, sqlstr, True, clsData.constr)

            Call LoadEmailAddresses(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetEmailAddressID() As String
    '    Try

    '        Dim tmpEmailAddressID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From EmailAddresses " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpEmailAddressID = drow("ID")
    '            tmpEmailAddressID = tmpEmailAddressID + 1
    '            tmpstr = Format(tmpEmailAddressID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpEmailAddressID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadEmailAddresses(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadEmailAddresses(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, "")
    End Sub



End Class