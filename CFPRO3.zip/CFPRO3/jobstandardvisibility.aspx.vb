﻿

Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Imports System.Web.UI.HtmlControls


Public Class jobstandardvisibility
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginFromDesktop(Request.QueryString("logintoken"))
            End If



            Dim CFAgentCFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFAgentCFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

            LabelCFAgentCFPROID.Text = CFAgentCFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFAgentCFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            Call LoadShippers(CFAgentCFPROID)
            Call LoadCFAgentUsers(CFAgentCFPROID)
            Call LoadVesselStatus(CFAgentCFPROID)
            Call LoadJobStatus(CFAgentCFPROID)
            Call LoadJobTypes(CFAgentCFPROID)
            Call LoadCFS(CFAgentCFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFAgentCFPROID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadJobs(Scope As String, dispatchdate As Boolean, CFAgentCFPROID As String, DoPDF As Boolean, ResetCacheTable As Boolean)
        Try
            Dim Opdate As String



            If dispatchdate Then
                Opdate = "DispatchDate"
            Else
                Opdate = "JobDate"
            End If



            Dim tmpstr As String
            Dim tmpstrdate1, tmpstrdate2 As String


            tmpstrdate1 = "'" & TextFromDate.Text & "' "
            tmpstrdate2 = "'" & TextToDate.Text & "' "




            If Not LCase(Scope) = "(all)" Then
                tmpstr = "And Jobs." & Opdate & " >= " & tmpstrdate1 & " " &
                          "And Jobs." & Opdate & " <= " & tmpstrdate2 & " "

            Else
                tmpstr = "And ID > 0 "

            End If



            'Dim tmpkeepVisible As String
            'tmpkeepVisible = " Or KeepVisible = 1 "


            'If ComboLoadedJobs.Text = "Jobs Kept Visible" Then
            '    tmpkeepVisible = ""
            'End If

            'If selectAgents Or selectClients Then
            '    tmpkeepVisible = ""
            'End If

            Select Case ComboLoadedJobs.Text
                Case "Active Jobs"
                    tmpstr = tmpstr & " And Jobs.JobStatus <> '" & "Closed" & "' "


                Case "Active + Closed Jobs"

                    tmpstr = " And Jobs.JobDate >= " & tmpstrdate1 & " " &
                         "And Jobs.JobDate <= " & tmpstrdate2 & " "

                Case "Closed Jobs"
                    tmpstr = tmpstr & " And Jobs.JobStatus = '" & "Closed" & "' "



                Case "Jobs Kept Visible"

                    tmpstr = " And  Jobs.KeepVisible = 1 "

            End Select



            Dim tmpstrClientsAgents As String = ""

            'If selectClients Then
            '    Dim tmpstrSel(), tmpclients() As String
            '    tmpstrSel = clsSubs.SelectedClients()

            '    Dim n As Integer
            '    If Not IsNothing(tmpstrSel) Then
            '        ReDim Preserve tmpclients(n)
            '        LabelVisibilityCaption.Text = "Clients: " & Join(tmpstrSel, ", ")
            '        For n = 0 To tmpstrSel.GetUpperBound(0)
            '            ReDim Preserve tmpclients(n)
            '            If n = 0 Then
            '                tmpclients(n) = "ClientID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                  " And " & tmpstr0
            '            Else
            '                tmpclients(n) = "Or ClientID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                 " And " & tmpstr0
            '            End If
            '        Next
            '        tmpstrClientsAgents = Join(tmpclients, " ")
            '        GoTo skipagent
            '    Else
            '        LabelMessage1.Text = "No Clients Selected."
            '        Exit Sub
            '    End If
            'Else
            '    tmpstrClientsAgents = tmpstr0
            'End If



            'If selectAgents Then
            '    Dim tmpstrSel(), tmpAgents() As String
            '    tmpstrSel = clsSubs.SelectedAgents()
            '    Dim n As Integer
            '    If Not IsNothing(tmpstrSel) Then
            '        ReDim Preserve tmpAgents(n)
            '        LabelVisibilityCaption.Text = "Agents: " & Join(tmpstrSel, ", ")

            '        For n = 0 To tmpstrSel.GetUpperBound(0)
            '            ReDim Preserve tmpAgents(n)
            '            If n = 0 Then
            '                tmpAgents(n) = "AgentID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                  " And " & tmpstr0
            '            Else
            '                tmpAgents(n) = "Or AgentID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                " And " & tmpstr0
            '            End If
            '        Next
            '        tmpstrClientsAgents = Join(tmpAgents, " ")
            '    Else
            '        LabelMessage1.Text = "No Agents Selected."
            '        Exit Sub
            '    End If
            'Else
            '    tmpstrClientsAgents = tmpstr0
            'End If

skipagent:

            Dim sqlstr As String =
                    "Select Top " & ComboSelectTop.Text & " " &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "CustomsSystem,BL,OrderNo,Goods," &
                    "ShipperID,ReleasePersonnel," &
                    "ReleasedTo, ReleaseDate," &
                    "DeclarationPersonnel," &
                    "ShippingPersonnel,ShipStatus," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,JobType,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested," &
                    "ManifestNo,ExtensionEndDate," &
                    "RemainingExtensionDays,StatusID,JobStatus," &
                    "UserID, ID " &
                    "From Jobs " &
                    "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                     tmpstr


            Dim tmptable As New DataTable("JobsData")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "ReturnDate, CrossBorderDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID " &
                  tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                        "Select CFS,CFSID " &
                        "From CFS " &
                        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim sqlstr4 As String =
                       "Select TOP 1 WITH TIES JobProgress.JobID," &
                       "Status, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID " &
                       tmpstr &
                      "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"


            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)



            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "


            Dim sqlstr7 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)





            Dim drow As DataRow
            Dim a, b, c As Integer


            Dim found As Boolean
            Dim tmpdate3 As Date
            Dim tmpstr3() As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
            Dim col7 As New DataColumn("ContainerReturnDays", Type.GetType("System.Int32"))
            Dim col8 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col9 As New DataColumn("ContainerNos", Type.GetType("System.String"))
            Dim col10 As New DataColumn("DaysTaken", Type.GetType("System.Double"))
            Dim col11 As New DataColumn("RemainingDays", Type.GetType("System.Double"))
            Dim col12 As New DataColumn("Quantity", Type.GetType("System.Double"))

            Dim col13 As New DataColumn("CBM", Type.GetType("System.Double"))
            Dim col14 As New DataColumn("Weight", Type.GetType("System.Double"))
            Dim col15 As New DataColumn("ProgressStatus", Type.GetType("System.String"))
            Dim col16 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col17 As New DataColumn("JobUrl", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)
            tmptable.Columns.Add(col17)

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now
            Dim ts As TimeSpan

            Dim CrossedBorder As Boolean

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Not CDate(drow("ExtensionEndDate")) = CDate("1-Jan-1800") Then
                    tmpdate3 = drow("ExtensionEndDate")
                    drow("RemainingExtensionDays") = CInt((tmpdate3.Subtract(CDate(Now)).TotalDays))
                Else
                    drow("RemainingExtensionDays") = "0"
                End If

                drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")

                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"

                c = 0
                TEU = 0
                CBM = 0
                Weight = 0




                CrossedBorder = True
                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)
                    c = c + 1
                    CBM = CBM + dv1(b)("CBM")
                    Weight = Weight + dv1(b)("Weight")
                    TEU = TEU + Val(dv1(b)("TEU"))

                    If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                        CrossedBorder = False
                    End If

                Next

                drow("CrossedBorder") = CrossedBorder


                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Quantity") = dv1.Count
                drow("TEU") = TEU
                drow("CBM") = CBM
                drow("Weight") = Weight


                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")
                End If

                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")
                    drow("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), drow("DispatchDate"))
                End If



                dv4.RowFilter = "JobId = '" & drow("JobID") & "' "
                If dv4.Count > 0 Then
                    Call clsData.NullChecker1(dv4, 0)
                    dv4.Sort = "Date DESC"
                    drow("ProgressStatus") = dv4(0)("Status")
                End If

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Client") = Mid(dv5(0)("Client"), 1, 25)
                End If


                found = False
                tmpdate = Now


                dv7.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "

                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)
                    drow("ContainerReturnDays") = clsShippingStorage.ContainerReturnDays(drow("ClientID"), drow("ShippingLineID"), drow("JobType"), dv7(0)("TransitReturnDays"), dv7(0)("LocalReturnDays"))


                    If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                        drow("RemainingDays") = 0
                    Else
                        dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "' "
                        dv1.Sort = "ReturnDate DESC"

                        If dv1.Count > 0 Then
                            drow("ReturnDate") = dv1(0)("ReturnDate")


                            Call clsData.NullChecker1(dv1, 0)
                            If CDate(drow("ReturnDate")) = CDate("1-Jan-1800") Then
                                tmpdate = Now
                            Else
                                tmpdate = drow("ReturnDate")
                            End If

                            ts = tmpdate.Subtract(CDate(drow("BerthingDate")))
                            drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)

                        End If
                    End If
                End If
                a = a + 1

            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            If tmptable.Rows.Count > 10 Then
                PanelJobs.Height = 300
            Else
                PanelJobs.Height = Nothing
            End If



            'If Not dispatchdate Then
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'Else
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " DISPATCHED Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'End If

            'If CheckSelectedAgents.Checked Then
            '    ComboAgents.Text = "(Selected Agents)"
            'ElseIf ComboAgents.Text = "(Selected Agents)" Then
            '    ComboAgents.Text = ""
            'End If

            'If CheckSelectedClients.Checked Then
            '    ComboClients.Text = "(Selected Clients)"
            'ElseIf ComboClients.Text = "(Selected Clients)" Then
            '    ComboClients.Text = ""
            'End If

            Dim dv As New DataView(tmptable)


            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort

            ' clsData.JobTable = tmptable 

            'cache table

            Session("JobTable") = tmptable

            LabelMessage1.Text = ""

            If ResetCacheTable Then
                Exit Sub
            End If

            If DoPDF Then
                Response.ClearContent()
                Response.ClearHeaders()
                Response.ContentType = "application/pdf"
                Response.AddHeader("Content-Disposition", "attachment; filename=Job Visibility Report - " & Format(Now, "dd MMM yyyy hh:mm:ss tt") & ".pdf")
                ' Response.Cache.SetCacheability(HttpCacheability.NoCache)
                Response.Buffer = True

                Response.BinaryWrite(clsJobPDF.JobsPDFReport(CFAgentCFPROID, tmptable, LabelReportCaption.Text, LabelFilterStr.Text, LabelSortStr.Text, LabelMessage1.Text))

                Response.End()
                Response.Flush()
                Response.Clear()
                Response.Close()
            Else
                GridJobs.DataSource = dv
                GridJobs.DataBind()

                Call Calctotal(dv, "")

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Private Sub LoadShippers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopComboWithValue(ComboCFAgentUsers, sqlstr, clsData.constr, 0, 1)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatus(CFAgentCFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus "
        ComboJobStatus.Items.Clear()
        Call clsData.PopCombo(ComboJobStatus, sqlstr, clsData.constr, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select Status " &
         "From JobStatuses "

        Call clsData.PopCombo(ComboJobStatus, sqlstr1, clsData.constr, 0)
        ComboJobStatus.Items.Insert(0, "(All)")
    End Sub


    Private Sub LoadJobTypes(CFAgentCFPROID As String)
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes " &
         "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "


        Call clsData.PopCombo(ComboJobType, sqlstr, clsData.constr, 0)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()
        'Dim a As Integer = GridJobs.SelectedValue.ToString
        'Dim selected As Boolean
        'If a >= 0 Then
        '    selected = GridJobs.SelectedIndex
        'End If

        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)


        '  GridJobs.SelectedIndex = a

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFAgentCFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day


            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFAgentCFPROID, False, False)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")

            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = dv.Count & " Jobs: " & tmpstr

                Else
                    LabelReportCaption.Text = dv.Count & " DISPATCHED JOBS: " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelReportCaption.Text = dv.Count & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFAgentCFPROID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer

            Dim CFAgentCFPROID As String = LabelCFAgentCFPROID.Text

            'If Not clsData.TableCacheOK(CFAgentCFPROID, clsData.JobTable) Then
            '    Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            'End If

            If IsNothing(Session("JobTable")) Then
                Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            End If

            Dim JobTable As DataTable = Session("JobTable")
            Dim dv As DataView = New DataView(JobTable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                b = b + 1
                tmpstr1(a) = "Agent : " & TextAgent.Text
            End If


            If Client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If Shipper Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                b = b + 1
            End If

            If ShipStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                b = b + 1
            End If

            If JobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobType Like '" & ComboJobType.Text & "%' "
                Else
                    tmpstr(a) = " And JobType Like '" & ComboJobType.Text & "%' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.Text
                b = b + 1
            End If

            If JobStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                b = b + 1
            End If


            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If

            'If EntensionRequested Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
            '    Else
            '        tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
            '    End If

            '    tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
            '    b = b + 1
            'End If

            If OmitDispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Dispatched" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Dispatched" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                b = b + 1
            End If


            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If

            If CustomsSystem Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                b = b + 1
            End If



            If CFAgentUser Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)

                If b = 0 Then

                    tmpstr(a) = "UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                Else
                    tmpstr(a) = " And UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                b = b + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridJobs.DataSource = dv
            GridJobs.DataBind()


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub


    Private Sub ComboLoadedJobs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboLoadedJobs.SelectedIndexChanged
        Static x As Boolean
        If x Then
            Call RefreshData()
        End If
        x = True
    End Sub



    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobId"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "VesselETA"
        Else
            Return "JobDate"
        End If
    End Function

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00015") Then
            Call ExportToExcel()
        Else
            LabelJobMessage.Text = "User Not Allowed"
            LabelJobMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckFilterAgent.Checked, CheckFilterClient.Checked, CheckFilterConsignee.Checked, CheckFilterShipper.Checked,
                            CheckShipStatus.Checked, CheckFilterJobType.Checked, CheckJobStatus.Checked, CheckFilterCFS.Checked,
                            CheckOmitDispatched.Checked, CheckOmitCrossedBorder.Checked, CheckFilterCustomsSystem.Checked, CheckCFAgentUser.Checked)
    End Sub

    Protected Sub ButtonProgressReports_Click(sender As Object, e As EventArgs) Handles ButtonProgressReports.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            If Not IsNothing(GridJobs.SelectedValue.ToString) Then
                Response.Redirect("jobprogressreport.aspx?loadedbyimporter=0&jobid=" & GridJobs.SelectedValue.ToString())
            End If
        End If

    End Sub
    Private Sub LoadPage(page As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = page
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonProgressUpdates_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
        Try
            If GridJobs.SelectedValue Is Nothing Then
                LabelJobMessage.Text = "Please select an item"
            Else
                If GridJobs.SelectedIndex >= 0 Then

                End If

                Dim row As GridViewRow = GridJobs.SelectedRow

                Call LoadPage("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString & "&CFAgentCFPROID=" &
                              LabelCFAgentCFPROID.Text & "&referenceno=" & row.Cells(0).Text & "&jobdate=" &
                               row.Cells(1).Text & "&client=" &
                               row.Cells(2).Text, "Progress Update", 545, 780)
            End If
        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try
    End Sub




    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignOut(LinkSignIn.Text, LabelUser.Text, Image1.ImageUrl, True)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call nSortOrder()
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("JobTable")) Then
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, True)
        End If

        Dim JobTable As DataTable = Session("JobTable")
        Dim dv As DataView = New DataView(JobTable)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or ContainerNos Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "

        GridJobs.DataSource = dv
        GridJobs.DataBind()

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsSubs.SearchClient(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsSubs.SearchAgent(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsSubs.SearchImporter(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub




    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)

        Dim CFAgentCFPROID As String = LabelCFAgentCFPROID.Text


        If dv Is Nothing Then

            If IsNothing(Session("JobTable")) Then
                Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            End If

            Dim JobTable As DataTable = Session("JobTable")
            dv = New DataView(JobTable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA " & tmpstrSort
        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridJobs.DataSource = dv
            GridJobs.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub

    Protected Sub ButtonPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonPDFReport.Click
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, True, False)
        ' Call PDFReport("Job Visibility Report " & Format(Now, "dd MMM yyyy"))
    End Sub


    Private Sub PDFReport(FileName As String)

        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"
        Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Buffer = True

        If IsNothing(Session("JobTable")) Then
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, True)
        End If

        Dim JobTable As DataTable = Session("JobTable")
        Dim dv As DataView = New DataView(JobTable)

        Response.BinaryWrite(clsJobPDF.JobsPDFReport(LabelCFAgentCFPROID.Text, JobTable, LabelReportCaption.Text, LabelFilterStr.Text, LabelSortStr.Text, LabelMessage1.Text))

        Response.End()
        Response.Flush()
        Response.Clear()
        Response.Close()

    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckFilterJobType.Checked = True
    End Sub


    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckFilterCFS.Checked = True
    End Sub

    Protected Sub ComboCustomsSystem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCustomsSystem.SelectedIndexChanged
        CheckFilterCustomsSystem.Checked = True
    End Sub

    Protected Sub ComboShippers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboShippers.SelectedIndexChanged
        CheckFilterShipper.Checked = True
    End Sub


    Protected Sub ComboCFAgentUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgentUsers.SelectedIndexChanged
        CheckCFAgentUser.Checked = True
    End Sub

    Protected Sub ComboVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVesselStatus.SelectedIndexChanged
        CheckShipStatus.Checked = True
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckFilterClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckFilterAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub

    Private Sub ExportToExcel()

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = GridJobs.Columns.Count
        Dim totalRows = GridJobs.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = GridJobs.Columns(col1 - 2).HeaderText
        Next

        workSheet.Cells("B3:N3").Merge = True
        workSheet.Cells("B4:N4").Merge = True

        workSheet.Cells("B3:N3").Style.Font.Size = 14
        workSheet.Cells("B4:N4").Style.Font.Size = 9
        workSheet.Cells("B3:N4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = "Job Visibility Report - Standard : " & LabelCFAgent.Text
        workSheet.Cells(4, 2).Value = LabelReportCaption.Text

        Dim row1 As GridViewRow
        Dim row As Integer
        Dim RefNoLink As HyperLink
        ' xlWorkSheet.Cells(i + 1, j + 1) = name.Text
        For row = 5 To totalRows + 4
            row1 = GridJobs.Rows(row - 5)
            For col1 As Integer = 1 To totalCols

                If col1 = 1 Then
                    RefNoLink = DirectCast(GridJobs.Rows(row - 5).Cells(col1 - 1).FindControl("HyperLink1"), HyperLink)
                    workSheet.Cells(row + 1, col1 + 1).Value = RefNoLink.Text
                Else
                    workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1 - 1).Text
                End If

                If row1.Cells(col1 - 1).Text = "&nbsp;" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next
        Next

        Using rng As ExcelRange = workSheet.Cells("B5:N" & GridJobs.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:N5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":N" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        workSheet.Cells("C" & row & ":D" & row).Merge = True
        workSheet.Cells("E" & row & ":F" & row).Merge = True
        workSheet.Cells("G" & row & ":H" & row).Merge = True
        workSheet.Cells("I" & row & ":J" & row).Merge = True

        workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        workSheet.Cells("I" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Jobs Visibility Report " & Format(Now, "dd MMM yyyy hh:Nm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub


End Class

