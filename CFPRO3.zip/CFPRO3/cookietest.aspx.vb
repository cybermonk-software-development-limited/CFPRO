﻿Public Class cookietest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim redirect As String = Request.QueryString("redirect")
        Dim acceptsCookies As String
        ' Was the cookie accepted?
        If Request.Cookies("testcookie") Is Nothing Then
            ' No cookie, so it must not have been accepted
            acceptsCookies = 0
        Else
            acceptsCookies = 1
            ' Delete test cookie
            Response.Cookies("testcookie").Expires = DateTime.Now.AddDays(-1)
        End If
        Response.Redirect(redirect & "?cookietest=" & acceptsCookies)
    End Sub

End Class