﻿Imports System.IO

Public Class clsDetailedVisibilityReport


    Shared Function LoadJobs(CFPROID As String, Scope As String, DispatchDate As Boolean,
                        FromDate As String, ToDate As String, LoadedJobs As String,
                        MaxRecords As String, SortOrder As String, SortOrderIndex As Integer,
                        StorageStartDate As Boolean, CFPROUserID As String, Optional ByRef ErrMSg As String = Nothing) As DataView
        Try
            Dim Opdate As String


            If DispatchDate Then
                Opdate = "DispatchDate"
            Else
                Opdate = "JobDate"
            End If



            Dim tmpstr As String = ""
            Dim tmpstrA As String = ""

            If Not Scope = "(All)" Then
                tmpstr = " And Jobs." & Opdate & " >= '" & FromDate & "' " &
                          " And Jobs." & Opdate & " <= '" & ToDate & "' "

            Else
                tmpstr = " And ID > 0 "

            End If



            Select Case LoadedJobs

                Case "Open + Jobs Kept Visible"

                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "
                    tmpstrA = " And Jobs.CFPROID = '" & CFPROID & "'  And Jobs.KeepVisible = 1  "

                Case "Open Jobs"
                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "

                Case "All Jobs"
                    tmpstr = tmpstr

                Case "Closed Jobs"
                    tmpstr = tmpstr &
                                " And Jobs.JobStatus Like '%Closed%' "


                    'tmpstrC =
                    '   "And (Jobs.JobStatus Like '%Closed%'  " &
                    '   "Or JobProgress.KPIProgressID = '000026') " &
                    '   "And JobProgress.JobID = Jobs.JobID " &
                    '   "And JobProgress.CFPROID = '" & CFPROID & "' " &
                    '   "And JobProgress.Date  >= '" & TextFromDate.Text & "' " &
                    '   "And JobProgress.Date <= '" & TextToDate.Text & "' "

                Case "Jobs Kept Visible Only"
                    tmpstr = " And Jobs.KeepVisible = 1  "

            End Select

            Dim tmpstr1 As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr1 = "And UserID = '" & CFPROUserID & "' "
            End If


            Dim sqlstr As String =
                    "Select Top " & MaxRecords & " " &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "CustomsSystem,BL,HouseBL," &
                    "OrderNo, Goods, Destination," &
                    "ShipperID,ReleasePersonnel," &
                    "ReleasedTo, ReleaseDate,TypeofEntry," &
                    "EntryRegistrationDate,EntryPassDate, EntryNo," &
                    "DeclarationPersonnel,ShippingPersonnel,ShipStatus," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,JobTypeID,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested," &
                    "ManifestNo,ExtensionEndDate," &
                    "RemainingExtensionDays,StatusID,JobStatus," &
                    "DocumentStatus,DocumentsLodgeDate,PortCharges," &
                    "PortChargesStatus,PortChargesPaidDate," &
                    "ReleaseOrderStatus,ReleaseOrderDate," &
                    "PortChargesCurrency,LoadingStatus,LoadingDate," &
                    "PickupOrderStatus,PickUpOrderDate," &
                    "PortStartDate,PortEndDate," &
                    "PortExpenses,PortStaff," &
                    "PortInvoiceNo,WareHouseRent, " &
                    "ShipStatus,ManifestNo,DeliveryOrderStatus," &
                    "DeliveryOrderCharges,DeliveryOrderDate,HandoverFees," &
                    "ContainerDeposit, ContainerDepositDate, " &
                    "ContainerRefundRequestDate,ContainerDepositRefund," &
                    "ContainerDepositRefundDate,ContainerDepositDeductions, " &
                    "ContainerDepositRemarks,ShippingPersonnel," &
                    "ShippingExpenses,ShippingStart,ShippingEnd, " &
                    "ModeofTransport,UserID,WeightUnit, ID " &
                    "From Jobs " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim sqlstrA As String

            sqlstrA = sqlstr & tmpstr & " " & tmpstr1
            Dim tmptable As New DataTable("DetailedVisibilityTable")
            Call clsData.TableData(sqlstrA, tmptable, clsData.constr)


            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrA = sqlstr & tmpstrA & " " & tmpstr1

                Dim tmptableA As New DataTable("DetailedVisibilityTable1")
                Call clsData.TableData(sqlstrA, tmptableA, clsData.constr)
                tmptable.Merge(tmptableA)
            End If

            Dim sqlstrB As String
            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,Payload,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate,CrossBorderDate, " &
                  "ReturnDate,JobCargo.TransporterID,VehicleNo, " &
                  "ContainerStatusRemarks,DestinationArrivalDate," &
                  "DestinationDepot,JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID "

            sqlstrB = sqlstr1 & tmpstr
            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstrB, tmptable1, clsData.constr)


            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrB = sqlstr1 & tmpstrA

                Dim tmptable1A As New DataTable()
                Call clsData.TableData(sqlstrB, tmptable1A, clsData.constr)
                tmptable1.Merge(tmptable1A)
            End If

            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                        "Select CFS, CFSID " &
                        "From CFS " &
                        "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate, VoyageNo  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)

            Dim sqlstrC As String
            Dim sqlstr4 As String =
                       "Select JobProgress.JobID," &
                       "Status, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                       "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID "


            sqlstrC = sqlstr4 & tmpstr & "Order By JobProgress.Date DESC "
            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstrC, tmptable4, clsData.constr)

            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrC = sqlstr4 & tmpstrA & "Order By JobProgress.Date DESC "

                Dim tmptable4A As New DataTable()
                Call clsData.TableData(sqlstrC, tmptable4A, clsData.constr)
                tmptable4.Merge(tmptable4A)
            End If

            Dim dv4 As New DataView(tmptable4)



            Dim sqlstr5 As String =
                    "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)



            Dim sqlstr5a As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' " &
                    "And IsAgent = 1 "

            Dim tmptable5a As New DataTable()
            Call clsData.TableData(sqlstr5a, tmptable5a, clsData.constr)
            Dim dv5a As New DataView(tmptable5a)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim sqlstr7 As String =
                 "Select ShipperID, Shipper " &
                 "From Shippers " &
                 "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)


            Dim sqlstr8 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable8 As New DataTable()
            Call clsData.TableData(sqlstr8, tmptable8, clsData.constr)
            Dim dv8 As New DataView(tmptable8)

            Dim sqlstr9 As String =
           "Select UserID,UserNames " &
           "From CFAgentUsers " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable9 As New DataTable()
            Call clsData.TableData(sqlstr9, tmptable9, clsData.constr)
            Dim dv9 As New DataView(tmptable9)

            Dim sqlstr10 As String =
            "Select TransporterID,Transporter " &
            "From Transporters " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable10 As New DataTable()
            Call clsData.TableData(sqlstr10, tmptable10, clsData.constr)
            Dim dv10 As New DataView(tmptable10)

            Dim sqlstr11 As String =
            "Select JobTypeID,JobType " &
            "From JobTypes " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable11 As New DataTable()
            Call clsData.TableData(sqlstr11, tmptable11, clsData.constr)
            Dim dv11 As New DataView(tmptable11)



            Dim sqlstr12 As String =
                        "SELECT  KPIItemID, Jobs.JobID " &
                        "FROM  KPIProgressUpdates,Jobs " &
                        "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                        "And Jobs.CFPROID = '" & CFPROID & "' " &
                        "And KPIProgressUpdates.JobID = Jobs.JobID " &
                        "And KPIItemID = '000026' " &
                        tmpstr

            Dim tmptable12 As New DataTable()
            Call clsData.TableData(sqlstr12, tmptable12, clsData.constr)
            Dim dv12 As New DataView(tmptable12)

            Dim tmptablejobs As New DataTable


            Call CreateJobTableColumns(tmptablejobs)


            Dim portexitdate, crossborderdate, eta, lastsling, destinationdepot As String


            Dim cfs, vessel, voyageno, client, agent, importer, shipper,
                shippingline, jobpersonnel, transporter, jobtype, weightunit As String

            Dim vesseleta, berthingdate, exitdate As Date

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now


            Dim drow, drow1 As DataRow

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            Dim nAllarrived As Boolean
            Dim nLatestCrossBorderDate, nLatestArrivalDate As Date
            Dim tmpstrsoc As String = ""
            Dim tmpstrtin As String = ""
            Dim nCFSStorage As String = ""

            Dim a, b, c, d, e As Integer

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                dv1.RowFilter = "JobID = '" & drow("JobID") & "' "
                dv4.RowFilter = "JobID = '" & drow("JobID") & "' "



                nAllarrived = AllArrived(dv1)

                nLatestCrossBorderDate = CDate("1-Jan-1800")
                nLatestArrivalDate = CDate("1-Jan-1800")

                nLatestCrossBorderDate = LatestCrossBorderDate(dv1)
                nLatestArrivalDate = LatestArrivalDate(dv1)

                cfs = ""
                vessel = ""
                vesseleta = CDate("1-Jan-1800")
                berthingdate = CDate("1-Jan-1800")
                exitdate = CDate("1-Jan-1800")
                voyageno = ""
                client = ""
                agent = ""
                importer = ""
                shipper = ""
                shippingline = ""
                voyageno = ""
                tmpstrsoc = ""
                tmpstrtin = ""
                jobpersonnel = ""
                jobtype = ""
                weightunit = ""

                If drow("WeightUnit") = "" Then
                    weightunit = "Kg"
                Else
                    weightunit = drow("WeightUnit")
                End If


                If drow("SOC") Then
                    tmpstrsoc = "SOC"
                Else
                    tmpstrsoc = ""
                End If


                d = c

                'row1

                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)

                drow1("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                drow1("Marker") = "Header"
                drow1("NoBreakRow") = 1

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "
                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "
                dv5a.RowFilter = "ClientID = '" & drow("AgentID") & "' "
                dv6.RowFilter = "ImporterID = '" & drow("ImporterID") & "' "
                dv7.RowFilter = "ShipperID = '" & drow("ShipperID") & "' "
                dv8.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "
                dv9.RowFilter = "UserID = '" & drow("UserID") & "' "
                dv11.RowFilter = "JobTypeID = '" & drow("JobTypeID") & "' "
                dv12.RowFilter = "JobID = '" & drow("JobID") & "' "

                TEU = 0
                CBM = 0
                Weight = 0


                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)
                    CBM = CBM + dv1(b)("CBM")
                    Weight = Weight + dv1(b)("Weight")
                    TEU = TEU + Val(dv1(b)("TEU"))
                Next




                drow1("Weight") = Weight
                drow1("CBM") = CBM
                drow1("TEU") = TEU
                drow1("Quantity") = dv1.Count



                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    cfs = dv2(0)("CFS")
                End If

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)
                    vessel = dv3(0)("Vessel")
                    vesseleta = dv3(0)("ETA")
                    berthingdate = dv3(0)("BerthingDate")
                    exitdate = dv3(0)("ExitDate")
                    voyageno = dv3(0)("VoyageNo")
                End If


                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    client = dv5(0)("Client")
                End If

                If dv5a.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    agent = dv5a(0)("Client")
                End If

                If dv6.Count > 0 Then
                    Call clsData.NullChecker1(dv6, 0)
                    importer = dv6(0)("Importer")
                End If


                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)
                    shipper = dv7(0)("Shipper")
                End If

                If dv8.Count > 0 Then
                    Call clsData.NullChecker1(dv8, 0)
                    shippingline = dv8(0)("ShippingLine")
                End If

                If dv9.Count > 0 Then
                    Call clsData.NullChecker1(dv9, 0)
                    jobpersonnel = dv9(0)("UserNames")
                End If

                If dv11.Count > 0 Then
                    Call clsData.NullChecker1(dv11, 0)
                    jobtype = dv11(0)("jobtype")
                End If



                drow1("References") = drow("ReferenceNo")
                drow1("Shipping") = shippingline
                drow1("ClientConsigneeShipper") = Mid(client, 1, 25)
                drow1("Transportation") = Format(Weight, "#,##0.#0") & weightunit & " : " & Format(CBM, "#,##0.#0") & "CbM"
                drow1("Entry") = "Type: " & drow("TypeofEntry")


                If CDate(drow("DeliveryOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DeliveryOrderStatus")
                Else
                    drow1("Customs") = "D.O:" & Format(drow("DeliveryOrderDate"), "dd MMM yyyy")
                End If

                If CDate(drow("PortChargesPaidDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("PortChargesStatus")
                Else
                    drow1("Port") = "Chgs:" & Format(drow("PortChargesPaidDate"), "dd MMM yyyy")
                End If



                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("Marker") = "Header"
                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")
                drow1("NoBreakRow") = 1

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")

                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("TIN") = tmpstrtin


                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = FileClosed(dv12)
                drow1("Goods") = drow("Goods")



                If AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1
                e = a


                'row2
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1


                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = drow("ReferenceNo1")
                drow1("ClientConsigneeShipper") = importer

                drow1("Transportation") = drow("ModeofTransport")

                If Not Trim(voyageno) = "" Then
                    voyageno = " / VOY:" & voyageno
                End If

                drow1("Shipping") = vessel & voyageno

                If Not CDate(drow("EntryRegistrationDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Lodg:" & Format(drow("EntryRegistrationDate"), "dd MMM yyyy")
                End If

                If CDate(drow("DocumentsLodgeDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DocumentStatus")
                Else
                    drow1("Customs") = "L.R:" & Format(drow("DocumentsLodgeDate"), "dd MMM yyyy")
                End If

                If CDate(drow("LoadingDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("LoadingStatus")
                Else
                    drow1("Port") = "Load:" & Format(drow("LoadingDate"), "dd MMM yyyy")
                End If

                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = FileClosed(dv12)
                drow1("Goods") = drow("Destination")

                If AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                'row3
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1
                'drow1("Id") = c

                drow1("JobID") = drow("JobID")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = "MBL: " & drow("BL") & " HBL: " & drow("HouseBL")
                drow1("ClientConsigneeShipper") = shipper
                drow1("Transportation") = drow("Destination")

                If Not CDate(vesseleta) = CDate("1-Jan-1800") Then
                    eta = "ETA:" & Format(vesseleta, "dd MMM yyyy")
                Else
                    eta = ""
                End If

                If Not CDate(exitdate) = CDate("1-Jan-1800") Then
                    lastsling = " / LS:" & Format(exitdate, "dd MMM yyyy")
                Else
                    lastsling = ""
                End If

                drow1("Shipping") = eta & lastsling

                If Not CDate(drow("EntryPassDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Pass:" & Format(drow("EntryPassDate"), "dd MMM yyyy")
                End If

                If CDate(drow("ReleaseOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = cfs & " " & drow("ReleaseOrderStatus")
                Else
                    drow1("Customs") = cfs & " R.O: " & Format(drow("ReleaseOrderDate"), "dd MMM yyyy")
                End If

                If CDate(drow("PickUpOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = "Pick: " & drow("PickupOrderStatus")
                Else
                    drow1("Port") = "Pick: " & Format(drow("PickUpOrderDate"), "dd MMM yyyy")
                End If

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")

                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = FileClosed(dv12)
                drow1("Goods") = drow("ModeofTransport")

                If AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1


                If StorageStartDate Then
                    nCFSStorage = CFSStorage(CFPROID, drow("ClientID"), drow("CFSID"), jobtype, drow("LastSlingDAte"))
                End If


                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)

                    If b <= 2 Then
                        drow1 = tmptablejobs.Rows(d + b)
                    Else
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1

                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("JobDate") = drow("JobDate")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = jobtype
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")

                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")


                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")
                        drow1("FileClosed") = FileClosed(dv12)

                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If



                    drow1("Cargo") = dv1(b)("ContainerNo") & " " & dv1(b)("Payload") & " " & Format(dv1(b)("Weight"), "#,##0.00") & weightunit & " " & tmpstrsoc & " " & nCFSStorage

                    If Trim(dv1(b)("ContainerStatusRemarks")) = "" Then
                        drow1("CargoStatus") = dv1(b)("ContainerStatus")
                    Else
                        drow1("CargoStatus") = dv1(b)("ContainerStatusRemarks")
                    End If


                    If Not CDate(dv1(b)("PortExitDate")) = CDate("1-Jan-1800") Then
                        portexitdate = Format(dv1(b)("PortExitDate"), "dd MMM yyyy")
                    Else
                        portexitdate = ""
                    End If

                    If Not CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                        crossborderdate = Format(dv1(b)("CrossBorderDate"), "dd MMM yyyy")
                    Else
                        crossborderdate = ""
                    End If

                    If Not dv1(b)("DestinationDepot") = "" Then
                        destinationdepot = " | " & dv1(b)("DestinationDepot")
                    Else
                        destinationdepot = ""
                    End If

                    If InStr(jobtype, "Local", CompareMethod.Text) <> 0 Then
                        drow1("Checkpoints") = "MSA:" & portexitdate & destinationdepot
                    Else
                        drow1("Checkpoints") = "MSA:" & portexitdate & " | MLB:" & crossborderdate & destinationdepot
                    End If

                    transporter = ""
                    dv10.RowFilter = "TransporterID = '" & dv1(b)("TransporterID") & "' "

                    If dv10.Count > 0 Then
                        transporter = dv10(0)("Transporter")
                    End If

                    If Not Trim(transporter) = "" Then
                        transporter = " \ " & transporter
                    Else
                        transporter = ""
                    End If

                    drow1("Transporter") = dv1(b)("VehicleNo") & transporter

                    If AllCrossedBorder(dv1, drow("JobID")) Then
                        drow1("CrossBorderDate") = nLatestCrossBorderDate
                        drow1("CrossedBorder") = CBool(1)
                    Else
                        drow1("CrossBorderDate") = CDate("1-Jan-1800")
                        drow1("CrossedBorder") = CBool(0)
                    End If

                    If nAllarrived Then
                        drow1("DestinationArrivalDate") = nLatestArrivalDate
                        drow1("Arrived") = CBool(1)
                    Else
                        drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                        drow1("Arrived") = CBool(0)
                    End If

                Next


                For b = 0 To dv4.Count - 1
                    Call clsData.NullChecker1(dv4, b)
                    If b <= 2 Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b <= (dv1.Count - 1) Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b > (dv1.Count - 4) Then
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1
                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = jobtype
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")
                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")

                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")
                        drow1("FileClosed") = FileClosed(dv12)

                        If AllCrossedBorder(dv1, drow("JobID")) Then
                            drow1("CrossBorderDate") = nLatestCrossBorderDate
                            drow1("CrossedBorder") = CBool(1)
                        Else
                            drow1("CrossBorderDate") = CDate("1-Jan-1800")
                            drow1("CrossedBorder") = CBool(0)
                        End If

                        If nAllarrived Then
                            drow1("DestinationArrivalDate") = nLatestArrivalDate
                            drow1("Arrived") = CBool(1)
                        Else
                            drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                            drow1("Arrived") = CBool(0)
                        End If



                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If

                    drow1("JobDate") = drow("JobDate")
                    drow1("Status") = Format(dv4(b)("Date"), "dd MMM yyyy") & " - " & dv4(b)("Status")
                    'drow1("Highlight") = dv4(b)("Highlight")

                Next

                'row 4
                drow1 = tmptablejobs.NewRow
                drow1("Marker") = "Break"
                drow1("NoBreakRow") = 0

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = jobtype
                drow1("JobDate") = drow("JobDate")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")

                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")


                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = FileClosed(dv12)
                'drow1("SCT") = SCT(drow("CustomsSystem"))


                If AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                tmptablejobs.Rows.Add(drow1)
                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                a = a + 1

            Next

            Dim dv As New DataView(tmptablejobs)


            Dim tmpstrSort As String


            If SortOrder = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder(SortOrderIndex)
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If

            HttpContext.Current.Session("JobTableDetailed") = tmptablejobs

            Return dv


        Catch exp As Exception
            ErrMSg = exp.Message & exp.StackTrace
        End Try
    End Function

    Shared Function FileClosed(ByRef dv As DataView) As Boolean
        If dv.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function

    Shared Function AllCrossedBorder(ByRef dv As DataView, JobID As String) As Boolean
        Dim a As Integer
        Dim all As Boolean = True
        dv.RowFilter = "JobID = '" & JobID & "' "

        For a = 0 To dv.Count - 1
            Call clsData.NullChecker1(dv, a)
            If CDate(dv(a)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                all = False
            End If
        Next
        Return all

    End Function

    Shared Function AllArrived(ByRef dv As DataView) As Boolean
        Dim a As Integer
        Dim all As Boolean = True
        For a = 0 To dv.Count - 1
            Call clsData.NullChecker1(dv, a)
            If CDate(dv(a)("DestinationArrivalDate")) = CDate("1-Jan-1800") Then
                all = False
            End If
        Next
        Return all
    End Function

    Shared Function LatestCrossBorderDate(ByRef dv As DataView) As String
        Dim tmpstr As String
        If dv.Count > 0 Then
            dv.Sort = "CrossBorderDate DESC"
            tmpstr = dv(0)("CrossBorderDate")
            dv.Sort = Nothing
            Return tmpstr
        Else
            Return "1-Jan-1800"
        End If
    End Function

    Shared Function LatestArrivalDate(ByRef dv As DataView) As String
        Dim tmpstr As String
        If dv.Count > 0 Then
            dv.Sort = "DestinationArrivalDate DESC"
            tmpstr = dv(0)("DestinationArrivalDate")
            dv.Sort = Nothing
            Return tmpstr
        Else
            Return "1-Jan-1800"
        End If

    End Function

    Shared Function SCT(ByVal CustomsSystem As String) As String
        Select Case CustomsSystem
            Case "KRA Simba System"
                Return ""
            Case "ASSYCUDA Uganda"
                Return "SCT-U"
            Case "ASSYCUDA Rwanda"
                Return "SCT-R"
            Case ""
                Return ""
        End Select
        Return ""
    End Function



    Shared Function CFSStorage(CFPROID As String, ClientID As String, CFSID As String, JobType As String, LastSlingDate As Date) As String
        Dim FreeDays As Integer
        Dim nClientFreeStorageDays(1) As Integer
        Dim drow As DataRow

        Dim tmptable As New DataTable
        Dim sqlstr As String =
             "Select CFSID, CFS, " &
             "LocalFreeDays, TransitFreeDays,ID " &
             "From CFS " &
             "Where CFPROID = '" & CFPROID & "' "

        If IsNothing(HttpContext.Current.Session("tableCFSStorage")) Then
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            HttpContext.Current.Session("tableCFSStorage") = tmptable
        Else
            tmptable = HttpContext.Current.Session("tableCFSStorage")
        End If


        For Each drow In tmptable.Rows

            If CFSID = drow("CFSID") Then

                nClientFreeStorageDays = clsStorageDemmurage.GetClientFreeStorageDays(CFPROID, ClientID, drow("CFSID"))

                If InStr(JobType, "transit", CompareMethod.Text) > 0 Then
                    If drow("TransitFreeDays") < nClientFreeStorageDays(1) Then
                        FreeDays = nClientFreeStorageDays(1)
                    Else
                        FreeDays = drow("TransitFreeDays")
                    End If
                Else
                    If drow("LocalFreeDays") < nClientFreeStorageDays(0) Then
                        FreeDays = nClientFreeStorageDays(0)
                    Else
                        FreeDays = drow("LocalFreeDays")
                    End If

                End If

                Exit For
            End If
        Next

        If Not CDate(LastSlingDate) = CDate("1-Jan-1800") Then
            Dim tmpdate As Date = LastSlingDate.AddDays(Val(FreeDays))
            Return "Stch: " & Format(tmpdate, "dd MMM yyyy")
        Else
            Return "--"
        End If

    End Function

    Shared Sub CreateJobTableColumns(ByRef tmptablejobs As DataTable)
        Dim col As New DataColumn("JobID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col)

        Dim col1 As New DataColumn("References", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col1)

        Dim col3 As New DataColumn("ClientConsigneeShipper", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col3)


        Dim col4 As New DataColumn("Transportation", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col4)

        Dim col5 As New DataColumn("Shipping", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col5)

        Dim col6 As New DataColumn("Entry", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col6)

        Dim col7 As New DataColumn("Customs", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col7)

        Dim col8 As New DataColumn("Port", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col8)


        Dim col9 As New DataColumn("Goods", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col9)


        Dim col9a As New DataColumn("Cargo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col9a)

        Dim col9b As New DataColumn("CargoStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col9b)


        Dim col10 As New DataColumn("Transporter", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col10)

        Dim col11 As New DataColumn("Checkpoints", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col11)

        Dim col12 As New DataColumn("Status", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col12)

        Dim col13 As New DataColumn("TIN", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col13)

        Dim col13a As New DataColumn("SCT", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col13a)

        Dim colm As New DataColumn("Marker", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(colm)

        Dim col14 As New DataColumn("Agent", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14)

        Dim col14a As New DataColumn("AgentID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14a)

        Dim col14b As New DataColumn("Client", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14b)

        Dim col14c As New DataColumn("ClientID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14c)

        Dim col15 As New DataColumn("Importer", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col15)

        Dim col15b As New DataColumn("ImporterID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col15b)

        Dim col16 As New DataColumn("Shipper", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col16)

        Dim col16b As New DataColumn("ShipperID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col16b)

        Dim col17 As New DataColumn("Weight", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col17)

        Dim col18 As New DataColumn("CBM", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col18)

        Dim col19 As New DataColumn("CFS", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col19)

        Dim col19a As New DataColumn("CFSID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col19a)

        Dim col20 As New DataColumn("JobType", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col20)

        Dim col21 As New DataColumn("JobStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col21)

        Dim col22 As New DataColumn("ShipStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col22)

        Dim col23 As New DataColumn("JobPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col23)

        Dim col24 As New DataColumn("ShippingPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col24)

        Dim col25 As New DataColumn("DeclarationPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col25)

        Dim col26 As New DataColumn("PortStaff", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col26)


        Dim col28 As New DataColumn("ReferenceNo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col28)

        Dim col29 As New DataColumn("ReferenceNo1", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col29)


        Dim col30 As New DataColumn("BL", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col30)

        Dim col31 As New DataColumn("JobDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col31)

        Dim col32 As New DataColumn("CrossBorderDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col32)

        Dim col32a As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col32a)


        Dim col33 As New DataColumn("DestinationArrivalDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col33)

        Dim col33a As New DataColumn("Arrived", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col33a)


        Dim col34 As New DataColumn("Highlight", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col34)

        Dim col35 As New DataColumn("SOC", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col35)

        '-----
        Dim col36 As New DataColumn("Vessel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col36)

        Dim col37 As New DataColumn("VoyageNo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col37)

        Dim col38 As New DataColumn("CustomsSystem", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col38)

        Dim col39 As New DataColumn("KeepVisible", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col39)


        Dim col40 As New DataColumn("TEU", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col40)

        Dim col41 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col41)

        Dim col42 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col42)

        Dim col43 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col43)

        Dim col44 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col44)

        Dim col45 As New DataColumn("ContainerReturnDays", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col45)

        Dim col46 As New DataColumn("DaysTaken", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col46)

        Dim col47 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col47)

        Dim col48 As New DataColumn("Quantity", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col48)

        Dim col51 As New DataColumn("ProgressStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col51)

        Dim col52 As New DataColumn("ShippingLineID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col52)

        Dim col53 As New DataColumn("ShippingLine", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col53)

        Dim col54 As New DataColumn("JobUrl", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col54)

        Dim col55 As New DataColumn("FileClosed", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col55)

        Dim col56 As New DataColumn("NoBreakRow", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col56)
    End Sub


    Shared Function nSortOrder(SelectedIndex As Integer) As String
        If SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf SelectedIndex = 2 Then
            Return "JobId"
        ElseIf SelectedIndex = 3 Then
            Return "VesselETA"
        Else
            Return "JobDate"
        End If
    End Function


    Shared Sub ExportToExcel(CFPROID As String, CFPROUserID As String,
                             Weight As String, CBM As String, TEU As String,
                             Quantity As String, FilterStr As String, SortStr As String,
                             ReportCaption As String, ByRef dv As DataView, Optional SessionLess As Boolean = False,
                             Optional FileName As String = "", Optional ByRef ErrMsg As String = Nothing)

        Try



            Dim totals(3) As String

            totals(0) = "Total Weight: " & Weight
            totals(1) = "Total CBM: " & CBM & " Cb.M"
            totals(2) = "Total TEU: " & TEU
            totals(3) = "Total Qty: " & Quantity



            Dim tmpcols(0) As String
            Dim tmpfields(0) As String

            Call DetailedVisilityReportColumns(CFPROID, tmpfields, tmpcols)


            Dim tmptable As New DataTable("JobTableDetailed")

            Dim SaveExcelDoc As Boolean

            If Not SessionLess Then
                tmptable = DirectCast(HttpContext.Current.Session("JobTableDetailed"), DataTable)
                SaveExcelDoc = False
            Else
                tmptable = dv.Table
                SaveExcelDoc = True
            End If

            If FileName = "" Then
                FileName = "Detailed Visibility"
            End If

            Call clsExportToExcel.ExportToExcel(CFPROID, FilterStr, SortStr, FileName, "Detailed Visibility",
                                                ReportCaption, True, totals, 0, "", tmpfields, tmpcols, tmptable, SaveExcelDoc)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try


    End Sub

    Shared Function FilterDetailedReport(FilterClient As Boolean, ClientID As String, Client As String,
                                        FilterImporter As Boolean, ImporterID As String, Importer As String,
                                        OmitDispatched As Boolean, OmitCrossedBorder As Boolean, OmitFileClosed As Boolean) As String()

        Dim tmpstr(0), tmpstr1(0) As String

        Dim a As Integer



        If FilterClient Then

            ReDim Preserve tmpstr(a), tmpstr1(a)
            If a = 0 Then
                tmpstr(a) = "ClientID = '" & ClientID & "' "
            Else
                tmpstr(a) = "And ClientID = '" & ClientID & "' "
            End If

            tmpstr1(a) = "Client: " & Client
            a = a + 1

        End If

        If FilterImporter Then
            ReDim Preserve tmpstr(a), tmpstr1(a)
            If a = 0 Then
                tmpstr(a) = "ImporterID = '" & ImporterID & "' "
            Else
                tmpstr(a) = " And ImporterID = '" & ImporterID & "' "
            End If

            tmpstr1(a) = "Consignee: " & Importer
            a = a + 1
        End If


        If OmitDispatched Then

            ReDim Preserve tmpstr(a), tmpstr1(a)
            If a = 0 Then
                tmpstr(a) = "JobStatus <> 'Dispatched' "
            Else
                tmpstr(a) = " And JobStatus <> 'Dispatched' "
            End If

            tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
            a = a + 1
        End If


        If OmitCrossedBorder Then
            ReDim Preserve tmpstr(a), tmpstr1(a)
            If a = 0 Then
                tmpstr(a) = "CrossedBorder = " & CBool(0) & " "
            Else
                tmpstr(a) = " And CrossedBorder = " & CBool(0) & " "
            End If

            tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
            a = a + 1

        End If



        If OmitFileClosed Then
            ReDim Preserve tmpstr(a), tmpstr1(a)
            If a = 0 Then
                tmpstr(a) = "FileClosed = " & CBool(0) & " "
            Else
                tmpstr(a) = " And FileClosed = " & CBool(0) & " "
            End If

            tmpstr1(a) = "ACTIVE JOBS: " & CBool(OmitFileClosed)
            a = a + 1
        End If

        Dim tmpstr2 = Join(tmpstr, " ")
        Dim tmpstr3 = Join(tmpstr1, ", ")


        Dim tmpfilter(1) As String
        tmpfilter(0) = tmpstr2
        tmpfilter(1) = tmpstr3

        Return tmpfilter

    End Function

    Shared Function Calctotal(ByVal dv As DataView, ByVal tmpcaption1 As String, Scope As String,
                             FromDate As String, ToDate As String, ByRef ErrMsg As String) As String()
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double
            Dim JobCount As Double

            Dim JobID As String = ""

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                If JobID <> dv(a)("JobID") Then
                    JobCount = JobCount + 1
                    JobID = dv(a)("JobID")
                End If


                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")

            Next


            Dim tmpstr(4) As String

            tmpstr(0) = Format(Weight, "#,##0.0")
            tmpstr(1) = Format(CBM, "#,##0.0")
            tmpstr(2) = Format(TEU, "#,##0.0")
            tmpstr(3) = Format(Qty, "#,##0.0")

            Dim tmpstr1 As String

            If Not Scope = "(All)" Then
                tmpstr1 = FromDate & " to " & ToDate
            Else
                tmpstr1 = "All Jobs In System"
            End If

            If tmpcaption1 = "" Then
                tmpstr(4) = JobCount & " Jobs: " & tmpstr1
            Else
                tmpstr(4) = JobCount & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr1

            End If

            Return tmpstr

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Function

    Shared Sub CreateDetailedVisibilityColumns(CFPROID As String, ByRef tmptable1 As DataTable)
        Dim sqlstr As String =
               "SELECT ColumnName, ColumnText," &
               "Show, CFPROID, SortOrder, ID " &
               "FROM  DetailedVisibilityReportColumns " &
               "Where CFPROID ='sys' " &
               "Order By SortOrder Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next

                drow1("CFPROID") = CFPROID
                tmptable1.Rows.Add(drow1)

            Next
        End If

        Call clsData.SaveData("DetailedVisibilityReportColumns", tmptable1, sqlstr, False, clsData.constr)

    End Sub

    Shared Sub DetailedVisilityReportColumns(CFPROID As String, ByRef columnnames() As String, ByRef columntext() As String)

        Dim sqlstr As String =
               "SELECT ColumnName, ColumnText, Show,ID " &
               "FROM  DetailedVisibilityReportColumns " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And Show = 1 " &
               "Order By Sortorder Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count = 0 Then
            Call clsDetailedVisibilityReport.CreateDetailedVisibilityColumns(CFPROID, tmptable)
        End If

        Dim a As Integer
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ReDim Preserve columnnames(a), columntext(a)
                columnnames(a) = drow("ColumnName")
                columntext(a) = drow("ColumnText")
                a = a + 1
            Next
        End If



    End Sub

End Class
