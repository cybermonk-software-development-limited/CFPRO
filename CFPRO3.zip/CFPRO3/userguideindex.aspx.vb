﻿Public Class userguideindex
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, "", LinkSignIn.Text, ImageUser.ImageUrl, "", False, "", False,,,,,, LabelMessage1.Text)


            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, ImageUser.ImageUrl, False, "userguideindex.aspx")
    End Sub
End Class