﻿Imports System.Drawing


Public Class quote
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            Dim Usertype As String = Request.QueryString("usertype")
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""


            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", CFAgentName, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID


            Dim QuoteID As String = ""

            If Not IsNothing(Request.QueryString("quoteid")) Then
                QuoteID = Request.QueryString("quoteid")
            End If


            Dim JobID As String = Request.QueryString("jobid")
            LabelJobID.Text = JobID


            Call clsAccounts.LoadActiveCurrencies(CFPROID, ComboCurrency)

            Call LoadSalesmen(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadQuoteIDs(CFPROID, JobID, QuoteID)


        End If
    End Sub


    Protected Sub ButtonQuoteID_Click(sender As Object, e As EventArgs) Handles ButtonQuoteID.Click
        Call LoadQuote(LabelCFPROID.Text, ComboQuoteID.Text, LabelJobID.Text)
    End Sub
    Private Sub LoadQuoteIDs(CFPROID As String, JobID As String, QuoteID As String)

        Try

            Dim sqlstr As String =
            "Select QuoteID " &
            "From QuoteHeader " &
            "Where JobID = '" & JobID & "' " &
            "And CFPROID = '" & CFPROID & "' " &
            "Order by ID Desc; "

            ComboQuoteID.Items.Clear()
            Call clsData.PopCombo(ComboQuoteID, sqlstr, clsData.constr, 0)

            LabelQuoteCount.Text = ComboQuoteID.Items.Count & " Job Quotes"

            If ComboQuoteID.Items.Count > 0 Then
                If QuoteID = "" Then
                    ComboQuoteID.SelectedIndex = 0
                Else
                    ComboQuoteID.Text = QuoteID
                End If

                Call LoadQuote(CFPROID, ComboQuoteID.Text, JobID)
            Else
                Call NewQuote(CFPROID, JobID)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & " " & exp.StackTrace
        End Try

    End Sub

    Private Sub LoadQuote(CFPROID As String, QuoteID As String, JobID As String)

        Dim sqlstr As String =
            "Select QuoteID,ClientID," &
            "JobDate, QuoteNo,  " &
            "QuoteDate,  Total, " &
            "SubTotal, VAT,VATAmount," &
            "QuoteParticulars, ApplyVAT," &
            "VATinclusive, PreparedByID," &
            "ReviewedByID,CurrencyID, " &
            "PreparedByDate,ReviewedByDate, " &
            "CurrencyRate,JobID," &
            "JobTypeID,SalesmanID,ID " &
            "FROM QuoteHeader" &
            "Where QuoteID ='" & QuoteID & "' " &
            "And CFPROID ='" & CFPROID & "' "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then

            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            LabelJobID.Text = drow("JobID")
            TextQuoteNo.Text = drow("QuoteNo")

            TextSubTotal.Text = Format(drow("SubTotal"), "#,##0.00")
            TextTotal.Text = Format(drow("Total"), "#,##0.00")
            TextTaxAmount.Text = Format(drow("VATAmount"), "#,##0.00")
            TextQuoteDate.Text = Format(drow("QuoteDate"), "dd-MMM-yyyy")
            ComboCurrency.Text = drow("CurrencyID")
            ComboSalesman.Text = drow("SalesmanID")
            Call GetClient(CFPROID, drow("ClientID"))

        End If

        Call LoadQuoteItems(CFPROID, QuoteID, JobID)


    End Sub

    Private Sub LoadQuoteItems(CFPROID As String, QuoteID As String, JobID As String)

        Try

            Dim sqlstr As String =
                "SELECT QuoteItems.ItemID, Item," &
                "Cost,SaleRate,Quantity, QuoteItems.Amount," &
                "QuoteItems.ApplyTax, QuoteItems.TaxPercent," &
                "TaxAmount, QuoteItems.TaxType," &
                "Total,QuoteID,VendorID,QuoteItems.ID  " &
                "FROM  QuoteItems, QuoteItems " &
                "Where QuoteID = '" & QuoteID & "' " &
                "And QuoteItems.JobID = '" & JobID & "' " &
                "And QuoteItems.CFPROID = '" & CFPROID & "' " &
                "And QuoteItems.CFPROID ='" & CFPROID & "' " &
                "And QuoteItems.ItemID = QuoteItems.ItemID " &
                "And QuoteItems.CFPROID = QuoteItems.CFPROID " &
                "Order By QuoteItems.ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    drow("Amount") = drow("SaleRate") * drow("Quantity")

                    If drow("ApplyTax") Then
                        drow("TaxAmount") = drow("Amount") * (drow("TaxPercent") / 100)
                    Else
                        drow("TaxAmount") = 0
                    End If

                    drow("Total") = drow("Amount") + drow("TaxAmount")
                    a = a + 1

                Next
            End If

            LabelQuoteCaption.Text = tmptable.Rows.Count & "  Quote Items"

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Item") = "Quote Items Not Set"
                tmptable.Rows.Add(drow)
            End If



            GridQuote.DataSource = tmptable
            GridQuote.DataBind()

            Call Calctotal(tmptable)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Private Sub Calctotal(tmptable As DataTable)
        Try


            Dim a As Integer
            Dim Amount, TotalTax, Total As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Amount = Amount + drow("Amount")
                TotalTax = TotalTax + drow("TaxAmount")
                Total = Total + drow("Total")

                a = a + 1

            Next

            TextSubTotal.Text = Format(Amount, "#,##0.00")
            TextTaxAmount.Text = Format(TotalTax, "#,##0.00")
            TextTotal.Text = Format(Total, "#,##0.00")


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub LoadSalesmen(CFPROID As String)
        Dim sqlstr As String =
            "Select Salesman,SalesmanID, ID " &
            "From Salesmen " &
            "Where CFPROID = '" & CFPROID & "' "
        Call clsData.PopComboWithValue(ComboSalesman, sqlstr, clsData.constr, 0, 1)
        ComboSalesman.Items.Insert(0, "")
    End Sub

    Protected Sub ButtonAddQuoteItems_Click(sender As Object, e As EventArgs) Handles ButtonAddQuoteItems.Click
        Call LoadQuoteItems(LabelCFPROID.Text, LabelJobID.Text)
    End Sub

    Protected Sub GridQuote_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridQuote.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridQuote, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub GridQuote_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridQuote.SelectedIndexChanged
        Dim row As GridViewRow = GridQuote.Rows(GridQuote.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridQuote.Rows.Count - 1
            row = GridQuote.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridQuote.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
        "Select JobType,JobTypeID,ID " &
        "From JobTypes " &
        "WHERE CFPROID='" & CFPROID & "' " &
        "Order By ID Asc;"

        ComboQuoteType.Items.Add("(None)")
        Call clsData.PopComboWithValue(ComboQuoteType, sqlstr, clsData.constr, 0, 1)
    End Sub

    Private Sub GetClient(CFPROID As String, ClientID As String)

        Dim sqlstr As String = "Select Client, ID " &
                               "From Clients " &
                               "Where ClientID = '" & ClientID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            TextClient.Text = drow("Client")
        Else
            TextClient.Text = ""
        End If

    End Sub
    Private Sub NewQuote(CFPROID As String, JobID As String)

        Try
            Dim QuoteID As String = clsSubs.GetLastID(LabelCFPROID.Text, "", "QuoteID")

            If Not IsDate(TodaysDate.Value) Then
                TodaysDate.Value = Format(Now, "dd-MMM-yyyy")
            End If


            TextQuoteDate.Text = TodaysDate.Value


            Dim sqlstr As String =
                "Select JobID, QuoteID," &
                "QuoteNo,QuoteDate,  " &
                "CurrencyID,CFPROID,, ID " &
                "FROM QuoteHeader " &
                "Where CFPROID ='" & CFPROID & "' " &
                "And JobID ='" & JobID & "'"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow = tmptable.NewRow
            drow("CFPROID") = CFPROID
            drow("JobID") = JobID
            drow("QuoteID") = QuoteID
            drow("QuoteNo") = QuoteID
            drow("QuoteDate") = TodaysDate.Value

            Dim tmpstr() As String = clsAccounts.GetLocalCurrency(CFPROID)
            drow("CurrencyID") = tmpstr(2)

            tmptable.Rows.Add(drow)

            Call clsData.SaveData("QuoteHeader", tmptable, sqlstr, False, clsData.constr)


            Call LoadQuoteIDs(CFPROID, JobID, "")

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Protected Sub ButtonSaveQuote_Click(sender As Object, e As EventArgs) Handles ButtonSaveQuote.Click
        Call SaveQuote(LabelCFPROID.Text, ComboQuoteID.SelectedValue, LabelJobID.Text)
    End Sub


    Private Sub SaveQuote(CFPROID As String, QuoteID As String, JobID As String)

        Try


            Dim sqlstr As String =
                "Select JobID,QuoteID,QuoteNo,  " &
                "QuoteDate, Cost, Total, " &
                "Paid, Balance, SubTotal, VAT," &
                "QuoteParticulars, ApplyVAT," &
                "VATinclusive,CurrencyID, QuoteHeader," &
                "QuoteDueDate, VATAmount," &
                "QuoteTypeID, SalesmanID," &
                "CompanyID,ID " &
                "FROM QuoteHeader " &
                "Where QuoteID='" & QuoteID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)

                If Trim(TextQuoteNo.Text) = "" Then
                    TextQuoteNo.Text = QuoteID
                End If


                drow("QuoteNo") = Trim(TextQuoteNo.Text)
                drow("SubTotal") = TextSubTotal.Text

                drow("Total") = TextTotal.Text
                drow("VATAmount") = TextTaxAmount.Text
                drow("Cost") = TextTotalCost.Text
                drow("QuoteDate") = TextQuoteDate.Text
                drow("CurrencyID") = ComboCurrency.Text



                Call clsData.SaveData("QuoteHeader", tmptable, sqlstr, False, clsData.constr)


            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub





    Private Sub SetQuoteType(CFPROID As String, QuoteID As String, JobTypeID As String)
        Dim sqlstr As String =
              "SELECT Item, Cost, Amount," &
              "ApplyTax,TaxPercent," &
              "TaxAmount,TaxType," &
              "Total, ID  " &
              "FROM JobTypeItems " &
              "Where JobTypeID ='" & JobTypeID & "' " &
              "And CFPROID ='" & CFPROID & "' " &
              "Order By ID Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim sqlstr1 As String =
            "SELECT ItemID, Item," &
            "Amount," &
            "ApplyTax, TaxPercent," &
            "TaxType,ID" &
            "FROM   InvoiceItems " &
            "Where CFPROID ='" & CFPROID & "' "


        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

        Dim dv1 As New DataView(tmptable1)

        Dim a As Integer
        Dim drow, drow1 As DataRow
        If tmptable.Rows.Count > 0 Then

            For a = 0 To tmptable1.Rows.Count - 1
                drow1 = tmptable1.Rows(a)
                drow1.Delete()
            Next

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                drow1 = tmptable1.NewRow
                drow1("Amount") = drow("Amount")
                drow1("ApplyTax") = drow("ApplyTax")
                drow1("TaxPercent") = drow("TaxPercent")
                drow1("TaxType") = drow("TaxType")

                tmptable1.Rows.Add(drow1)
                a = a + 1
            Next

            Call clsData.SaveData("QuoteItems", tmptable1, sqlstr1, True, clsData.constr)
            Call LoadQuoteItems(CFPROID, QuoteID)

            LabelQuoteCaption.Text = tmptable.Rows.Count & " Quote Items - " & JobTypeID

        End If

    End Sub




    Private Sub LoadQuoteItems(CFPROID As String, JobID As String)

        Try

            Dim sqlstr As String =
                "SELECT  Item," &
                "ItemID, CFPROID, ID " &
                "FROM  QuoteItems " &
                "Where CFPROID = '" & CFPROID & "' " &
                "Order By Item Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If


            If tmptable.Rows.Count = 0 Then
                Call clsSubs.CreateAccountInvoiceItems(CFPROID, tmptable, False)
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()



            Dim sqlstr1 As String =
                "SELECT  ItemID, ID " &
                "From  QuoteItems" &
                "Where CFPROID ='" & CFPROID & "' " &
                "And JobID ='" & JobID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim b As Integer
            If tmptable1.Rows.Count > 0 Then

                Dim chkbox As CheckBox
                Dim nFieldItemID As HiddenField

                For Each item As DataListItem In DataList1.Items
                    a = 0

                    chkbox = DirectCast(item.FindControl("CheckQuoteItem"), CheckBox)
                    nFieldItemID = DirectCast(item.FindControl("FieldItemID"), HiddenField)

                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, a)

                        If drow1("ItemID") = nFieldItemID.Value Then
                            chkbox.Checked = True
                            b = b + 1
                            Exit For
                        End If
                        a = a + 1
                    Next

                Next
            End If

            LabelItemypeCount.Text = b & " / " & DataList1.Items.Count & "Quote Items"
            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveQuoteTypeItems_Click(sender As Object, e As EventArgs) Handles ButtonSaveQuoteTypeItems.Click
        ModalPopupExtender1.Hide()
        Call SaveSelectedQuoteItems(LabelCFPROID.Text, ComboQuoteID.Text, LabelJobID.Text)
    End Sub


    Protected Sub CheckQuoteItem_CheckedChanged(sender As Object, e As EventArgs)

        Dim chkbox As CheckBox
        Dim a As Integer

        For Each item As DataListItem In DataList1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                chkbox = TryCast(item.FindControl("CheckQuoteItem"), CheckBox)
                If chkbox IsNot Nothing Then
                    If chkbox.Checked Then
                        a = a + 1
                    End If
                End If

            End If
        Next

        LabelItemypeCount.Text = a & " / " & DataList1.Items.Count & " Quote Items"
        ModalPopupExtender1.Show()

    End Sub
    Private Sub SaveSelectedQuoteItems(CFPROID As String, QuoteID As String, JobID As String)

        Try

            Dim sqlstr As String = "SELECT JobID,QuoteID, ItemID," &
                                    "Amount,ApplyTAx, TaxPercent," &
                                    "TaxType,CFPROID, ID " &
                                    "From  QuoteItems " &
                                    "Where QuoteID ='" & QuoteID & "' " &
                                    "And JobID ='" & JobID & "' " &
                                    "And CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
              "Select  Item," &
              "ItemID, Amount," &
              "ApplyTAx, TaxPercent," &
              "TaxType,CFPROID, ID " &
              "FROM  QuoteItems " &
              "Where CFPROID = '" & CFPROID & "' " &
              "Order By Item Asc;"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim dv1 As New DataView(tmptable1)


            Dim drow As DataRow

            Dim chkbox As CheckBox
            Dim nFieldItemID As HiddenField
            Dim found As Boolean
            Dim a As Integer

            For Each item As DataListItem In DataList1.Items

                If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                    chkbox = DirectCast(item.FindControl("CheckQuoteItem"), CheckBox)
                    nFieldItemID = DirectCast(item.FindControl("FieldItemID"), HiddenField)


                    If chkbox IsNot Nothing Then
                        If chkbox.Checked Then
                            a = 0
                            found = False

                            For Each drow In tmptable.Rows
                                Call clsData.NullChecker(tmptable, a)
                                If drow("ItemID") = nFieldItemID.Value Then
                                    found = True
                                    Exit For
                                End If
                                a = a + 1
                            Next

                            If Not found Then
                                Dim drow1 As DataRow = tmptable.NewRow
                                drow1("CFPROID") = CFPROID
                                drow1("QuoteID") = QuoteID
                                drow1("JobID") = JobID
                                drow1("ItemID") = nFieldItemID.Value

                                dv1.RowFilter = "ItemID = '" & nFieldItemID.Value & "'"
                                If dv1.Count > 0 Then
                                    Call clsData.NullChecker1(dv1, 0)
                                    drow1("Amount") = dv1(0)("Amount")
                                    drow1("ApplyTax") = dv1(0)("ApplyTax")
                                    drow1("TaxPercent") = dv1(0)("TaxPercent")
                                    drow1("TaxType") = dv1(0)("TaxType")
                                End If

                                tmptable.Rows.Add(drow1)
                            End If

                        End If
                    End If
                End If


            Next
            Call clsData.SaveData("QuoteItems", tmptable, sqlstr, False, clsData.constr)
            Call LoadQuoteItems(CFPROID, QuoteID, JobID)

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub



    Private Sub LoadDialog(sourcepage As String, dialogtitle As String, width As Integer, height As Integer)

        Dim iframebg As String = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit;" &
                "background-position-y: center; background-position-x: center;"

        PanelDialog.Attributes("style") = "width:" & width + 10 & "px; height:" & height + 72 & "px;"
        PanelDrag.Attributes("style") = "width:100%;"
        iframe1.Attributes("style") = "width:" & width & "px ; height:" & height & "px;" & iframebg

        LabelDialogTitle.Text = dialogtitle
        iframe1.Attributes("src") = sourcepage

        ModalPopupExtender5.Show()
    End Sub
    Protected Sub ButtonSetQuoteType_Click(sender As Object, e As EventArgs) Handles ButtonSetQuoteType.Click
        Call PromptDialog(LabelCFPROID.Text, "Set Quote")
    End Sub

    Protected Sub ButtonDeleteItem_Click(sender As Object, e As EventArgs) Handles ButtonDeleteItem.Click

        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Gray
        If GridQuote.SelectedIndex >= 0 Then
            Call PromptDialog(LabelCFPROID.Text, "Delete")
        Else
            LabelMessage.Text = "Select Item to Remove"
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub


    Private Sub PromptDialog(CFPROID As String, Message As String)

        If Message = "Delete" Then
            Dim row As GridViewRow = GridQuote.Rows(GridQuote.SelectedIndex)
            LabelPromptMessage.Text = "Delete " & row.Cells(0).Text & " ?"
            ButtonOKPrompt.Visible = True

        Else
            If GridQuote.Rows.Count > 0 Then
                LabelPromptMessage.Text = "Overwrite current Quote with " & ComboQuoteType.SelectedItem.Text & " ?"
                ButtonOKPrompt.Visible = True
            End If
        End If

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonOKPrompt_Click(sender As Object, e As EventArgs) Handles ButtonOKPrompt.Click
        If LabelPromptMessage.Text.Contains("Delete") Then
            Call DeleteQuoteItem(GridQuote.SelectedValue)
        Else
            Call SetQuoteType(LabelCFPROID.Text, ComboQuoteID.Text, ComboQuoteType.SelectedValue)
        End If

    End Sub


    Private Sub DeleteQuoteItem(ID As Integer)

        Dim sqlstr As String =
                 "Select  ID " &
                  "From QuoteItems  " &
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("QuoteItems", tmptable, sqlstr, True, clsData.constr)

            Dim row As GridViewRow = GridQuote.Rows(GridQuote.SelectedIndex)
            Dim LabelQuoteType As Label = CType(row.FindControl("LabelQuoteType"), Label)

            Call LoadQuoteItems(LabelCFPROID.Text, ComboQuoteID.Text, LabelJobID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Protected Sub ButtonEditItem_Click(sender As Object, e As EventArgs) Handles ButtonEditItem.Click

        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Gray

        If GridQuote.SelectedIndex < 0 Then
            LabelMessage.Text = "Please SELECT Quote Item."
            LabelMessage.ForeColor = Color.Red
        Else
            Call EditQuoteItem(LabelCFPROID.Text, GridQuote.SelectedValue)
        End If

    End Sub

    Private Sub EditQuoteItem(CFPROID As String, ID As Integer)
        Try

            LabelGridID.Text = ID
            Dim sqlstr As String = "SELECT SaleRate,Quantity," &
                                    "Amount,ApplyTax,TaxType," &
                                    "TaxPercent,ID " &
                                    "From  QuoteItems " &
                                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                If drow("Quantity") = 0 Then
                    drow("Quantity") = 1
                End If

                TextSaleRate.Text = drow("SaleRate")
                TextQuantity.Text = drow("Quantity")
                CheckApplyTax.Checked = drow("ApplyTax")
                ComboTaxType.Text = drow("TaxType")
                TextTaxPercent.Text = drow("TaxPercent")

            End If


            ModalPopupExtender7.Show()

            TextSaleRate.Focus()



        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSaveItem_Click(sender As Object, e As EventArgs) Handles ButtonSaveItem.Click
        Call SaveQuoteItem(LabelCFPROID.Text, LabelGridID.Text)
    End Sub

    Private Sub SaveQuoteItem(CFPROID As String, ID As Integer)

        Try

            Dim sqlstr As String =
                    "SELECT  ItemID, SaleRate," &
                    "Amount, Quantity,ApplyTax," &
                    "TaxType, TaxPercent," &
                    "CFPROID,CurrencyID,ID " &
                    "FROM  QuoteItems " &
                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("ItemID") = clsSubs.GetInvoiceItemID()
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("SaleRate") = Trim(TextSaleRate.Text)
            drow("Quantity") = Trim(Val(TextQuantity.Text))
            drow("ApplyTax") = CheckApplyTax.Checked
            drow("TaxType") = ComboTaxType.Text
            drow("TaxPercent") = Trim(TextTaxPercent.Text)
            drow("CurrencyID") = ComboCurrency.Text

            Call clsData.SaveData("QuoteItems", tmptable, sqlstr, False, clsData.constr)

            Call LoadQuoteItems(CFPROID, ComboQuoteID.Text, LabelJobID.Text)

            ModalPopupExtender7.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonQuotePDF_Click(sender As Object, e As EventArgs) Handles ButtonQuotePDF.Click

        Dim sourcepage As String = QuotePDF()
        Call LoadDialog(sourcepage, "Quote PDF", 780, 500)
    End Sub




    Private Function QuotePDF() As String

        Try
            ' Return clsCSDQuote.QuotePDF(LabelCFPROID.Text, "Quote " & TextQuoteNo.Text & " - " & Format(Now, "dd-MMM-yyyy"), tmptbl, tmptbl1, LabelMessage1.Text)

        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try
    End Function

    Protected Sub ButtonCostSheet_Click(sender As Object, e As EventArgs) Handles ButtonCostSheet.Click
        Response.Redirect("jobcostsheet.aspx?jobid=" & LabelJobID.Text & "&QuoteID=" & ComboQuoteID.Text)
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)

    End Sub

    Protected Sub ButtonNewQuote_Click(sender As Object, e As EventArgs) Handles ButtonNewQuote.Click
        Call NewQuote(LabelCFPROID.Text, LabelJobID.Text)
    End Sub

    Protected Sub ComboQuoteID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboQuoteID.SelectedIndexChanged
        Call LoadQuote(LabelCFPROID.Text, ComboQuoteID.Text, LabelJobID.Text)
    End Sub

    Protected Sub LinkQuoteItem_Click(sender As Object, e As EventArgs)
        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Gray
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim tmpstr As Integer = linkbutton.CommandArgument.ToString
        Call EditQuoteItem(LabelCFPROID.Text, tmpstr)
    End Sub
End Class

