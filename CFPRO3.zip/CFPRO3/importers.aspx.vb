﻿Imports System.Drawing

Public Class importers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)

            End If


            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call clsSubs.CountryList(ComboCountry)
            Call LoadImporters(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadImporters(CFPROID As String, Rowindex As Integer, SearchStr As String, Optional FilterIndex As Integer = 0)


        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Importer  Like '%" & Trim(TextSearch.Text) & "%' "
        End If

        If FilterIndex = 1 Then
            tmpstr = " And SendReports  = 1"
        End If

        Dim sqlstr As String =
              "Select ImporterID, Importer," &
              "Box,Telephone,Email," &
              "Town,Country,Id " &
              "From  Importers " &
              "Where CFPROID ='" & CFPROID & "' " &
              tmpstr &
              "Order By ID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next


        If tmptable.Rows.Count < 10 Then
            GridImporters.Height = 20 + (24 * tmptable.Rows.Count)
        End If

        Session("ImportersTable") = tmptable
        GridImporters.DataSource = tmptable
        GridImporters.DataBind()

        If GridImporters.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridImporters.Rows.Count - 1 Then
                Rowindex = GridImporters.Rows.Count - 1
            End If

            GridImporters.SelectedIndex = Rowindex
            Call ShowImporter(GridImporters.SelectedValue)
            Dim row As GridViewRow = GridImporters.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Consignees found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Consignees"
        End If

    End Sub



    Private Sub ShowImporter(ID As Integer)

        Dim sqlstr As String =
             "Select ImporterID, Importer," &
             "Box,Telephone,Email," &
             "Town,Country,SendReports " &
             "From  Importers " &
             "Where ID =" & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextImporter.Text = drow("Importer")
            TextAddress.Text = drow("Box")
            TextTelephone.Text = drow("Telephone")
            TextEmailAddress.Text = drow("Email")
            TextTown.Text = drow("Town")
            CheckSendReports.Checked = drow("SendReports")

            If drow("Country").ToString.Length > 0 And drow("Country").ToString.Length <= 2 Then
                ComboCountry.Text = Trim(drow("Country"))
            Else
                ComboCountry.SelectedIndex = 0
            End If

        End If

        LabelMessage.ForeColor = Color.Black
        LabelMessage.Text = ""

    End Sub



    Private Sub NewImporter(CFPROID As String)
        Try

            Dim ImporterID As String = GetImporterID()
            Dim sqlstr As String =
                  "Select ImporterID, CFPROID," &
                   "Importer,SendReports,ID " &
                   "From  Importers " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And ImporterID = '" & ImporterID & "'"

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow
            Drow("ImporterID") = ImporterID
            Drow("CFPROID") = CFPROID
            Drow("Importer") = "New Importer " & tmptable.Rows.Count
            Drow("SendReports") = 0

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Importers", tmptable, sqlstr, False, clsData.constr)
            Call LoadImporters(CFPROID, 0, TextSearch.Text)

            TextImporter.Focus()

        Catch exp As Exception
            MsgBox(exp.Message, , "AddImporter")
        End Try
    End Sub


    Private Function GetImporterID() As String
        Try

            Dim tmpImporterID As Integer

            Dim sqlstr As String =
             "Select Top 1 ID " &
             "From Importers " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpImporterID = drow("ID")
                tmpImporterID = tmpImporterID + 1
                tmpstr = Format(tmpImporterID, "00000000#")
            Else
                tmpstr = Format(tmpImporterID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Function
    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridImporters, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridImporters.SelectedIndexChanged
        Dim row As GridViewRow = GridImporters.Rows(GridImporters.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowImporter(GridImporters.SelectedValue)

        For a As Integer = 0 To GridImporters.Rows.Count - 1
            row = GridImporters.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridImporters.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewImporter(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveImporter(GridImporters.SelectedValue)
    End Sub


    Private Sub SaveImporter(ID As Integer)
        Try

            LabelMessage.ForeColor = Color.Black
            LabelMessage.Text = ""

            If Not Trim(TextEmailAddress.Text) = "" Then
                If Not Trim(TextEmailAddress.Text).Contains("@") Then
                    LabelMessage.Text = "Invalid Email Address"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If

            Dim sqlstr As String =
            "Select ImporterID, Importer," &
            "Box,Telephone,Email," &
            "Town,Country,SendReports," &
            "CFPROID, ID " &
            "From  Importers " &
            "Where ID = " & ID & " "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Importer") = Trim(TextImporter.Text)
                drow("Box") = Trim(TextAddress.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Town") = Trim(TextTown.Text)
                drow("Country") = ComboCountry.Text
                drow("SendReports") = CheckSendReports.Checked

            End If

            Call clsData.SaveData("Importers", tmptable, sqlstr, False, clsData.constr)

            Call LoadImporters(LabelCFPROID.Text, GridImporters.SelectedIndex, TextSearch.Text, ComboFilterBy.SelectedIndex)

        Catch exp As Exception
            MsgBox(exp.Message, , "AddImporter")
        End Try
    End Sub


    Private Sub DeleteImporter(ID As Integer)


        Dim sqlstr As String =
        "Select ID " &
        "From  Importers " &
        "Where ID =" & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Importers", tmptable, sqlstr, True, clsData.constr)
        Call LoadImporters(LabelCFPROID.Text, GridImporters.SelectedIndex - 1, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteImporter(GridImporters.SelectedValue)
    End Sub
    Protected Sub ComboFilterBy_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboFilterBy.SelectedIndexChanged
        Call LoadImporters(LabelCFPROID.Text, GridImporters.SelectedIndex, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadImporters(LabelCFPROID.Text, GridImporters.SelectedIndex - 1, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        TextSearch.Text = ""
        ComboFilterBy.SelectedIndex = 0
        Call LoadImporters(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click

        Dim Fields(5) As String
        Fields(0) = "ImporterID"
        Fields(1) = "Importer"
        Fields(2) = "Email"
        Fields(3) = "Telephone"
        Fields(4) = "Town"
        Fields(5) = "Country"


        Dim tmptable As DataTable = Session("ImportersTable")
        Call clsExportToExcel.ExportToExcel("", "", "", "Consignees", "Consignees",
                                           LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)

    End Sub


    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender2.Show()
    End Sub

    Protected Sub ButtonEmailAddresses_Click(sender As Object, e As EventArgs) Handles ButtonEmailAddresses.Click

        If GridImporters.SelectedIndex >= 0 Then
            Dim OwnerID As String = GridImporters.SelectedValue
            LoadDialog("emailaddresses.aspx?ownertype=importer&ownerid=" & OwnerID, "Additional Email Addresses", 400, 550)
        End If
    End Sub

    Protected Sub ButtonAutomatedReportSettings_Click(sender As Object, e As EventArgs) Handles ButtonAutomatedReportSettings.Click
        Dim RecipientID As String = GridImporters.SelectedValue
        Call LoadDialog("optionalalertsettings.aspx?recipientid=" & RecipientID & "&recipienttype=importer", "Optional Alert Settings", 418, 585)
    End Sub

    Protected Sub ButtonPhoneNumbers_Click(sender As Object, e As EventArgs) Handles ButtonPhoneNumbers.Click
        If GridImporters.SelectedIndex >= 0 Then
            Dim OwnerID As String = GridImporters.SelectedValue
            LoadDialog("telephonenos.aspx?ownertype=importer&ownerid=" & OwnerID, "Additional Phone Numbers", 400, 550)
        End If
    End Sub
End Class