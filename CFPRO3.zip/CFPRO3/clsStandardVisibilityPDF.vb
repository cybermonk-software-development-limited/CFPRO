﻿

Imports System.IO
Imports System.Data
Imports System.Configuration

Imports iTextSharp.text
Imports iTextSharp.text.html.simpleparser
Imports iTextSharp.text.pdf
Imports System.Net.Mail
Imports System.Net

Public Class clsStandardVisibilityPDF

    Friend Progresstmpdate1 As DateTime
    Friend Progresstmpdate2 As DateTime
    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75

        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub RightAligned(txt As String, sw As PdfContentByte, rect As Rectangle, fnt As Font)

        Dim ct As ColumnText = New ColumnText(sw)
        ct.SetSimpleColumn(rect)
        'ct.Alignment = HorizontalAlign.Right
        Dim par As New Paragraph(txt, fnt)
        par.Alignment = Element.ALIGN_RIGHT
        ct.AddElement(par)
        ct.Go()
    End Sub
    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single, lineWidth As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.SetLineWidth(lineWidth)
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - (y1 + height))
        contentByte.LineTo(x1, 595 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 595 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Function ReportDoc(StatusReportPDFName As String, tmptbl As DataTable, caption As String) As Byte()

        Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
        Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
        Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
        Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
        Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

        Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)


        Dim font6b As New Font(customfontb, 6)
        Dim font7b As New Font(customfontb, 7.4)

        Dim font7 As New Font(customfont, 7)

        Dim font8 As New Font(customfont, 8)
        Dim font8i As New Font(customfonti, 8)
        Dim font8b As New Font(customfontb, 8)
        Dim font9 As New Font(customfont, 9)
        Dim font9b As New Font(customfontb, 9)
        Dim font11c As New Font(customfontc, 10.5)
        Dim font10b As New Font(customfontb, 10)
        Dim font12b As New Font(customfontb, 12)
        Dim font22 As New Font(customfontb, 16)

        Dim drf As New Drawing.StringFormat()

        Dim brush1 As Drawing.Color = Drawing.Color.Black
        Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
        'Dim PDFReader As PdfReader = Nothing 'Read File

        ' Document starts here
        Dim regdocpath As String = HttpContext.Current.Server.MapPath(".") & "\regdocs\" & StatusReportPDFName & ".pdf"
        Dim doclogospath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp"
        Dim StandardVisibilityPDF As New Document(PageSize.A4.Rotate(), 0, 0, 0, 10)

        'New FileStream(regdocpath, FileMode.Create)

        Using memoryStream As New System.IO.MemoryStream()
            Dim PDFwriter As PdfWriter = PDFwriter.GetInstance(StandardVisibilityPDF, memoryStream)

            Dim logo As Image = Image.GetInstance(doclogospath)
            StandardVisibilityPDF.Open()



            'Create line pens
            Dim pen As PdfContentByte = PDFwriter.DirectContent
            Dim pen1 As PdfContentByte = PDFwriter.DirectContent
            Dim pen2 As PdfContentByte = PDFwriter.DirectContent
            Dim pen3 As PdfContentByte = PDFwriter.DirectContent

            pen.SetRGBColorStroke(195, 195, 195)
            pen1.SetRGBColorStroke(195, 195, 195)
            pen2.SetRGBColorStroke(0, 0, 0)
            pen3.SetRGBColorStroke(0, 0, 0)

            pen.SetLineWidth(0)
            pen1.SetLineWidth(0.5)
            pen2.SetLineWidth(0.5)

            Static d, f As Integer
            Dim a, b As Integer

            Dim sqlstr As String = ""

            Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

            Dim pageLimit As Integer = 100
            Dim sectionBCount As Integer = 0
            Dim sectionCCount As Integer = 0
            Dim proceedB As Boolean = True
            Dim proceedC As Boolean = True
            Dim docfooterpath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp"

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp") Then
                logo.ScaleToFit(842, 69)
                logo.SetAbsolutePosition(0, 520)
                StandardVisibilityPDF.Add(logo)
            End If

            DrawLine(pen2, 30, 180, 1120, 180, 1)
            DrawLine(pen2, 30, 205, 1120, 205, 1)
            DrawString("JOBS - STANDARD VISIBILITY REPORT", font12b, brush1, 39, 120, StringWriter)

            DrawString(Format(Now, "dd-MMM-yyyy"), font8i, brush1, 1040, 120, StringWriter)
            DrawString(caption, font8b, Drawing.Color.Black, 35, 145, StringWriter)

            DrawString("Ref No.", font8b, brush1, 75, 185, StringWriter)
            DrawString("Client", font8b, brush1, 225, 185, StringWriter)
            DrawString("Vessel", font8b, brush1, 330, 185, StringWriter)
            DrawString("Vess. ETA", font8b, brush1, 460, 185, StringWriter)

          
            DrawString("BL", font8b, brush1, 555, 185, StringWriter)
            DrawString("CFS", font8b, brush1, 645, 185, StringWriter)

            Dim rect As Rectangle
            rect = New Rectangle(757 * 0.75, 0.75 * 157, 0.75 * 820, 595 - 0.75 * 177)
            Call RightAligned("R. Days", StringWriter, rect, font8b)

            rect = New Rectangle(815 * 0.75, 0.75 * 157, 0.75 * 865, 595 - 0.75 * 177)
            Call RightAligned("D.Taken", StringWriter, rect, font8b)

            rect = New Rectangle(870 * 0.75, 0.75 * 157, 0.75 * 895, 595 - 0.75 * 177)
            Call RightAligned("Qty", StringWriter, rect, font8b)

            DrawString("Latest Status", font8b, brush1, 900, 185, StringWriter)

            f = f + 1

            rect = New Rectangle(1000 * 0.75, 595 - 0.75 * 760, 0.75 * 1100, 595 - 0.75 * 795)
            Call RightAligned("Page " & f, StringWriter, rect, font8i)

            For a = 0 To tmptbl.Rows.Count - 1
                If a >= d Then
                    Call clsData.NullChecker(tmptbl, a)
                    Dim tmpstr() As String = tmptbl(a)("Client").ToString.Split(vbCrLf)
                    ReDim Preserve tmpstr(0)

                    DrawString(a + 1 & ".", font8, brush1, 40, (b * 25) + 215, StringWriter)
                    DrawString(Mid(tmptbl(a)("ReferenceNo"), 1, 25), font8, brush1, 75, (b * 25) + 215, StringWriter)
                    DrawString(Mid(tmpstr(0), 1, 13), font8, brush1, 225, (b * 25) + 215, StringWriter)
                    DrawString(Mid(tmptbl(a)("ShippingVessel"), 1, 11), font8, brush1, 330, (b * 25) + 215, StringWriter)

                    If Not CDate(tmptbl(a)("VesselETA")) = CDate("1-Jan-1800") Then
                        DrawString(Format(tmptbl(a)("VesselETA"), "dd-MMM-yyyy"), font8, brush1, 460, (b * 25) + 215, StringWriter)
                    End If

                    Dim lastsling As String = ""
                    If Not CDate(tmptbl(a)("LastSlingDate")) = CDate("1-Jan-1800") Then
                        lastsling = Format(tmptbl(a)("LastSlingDate"), "dd-MMM-yyyy")
                    End If

                 
                    DrawString(Mid(tmptbl(a)("CFS"), 1, 12), font8, brush1, 645, (b * 25) + 215, StringWriter)
                    DrawString(tmptbl(a)("BL"), font8, brush1, 555, (b * 25) + 215, StringWriter)

                    rect = New Rectangle(757 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 820, 595 - 0.75 * (b * 25 + 207))
                    Call RightAligned("0", StringWriter, rect, font8)

                    'DrawString(tmptbl(a)("RemDays"), font8, brush1, 765, (b * 25) + 215, StringWriter)

                    rect = New Rectangle(820 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 865, 595 - 0.75 * (b * 25 + 207))
                    Call RightAligned(tmptbl(a)("DaysTaken"), StringWriter, rect, font8)

                    rect = New Rectangle(870 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 895, 595 - 0.75 * (b * 25 + 207))
                    Call RightAligned("0", StringWriter, rect, font8)


                    'DrawString(tmptbl(a)("DaysTaken"), font8, brush1, 827, (b * 25) + 215, StringWriter)
                    'DrawString(Format(Val(tmptbl(a)("Qty")), "#,##0"), font8, brush1, 879, (b * 25) + 215, StringWriter)
                    DrawString(Mid(tmptbl(a)("Status"), 1, 102), font6b, brush1, 895, (b * 25) + 215, StringWriter)

                    b = b + 1
                    d = d + 1

                End If



                If b = 20 Then
                    If d < tmptbl.Rows.Count Then
                        DrawLine(StringWriter, 30, (b * 25) + 212, 1120, (b * 25) + 212)
                        If File.Exists(HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp") Then
                            Dim footer As Image = Image.GetInstance(docfooterpath)
                            footer.ScaleToFit(842, 15)
                            footer.SetAbsolutePosition(0, 10)
                            StandardVisibilityPDF.Add(footer)
                        End If

                        'ReportDoc.HasMorePages = True
                        Exit Function
                    End If
                End If
            Next

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp") Then
                Dim footer As Image = Image.GetInstance(docfooterpath)
                footer.ScaleToFit(842, 15)
                footer.SetAbsolutePosition(0, 10)
                StandardVisibilityPDF.Add(footer)
            End If


            DrawLine(StringWriter, 30, (b * 25) + 212, 1120, (b * 25) + 212)
            rect = New Rectangle(870 * 0.75, 0.75 * (b * 25 + 192), 0.75 * 895, 595 - 0.75 * (b * 25 + 212))
            Call RightAligned("#.##", StringWriter, rect, font8b)


            b = b + 1
            DrawLine(StringWriter, 30, (b * 25) + 212, 1120, (b * 25) + 212)
            d = 0
            f = 0

            StandardVisibilityPDF.Close()
            Dim bytes As Byte() = memoryStream.ToArray()
            Return bytes
            memoryStream.Close()
        End Using
    End Function

End Class
