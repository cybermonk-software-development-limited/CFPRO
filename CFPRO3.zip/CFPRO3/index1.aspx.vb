﻿Public Class index1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            If IsNothing(Request.Cookies("CFPROToken")) Then
                Call RegisterToken()
            ElseIf Request.Cookies("CFPROToken").Value = "" Then
                Call RegisterToken()
            End If

            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            Call clsAuth.UserLoggedIn("", "", "", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, "", False)


        End If

    End Sub


    Private Sub RegisterToken()
        Try

            If Not IsNothing(Request.QueryString("logintoken")) Then


                Response.Cookies("CFPROToken").Value = (Request.QueryString("logintoken"))
                Response.Cookies("CFPROToken").Expires = Now.AddHours(6)

                If Not IsNothing(Request.QueryString("gotooption")) Then
                    Response.Redirect(Request.QueryString("gotooption"))
                End If
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Protected Sub LinkButtonCFAgent_Click(sender As Object, e As EventArgs) Handles LinkButtonCFAgent.Click


        If IsNothing(Request.Cookies("CFPROToken")) Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=jobentry.aspx")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=jobentry.aspx")
            End If

        ElseIf Request.Cookies("CFPROToken").Value = "" Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=jobentry.aspx")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=jobentry.aspx")
            End If
        Else
            Response.Redirect("jobentry.aspx")
        End If



    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=index.aspx")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
            End If
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
        End If
    End Sub

    Protected Sub LinkButtonImporter1_Click(sender As Object, e As EventArgs) Handles LinkButtonImporter1.Click
        If IsNothing(Request.Cookies("CFPROToken")) Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
            End If

        ElseIf Request.Cookies("CFPROToken").Value = "" Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
            End If
        Else
            Response.Redirect("cfproimportercfagents.aspx?importerdashboard=mobile")
        End If
    End Sub

    Protected Sub LinkButtonImporter_Click(sender As Object, e As EventArgs) Handles LinkButtonImporter.Click
        If IsNothing(Request.Cookies("CFPROToken")) Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
            End If

        ElseIf Request.Cookies("CFPROToken").Value = "" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
        Else
            Response.Redirect("cfproimportercfagents.aspx?importerdashboard=normal")
        End If
    End Sub

End Class