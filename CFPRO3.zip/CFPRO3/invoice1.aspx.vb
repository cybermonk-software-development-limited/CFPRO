﻿
Imports System.Data
Imports System.Drawing
Imports System.Web.UI.HtmlControls

Public Class invoice1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

        End If

    End Sub

    Protected Sub OnRowDataBound2(sender As Object, e As GridViewRowEventArgs) Handles GridInvoiceParticulars.RowDataBound

    End Sub

    Protected Sub OnSelectedIndexChanged2(sender As Object, e As EventArgs) Handles GridInvoiceParticulars.SelectedIndexChanged

    End Sub

    Protected Sub OnRowDataBound1(sender As Object, e As GridViewRowEventArgs) Handles GridItems.RowDataBound

    End Sub

    Protected Sub OnSelectedIndexChanged1(sender As Object, e As EventArgs) Handles GridItems.SelectedIndexChanged

    End Sub
End Class
