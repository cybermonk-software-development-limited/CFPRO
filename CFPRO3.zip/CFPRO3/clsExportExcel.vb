﻿Imports System.Drawing
Imports System.IO
Imports OfficeOpenXml


Public Class clsExportToExcel

    Shared Function ExportToExcel(CFPROID As String, Filter As String, Sort As String, FileName As String, FileTitle As String,
                             SubTitle As String, HasTotals As Boolean, Totals() As String, MaxRows As Integer,
                             ByRef ErrMsg As String, Optional Fields() As String = Nothing, Optional Columns() As String = Nothing,
                             Optional tmptable As DataTable = Nothing, Optional SaveExcelDoc As Boolean = False) As String
        Try

            Dim tmpfields(0) As String
            Dim tmpcols(0) As String
            ReDim Preserve Totals(11)
            Dim a As Integer

            If Not IsNothing(Fields) Then
                tmpfields = Fields
            Else
                If Not IsNothing(tmptable) Then
                    ReDim tmpfields(tmptable.Columns.Count - 1)
                    For a = 0 To tmptable.Columns.Count - 1
                        tmpfields(a) = tmptable.Columns(a).ColumnName
                    Next
                Else
                    Return 0
                End If
            End If

            If Not IsNothing(Columns) Then
                tmpcols = Columns
            Else
                tmpcols = tmpfields
            End If

            Dim Company As String = ""
            Call clsAuth.AuthCFAgent("", Company, "", "", "", "", False)


            FileTitle = FileTitle & ": " & Company



            Dim dv As DataView = tmptable.DefaultView

            If Not Filter = "" Then
                dv.RowFilter = Filter
            End If

            If Not Sort = "" Then
                dv.Sort = Sort
            End If

            If dv.Count > 0 Then
                Dim excel As New ExcelPackage()


                Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
                Dim totalCols = tmpfields.GetUpperBound(0) + 1
                Dim totalRows = dv.Count


                Dim lcol As String = GetExcelColumnName(totalCols + 1)

                For a = 2 To totalCols + 1
                    workSheet.Cells(5, a).Value = tmpcols(a - 2)
                Next

                workSheet.Cells("B3:" & lcol & "3").Merge = True
                workSheet.Cells("B4:" & lcol & "4").Merge = True

                workSheet.Cells("B3:" & lcol & "3").Style.Font.Size = 14
                workSheet.Cells("B4:" & lcol & "4").Style.Font.Size = 9
                workSheet.Cells("B3:" & lcol & "4").Style.Font.Bold = True

                'WORKSHEET TITLE(Displayed on Worksheet)
                workSheet.Cells(3, 2).Value = FileTitle
                workSheet.Cells(4, 2).Value = SubTitle


                Dim b As Integer
                Dim row As Integer
                For row = 5 To totalRows + 4
                    b = row - 5
                    Call clsData.NullChecker1(dv, b)


                    For a = 1 To totalCols
                        If tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.DateTime") Then
                            If Not CDate(dv(b)(tmpfields(a - 1))) <= CDate("1-Jan-1800") Then
                                workSheet.Cells(row + 1, a + 1).Value = Format(dv(b)(tmpfields(a - 1)), "dd MMM yyyy")
                            End If
                        ElseIf tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.Double") Then
                            workSheet.Cells(row + 1, a + 1).Value = CDbl(Format(dv(b)(tmpfields(a - 1)), "#,##0.00"))
                            workSheet.Cells(row + 1, a + 1).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
                            workSheet.Cells(row + 1, a + 1).Style.Numberformat.Format = "#,#0.00"

                            workSheet.Cells(5, a + 1).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right

                        ElseIf tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.Decimal") Then
                            workSheet.Cells(row + 1, a + 1).Value = CDbl(Format(dv(b)(tmpfields(a - 1)), "#,##0.00"))
                            workSheet.Cells(row + 1, a + 1).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
                            workSheet.Cells(row + 1, a + 1).Style.Numberformat.Format = "#,#0.00"

                            workSheet.Cells(5, a + 1).Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
                        Else
                            workSheet.Cells(row + 1, a + 1).Value = dv(b)(tmpfields(a - 1)).ToString
                        End If

                        workSheet.Cells(row + 1, a + 1).Style.VerticalAlignment = Style.ExcelVerticalAlignment.Top
                        workSheet.Cells(row + 1, a + 1).Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
                        workSheet.Cells(row + 1, a + 1).Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
                        workSheet.Cells(row + 1, a + 1).Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
                        workSheet.Cells(row + 1, a + 1).Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair

                    Next


                Next

                Using rng As ExcelRange = workSheet.Cells("B5:" & lcol & "" & dv.Count + 5)
                    'rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
                    'rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
                    'rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
                    'rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
                    rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                    rng.AutoFitColumns()
                    rng.Style.Font.Size = 9
                End Using


                Using rng As ExcelRange = workSheet.Cells("B3:" & lcol & "5")
                    rng.Style.Font.Bold = True
                    rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                    rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                End Using


                If HasTotals Then
                    row = row + 2
                    Using rng As ExcelRange = workSheet.Cells("B" & row & ":G" & row)
                        rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
                        rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
                        rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
                        rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                        rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                        rng.Style.Font.Size = 10
                        rng.Style.Font.Bold = True
                        rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Left
                    End Using


                    workSheet.Cells("B" & row & ":C" & row).Merge = True
                    workSheet.Cells("D" & row & ":E" & row).Merge = True
                    workSheet.Cells("F" & row & ":G" & row).Merge = True


                    workSheet.Cells("B" & row).Value = Totals(0)
                    workSheet.Cells("D" & row).Value = Totals(1)
                    workSheet.Cells("F" & row).Value = Totals(2)


                    If Not IsNothing(Totals(3)) Then
                        row = row + 1
                        Using rng As ExcelRange = workSheet.Cells("B" & row & ":G" & row)
                            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                            rng.Style.Font.Size = 10
                            rng.Style.Font.Bold = True
                            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Left
                        End Using

                        workSheet.Cells("B" & row & ":C" & row).Merge = True
                        workSheet.Cells("B" & row).Value = Totals(3) '"Total TEU: " & TextTotalQty.Text
                    End If

                    If Not IsNothing(Totals(4)) Then
                        workSheet.Cells("D" & row & ":E" & row).Merge = True
                        workSheet.Cells("D" & row).Value = Totals(4) '"Total TEU: " & TextTotalQty.Text
                    End If

                    If Not IsNothing(Totals(5)) Then
                        workSheet.Cells("F" & row & ":G" & row).Merge = True
                        workSheet.Cells("F" & row).Value = Totals(5)
                    End If




                    If Not IsNothing(Totals(6)) Then
                        row = row + 1
                        Using rng As ExcelRange = workSheet.Cells("B" & row & ":G" & row)
                            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                            rng.Style.Font.Size = 10
                            rng.Style.Font.Bold = True
                            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Left
                        End Using


                        workSheet.Cells("B" & row & ":C" & row).Merge = True
                        workSheet.Cells("B" & row).Value = Totals(6)
                    End If


                    If Not IsNothing(Totals(7)) Then
                        workSheet.Cells("D" & row & ":E" & row).Merge = True
                        workSheet.Cells("D" & row).Value = Totals(7) '"Total TEU: " & TextTotalQty.Text
                    End If

                    If Not IsNothing(Totals(8)) Then
                        workSheet.Cells("F" & row & ":G" & row).Merge = True
                        workSheet.Cells("F" & row).Value = Totals(8)
                    End If


                    If Not IsNothing(Totals(9)) Then
                        row = row + 1
                        Using rng As ExcelRange = workSheet.Cells("B" & row & ":G" & row)
                            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                            rng.Style.Font.Size = 10
                            rng.Style.Font.Bold = True
                            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Left
                        End Using


                        workSheet.Cells("B" & row & ":C" & row).Merge = True
                        workSheet.Cells("B" & row).Value = Totals(9)
                    End If


                    If Not IsNothing(Totals(10)) Then
                        workSheet.Cells("D" & row & ":E" & row).Merge = True
                        workSheet.Cells("D" & row).Value = Totals(10) '"Total TEU: " & TextTotalQty.Text
                    End If

                    If Not IsNothing(Totals(11)) Then
                        workSheet.Cells("F" & row & ":G" & row).Merge = True
                        workSheet.Cells("F" & row).Value = Totals(11)
                    End If
                End If

                Dim imagePath As String = HttpRuntime.AppDomainAppPath & "/ReportStamp.png"

                If IO.File.Exists(imagePath) Then
                    Using img As System.Drawing.Image = Image.FromFile(imagePath)
                        workSheet.Drawings.AddPicture("picture1", img)
                        workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
                    End Using
                End If

                If Not SaveExcelDoc Then

                    Using memoryStream = New MemoryStream()
                        HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        HttpContext.Current.Response.AddHeader("content-disposition", "attachment;  filename=" & FileName & " " & Format(Now, "dd MMM yyyy hh mm tt") & ".xlsx")
                        excel.SaveAs(memoryStream)
                        memoryStream.WriteTo(HttpContext.Current.Response.OutputStream)
                        HttpContext.Current.Response.Flush()
                        HttpContext.Current.Response.[End]()
                    End Using
                Else

                    Dim ExcelDocsPath As String = HttpRuntime.AppDomainAppPath & "\exceldocuments"
                    If Not Directory.Exists(ExcelDocsPath) Then
                        Directory.CreateDirectory(ExcelDocsPath)
                    End If

                    If Not Directory.Exists(ExcelDocsPath & "\" & CFPROID) Then
                        Directory.CreateDirectory(ExcelDocsPath & "\" & CFPROID)
                    End If

                    Dim ExcelDoc As String = ExcelDocsPath & "\" & CFPROID & "\" & FileName & ".xlsx"


                    If File.Exists(ExcelDoc) Then
                        File.Delete(ExcelDoc)
                    End If

                    Using memoryStream = New MemoryStream()

                        excel.SaveAs(memoryStream)
                        Dim bytes As Byte() = memoryStream.ToArray()

                        Using fs As FileStream = File.Create(ExcelDoc)
                            fs.Write(bytes, 0, CInt(bytes.Length))
                        End Using

                        memoryStream.Close()
                    End Using

                    Return "~/exceldocuments/" & CFPROID & "/" & FileName & ".xlsx"
                End If
            Else
                Return 0
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

        Return 0
    End Function

    Shared Function GetExcelColumnName(columnNumber As Integer) As String
        Dim dividend As Integer = columnNumber
        Dim columnname As String = String.Empty
        Dim modulo As Integer
        While dividend > 0
            modulo = (dividend - 1) Mod 26
            columnname = Convert.ToChar(65 + modulo).ToString() + columnname
            dividend = Convert.ToInt32((dividend - modulo) / 26)
        End While

        Return columnname

    End Function
























End Class
