﻿Imports System.Drawing
Public Class marineinsurancepurchase
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If


            Dim ClientID As String = ""
            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Dim AuthAgent As Boolean

            If Not IsNothing(Request.Cookies("UserType")) Then
                If Request.Cookies("UserType").Value = "cfagent" Then
                    AuthAgent = True
                End If
            End If


            Dim UserName As String = ""
            Dim CSDID As String = ""
            Call clsAuth.UserLogin(CSDID, CFPROID, CFPROUserID, UserName, "", "", "", "", AuthAgent, "", False)
            LabelCSDID.Text = CSDID
            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If IsNothing(Request.QueryString("insurablesum")) Then
                TextInsurableSum.Text = "0.00"
            Else
                TextInsurableSum.Text = Request.QueryString("insurablesum")
            End If

            If Not IsNothing(Request.QueryString("clientid")) Then
                ClientID = Request.QueryString("clientid")
            End If


            If UserName = "Guest" Then
                LabelCoverDetailsAutoFilled.Text = 0
            End If

            Call LoadUserClientDetails(clsEncr.EncryptString(CSDID), CFPROID, CFPROUserID, ClientID)

            Dim PolicyID As String = ""

            If Not IsNothing(Request.QueryString("policyid")) Then
                PolicyID = Request.QueryString("policyid")
            End If

            If PolicyID = "" Then
                Dim EmailAddress As String = ""

                If Not IsNothing(Request.Cookies("CFPROMCI")) Then
                    Dim tmpPolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMCI").Value)
                    Dim tmpstr() As String = tmpPolicyID.Split("|")
                    ReDim Preserve tmpstr(1)

                    If IsValidPolicyID(tmpstr(0)) Then
                        PolicyID = tmpstr(0)
                        EmailAddress = tmpstr(1)
                    End If
                End If

                If TextEmailAddress.Text = "" Then
                    If Not EmailAddress = "" Then
                        LabelPolicyID.Text = PolicyID
                        TextEmailAddress.Text = EmailAddress
                    End If
                Else

                    If LCase(TextEmailAddress.Text) = LCase(EmailAddress) Then
                        LabelPolicyID.Text = PolicyID
                    Else
                        Call PreserveUserActivity(2)
                        PolicyID = LabelPolicyID.Text
                    End If
                End If
            End If

            Call LoadInsurer()
            Call LoadCargoCategories()
            Call LoadCurrencies()

            Dim DocumentCount As Integer = 0

            If Not PolicyID = "" Then
                Call LoadPolicy(PolicyID)

                DocumentCount = clsDocuments.DocumentCount(CFPROID, "", "", PolicyID, "policy", "insurance", LabelMessage1.Text)

                If NoCoverDetails() Then
                    LabelCoverDetailFilled.Text = 0
                Else
                    LabelCoverDetailFilled.Text = 1
                End If

            Else
                LabelCoverDetailFilled.Text = 0
            End If



            If Not IsNothing(Request.QueryString("goback")) Then
                HyperLinkGoBack.NavigateUrl = Request.QueryString("goback")
            Else
                HyperLinkGoBack.Visible = False
            End If

            ButtonRequiredDocuments.Text = "Required Documents - " & DocumentCount & "/6"

        End If
    End Sub

    Private Sub LoadCurrencies()
        Dim sqlstr As String =
            "SELECT   CurrencyID, Currency, CurrencyCode " &
             "FROM Currencies " &
             "Order By Currency Asc"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        For Each drow In tmptable.Rows
            ComboCurrency.Items.Add(drow("Currency") & " - " & drow("CurrencyCode"))
            ComboCurrency.Items(ComboCurrency.Items.Count - 1).Value = drow("CurrencyCode")
        Next

        If ComboCurrency.Items.Count > 0 Then
            ComboCurrency.SelectedValue = "USD"
        End If
    End Sub
    Private Sub LoadUserClientDetails(CSDID As String, CFPROID As String, CFPROUserID As String, ClientID As String)

        Dim CSDEndPoint As String = "" '"http://csdwcfservice.cybermonksd.com/"
        Dim EndPointConfigName As String = "BasicHttpBinding_ICSDService1"


        Dim host As String = HttpContext.Current.Request.Url.Host
        Dim host1 As String = ""

        Dim nLoginURL As String = clsAuth.LoginURL()

        If nLoginURL = "" Then
            host1 = host
        Else
            host1 = nLoginURL
        End If

        If host1.Contains("com") Then
            CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"

        ElseIf host1.Contains("azurewebsites") Then
            CSDEndPoint = "http://csdwcfservice.azurewebsites.net/CSDService1.svc"

        ElseIf host.Contains("localhost") Then
            If nLoginURL = "" Then
                CSDEndPoint = "http://localhost:98"
            Else
                CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"
            End If

        ElseIf clsauth.IsIPAdress(host) Then
            If nLoginURL = "" Then
                CSDEndPoint = "http://" & host & ":98"

            ElseIf nLoginURL.Contains("cybermonksd") Then
                CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"

            ElseIf nLoginURL.Contains("azurewebsites") Then
                CSDEndPoint = "http://csdwcfservice.azurewebsites.net/CSDService1.svc"

            End If

        Else
            CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"
        End If





        If CFPROID = "" Then

            Dim tmptable As New DataTable("CSDUSer")

            Dim CSDWCFService1 As New CSDWCFService.CSDService1Client(EndPointConfigName, CSDEndPoint)

            tmptable = CSDWCFService1.CSDUserDetails(CSDID, "")
            CSDWCFService1.Close()

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                TextEmailAddress.Text = drow("EmailAddress")
                TextUserNames.Text = drow("UserNames")
                TextTelephone.Text = drow("Telephone")

                TextClientEmailAddress.Text = drow("EmailAddress")
                TextClientNames.Text = drow("UserNames")
                TextClientTelephone.Text = drow("Telephone")
                CheckAutoFill.Checked = True
                LabelCoverDetailsAutoFilled.Text = 1

            End If
        End If


        If Not CFPROUserID = "" Then
            Dim sqlstr As String = _
             "Select UserNames," & _
              "Email,Telephone " & _
              "From CFAgentUsers " & _
              "Where CFPROID ='" & CFPROID & "' " &
              "And UserID = '" & CFPROUserID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                TextEmailAddress.Text = drow("Email")
                TextUserNames.Text = drow("UserNames")
                TextTelephone.Text = drow("Telephone")
            End If
        End If

        If Not ClientID = "" Then
            Dim sqlstr As String = _
               "Select Client," & _
               "Email, Telephone " & _
               "From  Clients " & _
               "Where CFPROID = '" & CFPROID & "' " & _
               "And  ClientID = '" & ClientID & "' "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                TextClientEmailAddress.Text = drow("Email")
                TextClientNames.Text = drow("Client")
                TextClientTelephone.Text = drow("Telephone")
            End If
        End If

    End Sub
    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, " & _
            "Insurer,ProductName," & _
            "Description, URL," & _
            "EmailAddress,Telephone, SystemFees " & _
            "FROM MarineCargoInsurer "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)


        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)
            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")

            HyperLinkCompany.Text = drow("Insurer")
            HyperLinkCompany.NavigateUrl = drow("URL")


            LabelContacts.Text = drow("Contacts")
            LabelAboutPolicyURL.Text = "marineproductdesc.aspx?insurerid=" & drow("InsurerID")
            LabelSystemFees.Text = Format(drow("SystemFees"), "#,##0.00")

        End If

    End Sub


    Private Sub LoadCargoCategories()
        Dim sqlstr As String = _
            "SELECT  CategoryID, Category " & _
            "FROM MarineCargoCategories " &
            "Order By Category Asc;"

        Call clsData.PopCombo1a(ComboCargoCategories, sqlstr, clsData.constr, 0, 1)

    End Sub

    Private Sub CargoType(CategoryID As String)
        Dim sqlstr As String = _
            "SELECT CargoID, CargoDesc, Conditions,CategoryID  " & _
            "FROM MarineCargo " & _
            "Where CategoryID = '" & CategoryID & "' "

        ComboCargoType.Items.Clear()

        Call clsData.PopCombo1a(ComboCargoType, sqlstr, clsData.constr, 0, 1)
    End Sub


    Protected Sub ComboCargoCategories_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCargoCategories.SelectedIndexChanged
        Call CargoType(ComboCargoCategories.SelectedValue)
    End Sub

    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        LoadDialog("sendmessage.aspx?jobid=0&sendercsdid=" & LabelCSDID.Text & "&receivercsdid=" & LabelCFPROID.Text & "&CFPROID=" & LabelCFPROID.Text, "Send Message")
    End Sub

    Protected Sub ButtonCalculatePremium_Click(sender As Object, e As EventArgs) Handles ButtonCalculatePremium.Click

        Dim sea As Boolean
        If RadioButtonList1.SelectedIndex = 1 Then
            sea = True
        End If

        Dim containerised As Boolean
        If RadioButtonList2.SelectedIndex = 1 Then
            containerised = True
        End If

        Call CalculatePremuim(ComboCargoCategories.SelectedValue, ComboCargoType.SelectedValue, containerised, sea)
    End Sub

    Private Sub CalculatePremuim(CategoryID As String, CargoID As String, NonContainerised As Boolean, isAirFreight As Boolean)

        Try
            Label75.ForeColor = Color.Black
            Label83.ForeColor = Color.Black
            Label84.ForeColor = Color.Black
            LabelMessage.ForeColor = Color.Black
            LabelTotalPayable.ForeColor = Color.Black
            LabelInsurableAmount.ForeColor = Color.Black

            LabelMessage.Text = "Select Category of Cargo, Cargo Type, Enter Insurable sum and click Calculate."

            If CategoryID = "(select)" Then
                LabelMessage.Text = "Please Select Cargo Category"
                LabelMessage.ForeColor = Color.Red
                Label83.ForeColor = Color.Red
                Exit Sub
            End If


            If CargoID = "(select)" Then
                LabelMessage.Text = "Please Select Your Cargo Type"
                LabelMessage.ForeColor = Color.Red
                Label84.ForeColor = Color.Red
                Exit Sub
            End If


            Dim InsuredAmount As String = TextInsurableSum.Text
            InsuredAmount = InsuredAmount.Replace(" ", "")
            InsuredAmount = InsuredAmount.Replace(",", "")

            If Not IsNumeric(InsuredAmount) Then
                LabelMessage.Text = "Insurable Amount is not a valid Number"
                LabelMessage.ForeColor = Color.Red
                Label75.ForeColor = Color.Red
                Exit Sub
            End If

            TextInsurableSum.Text = Format(CDbl(InsuredAmount), "#,##0.00")

            Dim ExchnageRate As String = clsAccounts.convertCurrency(ComboCurrency.SelectedValue, "KES", LabelMessage1.Text)

            TextExchangeRate.Text = Format(CDbl(ExchnageRate), "#,##0.00")
            TextInsurableSumKES.Text = Format(CDbl(InsuredAmount) * CDbl(ExchnageRate), "#,##0.00")



            Dim InsuredAmountKES As String = TextInsurableSumKES.Text

            If InsuredAmountKES < 5000 Then
                LabelMessage.Text = "Insurable Amount is too small."
                LabelMessage.ForeColor = Color.Red
                LabelInsurableAmount.ForeColor = Color.Red
                Exit Sub
            End If

            Dim sqlstr As String = _
              "SELECT CategoryID, InsurerID," &
              "PremiumBase, PolicyHolderFundBase," &
              "TrainingLevyBase, PremiumContainerised," &
              "PremiumNonContainerised, TrainingLevy," &
              "StampDuty, PolicyHolderFund, AirFreight," &
              "MinimumPremiumCont, MaximumPremiumCont," &
              "MinimumPremiumNonCont, MaximumPremiumNonCont," &
              "AirFreightMinimum, AirFreightMaximum " &
              "FROM MarineCategoryRates " & _
              "Where CategoryID = '" & CategoryID & "' "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String = _
               "SELECT InsurerID, CategoryID," &
               "CargoID, PremiumBase,PremiumContainerised," &
               "PremiumNonContainerised, MinimumPremiumCont," &
               "MaximumPremiumCont, MinimumPremiumNonCont," &
               "MaximumPremiumNonCont, AirFreight," &
               "AirFreightMinimum, AirFreightMaximum " &
               "FROM MarineCargoRates " &
               "Where CargoID = '" & CargoID & "' "


            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim drow, drow1 As DataRow

            Dim nInsuredAmount As Double = TextInsurableSumKES.Text

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)


                Dim PolicyHolderFundBase As Double = drow("PolicyHolderFundBase")
                Dim TrainingLevyBase As Double = drow("TrainingLevyBase")

                Dim StampDuty As Double = drow("StampDuty") * nInsuredAmount
                Dim PolicyHolderFund As Double = drow("PolicyHolderFund") * nInsuredAmount
                Dim TrainingLevy As Double = drow("TrainingLevy") * nInsuredAmount

                Dim Premium As Double = 0
                Dim AirFreight As Double = 0
                Dim MinimumPremiumCont As Double = 0
                Dim Total As Double = 0
                Dim MaximumPremiumCont As Double = 0
                Dim MinimumPremiumNonCont As Double = 0
                Dim MaximumPremiumNonCont As Double = 0
                Dim AirFreightMinimum As Double = 0
                Dim AirFreightMaximum As Double = 0

                If tmptable1.Rows.Count > 0 Then
                    Call clsData.NullChecker(tmptable1, 0)
                    drow1 = tmptable1.Rows(0)

                    If drow1("PremiumBase") > 0 Then
                        Premium = drow1("PremiumBase")
                    End If

                    AirFreight = drow1("AirFreight") * nInsuredAmount
                    MinimumPremiumCont = drow1("MinimumPremiumCont")
                    MaximumPremiumCont = drow1("MaximumPremiumCont")
                    MinimumPremiumNonCont = drow1("MinimumPremiumNonCont")
                    MaximumPremiumNonCont = drow1("MaximumPremiumNonCont")
                    AirFreightMinimum = drow1("AirFreightMinimum")
                    AirFreightMaximum = drow1("AirFreightMaximum")
                Else
                    Premium = drow("PremiumBase")
                    AirFreight = drow("AirFreight") * nInsuredAmount
                    MinimumPremiumCont = drow("MinimumPremiumCont")
                    MaximumPremiumCont = drow("MaximumPremiumCont")
                    MinimumPremiumNonCont = drow("MinimumPremiumNonCont")
                    MaximumPremiumNonCont = drow("MaximumPremiumNonCont")
                    AirFreightMinimum = drow("AirFreightMinimum")
                    AirFreightMaximum = drow("AirFreightMaximum")
                End If



                Dim SystemFee As Double = LabelSystemFees.Text


                If NonContainerised Then
                    If (drow("PremiumNonContainerised") * nInsuredAmount) > Premium Then
                        Premium = (drow("PremiumNonContainerised") * nInsuredAmount)
                    End If
                Else
                    If (drow("PremiumContainerised") * nInsuredAmount) > Premium Then
                        Premium = (drow("PremiumContainerised") * nInsuredAmount)
                    End If
                End If


                If TrainingLevyBase > 0 And TrainingLevy < TrainingLevyBase Then
                    TrainingLevy = TrainingLevyBase
                End If


                If PolicyHolderFund > 0 And PolicyHolderFund < PolicyHolderFundBase Then
                    PolicyHolderFund = PolicyHolderFundBase
                End If


                'If NonContainerised Then
                '    If MaximumPremiumNonCont > 0 And Premium > MaximumPremiumNonCont Then
                '        Premium = MaximumPremiumNonCont
                '    ElseIf MinimumPremiumNonCont > 0 And Premium < MinimumPremiumNonCont Then
                '        Premium = MinimumPremiumNonCont
                '    End If
                'Else
                '    If MaximumPremiumCont > 0 And Premium > MaximumPremiumCont Then
                '        Premium = MaximumPremiumCont
                '    ElseIf MinimumPremiumCont > 0 And Premium < MinimumPremiumCont Then
                '        Premium = MinimumPremiumCont
                '    End If
                'End If


                'If AirFreightMaximum > 0 And AirFreight > AirFreightMaximum Then
                '    AirFreight = AirFreightMaximum
                'ElseIf AirFreightMinimum > 0 And AirFreight < AirFreightMinimum Then
                '    AirFreight = AirFreightMinimum
                'End If


                If isAirFreight Then
                    If AirFreight > Premium Then
                        Premium = AirFreight
                    End If
                End If

                Total = Premium + TrainingLevy + PolicyHolderFund + StampDuty + SystemFee

                TextPremium.Text = Format(Premium, "#,##0.00")
                TextStampDuty.Text = Format(StampDuty, "#,##0.00")
                TextTrainingLevy.Text = Format(TrainingLevy, "#,##0.00")
                TextPolicyHolderFund.Text = Format(PolicyHolderFund, "#,##0.00")
                TextSystemFees.Text = Format(SystemFee, "#,##0.00")
                TextTotal.Text = Format(Total, "#,##0.00")

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Protected Sub ButtonPurchaseCover_Click(sender As Object, e As EventArgs) Handles ButtonPurchaseCover.Click

        If LabelCoverDetailsAutoFilled.Text = 1 Then
            LabelCoverDetailsAutoFilled.Text = 0
            ModalPopupExtender5.Show()
        Else
            If LabelCoverDetailFilled.Text = 1 Then
                Call PurchasePolicy(LabelCFPROID.Text, LabelCSDID.Text, Trim(TextEmailAddress.Text))
            Else
                ModalPopupExtender5.Show()
            End If
        End If
    End Sub

    Private Sub LoadPolicy(PolicyID As String)

        Dim sqlstr As String =
                "SELECT CSDID, PolicyID,PurchaseDate," &
                "UserNames, EmailAddress, " &
                "Telephone,ClientNames," &
                "ClientEmailAddress, ClientTelephone," &
                "CategoryID, CargoID," &
                "AmountInsured,Currency,ExchangeRate," &
                "AmountInsuredKES,Premium, " &
                "TrainingLevy, StampDuty," &
                "PolicyHolderFund, SystemFees," &
                "Total, Status, " &
                "JobId,ClientIDNo, ClientPIN," &
                "OriginPort, DestinationCountry," &
                "DestinationPort, ViaPort, " &
                "Vessel, ID " &
                "FROM MarineInsurancePolicies " &
                "Where PolicyID ='" & PolicyID & "' " &
                "And Status ='" & "Started" & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            TextEmailAddress.Text = drow("EmailAddress")
            TextUserNames.Text = drow("UserNames")
            TextTelephone.Text = drow("Telephone")

            TextClientNames.Text = drow("ClientNames")
            TextClientEmailAddress.Text = drow("ClientEmailAddress")
            TextClientTelephone.Text = drow("ClientTelephone")
            TextIDNo.Text = drow("ClientIDNo")
            TextPIN.Text = drow("ClientPIN")

            TextInsurableSum.Text = Format(drow("AmountInsured"), "#,##0.00")
            ComboCurrency.SelectedValue = drow("Currency")

            TextExchangeRate.Text = Format(drow("ExchangeRate"), "#,##0.00")
            TextInsurableSumKES.Text = Format(drow("AmountInsuredKES"), "#,##0.00")

            TextTrainingLevy.Text = Format(drow("TrainingLevy"), "#,##0.00")
            TextStampDuty.Text = Format(drow("StampDuty"), "#,##0.00")
            TextPolicyHolderFund.Text = Format(drow("PolicyHolderFund"), "#,##0.00")
            TextSystemFees.Text = Format(drow("SystemFees"), "#,##0.00")
            TextPremium.Text = Format(drow("Premium"), "#,##0.00")
            TextTotal.Text = Format(drow("Total"), "#,##0.00")

            Call CargoType(drow("CategoryID"))

            ComboCargoCategories.SelectedValue = drow("CategoryID")
            ComboCargoType.SelectedValue = drow("CargoID")


        End If

    End Sub
    Private Sub PurchasePolicy(CFPROID As String, CSDID As String, EmailAddress As String)
        Try


            If CDbl(TextTotal.Text) <= 0 Then
                Label75.ForeColor = Color.Red
                LabelTotalPayable.ForeColor = Color.Red
                LabelMessage.Text = "Please provide all required details. See items marked in red"
                Exit Sub
            End If




            Dim PolicyID As String = ""


            If Not IsNothing(Request.Cookies("CFPROMCI")) Then
                Dim tmpPolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMCI").Value)
                Dim tmpstr() As String = tmpPolicyID.Split("|")
                ReDim Preserve tmpstr(1)

                If IsValidPolicyID(tmpstr(0)) Then
                    If EmailAddress = tmpstr(1) Then
                        PolicyID = tmpstr(0)
                    Else
                        PolicyID = GetPolicyID()
                    End If
                Else
                    PolicyID = GetPolicyID()
                End If

            Else
                PolicyID = GetPolicyID()
            End If

            Dim sqlstr As String =
                 "SELECT CFPROID,CSDID," &
                 "PolicyID,PurchaseDate," &
                 "UserNames, EmailAddress, " &
                 "Telephone,ClientNames," &
                 "ClientEmailAddress, ClientTelephone," &
                 "CategoryID, CargoID," &
                 "AmountInsured,Currency, ExchangeRate," &
                 "AmountInsuredKES, Premium," &
                 "TrainingLevy, StampDuty," &
                 "PolicyHolderFund, SystemFees," &
                 "Total, Status, " &
                 "JobId,ClientIDNo, ClientPIN," &
                 "OriginPort, DestinationCountry," &
                 "DestinationPort, ViaPort, " &
                 "Vessel, ID " &
                 "FROM MarineInsurancePolicies " &
                 "Where PolicyID ='" & PolicyID & "' " &
                 "And Status ='" & "Started" & "' "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("PolicyID") = PolicyID
                drow("PurchaseDate") = TodaysDate.Value
                drow("CSDID") = LabelCSDID.Text
                drow("Status") = "Started"
                tmptable.Rows.Add(drow)
            Else
                drow = tmptable.Rows(0)
            End If

            drow("EmailAddress") = Trim(TextEmailAddress.Text)
            drow("CFPROID") = CFPROID
            drow("UserNames") = Trim(TextUserNames.Text)
            drow("Telephone") = Trim(TextTelephone.Text)

            drow("ClientNames") = Trim(TextClientNames.Text)
            drow("ClientEmailAddress") = Trim(TextClientEmailAddress.Text)
            drow("ClientTelephone") = Trim(TextClientTelephone.Text)
            drow("ClientIDNo") = Trim(TextIDNo.Text)
            drow("ClientPIN") = Trim(TextPIN.Text)

            drow("AmountInsured") = Trim(TextInsurableSum.Text)
            drow("Currency") = ComboCurrency.SelectedValue

            drow("ExchangeRate") = Trim(TextExchangeRate.Text)
            drow("AmountInsuredKES") = Trim(TextInsurableSumKES.Text)

            drow("TrainingLevy") = TextTrainingLevy.Text
            drow("StampDuty") = TextStampDuty.Text
            drow("PolicyHolderFund") = TextPolicyHolderFund.Text
            drow("SystemFees") = TextSystemFees.Text
            drow("Premium") = TextPremium.Text
            drow("Total") = TextTotal.Text


            drow("CategoryID") = ComboCargoCategories.SelectedValue
            drow("CargoID") = ComboCargoType.SelectedValue



            Call clsData.SaveData("MarineInsurancePolicies", tmptable, sqlstr, False, clsData.constr)

            LabelPolicyID.Text = PolicyID
            Dim PolicyCertURL As String = "marinecargoinsurancecertificate.aspx?policyid=" & HttpUtility.UrlEncode(clsEncr.EncryptString(PolicyID))


            Dim PolicyID1 As String = clsEncr.EncryptString(PolicyID & "|" & EmailAddress)
            Response.Cookies("CFPROMCI").Value = PolicyID1
            Response.Cookies("CFPROMCI").Expires.AddHours(1)

            If CSDID = "" Then
                CSDID = "-"
            End If

            Call clsAuth.SendToPayment(Trim(TextUserNames.Text), _
                               Trim(TextEmailAddress.Text), Trim(TextTelephone.Text), CSDID, _
                               "EP00000001", TextTotal.Text, PolicyCertURL, PolicyID, LabelMessage1.Text)

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub
    Private Function NoCoverDetails() As Boolean

        Label75.ForeColor = Color.Black
        LabelTotalPayable.ForeColor = Color.Black
        Label90.ForeColor = Color.Black
        Label91.ForeColor = Color.Black
        Label92.ForeColor = Color.Black

        Label97.ForeColor = Color.Black
        Label98.ForeColor = Color.Black
        Label100.ForeColor = Color.Black
        Label101.ForeColor = Color.Black
        Label102.ForeColor = Color.Black

        Dim ErrFound As Boolean = False
        If Trim(TextUserNames.Text) = "" Then
            Label90.ForeColor = Color.Red
            ErrFound = True
        End If


        If Trim(TextEmailAddress.Text) = "" Then
            Label91.ForeColor = Color.Red
            ErrFound = True
        End If


        If InStr(Trim(TextEmailAddress.Text), "@", CompareMethod.Text) = 0 Then
            Label91.ForeColor = Color.Red
            Label91.Text = "Email address missing - @"
            ErrFound = True
        End If


        If Trim(TextTelephone.Text) = "" Then
            Label92.ForeColor = Color.Red
            Label92.Text = "Telephone number is too Short."
            ErrFound = True
        End If

        If Trim(TextTelephone.Text).Length < 9 Then
            Label92.ForeColor = Color.Red
            ErrFound = True
        End If

        If InStr(Trim(TextTelephone.Text), " ", CompareMethod.Text) > 0 Then
            Label92.ForeColor = Color.Red
            Label92.Text = "Remove Spaces from Number."
            ErrFound = True
        End If



        'client details

        If Trim(TextClientNames.Text) = "" Then
            Label97.ForeColor = Color.Red
            ErrFound = True
        End If

        If Trim(TextClientEmailAddress.Text) = "" Then
            Label98.ForeColor = Color.Red
            ErrFound = True
        End If


        If InStr(Trim(TextClientEmailAddress.Text), "@", CompareMethod.Text) = 0 Then
            Label98.ForeColor = Color.Red
            Label98.Text = "Client Email address missing - @"
            ErrFound = True
        End If


        If Trim(TextClientTelephone.Text) = "" Then
            Label100.ForeColor = Color.Red
            Label100.Text = "Client Telephone number is too Short."
            ErrFound = True
        End If

        If Trim(TextClientTelephone.Text).Length < 9 Then
            Label100.ForeColor = Color.Red
            ErrFound = True
        End If

        If InStr(Trim(TextClientTelephone.Text), " ", CompareMethod.Text) > 0 Then
            Label100.ForeColor = Color.Red
            Label100.Text = "Remove Spaces from Number."
            ErrFound = True
        End If

        TextUserNames.Text = clsSubs.Capitalise(Trim(TextUserNames.Text))

        LabelAttachMessage.Text = "< Attach Required Documents for Processing Policy "
        LabelAttachMessage.ForeColor = Color.Black

        Return ErrFound
    End Function

    Private Function GetPolicyID() As String


        Dim tmpPolicyID As Double = 1

        Dim sqlstr As String = _
            "Select top 1 ID " & _
            "From MarineInsurancePolicies " & _
            "Order By ID Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            tmpPolicyID = drow("ID")
            tmpPolicyID = tmpPolicyID + 1
        End If


        Return Format(tmpPolicyID, "000000000000#") & "-" & clsSubs.GetRandomNo

    End Function
    Protected Sub ButtonPurchaseCover1_Click(sender As Object, e As EventArgs) Handles ButtonPurchaseCover1.Click
        Call CoverDetails(True)
    End Sub

    Protected Sub ButtonCoverDetailsDone_Click(sender As Object, e As EventArgs) Handles ButtonCoverDetailsDone.Click
        Call CoverDetails(False)
    End Sub

    Private Sub CoverDetails(Purchase As Boolean)
        If NoCoverDetails() Then
            LabelMessage2.Text = "Please provide all required details. See items marked in red"
            ModalPopupExtender5.Show()
        Else
            LabelCoverDetailFilled.Text = 1

            Dim PolicyID As String = PreserveUserActivity(1)
            ModalPopupExtender5.Hide()

            If Not LabelPolicyID.Text = "" Then
                Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, "", "", LabelPolicyID.Text, "policy", "insurance", LabelMessage1.Text)
                ButtonRequiredDocuments.Text = "Required Documents - " & DocumentCount & "/6"
                If Purchase Then
                    Call PurchasePolicy(LabelCFPROID.Text, LabelCSDID.Text, Trim(TextEmailAddress.Text))
                End If

            End If

        End If
    End Sub

    Private Function PreserveUserActivity(Hours As Integer) As String
        Dim PolicyID As String = ""

        If Not IsNothing(Request.Cookies("CFPROMCI")) Then
            Dim tmpPolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMCI").Value)
            Dim tmpstr() As String = tmpPolicyID.Split("|")
            ReDim Preserve tmpstr(1)

            If IsValidPolicyID(tmpstr(0)) Then
                If Trim(TextEmailAddress.Text) = tmpstr(1) Then
                    PolicyID = tmpstr(0)
                Else
                    PolicyID = GetPolicyID()
                End If
            Else
                PolicyID = GetPolicyID()
            End If

        Else
            PolicyID = GetPolicyID()
        End If

        LabelPolicyID.Text = PolicyID

        Dim PolicyID1 As String = clsEncr.EncryptString(PolicyID & "|" & Trim(TextEmailAddress.Text))
        Response.Cookies("CFPROMCI").Value = PolicyID1
        Response.Cookies("CFPROMCI").Expires.AddHours(Hours)

        Return PolicyID


    End Function


    Protected Sub ButtonDocuments_Click(sender As Object, e As EventArgs) Handles ButtonRequiredDocuments.Click

        RequiredDocuments(TextEmailAddress.Text)

        Dim PolicyID As String = PreserveUserActivity(1)

    End Sub

    Private Sub RequiredDocuments(EmailAddress As String)
        Try

            LabelAttachMessage.Text = "< Attach Required Documents for Processing Policy "
            LabelAttachMessage.ForeColor = Color.Black

            If Trim(EmailAddress) = "" Then
                LabelAttachMessage.ForeColor = Color.Red
                LabelAttachMessage.Text = "Your Email Address is required first. See 'Cover Details'"
                Exit Sub
            End If


            If InStr(Trim(EmailAddress), "@", CompareMethod.Text) = 0 Then
                LabelAttachMessage.ForeColor = Color.Red
                LabelAttachMessage.Text = "Email address missing - @"
                Exit Sub
            End If

            If LabelPolicyID.Text = "" Then
                Call PreserveUserActivity(2)
            End If

            Call LoadDialog("documents.aspx?policyid=" & LabelPolicyID.Text & "&marinecargo=1", "Required Marine Cargo Documents")

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Protected Sub ButtonAboutPolicy_Click(sender As Object, e As EventArgs) Handles ButtonAboutPolicy.Click
        Call LoadDialog(LabelAboutPolicyURL.Text, "Marine Insurance Policy")
    End Sub

    Private Sub LoadDialog(src As String, Title As String)
        LablePolicyTitle.Text = Title
        iframe3.Attributes("src") = src
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonSearch0_Click(sender As Object, e As EventArgs) Handles ButtonSearch0.Click
        Call LoadSearch()
    End Sub

    Private Sub LoadSearch()

        Call Search(TextSearch.Text)
        ModalPopupExtender6.Show()
        TextSearch.Focus()

    End Sub


    Private Sub Search(searchstr As String)

        Dim tmptable3 As New DataTable
        Dim drow1 As DataRow
        Dim col As New DataColumn("CategoryID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("CargoID", Type.GetType("System.String"))
        Dim col2 As New DataColumn("CargoDesc", Type.GetType("System.String"))
        Dim col3 As New DataColumn("Conditions", Type.GetType("System.String"))
        Dim col4 As New DataColumn("CargoDetails", Type.GetType("System.String"))
        tmptable3.Columns.Add(col)
        tmptable3.Columns.Add(col1)
        tmptable3.Columns.Add(col2)
        tmptable3.Columns.Add(col3)
        tmptable3.Columns.Add(col4)



        If Not searchstr = "" Then



            Dim sqlstr As String =
             "SELECT ID, CategoryID, CargoID, CargoDesc, RiskCode, Conditions " &
             "FROM   MarineCargo "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
            "SELECT   ItemID, ItemDesc, CargoID " &
            "FROM  MarineCargoDescExt " &
            "Where ItemDesc Like '%" & searchstr & "%' "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)



            Dim sqlstr2 As String =
            "SELECT  CargoID, CargoDesc " &
            "FROM   MarineCargo " &
            "Where CargoDesc Like '%" & searchstr & "%' "

            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)



            Dim a As Integer

            Dim dv1 As New DataView(tmptable1)

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                dv1.RowFilter = "CargoID ='" & drow("CargoID") & "' "
                If dv1.Count > 0 Then
                    drow1 = tmptable3.NewRow
                    drow1("CategoryID") = drow("CategoryID")
                    drow1("CargoID") = drow("CargoID")
                    drow1("CargoDesc") = drow("CargoDesc")
                    drow1("Conditions") = drow("Conditions")
                    drow1("CargoDetails") = drow("CategoryID") & "|" & drow("CargoID")

                    tmptable3.Rows.Add(drow1)
                End If

                a = a + 1
            Next

            Dim dv2 As New DataView(tmptable2)
            Dim dv3 As New DataView(tmptable3)

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                dv2.RowFilter = "CargoID ='" & drow("CargoID") & "' "
                If dv2.Count > 0 Then
                    dv3.RowFilter = "CargoID ='" & drow("CargoID") & "' "
                    If dv3.Count = 0 Then
                        drow1 = tmptable3.NewRow
                        drow1("CategoryID") = drow("CategoryID")
                        drow1("CargoID") = drow("CargoID")
                        drow1("CargoDesc") = drow("CargoDesc")
                        drow1("Conditions") = drow("Conditions")
                        drow1("CargoDetails") = drow("CategoryID") & "|" & drow("CargoID")
                        tmptable3.Rows.Add(drow1)
                    End If
                End If

                a = a + 1
            Next

        End If

        If tmptable3.Rows.Count = 0 Then
            drow1 = tmptable3.NewRow
            drow1("CategoryID") = ""
            drow1("CargoID") = ""
            If searchstr = "" Then
                drow1("CargoDesc") = ""
            Else
                drow1("CargoDesc") = "No Items found - Use other term or Send Enquiry."
            End If

            drow1("Conditions") = ""
            drow1("CargoDetails") = "-|-"
            tmptable3.Rows.Add(drow1)
        End If



        DataList2.DataSource = tmptable3
        DataList2.DataBind()

        ModalPopupExtender6.Show()
    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(Trim(TextSearch.Text))
    End Sub

    Protected Sub LinkMarineCargoDesc_Click(sender As Object, e As EventArgs)
        GotoMarineCargoItem(sender)
    End Sub
    Private Sub GotoMarineCargoItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim tmpstr() As String = link.CommandArgument.ToString.Split("|")



        If Not tmpstr(0) = "-" Then
            Call CargoType(tmpstr(0))
            ComboCargoCategories.SelectedValue = tmpstr(0)
            ComboCargoType.SelectedValue = tmpstr(1)
            ModalPopupExtender6.Hide()
        End If


    End Sub

    Private Function IsValidPolicyID(PolicyID As String) As Boolean
        Dim sqlstr As String =
            "SELECT PolicyID, Status " &
            "FROM MarineInsurancePolicies " &
            "Where PolicyID ='" & PolicyID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            If drow("Status") = "Started" Then
                Return True
            Else
                Return False
            End If
        Else
            Return True
        End If

    End Function

    Protected Sub ButtonBuyerDetails_Click1(sender As Object, e As EventArgs) Handles ButtonBuyerDetails.Click
        ModalPopupExtender5.Show()
    End Sub


    Protected Sub CheckAutoFill_CheckedChanged(sender As Object, e As EventArgs) Handles CheckAutoFill.CheckedChanged
        If CheckAutoFill.Checked Then
            TextClientNames.Text = TextUserNames.Text
            TextClientEmailAddress.Text = TextEmailAddress.Text
            TextClientTelephone.Text = TextTelephone.Text
        Else
            If TextClientNames.Text = TextUserNames.Text Then
                TextClientNames.Text = ""
            End If
            If TextClientEmailAddress.Text = TextEmailAddress.Text Then
                TextClientEmailAddress.Text = ""
            End If

            If TextClientTelephone.Text = TextTelephone.Text Then
                TextClientTelephone.Text = ""
            End If
        End If
        ModalPopupExtender5.Show()
    End Sub


    Protected Sub ButtonCloseDialog_Click(sender As Object, e As EventArgs) Handles ButtonCloseDialog.Click
        ModalPopupExtender4.Hide()
        If Not LabelPolicyID.Text = "" Then
            Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, "", "", LabelPolicyID.Text, "policy", "insurance", LabelMessage1.Text)
            ButtonRequiredDocuments.Text = "Required Documents - " & DocumentCount & "/6"
        End If
    End Sub




End Class


