﻿Imports System.Drawing

Public Class containercontrol
    Inherits System.Web.UI.Page

    Friend JobId As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If

            Try

                Call LoadJobTypes(CFPROID)
                Call LoadTransporters(CFPROID)
                Call LoadReleaseOrderStatus(CFPROID)
                Call LoadContainerStatuses(CFPROID)
                Call LoadCFS(CFPROID)
                Call LoadVessels(CFPROID)
                Call LoadPayLoads(CFPROID)
                Call LoadDestinations(CFPROID)

            Catch ex As Exception
                LabelMessage1.Text = ex.Message & ex.StackTrace
            End Try

            If Not IsNothing(Request.Cookies("OperationalDate")) Then
                If IsNumeric(Request.Cookies("OperationalDate").Value) Then
                    RadioButtonList2.SelectedIndex = CInt(Request.Cookies("OperationalDate").Value)
                End If
            End If


            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If

    End Sub

    Private Sub LoadContainers(CFPROID As String, CFPROUserID As String)


        Dim sqlstrA As String = ""
        Try

            Dim tmpstr As String = ""
            Dim tmpstrA As String = ""

            Dim OperationalDate As String = ""


            If RadioButtonList2.SelectedIndex = 0 Then
                OperationalDate = "JobCargo.PortExitDate"

            ElseIf RadioButtonList2.SelectedIndex = 1 Then
                OperationalDate = "JobCargo.CrossBorderDate"

            ElseIf RadioButtonList2.SelectedIndex = 2 Then
                OperationalDate = "JobCargo.BorderArrivalDate"

            ElseIf RadioButtonList2.SelectedIndex = 3 Then
                OperationalDate = "Jobs.JobDate"

            End If

            Response.Cookies("OperationalDate").Value = RadioButtonList2.SelectedIndex
            Response.Cookies("OperationalDate").Expires = Now.AddDays(365)

            Select Case ComboLoadedJobs.Text

                Case "All Jobs"
                    tmpstr = " And " & OperationalDate & " >= '" & TextFromDate.Text & "' " &
                                "And " & OperationalDate & " <= '" & TextToDate.Text & "' "


                Case "Open + Jobs Kept Visible"
                    tmpstr = " And " & OperationalDate & " >= '" & TextFromDate.Text & "' " &
                                "And " & OperationalDate & " <= '" & TextToDate.Text & "' " &
                                "And  Jobs.JobStatus Not Like '%" & "Closed" & "%' "

                    tmpstrA = " And Jobs.CFPROID = '" & CFPROID & "' And Jobs.KeepVisible = 1 "


                Case "Open Jobs"
                    tmpstr = " And " & OperationalDate & " >= '" & TextFromDate.Text & "' " &
                                "And " & OperationalDate & " <= '" & TextToDate.Text & "' " &
                                "And  Jobs.JobStatus Not Like '%" & "Closed" & "%' "



                Case "Closed Jobs"
                    tmpstr = " And " & OperationalDate & " >= '" & TextFromDate.Text & "' " &
                                "And " & OperationalDate & " <= '" & TextToDate.Text & "' " &
                                "And Jobs.JobStatus Like '%" & "Closed" & "%'  "



                Case "Jobs Kept Visible"
                    tmpstr = "And  Jobs.KeepVisible = 1 "



            End Select


            Dim tmpstr1 As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr1 = "And Jobs.UserID = '" & CFPROUserID & "' "
            End If

            Dim sqlstr As String =
                   "Select Top " & ComboSelectTop.Text & " " &
                  "JobCargo.JobID,ContainerNo," &
                  "JobCargo.Weight,JobCargo.CBM,VehicleNo,TrailerNo," &
                  "JobCargo.TransporterID," &
                  "JobCargo.PortExitDate,BorderArrivalDate," &
                  "JobCargo.CrossBorderDate,ContainerStatus," &
                  "BorderDispatchDate,DestinationArrivalDate," &
                  "OffLoadDate,DestinationDispatchDate," &
                  "JobCargo.ReturnDate,JobCargo.Payload," &
                  "T812No,CustomsSealNo,TEU," &
                  "T1No,JobCargo.T1Expiry,GFValidity," &
                  "InterchangeNo, Jobs.Destination, DestinationDepot, " &
                  "SpecialCargoType, ContainerStatusRemarks, " &
                  "ReturnVehicleNo, DeliveryNoteNo, JobCargo.ID, " &
                  "Jobs.AgentID, Jobs.ClientID, " &
                  "Jobs.ImporterID,ShipperID," &
                  "Jobs.ShippingLineID, VesselID, SOC," &
                  "Jobs.JobStatus,Jobs.KeepVisible,DispatchDate," &
                  "BL,HouseBL,BLCountry,CFSID,Jobs.JobDate," &
                  "ReferenceNo,ReferenceNo1," &
                  "ManifestNo,Jobs.ID as ID1," &
                  "Jobs.ReleaseOrderStatus, Jobs.JobTypeID," &
                  "DocumentsReceivedDate, ContainerDepositDate," &
                  "PortofLoading, CountryofLoading," &
                  "PortChargesPaidDate, LoadingDate " &
                  "From JobCargo, Jobs " &
                  "Where  Jobs.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.JobID  = JobCargo.JobID "


            sqlstrA = sqlstr & tmpstr & " " & tmpstr1


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstrA, tmptable, clsData.constr)



            If ComboLoadedJobs.Text = "Open + Jobs Kept Visible" Then
                sqlstrA = sqlstr & tmpstrA & " " & tmpstr1
                Dim tmptableA As New DataTable()
                Call clsData.TableData(sqlstrA, tmptableA, clsData.constr)
                tmptable.Merge(tmptableA)
            End If


            Dim sqlstr1 As String =
                      "Select ShippingLineID, ShippingLine," &
                     "LocalReturnDays, TransitReturnDays " &
                     "From ShippingLines " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)

            Dim sqlstr2 As String = _
                    "Select CFSID, CFS, " & _
                    "LocalFreeDays, TransitFreeDays,ID " & _
                    "From CFS " & _
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)



            Dim sqlstr3 As String =
                    "Select VesselID,Vessel,VoyageNo, " &
                    "ETA,BerthingDate, ExitDate  " &
                    "From ShippingVessels " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim sqlstr4 As String =
                   "Select Transporter, TransporterID " &
                   "From Transporters " &
                   "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)


            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim col0 As New DataColumn("Transporter", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ShippingLine", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col7 As New DataColumn("StorageFreeDays", Type.GetType("System.Double"))
            Dim col8 As New DataColumn("StorageDays", Type.GetType("System.Double"))
            Dim col9 As New DataColumn("StorageCharges", Type.GetType("System.Double"))
            Dim col10 As New DataColumn("DemurrageFreeDays", Type.GetType("System.Double"))
            Dim col11 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
            Dim col12 As New DataColumn("DemurrageCharges", Type.GetType("System.Double"))
            Dim col13 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col14 As New DataColumn("Importer", Type.GetType("System.String"))
            Dim col15 As New DataColumn("VoyageNo", Type.GetType("System.String"))
            Dim col16 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col17 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col18 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col19 As New DataColumn("LoadedOut", Type.GetType("System.String"))
            Dim col20 As New DataColumn("Returned", Type.GetType("System.String"))
            Dim col21 As New DataColumn("PortExitDate1", Type.GetType("System.String"))
            Dim col22 As New DataColumn("ReturnDate1", Type.GetType("System.String"))
            Dim col23 As New DataColumn("GFValidity1", Type.GetType("System.String"))
            Dim col24 As New DataColumn("T1Expiry1", Type.GetType("System.String"))
            Dim col25 As New DataColumn("CrossBorderDate1", Type.GetType("System.String"))
            Dim col26 As New DataColumn("BorderDispatchDate1", Type.GetType("System.String"))
            Dim col27 As New DataColumn("BorderArrivalDate1", Type.GetType("System.String"))

            tmptable.Columns.Add(col0)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)
            tmptable.Columns.Add(col17)
            tmptable.Columns.Add(col18)
            tmptable.Columns.Add(col19)
            tmptable.Columns.Add(col20)
            tmptable.Columns.Add(col21)
            tmptable.Columns.Add(col22)
            tmptable.Columns.Add(col23)
            tmptable.Columns.Add(col24)
            tmptable.Columns.Add(col25)
            tmptable.Columns.Add(col26)
            tmptable.Columns.Add(col27)

            Dim tmpdate As Date = Now
            Dim ts As TimeSpan

            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                drow("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

                If CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                    drow("CrossedBorder") = False
                Else
                    drow("CrossedBorder") = True
                End If


                If CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                    If UCase(drow("ContainerStatus")) = "LOADED OUT" Then
                        drow("LoadedOut") = "YES"
                        drow("PortExitDate1") = "Missing"
                    Else
                        drow("LoadedOut") = "NO"
                    End If
                Else
                    drow("LoadedOut") = "YES"
                    drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
                End If

                If CDate(drow("ReturnDate")) = CDate("1-Jan-1800") Then
                    If UCase(drow("ContainerStatus")) = "RETURNED" Then
                        drow("Returned") = "YES"
                        drow("ReturnDate1") = "Missing"
                    Else
                        drow("Returned") = "NO"
                    End If
                Else
                    drow("Returned") = "YES"
                    drow("ReturnDate1") = Format(drow("ReturnDate"), "dd MMM yyyy")
                End If


                If Not CDate(drow("GFValidity")) = CDate("1-Jan-1800") Then
                    drow("GFValidity1") = Format(drow("GFValidity"), "dd MMM yyyy")
                End If


                If Not CDate(drow("T1Expiry")) = CDate("1-Jan-1800") Then
                    drow("T1Expiry1") = Format(drow("T1Expiry"), "dd MMM yyyy")
                End If

                If Not CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                    drow("CrossBorderDate1") = Format(drow("CrossBorderDate"), "dd MMM yyyy")
                End If

                If Not CDate(drow("BorderDispatchDate")) = CDate("1-Jan-1800") Then
                    drow("BorderDispatchDate1") = Format(drow("BorderDispatchDate"), "dd MMM yyyy")
                End If

                If Not CDate(drow("BorderArrivalDate")) = CDate("1-Jan-1800") Then
                    drow("BorderArrivalDate1") = Format(drow("BorderArrivalDate"), "dd MMM yyyy")
                End If



                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VoyageNo") = dv3(0)("VoyageNo")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")

                End If

                dv1.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "
                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    drow("ShippingLine") = dv1(0)("ShippingLine")
                    drow("DemurrageFreeDays") = clsShippingStorage.DemurrageFreeDays(CFPROID, drow("ClientID"), drow("ShippingLineID"), drow("JobType"), dv1(0)("TransitReturnDays"), dv1(0)("LocalReturnDays"))


                    If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                        drow("DemurrageDays") = 0
                    Else

                        If CDate(drow("ReturnDate")) = CDate("1-Jan-1800") Then
                            tmpdate = Now
                        Else
                            tmpdate = drow("ReturnDate")
                        End If

                        ts = tmpdate.Subtract(CDate(drow("BerthingDate")))
                        drow("DemurrageDays") = drow("DemurrageFreeDays") - (ts.Days)


                    End If
                End If



                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")

                    drow("StorageFreeDays") = clsShippingStorage.StorageFreeDays(CFPROID, drow("ClientID"), drow("CFSID"), drow("JobType"), dv2(0)("TransitFreeDays"), dv2(0)("LocalFreeDays"))
                    If CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                        drow("StorageDays") = 0
                    Else


                        If CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                            tmpdate = Now
                        Else
                            tmpdate = drow("PortExitDate")
                        End If

                        ts = tmpdate.Subtract(CDate(drow("LastSlingDate")))
                        drow("StorageDays") = drow("StorageFreeDays") - (ts.Days)


                    End If
                End If






                dv4.RowFilter = "TransporterID = '" & drow("TransporterID") & "' "

                If dv4.Count > 0 Then
                    Call clsData.NullChecker1(dv4, 0)
                    drow("Transporter") = dv4(0)("Transporter")
                End If


                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Client") = Mid(dv5(0)("Client"), 1, 25)
                End If

                dv6.RowFilter = "ImporterID = '" & drow("ImporterID") & "' "
                If dv6.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Importer") = Mid(dv6(0)("Importer"), 1, 25)
                End If
                a = a + 1
            Next


            Dim dv As New DataView(tmptable)
            Session("JobCargo") = tmptable

            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "PortExitDate" Then
                dv.Sort = "PortExitDate " & tmpstrSort

            ElseIf SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "BerthingDate" Then
                dv.Sort = "BerthingDate " & tmpstrSort

            ElseIf SortBy = "BerthingDate" Then
                dv.Sort = "BerthingDate " & tmpstrSort

            ElseIf SortBy = "StorageDays" Then
                dv.Sort = "StorageDays " & tmpstrSort

            ElseIf SortBy = "DemurrageDays" Then
                dv.Sort = "DemurrageDays " & tmpstrSort

            End If


            LabelSortStr.Text = dv.Sort

            GridCargo.DataSource = dv
            GridCargo.DataBind()

            Call Calctotal(dv, "")



            If tmptable.Rows.Count >= 10 Then
                PanelCargo.Height = 250
            Else
                PanelCargo.Height = Nothing
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Private Function nSortOrder() As String

        If RadioButtonList1.SelectedIndex = 0 Then
            Return "PortExitDate"

        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "JobDate"

        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "ReferenceNo"

        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "BerthingDate"

        ElseIf RadioButtonList1.SelectedIndex = 4 Then
            Return "StorageDays"

        ElseIf RadioButtonList1.SelectedIndex = 5 Then
            Return "DemurrageDays"

        Else
            Return "JobDate"
        End If
    End Function

    Private Sub ApplySort(dv As DataView, Databind As Boolean)

        If dv Is Nothing Then

            If IsNothing(Session("JobCargo")) Then
                Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobCargo As DataTable = Session("JobCargo")
            dv = New DataView(JobCargo)
        End If

        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()

        If SortBy = "PortExitDate" Then
            dv.Sort = "PortExitDate " & tmpstrSort

        ElseIf SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort


        ElseIf SortBy = "BerthingDate" Then
            dv.Sort = "BerthingDate " & tmpstrSort

        ElseIf SortBy = "StorageDays" Then
            dv.Sort = "StorageDays " & tmpstrSort

        ElseIf SortBy = "DemurrageDays" Then
            dv.Sort = "DemurrageDays " & tmpstrSort

        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridCargo.DataSource = dv
            GridCargo.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub
    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim TEU, Weight, CBM As Double
            Dim TWFT, FTFT As Double

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + Val(dv(a)("TEU"))

                If InStr(dv(a)("PayLoad"), "20", CompareMethod.Text) > 0 Then
                    TWFT = TWFT + 1
                End If

                If InStr(dv(a)("PayLoad"), "40", CompareMethod.Text) > 0 Then
                    FTFT = FTFT + 1
                End If

            Next

            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTEU.Text = Format(TEU, "#,##0")

            TextTotal20ft.Text = Format(TWFT, "#,##0")
            TextTotal40ft.Text = Format(FTFT, "#,##0")
            TextTotalContainers.Text = Format((TWFT + FTFT), "#,##0")

            TextTotalQty.Text = Format(dv.Count, "#,##0")

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & RadioButtonList2.Text & " )" & " - " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = " (" & RadioButtonList2.Text & " )" & " - " & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " | " & tmpstr
            Else
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " " & tmpcaption1 & " | " & tmpstr
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub LoadDestinations(CFPROID As String)
        Dim sqlstr As String =
        "Select Destination From Destinations " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Destination Asc;"

        ComboDestination.Items.Clear()
        Call clsData.PopCombo(ComboDestination, sqlstr, clsData.constr, 0)
        ComboDestination.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadTransporters(CFPROID As String)
        Dim sqlstr As String =
        "Select Transporter,TransporterID From Transporters " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Transporter Asc;"

        ComboTransporter.Items.Clear()
        Call clsData.PopComboWithValue(ComboTransporter, sqlstr, clsData.constr, 0, 1)
        ComboTransporter.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadPayLoads(CFPROID As String)
        Dim sqlstr As String =
        "Select Payload From Payloads " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Payload Asc;"

        ComboPayload.Items.Clear()
        Call clsData.PopCombo(ComboPayload, sqlstr, clsData.constr, 0)
        ComboPayload.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadReleaseOrderStatus(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ReleaseOrderStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboReleaseOrderStatus.Items.Clear()
        Call clsData.PopCombo(ComboReleaseOrderStatus, sqlstr, clsData.constr, 0)
        ComboReleaseOrderStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadContainerStatuses(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ContainerStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboContainerStatus.Items.Clear()
        Call clsData.PopCombo(ComboContainerStatus, sqlstr, clsData.constr, 0)
        ComboContainerStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadVessels(CFPROID As String)
        Dim sqlstr As String =
        "Select Vessel, VesselID " &
        "From ShippingVessels " &
        "Where CFPROID = '" & CFPROID & "' " &
        "And Active =1 " &
        "Order By Vessel Asc;"

        Call clsData.PopComboWithValue(ComboVessel, sqlstr, clsData.constr, 0, 1)
        ComboVessel.Items.Insert(0, "(All)")

    End Sub
    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub CompoundFilter(agent As Boolean, client As Boolean, containerStatus As Boolean, consignee As Boolean,
                               jobType As Boolean, ROstatus As Boolean, payLoad As Boolean, transporter As Boolean,
                               cfs As Boolean, vessel As Boolean, destination As Boolean, DemurrageDays As Boolean,
                               ByVal OmitCrossedBorder As Boolean, Optional ByRef ErrMsg As String = "")
        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a As Integer = 0


            If IsNothing(Session("JobCargo")) Then
                Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim tmptable As DataTable = Session("JobCargo")

            Dim dv As New DataView(tmptable)


            If agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID Like '%" & Trim(LabelAgentID.Text) & "%' "
                tmpstr1(a) = "Agent : " & TextAgent.Text
                a = a + 1

            End If


            If client Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ClientID = '" & Trim(LabelClientID.Text) & "' "
                Else
                    tmpstr(a) = "And ClientID = '" & Trim(LabelClientID.Text) & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                a = a + 1


            End If

            If containerStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim tmpand As String = ""
                If a > 0 Then
                    tmpand = " And "
                End If

                If UCase(ComboContainerStatus.Text) = "LOADED OUT" Then
                    tmpstr(a) = tmpand & " (ContainerStatus Like 'LOADED OUT%' " &
                            "OR LoadedOut = 'YES') "

                ElseIf UCase(ComboContainerStatus.Text) = "NOT LOADED OUT" Then
                    tmpstr(a) = tmpand & "(ContainerStatus Like '%NOT LOADED OUT%' " &
                            "OR LoadedOut = 'NO') "

                ElseIf UCase(ComboContainerStatus.Text) = "RETURNED" Then
                    tmpstr(a) = tmpand & "(ContainerStatus Like 'RETURN%' " &
                            "OR Returned = 'YES') "

                ElseIf UCase(ComboContainerStatus.Text) = "NOT RETURNED" Then
                    tmpstr(a) = tmpand & "(ContainerStatus Like '%NOT RETURNED%' " &
                            "OR Returned = 'NO') "

                Else
                    tmpstr(a) = tmpand & " ContainerStatus Like '%" & ComboContainerStatus.Text & "%' "

                End If

                tmpstr1(a) = "Container Status: " & ComboContainerStatus.Text
                a = a + 1
            End If

            If consignee Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ImporterID = '" & Trim(LabelImporterID.Text) & "' "
                Else
                    tmpstr(a) = " And ImporterID = '" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                a = a + 1
            End If

            If jobType Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                a = a + 1
            End If

            If vessel Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "VesselID = '" & Trim(ComboVessel.Text) & "' "
                Else
                    tmpstr(a) = " And VesselID = '" & ComboVessel.Text & "%' "
                End If

                tmpstr1(a) = "Vessel: " & ComboVessel.SelectedItem.Text
                a = a + 1
            End If


            If payLoad Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "PayLoad Like '%" & Trim(ComboPayload.Text) & "%' "
                Else
                    tmpstr(a) = " And PayLoad Like '%" & ComboPayload.Text & "%' "
                End If

                tmpstr1(a) = "PayLoad: " & ComboPayload.Text
                a = a + 1
            End If


            If transporter Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "TransporterID Like '%" & Trim(ComboTransporter.Text) & "%' "
                Else
                    tmpstr(a) = " And TransporterID Like '%" & ComboTransporter.Text & "%' "
                End If

                tmpstr1(a) = "Transporter: " & ComboTransporter.SelectedItem.ToString
                a = a + 1
            End If

            If ROstatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ReleaseOrderStatus Like '%" & Trim(ComboReleaseOrderStatus.Text) & "%' "
                Else
                    tmpstr(a) = " And ReleaseOrderStatus Like '%" & ComboReleaseOrderStatus.Text & "%' "
                End If
                tmpstr1(a) = "Release Order Status: " & ComboReleaseOrderStatus.Text
                a = a + 1
            End If

            If OmitCrossedBorder Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                a = a + 1
            End If


            If destination Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "Destination Like '%" & Trim(ComboDestination.Text) & "%' "
                Else
                    tmpstr(a) = " And Destination Like '%" & ComboDestination.Text & "%' "
                End If

                tmpstr1(a) = "Destination: " & ComboDestination.Text
                a = a + 1
            End If

            If cfs Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CFSID =  '" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = '" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                a = a + 1
            End If

            If DemurrageDays Then
                ReDim Preserve tmpstr(a), tmpstr1(a)

                If ComboDemurrageDays.SelectedIndex > 0 Then
                    If ComboDemurrageDays.SelectedValue >= 0 Then
                        If a = 0 Then
                            tmpstr(a) = "DemurrageDays <= " & Trim(ComboDemurrageDays.SelectedValue) & " " &
                                "And DemurrageDays >= 0"
                        Else
                            tmpstr(a) = "And DemurrageDays <=  " & ComboDemurrageDays.SelectedValue & " " &
                                "And DemurrageDays >= 0"
                        End If
                    Else
                        If a = 0 Then
                            tmpstr(a) = "DemurrageDays <= " & Trim(ComboDemurrageDays.SelectedValue) & " " &
                                "And DemurrageDays <= 0"
                        Else
                            tmpstr(a) = "And DemurrageDays <= " & ComboDemurrageDays.SelectedValue & " " &
                                "And DemurrageDays <= 0"
                        End If
                    End If
                End If

                tmpstr1(a) = "Demurrage Days: " & ComboDemurrageDays.SelectedItem.Text
                a = a + 1
            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")


            dv.RowFilter = tmpstr2

            If Not LabelSortStr.Text = "" Then
                dv.Sort = LabelSortStr.Text
            End If

            GridCargo.DataSource = dv
            GridCargo.DataBind()


            LabelFilterStr.Text = tmpstr2
            LabelReportCaption.Text = dv.Count & " Containers"


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadContainers(CFPROID, CFPROUserID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2



                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadContainers(CFPROID, CFPROUserID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelFilters.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub
    Protected Sub GridCargo_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ClearFilters()
        Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExportToExcel(LabelCFPROID.Text)
    End Sub
    Protected Sub ExportToExcel(CFPROID As String)

        If clsAuth.UserAllowed(CFPROID, LabelCFPROUserID.Text, "00015") Then
            Dim totals(5) As String

            totals(0) = "Total Weight: " & TextWeight.Text & " (Kgs)"
            totals(1) = "Total CBM: " & TextTotalCbm.Text & " Cb.M"
            totals(2) = "Total TEU: " & TextTotalTEU.Text
            totals(3) = "Total 1x20: " & TextTotal20ft.Text
            totals(4) = "Total 1x40: " & TextTotal40ft.Text
            totals(5) = "Total Containers: " & TextTotalContainers.Text


            Dim tmpfields(0) As String
             Dim tmpcols(0) As String
            Call clsContainerControlReport.ContainerControlReportColumns(CFPROID, tmpfields, tmpcols)


            Dim tmptable As DataTable = Session("JobCargo")

            Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Container Control", "Container Control",
                                                LabelReportCaption.Text, True, totals, 0, LabelMessage1.Text, tmpfields, tmpcols, tmptable, False)
        Else
            LabelCargoMessage.Text = "User Not Allowed"
            LabelCargoMessage.ForeColor = Color.Red
        End If

    End Sub



    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Protected Sub ButtonApplySort0_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilter.Click
        Call CompoundFilter(CheckFilterAgent.Checked, CheckFilterClient.Checked, CheckContainerStatus.Checked, CheckFilterConsignee.Checked,
                                  CheckJobType.Checked, CheckRO.Checked, CheckPayload.Checked, CheckTransporter.Checked,
                                   CheckCFS.Checked, CheckVessel.Checked, CheckDestination.Checked, CheckRemainingDays.Checked,
                                   CheckOmitCrossedBorder.Checked, LabelMessage1.Text)
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text, True)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub


    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckFilterClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckFilterAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call SearchContainer(Trim(TextSearch.Text))
    End Sub

    Private Sub SearchContainer(SearchStr As String)


        If IsNothing(Session("JobCargo")) Then
            Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If

        Dim JobCargo As New DataTable
        JobCargo = Session("JobCargo")

        Dim dv As New DataView(JobCargo)



        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or ContainerNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "




        GridCargo.DataSource = dv
        GridCargo.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching " & " " & Trim(SearchStr)

        Call Calctotal(dv, tmpstr)
    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub


    Protected Sub ComboContainerStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboContainerStatus.SelectedIndexChanged
        CheckContainerStatus.Checked = True
    End Sub

    Protected Sub ComboPayload_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPayload.SelectedIndexChanged
        CheckPayload.Checked = True
    End Sub

    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub

    Protected Sub ComboVessel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVessel.SelectedIndexChanged
        CheckVessel.Checked = True
    End Sub

    Protected Sub ComboTransporter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboTransporter.SelectedIndexChanged
        CheckTransporter.Checked = True
    End Sub

    Protected Sub ComboDestination_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDestination.SelectedIndexChanged
        CheckDestination.Checked = True
    End Sub

    Protected Sub ComboReleaseOrderStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboReleaseOrderStatus.SelectedIndexChanged
        CheckRO.Checked = True
    End Sub


    Protected Sub ComboRemainingDays_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDemurrageDays.SelectedIndexChanged
        CheckRemainingDays.Checked = True
    End Sub


    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub LinkContainerNo_Click(sender As Object, e As EventArgs)
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim ID As Integer = linkbutton.CommandArgument.ToString
        Call EditCargo(ID)
    End Sub
    Private Sub EditCargo(ID As Integer)
        LabelCargoMessage.Text = ""
        LabelCargoMessage.ForeColor = Color.Gray
        Call LoadDialog("morecargodetails.aspx?jobcargoid=" & ID, "More Cargo Details", 550, 780)
    End Sub

    Protected Sub ButtonExcelColumns_Click(sender As Object, e As EventArgs) Handles ButtonExcelColumns.Click
        Call LoadDialog("containercontrolcolumns.aspx", "Container Control Excel Report Columns", 440, 585)
    End Sub

    Protected Sub ButtonEditCargo_Click(sender As Object, e As EventArgs) Handles ButtonEditCargo.Click
        If GridCargo.SelectedIndex >= 0 Then
            Call LoadDialog("morecargodetails.aspx?jobcargoid=" & GridCargo.SelectedValue, "More Cargo Details", 550, 780)
        Else
            LabelCargoMessage.Text = "Please Select Cargo Item .."
        End If
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender4.Show()
    End Sub

End Class