﻿Imports System.Drawing

Public Class jobstatus
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadJobStatus(CFPROID, "")

        End If

    End Sub

    Private Sub LoadJobStatus(ByVal CFPROID As String, SearchStr As String)

        Try


            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Status Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select " &
                              "Status, ID " &
                              "From CFAgentJobStatus " &
                              "Where CFPROID ='" & CFPROID & "' " &
                               tmpstr &
                              "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridJobStatus.DataSource = tmptable
            GridJobStatus.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Job Status"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridJobStatus.SelectedIndexChanged
        Dim row As GridViewRow = GridJobStatus.Rows(GridJobStatus.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridJobStatus.Rows.Count - 1
            row = GridJobStatus.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridJobStatus.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingJobStatus_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobStatus.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobStatus, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call FunctionAddEditJobStatus(LabelCFPROID.Text, True)
    End Sub
    Private Sub FunctionAddEditJobStatus(CFPROID As String, Edit As Boolean)
        Try



            If Edit Then
                If GridJobStatus.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select Job Status."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit CFAgentJobStatus"
                Dim ID As Integer = GridJobStatus.SelectedValue
                Dim sqlstr As String = "SELECT Status,ID " &
                                        "From CFAgentJobStatus " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)


                    TextAddEdit.Text = drow("Status")


                End If

            Else
                LabelAddEdit.Text = "Add Job Status"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call FunctionAddEditJobStatus(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveJobStatus(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveJobStatus(CFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If JobStatusExists(CFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridJobStatus.SelectedIndex >= 0 Then
                    ID = GridJobStatus.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT Status, CFPROID, ID " &
                                    "From CFAgentJobStatus " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Status") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("CFAgentJobStatus", tmptable, sqlstr, False, clsData.constr)

            Call LoadJobStatus(CFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function JobStatusExists(CFPROID As String, CFAgentJobStatus As String) As Boolean


        Dim sqlstr As String = "SELECT Status " &
                                "From CFAgentJobStatus " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And CFAgentJobStatus = " & Trim(CFAgentJobStatus) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridJobStatus.SelectedIndex >= 0 Then
            Call PromptDeleteJobStatus(GridJobStatus.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Job Status to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteJobStatus(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridJobStatus.Rows(GridJobStatus.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteJobStatus(GridJobStatus.SelectedValue)
    End Sub
    Private Sub DeleteJobStatus(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From CFAgentJobStatus  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("CFAgentJobStatus", tmptable, sqlstr, True, clsData.constr)

            Call LoadJobStatus(LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetJobStatusID() As String
    '    Try

    '        Dim tmpJobStatusID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From CFAgentJobStatus " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpJobStatusID = drow("ID")
    '            tmpJobStatusID = tmpJobStatusID + 1
    '            tmpstr = Format(tmpJobStatusID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpJobStatusID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadJobStatus(LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadJobStatus(LabelCFPROID.Text, "")
    End Sub



End Class