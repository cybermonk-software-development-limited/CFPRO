﻿Imports System.Drawing
Imports System.IO
Imports QRCoder

Public Class marinecargoinsurancecertificate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Call clsAuth.UserLogin(LabelCSDID.Text, LabelCFPROID.Text, LabelCFPROUserID.Text, "", "", "", "", "", False, "", False)

            Dim PolicyID As String = "-1"

            If Not IsNothing(Request.QueryString("policyid")) Then
                PolicyID = clsEncr.DecryptString(Request.QueryString("policyid"))

                Dim tmpstr() As String = PolicyID.Split("&")
                ReDim Preserve tmpstr(0)

                PolicyID = tmpstr(0)
                LabelPolicyID.Text = PolicyID

                Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, "", "", LabelPolicyID.Text, "policy", "insurance", LabelMessage1.Text)
                ButtonRequiredDocuments.Text = "Documents - " & DocumentCount & "/6"
            End If


            If Not IsNothing(Request.QueryString("nocovfot")) Then
                PanelFooter.Visible = False
            End If
            Call LoadInsurer()
            Call LoadPolicy(PolicyID)


        End If
    End Sub





    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, " & _
            "Insurer,ProductName," & _
            "Description, URL," & _
            "EmailAddress,Telephone, SystemFees " & _
            "FROM MarineCargoInsurer "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)

            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")

            LabelContacts.Text = drow("Contacts")

        End If



    End Sub





    Private Sub LoadPolicy(PolicyID As String)


        Dim sqlstr As String =
             "SELECT CSDID, PolicyID,PurchaseDate," &
                 "UserNames, EmailAddress, " &
                 "Telephone,ClientNames," &
                 "ClientEmailAddress, ClientTelephone," &
                 "CategoryID, CargoID," &
                 "AmountInsured,Currency, ExchangeRate," &
                 "AmountInsuredKES,Premium, " &
                 "TrainingLevy, StampDuty," &
                 "PolicyHolderFund, SystemFees," &
                 "Total, Status," &
                 "JobID, CFPROID," &
                 "ClientIDNo, ClientPIN," &
                 "OriginPort, DestinationCountry," &
                 "DestinationPort, ViaPort, " &
                 "Vessel, ID " &
                 "FROM MarineInsurancePolicies " &
                 "Where PolicyID ='" & PolicyID & "' " &
                 "And Status ='" & "Started" & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)




        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)



            If drow("Status") = "Started" Then
                LabelPolicyStatus.Text = "NOT PAID"
                LabelPolicyStatus.ForeColor = Color.Red
                ButtonModifyPurchasePolicy.Visible = True
            Else
                LabelPolicyStatus.Text = "PAID"
                LabelPolicyStatus.ForeColor = Color.Green
                ButtonModifyPurchasePolicy.Visible = False
            End If

            LabelUserNames.Text = drow("UserNames")
            LabelEmailAddress.Text = drow("EmailAddress")
            LabelTelephone.Text = drow("Telephone")

            LabelClientNames.Text = drow("ClientNames")
            LabelClientEmailAddress.Text = drow("ClientEmailAddress")
            LabelClientTelephone.Text = drow("ClientTelephone")
            LabelIDNo.Text = drow("ClientIDNo")
            LabelPIN.Text = drow("ClientPIN")


            LabelTrainingLevy.Text = "KES " & Format(drow("TrainingLevy"), "#,##0.00")
            LabelStampDuty.Text = "KES " & Format(drow("StampDuty"), "#,##0.00")
            LabelPolicyHoldersFund.Text = "KES " & Format(drow("PolicyHolderFund"), "#,##0.00")
            LabelSystemFees.Text = "KES " & Format(drow("SystemFees"), "#,##0.00")

            LabelAmountInsured.Text = drow("Currency") & " " & Format(drow("AmountInsured"), "#,##0.00")
            LabelExchangeRate.Text = Format(drow("ExchangeRate"), "#,##0.00")

            LabelAmountInsuredKES.Text = "KES " & Format(drow("AmountInsuredKES"), "#,##0.00")
            LabelPremium.Text = "KES " & Format(drow("Premium"), "#,##0.00")
            LabelTotal.Text = "KES " & Format(drow("Total"), "#,##0.00")






            Dim sqlstr1 As String = _
            "SELECT CargoDesc " & _
            "FROM MarineCargo " &
            "Where CargoID ='" & drow("CargoID") & "' "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            If tmptable1.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable1, 0)
                Dim drow1 As DataRow = tmptable1.Rows(0)
                LabelCargoDescription.Text = drow1("CargoDesc")
            End If


            LabelPolicyID.Text = PolicyID
            ImageQRCode.ImageUrl = PolicyIDQR(PolicyID)



            If Not drow("JobID") = "" Then
                Call LoadJob(drow("JobID"), drow("CFPROID"))
            End If

            Dim col1 As New DataColumn("CargoDesc", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
            Dim col3 As New DataColumn("InvoiceNo", Type.GetType("System.String"))
            Dim col4 As New DataColumn("BL", Type.GetType("System.String"))
            Dim col5 As New DataColumn("BLCountry", Type.GetType("System.String"))
            Dim col6 As New DataColumn("Goods", Type.GetType("System.String"))



            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)

            drow("CargoDesc") = LabelCargoDescription.Text
            drow("Contacts") = LabelContacts.Text
            drow("InvoiceNo") = LabelInvoiceNo.Text
            drow("BL") = LabelBL.Text
            drow("BLCountry") = LabelCountry.Text
            drow("Goods") = LabelGoods.Text



            Session("MCICoverNote") = tmptable


        End If
    End Sub

    Private Sub LoadJob(JobID As String, CFPROID As String)



        If JobID = "" Then
            Dim tmpinscode() As String = TextInsuranceCode.Text.Split("-")
            ReDim Preserve tmpinscode(1)

            JobID = tmpinscode(0)
            CFPROID = tmpinscode(1)
        End If


        Dim sqlstr As String = _
                "Select JobId,InvoiceNo," & _
                "BL,BLCountry,ID " & _
                "From Jobs " & _
                "Where JobId ='" & JobID & "' " & _
                "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)

            LabelInvoiceNo.Text = drow("InvoiceNo")
            LabelBL.Text = drow("BL")
            LabelCountry.Text = drow("BLCountry")
            LabelGoods.Text = drow("Goods")


        End If



    End Sub

    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        Call LoadEmailMCICoverNote(LabelCFPROID.Text)
    End Sub
    Private Sub LoadEmailMCICoverNote(CFPROID As String)


        PanelMessage.Visible = True
        ButtonEmailMCICoverNote.Visible = True
        Image7.Visible = False


        TextEmailAddress.Text = LabelClientEmailAddress.Text
        TextEmailSubject.Text = "Instacover MCI Cover Note: " & LabelPolicyID.Text

        If CFPROID = "" Then
            CFPROID = "Instacover"
        End If

        Dim EmailServer As Integer = clsEmail.CFAgentEmailServer(CFPROID)

        If EmailServer = 0 Then
            CheckDefaultEmailServer.Checked = True
            CheckDefaultEmailServer.Enabled = False

        ElseIf EmailServer = 1 Then
            CheckDefaultEmailServer.Checked = False
            CheckDefaultEmailServer.Enabled = True

        ElseIf EmailServer = 2 Then
            CheckDefaultEmailServer.Checked = True
            CheckDefaultEmailServer.Enabled = True
        End If

        ModalPopupExtender2.Show()

    End Sub

    Protected Sub ButtonEmailPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonEmailMCICoverNote.Click
        Call EmailMCICoverNote(LabelCFPROID.Text, LabelCFPROUserID.Text, LabelPolicyID.Text)
    End Sub

    Private Sub EmailMCICoverNote(CFPROID As String, UserID As String, PolicyID As String)
        Try

            Dim UserEmailAddress As String = LabelEmailAddress.Text
            Dim UserNames As String = LabelUserNames.Text

            Dim CFAgentName As String = ""
            Dim CFAgentEmailAddress As String = ""

            Dim ClientEmailAddress As String = Trim(TextEmailAddress.Text)
            Dim ClientNames As String = LabelClientNames.Text

            If Not CFPROID = "" Then

                Dim sqlstr As String =
                "Select CFAgentName," &
                "EmailAddress " &
                "From CFPROAccounts " &
                "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)

                    CFAgentName = drow("CFAgentName")
                    CFAgentEmailAddress = drow("EmailAddress")
                End If


                Dim sqlstr1 As String = _
                   "SELECT  UserNames, Email, Department " & _
                   "FROM CFAgentUsers " & _
                   "Where CFPROID = '" & CFPROID & "' " &
                   "And UserID  = '" & UserID & "' "

                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                If tmptable1.Rows.Count > 0 Then
                    Dim drow1 As DataRow = tmptable1.Rows(0)
                    Call clsData.NullChecker(tmptable1, 0)
                    UserEmailAddress = drow1("Email")
                    UserEmailAddress = drow1("UserNames")
                End If
            Else
                CFPROID = "Instacover"
            End If

            Dim Subject As String = Trim(TextEmailSubject.Text)
            Dim EmailBody As String = MCIEmailHtml()



            If Not ClientEmailAddress = "" And InStr(ClientEmailAddress, "@", CompareMethod.Text) > 0 Then


                If UserEmailAddress = "" Then
                    UserEmailAddress = ClientEmailAddress
                    UserNames = ClientNames
                End If

                Dim MCICoverNote As New DataTable("MCICoverNote")
                MCICoverNote = DirectCast(Session("MCICoverNote"), DataTable)

                Call clsMCICoverNotePDF.MCICoverNotePDF(MCICoverNote, LabelPolicyID.Text, True)
                Dim CoverNotePDFName As String = Server.MapPath(".") & "\mcicovernotes\MCI Cover Note " & PolicyID & ".pdf"


                Dim SendResult As String = ""
                Call clsEmail.SendEmail(ClientEmailAddress, Subject, EmailBody, ClientNames,
                                    UserEmailAddress, UserNames, True, CFPROID, SendResult, CheckDefaultEmailServer.Checked, CoverNotePDFName, LabelMessage1.Text)


                PanelMessage.Visible = False
                ButtonEmailMCICoverNote.Visible = False
                Image7.Visible = True

                If SendResult = "Email Sent" Then
                    Image7.ImageUrl = "messagesent1.png"
                ElseIf SendResult = "Email Not Sent" Then
                    Image7.ImageUrl = "messagenotsent1.png"
                Else
                    Image7.ImageUrl = "error.png"
                    LabelMessage1.Text = SendResult
                End If


            Else
                Label43.Text = "Invalid Email Address"
                Label43.ForeColor = Color.Red
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Private Function MCIEmailHtml() As String

        Dim strBuilder As New StringBuilder()
        Dim strWriter As New StringWriter(strBuilder)
        Dim htw As New HtmlTextWriter(strWriter)
        Me.TableCoverContent.RenderControl(htw)
        Return strBuilder.ToString()

    End Function



    Protected Sub ButtonCloseEmailPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonCloseEmail.Click
        ModalPopupExtender2.Hide()
    End Sub


    Protected Sub ButtonApplyJobCode_Click(sender As Object, e As EventArgs) Handles ButtonApplyJobCode.Click
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonCloseInsuranceCode_Click(sender As Object, e As EventArgs) Handles ButtonCloseInsuranceCode.Click
        ModalPopupExtender1.Hide()
    End Sub


    Protected Sub ButtonDocuments_Click(sender As Object, e As EventArgs) Handles ButtonRequiredDocuments.Click
        Call LoadDialog("documents.aspx?policyid=" & LabelPolicyID.Text & "&marinecargo=1", "Required Marine Cargo Documents")
    End Sub

    Private Sub LoadDialog(src As String, Title As String)
        LablePolicyTitle.Text = Title
        iframe3.Attributes("src") = src
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonCloseDialog_Click(sender As Object, e As EventArgs) Handles ButtonCloseDialog.Click
        ModalPopupExtender4.Hide()
        If Not LabelPolicyID.Text = "" Then
            Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, "", "", LabelPolicyID.Text, "policy", "insurance", LabelMessage1.Text)
            ButtonRequiredDocuments.Text = "Documents - " & DocumentCount & "/6"
        End If
    End Sub

    Protected Sub ButtonApplyInsuranceCode_Click(sender As Object, e As EventArgs) Handles ButtonApplyInsuranceCode.Click
        If Not Trim(TextInsuranceCode.Text) = "" Then
            Call LoadJob("", "")
        End If

    End Sub


    Private Function PolicyIDQR(PolicyID As String) As String
        Dim host As String = ""

        If InStr(Request.Url.ToString, "localhost:90", CompareMethod.Text) > 0 Then
            host = "http://localhost:90"
        ElseIf InStr(Request.Url.ToString, "172.16.254.10", CompareMethod.Text) > 0 Then
            host = "http://172.16.254.105:90"
        ElseIf InStr(Request.Url.ToString, "localhost:91", CompareMethod.Text) > 0 Then
            host = "http://www.cfproonline.com"
        Else
            host = "http://www.cfproonline.com"
        End If



        Dim PolicyQRPath As String = HttpContext.Current.Server.MapPath(".") & "\mcicovernotes"
        If Not Directory.Exists(PolicyQRPath) Then
            Directory.CreateDirectory(PolicyQRPath)
        End If


        Dim PolicyQRName As String = PolicyQRPath & "\" & PolicyID & ".png"



        Dim PolicyURL = host & "/marineinsurancecovernote.aspx?nocovfot=0&policyid=" & HttpUtility.UrlEncode(clsEncr.EncryptString(PolicyID))

        If File.Exists(PolicyQRName) Then
            File.Delete(PolicyQRName)
        End If


        Dim qrGenerator As New QRCodeGenerator()
        Dim qrCode As QRCodeGenerator.QRCode = qrGenerator.CreateQrCode(PolicyURL, QRCodeGenerator.ECCLevel.Q)
        Using bitMap As Bitmap = qrCode.GetGraphic(20)
            Using ms As New MemoryStream()
                bitMap.Save(ms, System.Drawing.Imaging.ImageFormat.Png)
                Dim byteImage As Byte() = ms.ToArray()
                Using fs As FileStream = File.Create(PolicyQRName)
                    fs.Write(byteImage, 0, CInt(byteImage.Length))
                    fs.Close()

                End Using
                ms.Close()
                'Return "data:image/png;base64," + Convert.ToBase64String(byteImage)
            End Using

        End Using

        Dim PolicyQRURL As String = host & "/mcicovernotes/" & PolicyID & ".png"
        Return PolicyQRURL

    End Function


    Protected Sub ButtonCoverNotePDF_Click(sender As Object, e As EventArgs) Handles ButtonCoverNotePDF.Click
        Dim MCICoverNote As New DataTable("MCICoverNote")
        MCICoverNote = DirectCast(Session("MCICoverNote"), DataTable)
        Call clsMCICoverNotePDF.MCICoverNotePDF(MCICoverNote, LabelPolicyID.Text, False)
    End Sub

    Protected Sub ButtonEditPolicy_Click(sender As Object, e As EventArgs) Handles ButtonModifyPurchasePolicy.Click

        Panel16.Visible = False

        Dim destpage As String = "marinecargoinsurance.aspx?policyid=" & LabelPolicyID.Text
        Page.ClientScript.RegisterClientScriptBlock(GetType(String), "", "self.parent.location='" & destpage & "';", True)

    End Sub
End Class


