﻿Public Class optionalalertsettings
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""


            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)



            Dim RecipientID As String = Request.QueryString("recipientid")
            Dim RecipientType As String = Request.QueryString("recipienttype")

            LabelCFPROID.Text = CFPROID
            LabelRecipientID.Text = RecipientID
            LabelRecipientType.Text = RecipientType


            Call LoadOptionalAlerts(CFPROID, RecipientID, RecipientType)
        End If


    End Sub

    Private Sub LoadOptionalAlerts(CFPROID As String, RecipientID As String, RecipientType As String)



        Dim sqlstr As String =
            "SELECT  AlertID, AlertName," &
            "Condition,ID " &
            "FROM Alerts " &
            "Where ToClient = 1 " &
            "And IsOptional = 1 "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr As String = ""
        If RecipientType = "client" Then
            tmpstr = "And ClientID = '" & RecipientID & "' "
            LabelAlertTitle.Text = "Select Alerts To Send to Client"

        ElseIf RecipientType = "importer" Then
            tmpstr = "And ImporterID = '" & RecipientID & "' "
            LabelAlertTitle.Text = "Select Alerts To Send to Consignee / Importer"

        End If

        Dim sqlstr1 As String =
            "SELECT  CFPROID, ClientID," &
            "ImporterID, AlertID " &
            "FROM  SendAlerts " &
            "Where CFPROID = '" & CFPROID & "' " &
           tmpstr

        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)



        Dim col As New DataColumn("Send", Type.GetType("System.Boolean"))
        tmptable.Columns.Add(col)

        Dim a, b, c As Integer
        If tmptable.Rows.Count > 0 Then

            a = 0

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                b = 0
                For Each drow1 In tmptable1.Rows
                    Call clsData.NullChecker(tmptable1, b)
                    If drow("AlertID") = drow1("AlertID") Then
                        drow("Send") = 1
                        c = c + 1
                        Exit For
                    End If
                    b = b + 1
                Next
                a = a + 1
            Next
        End If

        DataList1.DataSource = tmptable
        DataList1.DataBind()

        LabelAlertCount.Text = c & " / " & DataList1.Items.Count & " Optional Alerts Selected "


    End Sub

    Protected Sub ButtonSaveSendAlerts_Click(sender As Object, e As EventArgs) Handles ButtonSaveSendAlerts.Click
        Call SaveSendAlerts(LabelCFPROID.Text, LabelRecipientID.Text, LabelRecipientType.Text)

    End Sub


    Protected Sub CheckAlertType_CheckedChanged(sender As Object, e As EventArgs)

        Dim chkbox As CheckBox
        Dim a As Integer

        For Each item As DataListItem In DataList1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                chkbox = TryCast(item.FindControl("CheckAlertType"), CheckBox)

                If chkbox IsNot Nothing Then
                    If chkbox.Checked Then
                        a = a + 1
                    End If
                End If

            End If
        Next

        LabelAlertCount.Text = a & " / " & DataList1.Items.Count & " Optional Alerts Selected"


    End Sub
    Private Sub SaveSendAlerts(CFPROID As String, RecipientID As String, RecipientType As String)

        Try


            Dim tmpstr As String = ""
            If RecipientType = "client" Then
                tmpstr = "And ClientID = '" & RecipientID & "' "
            ElseIf RecipientType = "importer" Then
                tmpstr = "And ImporterID = '" & RecipientID & "' "
            End If

            Dim sqlstr As String =
            "SELECT  CFPROID, ClientID," &
            "ImporterID, AlertID, ID " &
            "FROM  SendAlerts " &
            "Where CFPROID = '" & CFPROID & "' " &
           tmpstr

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            Dim chkbox As CheckBox
            Dim nfieldAlertID As HiddenField
            Dim found As Boolean
            Dim a As Integer

            For Each item As DataListItem In DataList1.Items

                If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                    chkbox = DirectCast(item.FindControl("CheckAlertType"), CheckBox)
                    nfieldAlertID = DirectCast(item.FindControl("FieldAlertID"), HiddenField)

                    found = False
                    If chkbox IsNot Nothing Then

                        For Each drow In tmptable.Rows
                            If Not drow.RowState = DataRowState.Deleted Then
                                Call clsData.NullChecker(tmptable, a)
                                If drow("AlertID") = nFieldAlertID.Value Then
                                    If Not chkbox.Checked Then
                                        drow.Delete()
                                    Else
                                        found = True
                                    End If
                                    Exit For
                                End If
                            End If

                        Next
                        If Not found Then
                            If chkbox.Checked Then
                                Dim drow1 As DataRow = tmptable.NewRow
                                drow1("CFPROID") = CFPROID
                                drow1("AlertID") = nfieldAlertID.Value

                                If RecipientType = "client" Then
                                    drow1("ClientID") = RecipientID
                                ElseIf RecipientType = "importer" Then
                                    drow1("ImporterID") = RecipientID
                                End If
                                tmptable.Rows.Add(drow1)
                            End If
                        End If

                    End If
                End If
            Next

            Call clsData.SaveData("SendAlerts", tmptable, sqlstr, True, clsData.constr)


            Call LoadOptionalAlerts(CFPROID, RecipientID, RecipientType)


        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

End Class