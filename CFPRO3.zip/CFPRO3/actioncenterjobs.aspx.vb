﻿Public Class actioncenterjobs
    Inherits System.Web.UI.Page


    Dim sqlstr, sqlstr1, sqlstr2 As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            Call LoadJobs()
        End If
    End Sub
    Private Sub LoadJobs()
        Dim sqlstr As String =
            "Select TOP 5 JobId, ReferenceNo," &
                    "JobDate,Agent,Clients.Client," &
                    "ShippingVessel,VesselETA,LastSlingDate, " &
                    "CustomsSystem, BL,CFS " &
                    "From Jobs,Clients Where Clients.ClientId = Jobs.ClientId "
        Dim tmptbl As New DataTable()
        Call clsData.TableData(sqlstr, tmptbl, clsData.constr)
        If tmptbl.Rows.Count > 0 Then
            GridActionCenterJobs.DataSource = tmptbl
            GridActionCenterJobs.DataBind()
        End If
    End Sub

End Class