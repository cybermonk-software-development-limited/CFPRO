﻿
Imports System.Drawing
Public Class shipping
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            Dim CFAgentUserName As String = ""
            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, CFAgentUserName, "", "", "", "", True, "", False)

            LabelCFPROID.Text = CFPROID
            LabelUserID.Text = CFPROUserID
            Dim JobID As String = Request.QueryString("jobid")
            LabelJobID.Text = JobID


            Call LoadCFAgentUsers(CFPROID)
            Call LoadShipStatus(CFPROID)
            Call LoadDeliveryOrderStatus(CFPROID)



            Call LoadShipping(CFPROID, JobID, CFAgentUserName)

            Dim ReadOnlyUser As Boolean = Not clsAuth.ReadOnlyUser(CFPROID, CFPROUserID)

            ButtonSaveShipping.Enabled = ReadOnlyUser
            ButtonGetVessel.Enabled = ReadOnlyUser
            ButtonGetShippingLine.Enabled = ReadOnlyUser

        End If

    End Sub


    Private Sub LoadShipping(CFPROID As String, JobID As String, CFAgentUserName As String)


        Try


            Dim sqlstr As String =
            "Select ClientID, JobTypeID,VesselID," &
            "ShippingLineID,ShipStatus," &
            "ManifestNo,ManifestAdviseDate," &
            "DeliveryOrderStatus,DeliveryOrderCharges," &
            "DeliveryOrderDate,HandoverFees," &
            "ContainerDeposit, ContainerDepositDate, " &
            "ContainerRefundRequestDate,ContainerDepositRefund," &
            "ContainerDepositRefundDate,ContainerDepositDeductions, " &
            "ContainerDepositRemarks,ShippingPersonnel," &
            "ShippingExpenses,ShippingStart,ShippingEnd,ID " &
            "From Jobs " &
            "Where  CFPROID = '" & CFPROID & "' " &
            "And JobID ='" & JobID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim JobType As String = ""
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                JobType = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

                LabelClientID.Text = drow("ClientID")
                LabelJobType.Text = JobType
                LabelVesselID.Text = drow("VesselID")
                LabelShippingLineID.Text = drow("ShippingLineID")

                ComboVesselStatus.Text = drow("ShipStatus")
                TextManifestNo.Text = drow("ManifestNo")

                ComboDeliveryOrderStatus.Text = drow("DeliveryOrderStatus")
                TextDeliveryOrderDate.Text = Format(drow("DeliveryOrderDate"), "dd MMM yyyy")
                TextDeliveryOrderCharges.Text = Format(drow("DeliveryOrderCharges"), "#,##0.#0")
                TextHandOverFees.Text = Format(drow("HandoverFees"), "###,##0.#0")



                TextContainerDeposit.Text = Format(drow("ContainerDeposit"), "#,##0.#0")
                TextContainerDepositDate.Text = Format(drow("ContainerDepositDate"), "dd MMM yyyy")

                TextRefundRequestDate.Text = Format(drow("ContainerRefundRequestDate"), "dd MMM yyyy")
                TextContainerDepositRefund.Text = Format(drow("ContainerDepositRefund"), "#,##0.#0")
                TextContainerDepositRefundDate.Text = Format(drow("ContainerDepositRefundDate"), "dd MMM yyyy")
                TextDeductions.Text = Format(drow("ContainerDepositDeductions"), "#,##0.#0")
                TextRemarks.Text = drow("ContainerDepositRemarks")


                TextExpenses.Text = Format(drow("Shippingexpenses"), "#,##0.#0")
                TextStartDate.Text = Format(drow("ShippingStart"), "dd MMM yyyy")
                TextEndDate.Text = Format(drow("ShippingEnd"), "dd MMM yyyy")
                ComboPersonnel.Text = drow("ShippingPersonnel")

                If CDate(TextStartDate.Text) = CDate("1-Jan-1800") Then
                    TextStartDate.Text = Format(Now, "dd MMM yyyy")
                    ComboPersonnel.Text = CFAgentUserName
                End If

                Call Shippingline(CFPROID, drow("ShippingLineID"), drow("ClientID"), JobType)
                Call SetVessel(CFPROID, drow("VesselID"), Val(TextContainerReturnDays.Text))

            End If
        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub


    Private Sub LoadDeliveryOrderStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status from DeliveryOrderStatus " &
         "Where CFPROID = '" & CFPROID & "' "
        Call clsData.PopCombo(ComboDeliveryOrderStatus, sqlstr, clsData.constr, 0)
        ComboDeliveryOrderStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadShipStatus(CFPROID As String)
        Dim sqlstr As String =
         "Select Status From VesselStatus " &
         "Where CFPROID = '" & CFPROID & "' "
        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "")
    End Sub
    Private Sub SetVessel(CFPROID As String, ByVal VesselID As String, ReturnDays As Integer)

        Dim tmpstr() As String = clsShippingStorage.GetVessel(CFPROID, VesselID, LabelMessage1.Text)
        LabelVesselID.Text = VesselID
        TextVesselName.Text = tmpstr(1)
        TextVoyageNo.Text = tmpstr(2)
        TextVesselETA.Text = tmpstr(3)
        TextBerthingDate.Text = tmpstr(4)
        TextLastSlingDate.Text = tmpstr(5)

        If IsDate(tmpstr(4)) Then
            TextContainerReturnDueDate.Text = clsShippingStorage.ContainerReturnDueDate(CDate(tmpstr(4)), ReturnDays)
        End If


    End Sub




    Private Sub SearchVessel(CFPROID As String)


        Dim sqlstr As String = "Select " &
                "VesselID,Vessel,VoyageNo," &
                "ETA,BerthingDate," &
                "ExitDate,Id " &
                "From  ShippingVessels " &
                "Where  CFPROID = '" & CFPROID & "' " &
                "And Vessel  Like '%" & Trim(TextSearchVessel.Text) & "%' " &
                "And Active = 1 " &
                "Order By ID Desc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer


        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
        Next

        LabelGetVesselMessage.Text = tmptable.Rows.Count & " Vessel(s) found matchng '" & TextSearchVessel.Text & "'"

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("VesselID") = Nothing
            drow("Vessel") = "No Vessels found for '" & TextSearchVessel.Text & "'"
            tmptable.Rows.Add(drow)
        End If



        GridVessels.DataSource = tmptable
        GridVessels.DataBind()
    End Sub


    Protected Sub ButtonGetClient_Click(sender As Object, e As EventArgs) Handles ButtonGetVessel.Click
        Call LoadVessels(LabelCFPROID.Text)
    End Sub


    Private Sub LoadVessels(CFPROID As String)

        ModalPopupExtender1.Show()

        Try

            Dim sqlstr As String =
                "Select top 200 VesselID,Vessel,VoyageNo," &
                "ETA,BerthingDate," &
                "ExitDate,Id " &
                "From ShippingVessels " &
                "Where  CFPROID = '" & CFPROID & "' " &
                "And Active = 1 " &
                "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim Drow As DataRow
            Dim a As Integer

            For Each Drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
            Next


            LabelGetVesselMessage.Text = tmptable.Rows.Count & " Vessel(s) Loaded."

            If tmptable.Rows.Count = 0 Then
                Drow = tmptable.NewRow
                Drow("VesselID") = Nothing
                Drow("Vessel") = "No Vessels"
                tmptable.Rows.Add(Drow)
            End If


            GridVessels.DataSource = tmptable
            GridVessels.DataBind()



        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try


    End Sub


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)


        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridVessels, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs)
        Dim row As GridViewRow = GridVessels.Rows(GridVessels.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridVessels.Rows.Count - 1
            row = GridVessels.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridVessels.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Protected Sub OnRowDataBound1(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridShippingLine, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged1(sender As Object, e As EventArgs)
        Dim row As GridViewRow = GridShippingLine.Rows(GridShippingLine.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridShippingLine.Rows.Count - 1
            row = GridShippingLine.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridShippingLine.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub
    Protected Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Call SearchVessel(LabelCFPROID.Text)
    End Sub


    Private Sub SaveShipping(CFPROID As String, JobID As String)
        Try

            Dim sqlstr As String =
                "Select VesselID,ShippingLineID," &
                "ManifestNo,ManifestAdviseDate," &
                "DeliveryOrderStatus,DeliveryOrderCharges," &
                "ShipStatus,DeliveryOrderDate," &
                "HandoverFees,ContainerDeposit," &
                "ContainerDepositDate,ContainerRefundRequestDate," &
                "ContainerDepositRefund," &
                "ContainerDepositRefundDate,ContainerDepositDeductions, " &
                "ContainerDepositRemarks,ShippingPersonnel," &
                "ShippingExpenses,ShippingStart," &
                "ShippingEnd,ID " &
                "From Jobs " &
                "Where  CFPROID = '" & CFPROID & "' " &
                "And JobId ='" & JobID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)

                drow("ShippingLineID") = LabelShippingLineID.Text
                drow("VesselID") = LabelVesselID.Text

                drow("ShipStatus") = ComboVesselStatus.Text
                drow("ManifestNo") = TextManifestNo.Text

                drow("DeliveryOrderStatus") = ComboDeliveryOrderStatus.Text
                drow("DeliveryOrderCharges") = TextDeliveryOrderCharges.Text
                drow("DeliveryOrderDate") = TextDeliveryOrderDate.Text
                drow("HandoverFees") = TextHandOverFees.Text

                drow("ContainerDeposit") = TextContainerDeposit.Text
                drow("ContainerDepositDate") = TextContainerDepositDate.Text


                drow("ContainerRefundRequestDate") = TextRefundRequestDate.Text
                drow("ContainerDepositRefund") = TextContainerDepositRefund.Text
                drow("ContainerDepositRefundDate") = TextContainerDepositRefundDate.Text
                drow("ContainerDepositDeductions") = TextDeductions.Text
                drow("ContainerDepositRemarks") = TextRemarks.Text

                drow("ShippingStart") = TextStartDate.Text
                drow("ShippingEnd") = TextEndDate.Text

                drow("Shippingexpenses") = TextExpenses.Text
                drow("ShippingPersonnel") = ComboPersonnel.Text


                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
                Call UpdateVesselStatusAllJobs(CFPROID, LabelVesselID.Text, JobID, ComboVesselStatus.Text, CheckVesselStatusAll.Checked, TodaysDate.Value)


            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub ButtonSaveShipping_Click(sender As Object, e As EventArgs) Handles ButtonSaveShipping.Click
        Call SaveShipping(LabelCFPROID.Text, LabelJobID.Text)
    End Sub


    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr1 As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPersonnel, sqlstr1, clsData.constr, 0)

        ComboPersonnel.Items.Insert(0, "")
    End Sub
    Private Sub LoadShippingLines(CFPROID As String)

        ModalPopupExtender2.Show()

        Dim sqlstr As String =
        "Select ShippingLineID, ShippingLine " &
        "From ShippingLines " &
        "Where  CFPROID = '" & CFPROID & "' " &
        "Order By ShippingLine Asc;"

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            a = a + 1
        Next

        LabelGetShippingLineMessage.Text = tmptable.Rows.Count & " ShippingLine(s) Loaded."


        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ShippingLineID") = Nothing
            drow("ShippingLine") = "No Shipping Lines"
            tmptable.Rows.Add(drow)
        End If

        GridShippingLine.DataSource = tmptable
        GridShippingLine.DataBind()

    End Sub
    Private Sub SearchShippingLine(CFPROID As String)


        Dim sqlstr As String =
                "Select ShippingLineID,ShippingLine, " &
                 "LocalReturnDays, TransitReturnDays,Id  " &
                 "From ShippingLines " &
                 "Where  CFPROID = '" & CFPROID & "' " &
                 "And ShippingLine Like '%" & Trim(TextSearchShippingLine.Text) & "%' " &
                 "Order By ShippingLine Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer


        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
        Next

        LabelGetShippingLineMessage.Text = tmptable.Rows.Count & " ShippingLine(s) found matching '" & TextSearchShippingLine.Text & "'"

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ShippingLineID") = Nothing
            drow("ShippingLine") = "No Shippings Lines found matching '" & TextSearchShippingLine.Text & "'"
            tmptable.Rows.Add(drow)
        End If



        GridShippingLine.DataSource = tmptable
        GridShippingLine.DataBind()
    End Sub




    Private Sub Shippingline(CFPROID As String, ShippingLineID As String, nClientID As String, JobType As String)
        Try

            Dim tmpstr() As String = clsShippingStorage.GetShippingline(CFPROID, ShippingLineID, LabelMessage1.Text)
            ReDim Preserve tmpstr(3)
            LabelShippingLineID.Text = ShippingLineID
            TextShippingLine.Text = tmpstr(1)

            Dim ReturnDays As Integer = clsShippingStorage.DemurrageFreeDays(CFPROID, nClientID, ShippingLineID, JobType, tmpstr(2), tmpstr(3))

            TextContainerReturnDays.Text = ReturnDays
            TextContainerReturnDueDate.Text = clsShippingStorage.ContainerReturnDueDate(TextBerthingDate.Text, ReturnDays)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Protected Sub ButtonGetShippingLine_Click(sender As Object, e As EventArgs) Handles ButtonGetShippingLine.Click
        Call LoadShippingLines(LabelCFPROID.Text)
    End Sub

    Protected Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        Call SearchShippingLine(LabelCFPROID.Text)
    End Sub


    Protected Sub LinkShippingLine_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ShippingLineID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        Call Shippingline(LabelCFPROID.Text, ShippingLineID, LabelClientID.Text, LabelJobType.Text)
        ModalPopupExtender2.Hide()
    End Sub

    Protected Sub LinkVessel_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text
        Call SetVessel(LabelCFPROID.Text, ItemID, Val(TextContainerReturnDays.Text))

        ModalPopupExtender1.Hide()
    End Sub

    Protected Sub ButtonAddVessel_Click(sender As Object, e As EventArgs) Handles ButtonAddVessel.Click
        ModalPopupExtender1.Hide()
        LabelVesselID.Text = "-1"
        Call AddEditvessel(LabelCFPROID.Text, LabelVesselID.Text, False)
    End Sub
    Private Sub AddEditvessel(CFPROID As String, VesselID As String, edit As Boolean)
        Try



            If edit Then
                If LabelVesselID.Text = "" Then
                    LabelMessage.Text = "Please Set a Vessel."
                    Exit Sub
                End If

                LabelAddEditVessel.Text = "Edit Vessel"
                LabelAddEditVessel.ForeColor = Color.Silver

                Dim sqlstr As String = "SELECT VesselID,Vessel,VoyageNo," &
                                        "ShippingLine,ETA," &
                                        "BerthingDate,ExitDate," &
                                        "Active, ID " &
                                        "From  ShippingVessels " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And VesselID = '" & VesselID & "' "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)


                    TextEditVesselName.Text = drow("Vessel")
                    TextEditVoyageNo.Text = drow("VoyageNo")
                    TextEditVesselETA.Text = Format(drow("ETA"), "dd MMM yyyy")
                    TextEditBerthingDate.Text = Format(drow("BerthingDate"), "dd MMM yyyy")
                    TextEditExitDate.Text = Format(drow("ExitDate"), "dd MMM yyyy")
                    CheckActive.Checked = drow("Active")

                End If

            Else
                LabelAddEditVessel.Text = "Add Vessel"
                LabelAddEditVessel.ForeColor = Color.Silver

                TextEditVesselName.Text = ""
                TextEditVoyageNo.Text = ""
                TextEditVesselETA.Text = ""
                TextEditBerthingDate.Text = ""
                TextEditExitDate.Text = ""
                CheckActive.Checked = True
            End If

            ModalPopupExtender3.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub



    Protected Sub ButtonSaveVessel_Click(sender As Object, e As EventArgs) Handles ButtonSaveVessel.Click
        Call SaveVessel(LabelCFPROID.Text)
    End Sub

    Private Sub SaveVessel(CFPROID As String)

        Try

            If Trim(TextEditVesselName.Text) = "" Then
                LabelAddEditVessel.Text = "Invalid Vessel Name"
                LabelAddEditVessel.ForeColor = Color.Red
                ModalPopupExtender3.Show()
                Exit Sub
            End If

            Dim tmpstr(5) As String
            tmpstr(0) = Trim(UCase(TextEditVesselName.Text))
            tmpstr(1) = Trim(TextEditVoyageNo.Text)
            tmpstr(2) = Trim(TextEditVesselETA.Text)
            tmpstr(3) = Trim(TextEditBerthingDate.Text)
            tmpstr(4) = Trim(TextEditExitDate.Text)
            tmpstr(5) = CheckActive.Checked.ToString

            Call clsShippingStorage.SaveVessel(CFPROID, tmpstr, LabelVesselID.Text, "-1", "")
            Call SetVessel(CFPROID, LabelVesselID.Text, Val(TextContainerReturnDays.Text))

            ModalPopupExtender3.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonVesselETA_Click(sender As Object, e As EventArgs) Handles ButtonVesselETA.Click
        Call AddEditvessel(LabelCFPROID.Text, LabelVesselID.Text, True)
    End Sub

    Protected Sub ButtonAddEditVoyageNo_Click(sender As Object, e As EventArgs) Handles ButtonAddEditVoyageNo.Click
        Call AddEditvessel(LabelCFPROID.Text, LabelVesselID.Text, True)
    End Sub

    Protected Sub ButtonBerthingDate_Click(sender As Object, e As EventArgs) Handles ButtonBerthingDate.Click
        Call AddEditvessel(LabelCFPROID.Text, LabelVesselID.Text, True)
    End Sub

    Protected Sub ButtonlastSlingDate_Click(sender As Object, e As EventArgs) Handles ButtonlastSlingDate.Click
        Call AddEditvessel(LabelCFPROID.Text, LabelVesselID.Text, True)
    End Sub



    Private Sub UpdateVesselStatusAllJobs(CFPROID As String, VesselID As String, JobID As String, VesselStatus As String, AllJobs As Boolean, nTodaysDate As String)

        Try

            Dim tmpstr As String = ""
            If InStr(VesselStatus, "WAIT", CompareMethod.Text) > 0 Then

                If Not AllJobs Then
                    tmpstr = "And JobID ='" & JobID & "' "
                End If

                Dim sqlstr As String =
                             "Select VesselID, JobID," &
                              "ShipStatus, ID " &
                             "From Jobs " &
                             "Where  CFPROID = '" & CFPROID & "' " &
                             "And VesselID ='" & VesselID & "' " &
                             tmpstr

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)


                Dim KPIProgressID As String = "-1"

                If IsDate(nTodaysDate) Then
                    nTodaysDate = Format(CDate(nTodaysDate), "dd MMM yyyy HH:mm")
                Else
                    nTodaysDate = Format(Now, "dd MMM yyyy HH:mm")
                End If


                Dim drow As DataRow
                Dim a As Integer

                For Each drow In tmptable.Rows
                    drow("ShipStatus") = VesselStatus

                    If Not clsProgressUpdates.UpdateExists(CFPROID, drow("JobID"), "000001", nTodaysDate, LabelMessage1.Text) Then

                        Call clsData.NullChecker(tmptable, a)
                        Call clsProgressUpdates.UpdateKPIProgress(CFPROID, drow("JobID"), "000001", KPIProgressID,
                                                           "VESSEL STATUS IS " & UCase(VesselStatus), nTodaysDate, LabelUserID.Text, -1, False, False, LabelMessage1.Text)

                    End If

                    a = a + 1
                Next

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


End Class