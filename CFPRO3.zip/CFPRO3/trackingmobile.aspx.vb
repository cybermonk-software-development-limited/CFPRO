﻿
Imports System.Drawing


Public Class trackingmobile
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            TextCFAgent.Attributes.Add("value", "Search & Select C&F Agent")
            TextCFAgent.Style.Add("color", "LightGrey")
            TextCFAgent.Attributes.Add("onFocus", "if(this.value == 'Search & Select C&F Agent') {this.value = '';}")
            TextCFAgent.Attributes.Add("onBlur", "if (this.value == '') {this.value = 'Search & Select C&F Agent';} {this.style.color = ''}")
            TextCFAgent.Attributes.Add("onClick", "this.style.color = ''; if(this.value !== 'Search & Select C&F Agent') {this.selectionStart = this.value.length;}")


            TextTrack.Attributes.Add("value", "Enter Number")
            TextTrack.Style.Add("color", "LightGrey")
            TextTrack.Attributes.Add("onFocus", "if(this.value == 'Enter Number') {this.value = '';}")
            TextTrack.Attributes.Add("onBlur", "if (this.value == '') {this.value = 'Enter Number';} {this.style.color = ''}")
            TextTrack.Attributes.Add("onClick", "this.style.color = ''; if(this.value !== 'Enter Number') {this.selectionStart = this.value.length;}")

            Dim CFPROID As String = ""

            If IsNothing(Request.Cookies("CFPROID")) And IsNothing(Request.QueryString("cfproid")) Then
                PanelCFAgent.Visible = False
                PanelCFAgent.Height = 0

                PanelSearch.Visible = True
                PanelSearch.Height = 68

            ElseIf Not IsNothing(Request.Cookies("CFPROID")) Then
                CFPROID = clsEncr.DecryptString(Request.Cookies("CFPROID").Value)

                Call LoadCFAgent(CFPROID)

            ElseIf Not IsNothing(Request.QueryString("cfproid")) Then
                CFPROID = clsEncr.DecryptString(Request.QueryString("cfproid"))
                Call LoadCFAgent(CFPROID)

            End If
            If IsNothing(Request.Cookies("CFPROToken")) Then
                Call RegisterToken()
            End If



            If Not IsNothing(Request.QueryString("internal")) Then
                If Request.QueryString("internal") = "1" Then
                    PanelHeader.Visible = False
                    PanelFooter.Visible = False
                    PanelChangeCFAgent.Visible = False
                    LabelCFAgentName.Visible = False
                    If CFPROID = "CFPR000000272-80" Then
                        RadioButtonList1.Items.RemoveAt(2)
                    End If
                End If
            End If

            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin("", "", CFPROUserID, LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, "", False)



            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub


    Private Sub LoadCFAgent(CFPROID As String)

        LabelCFPROID.Text = CFPROID


        Dim sqlstr As String =
            "SELECT   CFPROID, CFAgentName," &
            "CFAgentAddress,LogoURL,  ID " &
            "FROM  CFPROAccounts " &
            "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim a As Integer
            Dim drow As DataRow = tmptable.Rows(0)

            LabelCFAgentName.Text = drow("CFAgentName")
            LabelAddress.Text = drow("CFAgentAddress")

            Dim tmpstr() As String
            tmpstr = drow("LogoURL").ToString.Split(".")
            a = tmpstr.GetUpperBound(0)
            If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFPROID") & "." & tmpstr(a)) Then
                ImageCFAgent.ImageUrl = "~/cfagentimages/" & drow("CFPROID") & "." & tmpstr(a)
            Else
                ImageCFAgent.ImageUrl = "~/cfagentimages/000000000.png"
            End If


            PanelCFAgent.Visible = True

            PanelSearch.Visible = False
            PanelSearch.Height = 0


            Response.Cookies("CFPROID").Value = clsEncr.EncryptString(CFPROID)
            Response.Cookies("CFPROID").Expires = Now.AddDays(30)


            Dim UserType As String = "tracking"
            Response.Cookies("UserType").Value = UserType

            Dim AuthDet As String = drow("CFPROID") & "|" & drow("CFAgentName") & "|" & "-" & "|" & UserType & "|" & drow("CFAgentAddress")

            Response.Cookies("CFAgent").Value = AuthDet
            Response.Cookies("CFAgent").Expires = Now.AddHours(94)


            LabelCFPROID.Text = clsEncr.EncryptString(CFPROID)

            Try
                If Not IsNothing(Request.QueryString("refno")) Then
                    If Not Request.QueryString("refno") = "" Then
                        RadioButtonList1.SelectedIndex = 2
                        TextTrack.Text = Request.QueryString("refno")
                        Call clsProgressUpdates.Track(LabelCFPROID.Text, Request.QueryString("refno"), RadioButtonList1, LabelUserType.Text, LabelMessage)
                    End If
                End If

                If Not IsNothing(Request.Cookies("SearchedItem")) Then
                    Dim SearchedItem() As String = Request.Cookies("SearchedItem").Value.ToString.Split("|")
                    ReDim Preserve SearchedItem(1)
                    RadioButtonList1.SelectedIndex = CInt(SearchedItem(0))
                    TextTrack.Text = SearchedItem(1)
                End If

            Catch ex As Exception

            End Try

        Else

            PanelCFAgent.Visible = False
            PanelCFAgent.Height = 0

            PanelSearch.Visible = True
            PanelSearch.Height = 68

        End If



    End Sub
    Private Sub RegisterToken()

        If Not IsNothing(Request.QueryString("logintoken")) Then
            Call clsAuth.SignInOut("Sign Out", LabelUser.Text, Image1.ImageUrl, False, "tracking.aspx")
            Call clsAuth.LoginToken(Request.QueryString("logintoken"), False, LabelMessage1.Text)
        End If
    End Sub

    Protected Sub ButtonTrack_Click(sender As Object, e As EventArgs) Handles ButtonTrack.Click
        Call clsProgressUpdates.Track(LabelCFPROID.Text, TextTrack.Text, RadioButtonList1, LabelUserType.Text, LabelMessage)
    End Sub


    <System.Web.Script.Services.ScriptMethod(),
  System.Web.Services.WebMethod()>
    Public Shared Function SearchCFAgent(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return clsData.GetCFAgents(prefixText, count)
    End Function

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image1.ImageUrl, True, "tracking.aspx")
    End Sub

    Protected Sub TextCFAgent_TextChanged(sender As Object, e As EventArgs) Handles TextCFAgent.TextChanged
        Call LoadCFAgent(CFPROIDField.Value)
        TextTrack.Focus()
    End Sub



    Protected Sub ButtonChangeCFAgent_Click(sender As Object, e As EventArgs) Handles ButtonChangeCFAgent.Click

        PanelCFAgent.Visible = False
        PanelSearch.Visible = True
        PanelSearch.Height = 68
        PanelCFAgent.Height = 0

        Response.Cookies("CFPROID").Expires = Now.AddDays(-1)
        Response.Cookies("CFAgent").Expires = Now.AddDays(-1)

    End Sub
End Class