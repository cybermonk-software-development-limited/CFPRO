﻿Public Class clsTextToHtml

    Private Sub New()
    End Sub
    Private Shared _paraBreak As String = vbCr & vbLf & vbCr & vbLf
    Private Shared _link As String = "<a href=""{0}"">{1}</a>"
    Private Shared _linkNoFollow As String = "<a href=""{0}"" rel=""nofollow"">{1}</a>"

 
    '<System.Runtime.CompilerServices.Extension> _
    Public Shared Function ToHtml(s As String) As String
        Return ToHtml(s, False)
    End Function

    
    '<System.Runtime.CompilerServices.Extension> _
    Public Shared Function ToHtml(s As String, nofollow As Boolean) As String
        Dim sb As New StringBuilder()

        Dim pos As Integer = 0
        While pos < s.Length
            ' Extract next paragraph
            Dim start As Integer = pos
            pos = s.IndexOf(_paraBreak, start)
            If pos < 0 Then
                pos = s.Length
            End If
            Dim para As String = s.Substring(start, pos - start).Trim()

            ' Encode non-empty paragraph
            If para.Length > 0 Then
                EncodeParagraph(para, sb, nofollow)
            End If

            ' Skip over paragraph break
            pos += _paraBreak.Length
        End While
        ' Return result
        Return sb.ToString()
    End Function

    ''' <summary>
    ''' Encodes a single paragraph to HTML.
    ''' </summary>
    ''' <param name="s">Text to encode</param>
    ''' <param name="sb">StringBuilder to write results</param>
    ''' <param name="nofollow">If true, links are given "nofollow"
    ''' attribute</param>
    Private Shared Sub EncodeParagraph(s As String, sb As StringBuilder, nofollow As Boolean)
        ' Start new paragraph
        ' sb.AppendLine("<p>")

        ' HTML encode text
        s = HttpUtility.HtmlEncode(s)

        ' Convert single newlines to <br>
        s = s.Replace(Environment.NewLine, "<br/>" & vbCr & vbLf)


        ' Encode any hyperlinks
        EncodeLinks(s, sb, nofollow)

        ' Close paragraph
        sb.AppendLine(vbCr & vbLf & "</p>")
    End Sub

    
    Private Shared Sub EncodeLinks(s As String, sb As StringBuilder, nofollow As Boolean)
        ' Parse and encode any hyperlinks
        Dim pos As Integer = 0
        While pos < s.Length
            ' Look for next link
            Dim start As Integer = pos
            pos = s.IndexOf("[[", pos)
            If pos < 0 Then
                pos = s.Length
            End If

            ' Copy text before link
            sb.Append(s.Substring(start, pos - start))
            If pos < s.Length Then
                Dim label As String, link As String

                start = pos + 2
                pos = s.IndexOf("]]", start)
                If pos < 0 Then
                    pos = s.Length
                End If
                label = s.Substring(start, pos - start)
                Dim i As Integer = label.IndexOf("][")
                If i >= 0 Then
                    link = label.Substring(i + 2)
                    label = label.Substring(0, i)
                Else
                    link = label
                End If
                ' Append link
                sb.Append([String].Format(If(nofollow, _linkNoFollow, _link), link, label))

                ' Skip over closing "]]"
                pos += 2
            End If
        End While
    End Sub


End Class
