﻿Public Class portcustoms
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           

            Dim CFPROID As String = ""
            Dim CFAgentUserName As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", CFAgentUserName, "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Call LoadDocumentStatus(CFPROID)
            Call LoadCurrencies()
            'Call LoadPortChargesStatus(CFPROID)
            'Call LoadPickUpOrderStatus(CFPROID)
            'Call LoadLoadingStatus(CFPROID)
            Call ReleaseOrderStatus(CFPROID)
            Call LoadCFAgentUsers(CFPROID)

            Call LoadPort(CFPROID, CFAgentUserName)

        End If
    End Sub

    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr1 As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPersonnel, sqlstr1, clsData.constr, 0)
        ComboPersonnel.Items.Insert(0, "")
    End Sub

    Private Sub ReleaseOrderStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status " &
        "From ReleaseOrderStatus " &
        "Where CFPROID ='" & CFPROID & "' "
        Call clsData.PopCombo(ComboReleaseOrderStatus, sqlstr, clsData.constr, 0)
        ComboReleaseOrderStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadLoadingStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status from LoadingStatus " &
        "Where CFPROID ='" & CFPROID & "' "
        Call clsData.PopCombo(ComboLoadingStatus, sqlstr, clsData.constr, 0)
        ComboLoadingStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadPickUpOrderStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status from PickUpOrderStatus " &
        "Where CFPROID ='" & CFPROID & "' "
        Call clsData.PopCombo(ComboPickUpOrderStatus, sqlstr, clsData.constr, 0)
        ComboPickUpOrderStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadPortChargesStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status from PortChargesStatus " &
        "Where CFPROID ='" & CFPROID & "' "
        Call clsData.PopCombo(ComboPortChargesStatus, sqlstr, clsData.constr, 0)
        ComboPortChargesStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadCurrencies()
        Dim sqlstr As String =
        "Select CurrencyCode From Currencies"
        Call clsData.PopCombo(ComboCurrency, sqlstr, clsData.constr, 0)
        ComboCurrency.Items.Insert(0, "")
    End Sub

    Private Sub LoadDocumentStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status From DocumentStatus " &
        "Where CFPROID ='" & CFPROID & "' "
        Call clsData.PopCombo(ComboDocumentStatus, sqlstr, clsData.constr, 0)
        ComboDocumentStatus.Items.Insert(0, "")
    End Sub

    Private Sub LoadPort(CFPROID As String, CFAgentUserName As String)
        Dim JobId As String = Request.QueryString("jobId")

        Dim sqlstr As String =
        "Select DocumentStatus," &
        "DocumentsLodgeDate,PortCharges," &
        "PortChargesStatus,PortChargesPaidDate," &
        "ReleaseOrderStatus,ReleaseOrderDate," &
        "PortChargesCurrency,LoadingStatus,LoadingDate," &
        "PickupOrderStatus,PickUpOrderDate," &
        "PortStartDate,PortEndDate," &
        "PortExpenses,PortStaff," &
        "PortInvoiceNo,WareHouseRent,ID " &
        "From Jobs " &
        "Where CFPROID ='" & CFPROID & "' " &
        "And JobID = '" & JobId & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            ComboDocumentStatus.Text = drow("DocumentStatus")
            TextDocumentsLodgeDate.Text = Format(drow("DocumentsLodgeDate"), "dd MMM yyyy")

            ComboReleaseOrderStatus.Text = drow("ReleaseOrderStatus")
            TextReleaseOrderDate.Text = Format(drow("ReleaseOrderDate"), "dd MMM yyyy")

            ComboPortChargesStatus.Text = drow("PortChargesStatus")
            TextPortChargesPaidDate.Text = Format(drow("PortChargesPaidDate"), "dd MMM yyyy")

            TextPortCharges.Text = Format(drow("PortCharges"), "#,##0.#0")
            ComboCurrency.Text = drow("PortChargesCurrency")

            ComboLoadingStatus.Text = drow("LoadingStatus")
            TextLoadingDate.Text = Format(drow("LoadingDate"), "dd MMM yyyy")


            ComboPickUpOrderStatus.Text = drow("PickupOrderStatus")
            TextPickupOrderDate.Text = Format(drow("PickUpOrderDate"), "dd MMM yyyy")

            TextPortInvoiceNo.Text = drow("PortInvoiceNo")
            TextWarehouseRent.Text = Format(drow("WareHouseRent"), "#,##0.#0")

            TextStartDate.Text = Format(drow("PortStartDate"), "dd MMM yyyy")
            TextEndDate.Text = Format(drow("PortEndDate"), "dd MMM yyyy")
            TextPortExpenses.Text = Format(drow("PortExpenses"), "#,##0.#0")

            ComboPersonnel.Text = drow("PortStaff")

            If CDate(TextStartDate.Text) = CDate("1-Jan-1800") Then
                TextStartDate.Text = Format(Now, "dd MMM yyyy")
                ComboPersonnel.Text = CFAgentUserName
            End If
        End If

    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SavePort(LabelCFPROID.Text)
    End Sub

    Private Sub SavePort(CFPROID As String)

        Dim JobId As String = Request.QueryString("jobId")

        Dim sqlstr As String =
             "Select DocumentStatus," &
             "DocumentsLodgeDate,PortCharges," &
             "PortChargesStatus,PortChargesPaidDate," &
             "ReleaseOrderStatus,ReleaseOrderDate," &
             "PortChargesCurrency,LoadingStatus,LoadingDate," &
             "PickupOrderStatus,PickUpOrderDate," &
             "PortStartDate,PortEndDate," &
             "PortExpenses,PortStaff," &
             "PortInvoiceNo,WareHouseRent,Id " &
             "From Jobs " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And JobID = '" & JobId & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow


        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            drow("PortCharges") = TextPortCharges.Text
            drow("PortStartDate") = TextStartDate.Text

            drow("DocumentStatus") = ComboDocumentStatus.Text
            drow("DocumentsLodgeDate") = TextDocumentsLodgeDate.Text

            drow("PortChargesStatus") = ComboPortChargesStatus.Text
            drow("PortChargesPaidDate") = TextPortChargesPaidDate.Text
            drow("PortChargesCurrency") = ComboCurrency.Text

            drow("ReleaseOrderStatus") = ComboReleaseOrderStatus.Text
            drow("ReleaseOrderDate") = TextReleaseOrderDate.Text

            drow("PickupOrderStatus") = ComboPickUpOrderStatus.Text
            drow("PickUpOrderDate") = TextPickUpOrderDate.Text

            drow("LoadingStatus") = ComboLoadingStatus.Text
            drow("LoadingDate") = TextLoadingDate.Text

            drow("PortEndDate") = TextEndDate.Text
            drow("PortExpenses") = TextPortExpenses.Text

            drow("PortStaff") = ComboPersonnel.Text
            drow("PortInvoiceNo") = TextPortInvoiceNo.Text
            drow("WareHouseRent") = TextWarehouseRent.Text
            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

        End If
    End Sub

   
End Class