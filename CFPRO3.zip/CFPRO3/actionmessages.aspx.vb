﻿Imports System.Drawing

Public Class actionmessages
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then



            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", False)
            LabelCFPROID.Text = CFPROID

            Call LoadMessages(CFPROID, "")

        End If

    End Sub

    Private Sub LoadMessages(ByVal CFPROID As String, SearchStr As String)

        Try

            Dim tmpstr1 As String = ""

            If Not Trim(SearchStr) = "" Then
                tmpstr1 = "And Message Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select Message, " &
                                    "StartDate,EndDate," &
                                    "Active,ID " &
                                    "From  ActionMessages " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    tmpstr1 &
                                    "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    If CDate(drow("StartDate")) = CDate("1-Jan-1800") Then
                        drow("StartDate") = DBNull.Value
                    End If

                    If CDate(drow("EndDate")) = CDate("1-Jan-1800") Then
                        drow("EndDate") = DBNull.Value
                    End If

                    a = a + 1
                Next
            End If

            Session("MessagesTable") = tmptable
            GridActionMessage.DataSource = tmptable
            GridActionMessage.DataBind()



            If Not Trim(SearchStr) = "" Then
                LabelMessagesCaption.Text = tmptable.Rows.Count & " Messages found matching  '" & TextSearch.Text & "' "
            Else
                LabelMessagesCaption.Text = tmptable.Rows.Count & " Messages"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub GridActionMessage_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridActionMessage.SelectedIndexChanged
        Dim row As GridViewRow = GridActionMessage.Rows(GridActionMessage.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridActionMessage.Rows.Count - 1
            row = GridActionMessage.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridActionMessage.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridActionMessage_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridActionMessage.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridActionMessage, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonEditMessage_Click(sender As Object, e As EventArgs) Handles ButtonEditMessage.Click
        Call AddEditMessage(LabelCFPROID.Text, True)
    End Sub

    Protected Sub ButtonAddMessage_Click(sender As Object, e As EventArgs) Handles ButtonNewMessage.Click
        Call AddEditMessage(LabelCFPROID.Text, False)
    End Sub

    Private Sub AddEditMessage(CFPROID As String, edit As Boolean)
        Try

            If edit Then
                If GridActionMessage.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select a Message From the List"
                    Exit Sub
                End If

                LabelAddEditMessage.Text = "Edit Message"
                Dim ID As Integer = GridActionMessage.SelectedValue

                Dim sqlstr As String = "Select [Message]," &
                                        "StartDate,EndDate," &
                                        "[Active],ID " &
                                        "From  ActionMessages " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)

                    TextMessage.Text = drow("Message")
                    TextStartDate.Text = Format(drow("StartDate"), "dd MMM yyyy")
                    TextEndDate.Text = Format(drow("EndDate"), "dd MMM yyyy")
                    CheckActive.Checked = drow("Active")

                End If

            Else
                LabelAddEditMessage.Text = "Add Message"
                TextMessage.Text = "New Message..."
                TextStartDate.Text = Format(Now, "dd MMM yyyy")
                TextEndDate.Text = Format(Now, "dd MMM yyyy")

                CheckActive.Checked = True
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSaveMessage_Click(sender As Object, e As EventArgs) Handles ButtonSaveMessage.Click
        Call SaveMessage(LabelCFPROID.Text)
    End Sub


    Private Sub SaveMessage(CFPROID As String)

        Try
            Dim ID As Integer = -1

            If InStr(LabelAddEditMessage.Text, "Edit") > 0 Then
                ID = GridActionMessage.SelectedValue
            End If


            Dim sqlstr As String = "SELECT [Message]," &
                                   "StartDate,EndDate," &
                                    "[Active],CFPROID, ID " &
                                    "From  ActionMessages " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Message") = TextMessage.Text

            If IsDate(Trim(TextStartDate.Text)) Then
                drow("StartDate") = Trim(TextStartDate.Text)
            End If


            If IsDate(Trim(TextEndDate.Text)) Then
                drow("EndDate") = Trim(TextEndDate.Text)
            End If


            drow("Active") = CheckActive.Checked

            Call clsData.SaveData("ActionMessages", tmptable, sqlstr, False, clsData.constr)

            ModalPopupExtender2.Hide()

            Call LoadMessages(LabelCFPROID.Text, "")

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridActionMessage.SelectedIndex >= 0 Then
            Call PromptDeleteMessage(GridActionMessage.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select a Message From the List"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteMessage(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridActionMessage.Rows(GridActionMessage.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteMessage(GridActionMessage.SelectedValue)
    End Sub
    Private Sub DeleteMessage(ID As Integer)

        Dim sqlstr As String =
                 "Select  ID " &
                  "From ActionMessages  " &
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("ActionMessages", tmptable, sqlstr, True, clsData.constr)

            Call LoadMessages(LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadMessages(LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadMessages(LabelCFPROID.Text, "")
    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click


        Dim Fields(4) As String
        Fields(0) = "ID"
        Fields(1) = "Message"
        Fields(2) = "StartDate"
        Fields(3) = "EndDate"
        Fields(4) = "Active"


        Dim Fields1(4) As String
        Fields1(0) = "Message ID"
        Fields1(1) = "Message "
        Fields1(2) = "Start Date"
        Fields1(3) = "End Date"
        Fields1(4) = "Active"


        Dim tmptable As New DataTable("MessagesTable")
        tmptable = DirectCast(Session("MessagesTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Action Messages", "Action Messages",
                                            LabelMessagesCaption.Text, False, Nothing, 0, "", Fields, Fields1, tmptable, False)


    End Sub


End Class