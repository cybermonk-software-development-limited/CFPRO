﻿

Public Class clsShippingStorage

    Public Enum ShippingLine
        ShippingLineID = 0
        ShippingLine = 1
        TransitReturnDays = 2
        LocalReturnDays = 3
    End Enum

    Public Enum Vessel
        VesselID = 0
        Vessel = 1
        VoyageNo = 2
        ETA = 3
        BerthingDate = 4
        ExitDate = 5
    End Enum
    Shared Function GetShippingline(CFPROID As String, ShippingLineID As String, ByRef ErrMsg As String) As String()

        Dim tmpstr(3) As String
        Try

            Dim sqlstr As String =
            "Select ShippingLineID,ShippingLine, " &
            "LocalReturnDays, TransitReturnDays,ID  " &
            "From ShippingLines " &
            "Where  CFPROID = '" & CFPROID & "' " & _
            "And ShippingLineID = '" & ShippingLineID & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim ReturnDays As Integer = 0
            Dim nClientdaystodemurrage(3) As Integer

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                tmpstr(1) = drow("ShippingLineID")
                tmpstr(1) = drow("ShippingLine")
                tmpstr(2) = drow("TransitReturnDays")
                tmpstr(3) = drow("LocalReturnDays")
            Else
                tmpstr(0) = ""
                tmpstr(1) = ""
                tmpstr(2) = 0
                tmpstr(3) = 0
            End If

            Return tmpstr


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
            Return tmpstr
        End Try

    End Function

    Shared Function GetVessel(CFPROID As String, ByVal VesselID As String, ByRef ErrMsg As String) As String()

        Dim tmpstr(5) As String
        Try

            Dim tmptable As New DataTable()
            Dim sqlstr As String = _
                "SELECT VesselID, Vessel, " &
                "VoyageNo,ETA,BerthingDate," &
                "ExitDate, ID " &
                "From  ShippingVessels " &
                "Where  CFPROID = '" & CFPROID & "' " & _
                "And VesselID ='" & VesselID & "' "

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)


                tmpstr(0) = drow("VesselID")
                tmpstr(1) = drow("Vessel")
                tmpstr(2) = drow("VoyageNo")
                tmpstr(3) = Format(drow("ETA"), "dd MMM yyyy")
                tmpstr(4) = Format(drow("BerthingDate"), "dd MMM yyyy")
                tmpstr(5) = Format(drow("ExitDate"), "dd MMM yyyy")


            Else
                tmpstr(0) = ""
                tmpstr(1) = ""
                tmpstr(2) = ""
                tmpstr(3) = "1 Jan 1800"
                tmpstr(4) = "1 Jan 1800"
                tmpstr(5) = "1 Jan 1800"
            End If

            Return tmpstr

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
            Return tmpstr
        End Try
    End Function


    Shared Function GetCFS(CFPROID As String, CFSID As String, ClientID As String, JobType As String) As String()
        Dim sqlstr As String = _
                   "Select CFS, CFSID," &
                   "LocalFreeDays, TransitFreeDays " & _
                   "From CFS " & _
                   "Where CFPROID = '" & CFPROID & "' " & _
                   "And CFSID = '" & CFSID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim tmpstr(4) As String

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            Dim FreeStorageDays As Integer


            Dim nClientFreeStorageDays(1) As Integer

            If Not ClientID = "" Then
                nClientFreeStorageDays = clsStorageDemmurage.GetClientFreeStorageDays(CFPROID, ClientID, CFSID)
            End If

            If InStr(JobType, "trans", CompareMethod.Text) > 0 Then
                If nClientFreeStorageDays(1) <= drow("TransitFreeDays") Then
                    FreeStorageDays = drow("TransitFreeDays")
                Else
                    FreeStorageDays = nClientFreeStorageDays(1)
                End If
            Else
                If nClientFreeStorageDays(0) <= drow("LocalFreeDays") Then
                    FreeStorageDays = drow("LocalFreeDays")
                Else
                    FreeStorageDays = nClientFreeStorageDays(0)
                End If
            End If


            tmpstr(0) = drow("CFSID")
            tmpstr(1) = drow("CFS")
            tmpstr(2) = FreeStorageDays
            tmpstr(3) = drow("TransitFreeDays")
            tmpstr(4) = drow("LocalFreeDays")
        Else

            tmpstr(0) = ""
            tmpstr(1) = ""
            tmpstr(2) = "0"
            tmpstr(3) = "0"
            tmpstr(4) = "0"
        End If

        Return tmpstr

    End Function


    Shared Sub SetDemurrageStorageDays(ByRef tmptable1 As DataTable, JobID As String, CFPROID As String, Optional ByRef ErrMsg As String = "")
        Try


            Dim sqlstr As String =
                           "Select  JobID,ClientID,JobTypeID," &
                           "SOC,DispatchDate,ShippingLineID," &
                           "VesselID, CFSID,ID " &
                           "From Jobs " &
                           "Where CFPROID ='" & CFPROID & "' " &
                           "And JobID ='" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow, drow1 As DataRow
            If tmptable.Rows.Count > 0 Then

                Call clsData.NullChecker(tmptable, 0)

                drow = tmptable.Rows(0)
                Dim JobType As String = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

                Dim tmpstr() As String = GetShippingline(CFPROID, drow("ShippingLineID"), "")
                Dim tmpstr1() As String = GetVessel(CFPROID, drow("VesselID"), "")
                Dim tmpstr2() As String = GetCFS(CFPROID, drow("CFSID"), drow("ClientID"), JobType)



                Dim nDemurrageFreeDays As Integer = DemurrageFreeDays(CFPROID, drow("ClientID"), drow("ShippingLineID"), JobType, tmpstr(2), tmpstr(3))
                Dim nStorageFreeDays As Integer = StorageFreeDays(CFPROID, drow("ClientID"), drow("CFSID"), JobType, tmpstr2(3), tmpstr2(4))

                Dim a As Integer

                For Each drow1 In tmptable1.Rows
                    Call clsData.NullChecker(tmptable1, a)
                    drow1("DemurrageDays") = GetDemurrageDays(tmptable1, drow("JobID"), tmpstr1(4),
                                             drow1("ReturnDate"), nDemurrageFreeDays, drow1("ID"),
                                             drow("SOC"), JobType, drow1("PortExitDate"), drow1("CrossBorderDate"), ErrMsg)
                    If Not drow("CFSID") = "" Then
                        drow1("StorageDays") = GetStorageDays(tmpstr1(5), nStorageFreeDays, drow1("PortExitDate"), ErrMsg)
                    End If


                    a = a + 1
                Next
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Function GetDemurrageDays(tmptable1 As DataTable, ByVal JobID As String, ByVal BerthDate As Date, ByVal ReturnDate As Date,
                      ByVal DemurrageFreeDays As Double, ByVal CargoID As Integer, ByVal SOC As Boolean, ByVal JobType As String,
                      ByVal PortExitDate As Date, ByVal CrossboderDate As Date, ByRef ErrMsg As String) As Integer

        Try

            If Not IsDate(BerthDate) Then
                Return 0
            End If

            If tmptable1.Rows.Count = 0 Then
                Return 0
            End If


            Dim dv As New DataView(tmptable1)

            dv.RowFilter = "JobID = '" & JobID & "'"
            If dv.Count = 0 Then
                Return 0
            End If


            If CDate(BerthDate) = CDate("1/Jan/1800") Then
                Return 0
            Else
                Dim tmpdate As Date = Now
                Dim ts As TimeSpan

                If CargoID > 0 Then

                    dv.RowFilter = "ContainerStatus = '" & "Damaged" & "' " &
                       "And ID = " & CargoID & " "

                    If dv.Count > 0 Then
                        Return "0"
                    End If

                    dv.RowFilter = "ContainerStatus = '" & "Returned" & "' " &
                                               "And ID = " & CargoID & " "

                    If dv.Count > 0 Then
                        tmpdate = ReturnDate

                        ts = tmpdate.Subtract(BerthDate)
                        Return DemurrageFreeDays - (ts.Days)

                    Else
                        If SOC Then
                            If InStr(JobType, "Transit", CompareMethod.Text) > 0 Then
                                tmpdate = CrossboderDate
                            Else
                                tmpdate = PortExitDate
                            End If
                        End If

                        ts = tmpdate.Subtract(BerthDate)
                        Return DemurrageFreeDays - (ts.Days)
                    End If
                Else
                    dv.RowFilter = "ContainerStatus <> '" & "Returned" & "' " &
                                                "And ContainerStatus <> '" & "Damaged" & "' " &
                                                "And JobID = '" & JobID & "'"

                    If dv.Count > 0 Then

                        If SOC Then
                            If InStr(JobType, "Transit", CompareMethod.Text) > 0 Then
                                tmpdate = CrossboderDate
                            Else
                                tmpdate = PortExitDate
                            End If
                        End If

                        ts = tmpdate.Subtract(BerthDate)

                        Return DemurrageFreeDays - (ts.Days)
                    Else
                        dv.RowFilter = "ContainerStatus = '" & "Damaged" & "' " &
                                                                    "And JobID = '" & JobID & "'"
                        If dv.Count = 1 Then
                            Return "0"
                        End If

                        ts = tmpdate.Subtract(ReturnDate)
                        Return DemurrageFreeDays - (ts.Days)
                    End If

                End If
            End If
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function GetStorageDays(ByVal LastslingDate As Date, ByVal StorageFreeDays As Double, ByVal PortExitDate As Date, ByRef ErrMsg As String) As String

        Try

            If Not IsDate(LastslingDate) Then
                Return 0
            End If

            If CDate(LastslingDate) = CDate("1-Jan-1800") Then
                Return 0
            Else
                Dim tmpdate As Date = Now
                Dim ts As TimeSpan

                If Not CDate(PortExitDate) = CDate("1-Jan-1800") Then
                    tmpdate = PortExitDate
                End If

                ts = tmpdate.Subtract(LastslingDate)
                Return StorageFreeDays - (ts.Days)
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function
    Shared Function DaysTaken(ByVal LastSlingDate As String, ByVal DispatchDate As String) As Integer


        If IsDate(LastSlingDate) Then
            If CDate(LastSlingDate) = CDate("1-Jan-1800") Then
                Return 0
            Else
                Dim tmpdate As Date

                If IsDate(DispatchDate) Then
                    tmpdate = DispatchDate
                Else
                    tmpdate = "1-Jan-1800"
                End If

                If CDate(tmpdate) = CDate("1-Jan-1800") Then
                    If CDate(Now) >= CDate(LastSlingDate) Then
                        tmpdate = CDate(Now)
                    Else
                        Return 0
                    End If
                End If

                Dim ts As TimeSpan
                ts = tmpdate.Subtract(LastSlingDate)
                Return ts.Days

            End If
        End If


        Return 0



    End Function


    Shared Function ContainerReturnDueDate(ByVal BerthingDate As String, ByVal ReturnDays As Integer) As String

        If IsDate(BerthingDate) Then
            If Not CDate(BerthingDate) = CDate("1-Jan-1800") Then
                Dim tmpdate As Date = CDate(BerthingDate).AddDays(ReturnDays)
                Return Format(tmpdate, "dd MMM yyyy")
            End If
        Else
            Return "1 Jan 1800"
        End If


    End Function

    Shared Function DemurrageFreeDays(CFPROID As String, nClientID As String, ShippingLineID As String, JobType As String, TransitReturnDays As Integer, LocalReturnDays As Integer) As Integer

        Dim nClientFreeDemurrageDays() As Integer =
        clsStorageDemmurage.GetClientFreeDemurrageDays(CFPROID, nClientID, ShippingLineID)

        If InStr(JobType, "trans", CompareMethod.Text) > 0 Then

            If nClientFreeDemurrageDays(1) <= TransitReturnDays Then
                Return TransitReturnDays
            Else
                Return nClientFreeDemurrageDays(1)
            End If

        Else
            If nClientFreeDemurrageDays(0) <= LocalReturnDays Then
                Return LocalReturnDays
            Else
                Return nClientFreeDemurrageDays(0)
            End If
        End If


    End Function

    Shared Function StorageFreeDays(CFPROID As String, nClientID As String, CFSID As String, JobType As String, TransitFreeDays As Integer, LocalFreeDays As Integer) As Integer

        Dim nClientFreeStorageDays() As Integer =
        clsStorageDemmurage.GetClientFreeStorageDays(CFPROID, nClientID, CFSID)

        If InStr(JobType, "trans", CompareMethod.Text) > 0 Then

            If nClientFreeStorageDays(1) <= TransitFreeDays Then
                Return TransitFreeDays
            Else
                Return nClientFreeStorageDays(1)
            End If

        Else
            If nClientFreeStorageDays(0) <= LocalFreeDays Then
                Return LocalFreeDays
            Else
                Return nClientFreeStorageDays(0)
            End If
        End If


    End Function

    Shared Function JobPortExitDate(CFPROID As String, JobID As String) As Date

        Dim sqlstr As String =
            "Select PortExitDate " &
            "From JobCargo " &
               "Where CFPROID = '" & CFPROID & "' " &
               "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim dv As New DataView(tmptable)

        dv.Sort = "PortExitDate DESC"

        If dv.Count > 0 Then
            Call clsData.NullChecker1(dv, 0)
            Return dv(0)("PortExitDate")
        End If

        Return "1-Jan-1800"

    End Function


    Shared Function JobContainerReturnDate(CFPROID As String, JobID As String) As Date
        Dim sqlstr As String =
         "Select ReturnDate From JobCargo " &
         "Where CFPROID = '" & CFPROID & "' " &
         "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim dv As New DataView(tmptable)

        dv.Sort = "ReturnDate DESC"

        If dv.Count > 0 Then
            Call clsData.NullChecker1(dv, 0)
            Return dv(0)("ReturnDate")
        End If

        Return "1-Jan-1800"

    End Function


    Shared Sub SaveVessel(CFPROID As String, tmpstr() As String,
                           ByRef VesselID As String, Optional ID As Integer = -1, Optional ByRef ErrMsg As String = "")

        Try

            Dim tmpstr1 As String

            If ID >= 0 Then
                tmpstr1 = "And ID = " & ID & " "
            Else
                tmpstr1 = "And VesselID = '" & VesselID & "' "
            End If

            Dim sqlstr As String = "SELECT VesselID,Vessel,VoyageNo," &
                                    "ShippingLine,ETA," &
                                    "BerthingDate,ExitDate," &
                                    "Active,CFPROID, ID " &
                                    "From  ShippingVessels " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    tmpstr1

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                VesselID = GetVesselID(ErrMsg)
                drow("VesselID") = VesselID
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Vessel") = tmpstr(0)
            drow("VoyageNo") = tmpstr(1)

            If IsDate(tmpstr(2)) Then
                drow("ETA") = tmpstr(2)
            End If


            If IsDate(tmpstr(3)) Then
                drow("BerthingDate") = tmpstr(3)
            End If

            If IsDate(tmpstr(4)) Then
                drow("ExitDate") = tmpstr(4)
            End If


            drow("Active") = CBool(tmpstr(5))

            Call clsData.SaveData("ShippingVessels", tmptable, sqlstr, False, clsData.constr)


        Catch ex As Exception
            ErrMsg = ex.Message + ex.StackTrace
        End Try
    End Sub


    Shared Function GetVesselID(ErrMsg As String) As String
        Try

            Dim tmpVesselID As Integer

            Dim sqlstr As String = _
             "Select top 1 ID " & _
             "From ShippingVessels " & _
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpVesselID = drow("ID")
                tmpVesselID = tmpVesselID + 1
                tmpstr = Format(tmpVesselID, "000000000#")
            Else
                tmpstr = Format(tmpVesselID, "000000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function

    
End Class
