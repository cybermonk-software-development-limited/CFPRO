﻿Imports System.Drawing
Imports System.Configuration
Public Class cfagentdashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Dim CFAgentName As String = ""
            Dim CFAgentAddress As String = ""

            Call clsAuth.UserLoggedIn(LabelUserCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, "", LinkSignIn.Text, Image2.ImageUrl, "", False, "cfagent", True)


            Call SetCurrentAgent("")

            Call LoadAccounts(LabelUserCSDID.Text)

        End If
    End Sub

    Private Sub LoadAccounts(UserCSDID As String)
        Try

            Dim UserType As String = Session("UserType")

            Dim sqlstr As String = _
                "Select CFPROAccountConnect.CFAgentCFPROID, CFAgentName," & _
                "CFAgentAddress,CFPROUserID,UserCSDID, " & _
                "UserType, DateAdded " & _
                "FROM CFPROAccountConnect, CFPROAccounts  " & _
                "Where  CFPROAccountConnect.CFAgentCFPROID = CFPROAccounts.CFAgentCFPROID " & _
                "And  CFPROAccountConnect.UserCSDID = '" & UserCSDID & "' " & _
                "And CFPROAccountConnect.Usertype = '" & UserType & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("Destination", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ImageURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Added", Type.GetType("System.String"))
            Dim col3 As New DataColumn("AuthDet", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)

            Dim a As Integer


            Dim drow As DataRow
            Dim imageurl As String = ""
            For Each drow In tmptable.Rows
                clsSubs.NullChecker(tmptable, a)

                If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentCFPROID") & ".jpg") Then
                    imageurl = "~/cfagentimages/" & drow("CFAgentCFPROID") & ".jpg"
                ElseIf IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentCFPROID") & ".png") Then
                    imageurl = "~/cfagentimages/" & drow("CFAgentCFPROID") & ".png"
                Else
                    imageurl = "~/cfagentimages/000000000.png"
                End If

                drow("ImageURL") = imageurl


                drow("AuthDet") = drow("CFAgentCFPROID") & "|" & drow("CFAgentName") & "|" & drow("CFPROUserID") & "|" & UserType & "|" & drow("CFAgentAddress")
                drow("Added") = "Added -" & Format(drow("DateAdded"), "dd MMM yyyy")

                a = a + 1
            Next

            LabelAddCFAgent.Text = "Request your '" & clsSubs.Capitalise(UserType) & " Access Code' from your C&F Agent."

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            If tmptable.Rows.Count = 1 Then
                drow = tmptable.Rows(0)
                Call SetCurrentAgent(drow("AuthDet"))
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call ConnectAccount(Trim(TextConnectString.Text), LabelUserCSDID.Text, LabelUserType.Text)
    End Sub
    Private Sub ConnectAccount(ConnectStr As String, UserCSDID As String, UserType As String)

        If InStr(UserType, "cfagent", CompareMethod.Text) > 0 Then
            UserType = "cfagent"
        End If

        Dim sqlstr As String = _
         "UserCSDID,CFAgentCFPROID, " & _
         "UserID,UserType,DateAdded,ID " & _
         "FROM CFPROAccountConnect " & _
         "Where  UserCSDID = '" & UserCSDID & "' " & _
         "And Usertype = '" & UserType & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr() As String = clsEncr.DecryptString(ConnectStr).Split("|")
        ReDim Preserve tmpstr(2)

        If tmpstr(2) = UserType Then
            If tmptable.Rows.Count = 0 Then
                Dim drow As DataRow = tmptable.NewRow
                drow("CFAgentCFPROID") = tmpstr(0)
                drow("UserID") = tmpstr(1)
                drow("UserCSDID") = UserCSDID
                drow("Usertype") = UserType
                drow("DateAdded") = Format(Now, "dd MMM yyyy")
            End If

            Call clsData.SaveData("CFPROAccountConnect", tmptable, sqlstr, False, clsData.constr)

            Call LoadAccounts(LabelUserCSDID.Text)
        End If


    End Sub


    Private Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "selected" Then
            Call SetCurrentAgent(e.CommandArgument)
        End If
    End Sub

    Private Sub SetCurrentAgent(AuthDet As String)

        If Not AuthDet = "" Then
            Response.Cookies("CFAgent").Value = AuthDet
            Response.Cookies("CFAgent").Expires = Now.AddHours(94)

        End If

        Dim CFAgentName As String = ""
        Dim CFAgentAddress As String = ""

        Call clsAuth.AuthCFAgent(LabelCFAgentCFPROID.Text, CFAgentName, CFAgentAddress, LabelCFPROUserID.Text, Image3.ImageUrl)

        If CFAgentName = "" Then
            LinkCFAgentName.Text = "No C&F Agent Selected"
            LabelCFAgentAddress.Text = " "
        Else
            LinkCFAgentName.Text = CFAgentName
            LabelCFAgentAddress.Text = CFAgentAddress
        End If


    End Sub



    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub LinkReasonsWhyCFPRO_Click(sender As Object, e As EventArgs) Handles LinkReasonsWhyCFPRO.Click
        PanelReason.Visible = True
        PanelReasonLess.Visible = False
    End Sub

    Protected Sub LinkReasonsWhyCFPROLess_Click(sender As Object, e As EventArgs) Handles LinkReasonsWhyCFPROLess.Click
        PanelReason.Visible = False
        PanelReasonLess.Visible = True
    End Sub
End Class