﻿Imports Microsoft.Owin
Imports Owin
Imports Hangfire
Imports Hangfire.Dashboard

<Assembly: OwinStartup(GetType(CFPRO3.clsUpdatesStartup))> 

Namespace CFPRO3


    Public Class clsUpdatesStartup
        Private Const updateprocess As String = "/updateprocess"

        Public Sub Configuration(app As IAppBuilder)
            GlobalConfiguration.Configuration.UseSqlServerStorage(clsData.constr)

            app.UseHangfireDashboard(updateprocess, New DashboardOptions With {.Authorization = Enumerable.Empty(Of IDashboardAuthorizationFilter)()})
            app.UseHangfireServer()

            'Process Agent Alert Summary Emails
            RecurringJob.AddOrUpdate("Progress Updates", Function() clsActionCenter.ProcessProgressUpdateStatus(), Cron.HourInterval(2))

            RecurringJob.AddOrUpdate("Recieved Documents", Function() clsActionCenter.ProcessReceivedJobDocuments(), Cron.HourInterval(3))

            RecurringJob.AddOrUpdate("Missing Shipping Information", Function() clsActionCenter.ProcessMissingShippingInformation(), Cron.HourInterval(3))

            RecurringJob.AddOrUpdate("CF Agent Alert Summary Emails", Function() clsActionCenter.ProcessCFAgentAlertSummaryEmails(), Cron.HourInterval(24))


            'Invoice Alerts"
            RecurringJob.AddOrUpdate("Invoice Alerts", Function() clsActionCenter.ProcessCFAgentInvoices(), Cron.HourInterval(2))

            RecurringJob.AddOrUpdate("Invoice Alerts Emails", Function() clsActionCenter.ProcessCFAgentInvoiceAlertEmails(), Cron.HourInterval(72))

            'Detailed Visibility Reports
            RecurringJob.AddOrUpdate("Detailed Visibility Reports", Function() clsActionCenter.ProcessDetailedVisibilityReports(), Cron.HourInterval(2))

            RecurringJob.AddOrUpdate("Detailed Visibility Reports Emails", Function() clsActionCenter.ProcessDetailedVisibilityEmails(), Cron.HourInterval(24))

            'Storage and Demurrage Alerts
            RecurringJob.AddOrUpdate("Storage and Demurrage Alerts", Function() clsActionCenter.ProcessStorageandDemurrage(), Cron.HourInterval(2))

            'Client and progress reports
            RecurringJob.AddOrUpdate("Client Progress Summaries", Function() clsActionCenter.ProcessClientProgressReportEmail, Cron.HourInterval(24))

        End Sub


    End Class


End Namespace
