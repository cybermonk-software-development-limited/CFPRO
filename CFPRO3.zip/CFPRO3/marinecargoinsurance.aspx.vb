﻿Public Class marinecargoinsurance
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim AuthAgent As Boolean

            If Not IsNothing(Request.Cookies("UserType")) Then
                If Request.Cookies("UserType").Value = "cfagent" Then
                    AuthAgent = True
                End If
            End If


            Dim CSDID As String = ""

            Call clsAuth.UserLogin(CSDID, LabelCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", AuthAgent, "", False)
            LabelCSDID.Text = CSDID

            If CSDID = "" Then
                HyperLinkHome.Text = "Home"
                HyperLinkHome.NavigateUrl = "~/index.aspx"
            Else
                HyperLinkHome.Text = "Dashboard"
                HyperLinkHome.NavigateUrl = "~/cfprodashboard.aspx"
            End If

            Dim tmpstr(1) As String
            Dim GoBackURL As String = "marinecargoinsurance.aspx"

            If Not IsNothing(Page.Request.UrlReferrer) Then
                tmpstr = Page.Request.UrlReferrer.ToString.Split("?")

                ReDim Preserve tmpstr(1)

                If Not tmpstr(1) = "" Then
                    tmpstr(1) = HttpUtility.UrlEncode(tmpstr(1))
                    tmpstr(1) = Replace(tmpstr(1), "%3d", "=", 1)
                    GoBackURL = tmpstr(0) & "?" & tmpstr(1)
                Else
                    GoBackURL = Page.Request.UrlReferrer.ToString
                End If
            End If

            If InStr(GoBackURL, "cargo", CompareMethod.Text) Then
                GoBackURL = "marinecargoinsurance.aspx"
            End If


            Dim PolicyIDURL As String = ""
            If Not IsNothing(Request.QueryString("policyid")) Then
                PolicyIDURL = "&policyid=" & Request.QueryString("policyid")
            End If


            iframe1.Attributes("src") = "marineinsurancepurchase.aspx?goback=" & HttpUtility.UrlEncode(GoBackURL) & PolicyIDURL
            iframe1.Attributes("style") = "height:" & 840 & "px; width:" & 1026 & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: 80px; background-position-x:300px;"


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If
    End Sub

    Protected Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        If Not LabelUser.Text = "Guest" Then
            Timer1.Enabled = False
        Else

            Dim AuthAgent As Boolean

            If Not IsNothing(Request.Cookies("UserType")) Then
                If Request.Cookies("UserType").Value = "cfagent" Then
                    AuthAgent = True
                End If
            End If
            Call clsAuth.UserLogin(LabelCSDID.Text, LabelCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", AuthAgent, "", False)
        End If

    End Sub

    Private Sub MypoliciesCount(CSDID As String, CFPROID As String)



        If CSDID = "" Then
            HyperLinkHome.Text = "Home"
            HyperLinkHome.NavigateUrl = "~/index.aspx"
        Else
            HyperLinkHome.Text = "Dashboard"
            HyperLinkHome.NavigateUrl = "~/cfprodashboard.aspx"
        End If


        LabelCSDID.Text = CSDID
        LabelCFPROID.Text = CFPROID

        Dim EmailAddress As String = ""

        If Not IsNothing(Request.Cookies("CFPROMCI")) Then
            Dim tmpPolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMCI").Value)

            Dim tmpstr() As String = tmpPolicyID.Split("|")
            ReDim Preserve tmpstr(1)

            EmailAddress = tmpstr(1)

        End If



        Dim tmpstr1 As String = ""

        If Not EmailAddress = "" Then
            If Not CFPROID = "" Then
                tmpstr1 = "Where EmailAddress ='" & EmailAddress & "' " &
                         "Or CFPROID ='" & CFPROID & "' "
            Else
                tmpstr1 = "Where EmailAddress ='" & EmailAddress & "' "
            End If

        ElseIf Not CSDID = "" Then
            If Not CFPROID = "" Then
                tmpstr1 = "Where CSDID ='" & CSDID & "' " &
                         "Or CFPROID ='" & CFPROID & "' "
            Else
                tmpstr1 = "Where CSDID ='" & CSDID & "' "
            End If
            HyperLinkMyPolicies.Text = "My Policies - 0"
        Else
            Exit Sub
        End If

        Dim sqlstr As String =
              "SELECT PolicyID " &
              "FROM MarineInsurancePolicies " &
               tmpstr1



        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        HyperLinkMyPolicies.Text = "My Policies - " & tmptable.Rows.Count


    End Sub

    Protected Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Call MypoliciesCount(LabelCSDID.Text, LabelCFPROID.Text)
    End Sub
End Class


