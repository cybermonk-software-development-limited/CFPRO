﻿Imports System.Drawing

Public Class addeditcargo
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim tmpstr() As String = Request.QueryString("cargoaddeditdetails").Split(",")
            ReDim Preserve tmpstr(5)

            LabelCFPROID.Text = tmpstr(0)
            LabelCargoID.Text = tmpstr(1)
            LabelRowIndex.Text = tmpstr(2)
            LabelJobID.Text = tmpstr(3)
            LabelCargoAddEdit.Text = tmpstr(4)



            Call AddEditCargoItem(tmpstr(0), tmpstr(1), tmpstr(4), tmpstr(5))
        End If

    End Sub


    Private Sub AddEditCargoItem(CFPROID As String, CargoID As String, AddEdit As String, CFPROUserID As String)
        Try

            Dim TransitUpdateUser As Boolean = Not clsAuth.TransitUpdateUser(CFPROID, CFPROUserID)

            TextContainerNo.Enabled = TransitUpdateUser
            TextTEU.Enabled = TransitUpdateUser
            TextCargoWeight.Enabled = TransitUpdateUser
            TextCargoCBM.Enabled = TransitUpdateUser
            TextVehicleNo.Enabled = TransitUpdateUser
            TextTransporter.Enabled = TransitUpdateUser
            TextPortExitDate.Enabled = TransitUpdateUser

            ButtonSearchVehicle.Enabled = TransitUpdateUser
            ButtonSearchTransporter.Enabled = TransitUpdateUser

            TextContainerNo.Text = ""
            TextTEU.Text = ""
            TextCargoWeight.Text = ""
            TextCargoCBM.Text = ""
            TextVehicleNo.Text = ""
            TextTransporter.Text = ""

            ' LabelCargoMessage.ForeColor = Color.Black
            LabelAddEditCargoMessage.Text = ""


            Dim sqlstr1 As String =
                     "SELECT Payload FROM Payloads " &
                     "Where CFPROID = '" & CFPROID & "' "
            ComboPayLoad.Items.Clear()
            ComboPayLoad.Items.Add("")
            clsData.PopCombo(ComboPayLoad, sqlstr1, clsData.constr, 0)

            Dim sqlstr4 As String =
                "Select Status " &
                "From ContainerStatus " &
                "Where CFPROID = '" & CFPROID & "' " &
                "Order By ID Desc; "

            ComboContainerStatus.Items.Clear()
            ComboContainerStatus.Items.Add("")


            Call clsData.PopCombo(ComboContainerStatus, sqlstr4, clsData.constr, 0)

            If CargoID = "" Then
                CargoID = "-1"
            End If

            If AddEdit = "Edit" Then

                Dim sqlstr As String =
                    "Select JobID,ContainerNo,Payload," &
                    "TEU,Weight,CBM," &
                    "VehicleNo,TransporterID," &
                    "PortExitDate,CrossBorderDate," &
                    "ReturnDate,InterchangeNo," &
                    "ContainerStatus,ID " &
                    "From JobCargo " &
                    "Where ID = " & CInt(CargoID) & " "


                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)
                If tmptable.Rows.Count > 0 Then
                    clsData.NullChecker(tmptable, 0)

                    Dim drow As DataRow = tmptable.Rows(0)

                    ComboPayLoad.SelectedValue = drow("Payload")

                    TextContainerNo.Text = drow("ContainerNo")
                    TextTEU.Text = drow("TEU")
                    TextCargoWeight.Text = Format(drow("Weight"), "#,##0.#0")
                    TextCargoCBM.Text = Format(drow("CBM"), "#,##0.#0")

                    TextVehicleNo.Text = drow("VehicleNo")
                    ComboContainerStatus.Text = drow("ContainerStatus")

                    TextPortExitDate.Text = Format(drow("PortExitDate"), "dd MMM yyyy")
                    TextCrossBorderDate.Text = Format(drow("CrossBorderDate"), "dd MMM yyyy")
                    TextReturnDate.Text = Format(drow("ReturnDate"), "dd MMM yyyy")

                    TextInterChangeNo.Text = drow("InterchangeNo")
                    LabelTransporterID.Text = drow("TransporterID")

                    Call clsGetIdentities.SetTransporter(CFPROID, drow("TransporterID"), "", TextTransporter.Text, LabelTransporterID.Text,
                                              Nothing, Nothing, LabelMessage1.Text)


                End If
            End If

            '   LabelCargoCaption.Text = "Container / Cargo & Transport : " & GridJobCargo.Rows.Count & "  Items "

        Catch exp As Exception
            ' LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub Button20_Click(sender As Object, e As EventArgs) Handles ButtonSaveCargo.Click
        Call SaveCargoItem(LabelCFPROID.Text, LabelJobID.Text, LabelRowIndex.Text)
    End Sub

    Private Sub SaveCargoItem(CFPROID As String, JobID As String, RowIndex As Integer)

        Try

            If ComboPayLoad.SelectedIndex < 0 Then
                LabelAddEditCargoMessage.Text = "Payload Not Selected."
                LabelAddEditCargoMessage.ForeColor = Color.Red
                Exit Sub
            End If


            If TextTransporter.Text = "" Then
                LabelTransporterID.Text = ""
            End If

            Dim CargoID As Integer

            If LabelCargoAddEdit.Text = "Add" Then
                CargoID = "-1"
            Else
                CargoID = LabelCargoID.Text
            End If


            Dim sqlstr As String = _
             "Select JobID,ContainerNo,Payload," & _
             "TEU,Weight,CBM," & _
             "VehicleNo,TransporterID," & _
             "PortExitDate,CrossBorderDate," & _
             "ReturnDate,InterchangeNo," & _
             "ContainerStatus,CFPROID,ID " & _
              "From JobCargo " & _
             "Where ID = " & CargoID & " "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow

            If LabelCargoAddEdit.Text = "Add" Then
                drow = tmptable.NewRow
                drow("JobID") = JobID
                tmptable.Rows.Add(drow)
            Else
                drow = tmptable.Rows(0)
            End If


            drow("CFPROID") = CFPROID
            drow("PayLoad") = ComboPayLoad.Text
            drow("TEU") = Trim(TextTEU.Text)
            drow("ContainerNo") = UCase(Trim(TextContainerNo.Text))

            drow("TransporterID") = LabelTransporterID.Text
            drow("VehicleNo") = TextVehicleNo.Text
            drow("ContainerStatus") = ComboContainerStatus.Text
            drow("InterChangeNo") = Trim(TextInterChangeNo.Text)


            If IsNumeric(Trim(TextCargoWeight.Text)) Then
                drow("Weight") = Trim(TextCargoWeight.Text)
            Else
                drow("Weight") = 0
            End If

            If IsNumeric(Trim(TextCargoCBM.Text)) Then
                drow("CBM") = Trim(TextCargoCBM.Text)
            Else
                drow("CBM") = 0
            End If

            If IsDate(Trim(TextPortExitDate.Text)) Then
                drow("PortExitDate") = Trim(TextPortExitDate.Text)
            End If

            If IsDate(Trim(TextCrossBorderDate.Text)) Then
                drow("CrossBorderDate") = Trim(TextCrossBorderDate.Text)
            End If

            If IsDate(Trim(TextReturnDate.Text)) Then
                drow("ReturnDate") = Trim(TextReturnDate.Text)
            End If

            Call clsData.SaveData("JobCargo", tmptable, sqlstr, False, clsData.constr)

            If LabelCargoAddEdit.Text = "Add" Then
                LabelCargoAddEdit.Text = "Edit"
                LabelCargoID.Text = GetCargoID(CFPROID)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Function GetCargoID(CFPROID As String) As Integer
        Dim sqlstr As String = _
           "Select Top 1 ID " & _
           "From JobCargo " & _
           "Where CFPROID = '" & CFPROID & "' " &
           "Order By ID Desc "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Return drow("ID")
        Else
            Return "-1"
        End If


    End Function

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetSelectedItem(sender)
    End Sub
    Private Sub SetSelectedItem(sender As Object)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

       If LabelItemType.Text = "Search / Select Vehicle" Then
            Call clsGetIdentities.SetVehicleNo(LabelCFPROID.Text, ItemID, TextVehicleNo.Text, TextTransporter.Text, LabelTransporterID.Text,
                                           ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Transporter" Then
            Call clsGetIdentities.SetTransporter(LabelCFPROID.Text, ItemID, "", TextTransporter.Text, LabelTransporterID.Text,
                                           ModalPopupExtender2, , LabelMessage1.Text)

        End If
    End Sub


    Protected Sub ButtonSearchTransporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchTransporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "transporter", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub


    Protected Sub ButtonSearchVehicle_Click(sender As Object, e As EventArgs) Handles ButtonSearchVehicle.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "vehicleno", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ComboPayLoad_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPayLoad.SelectedIndexChanged


        If InStr(sender.text, "20", CompareMethod.Text) Then
            TextTEU.Text = 1
        ElseIf InStr(sender.text, "40", CompareMethod.Text) Then
            TextTEU.Text = 2
        Else
            TextTEU.Text = ""
        End If

    End Sub


    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text.Contains("Vehicle") Then
            clsGetIdentities.SearchVehicle(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf LabelItemType.Text.Contains("Transporter") Then
            clsGetIdentities.SearchTransporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)
        End If
    End Sub
End Class