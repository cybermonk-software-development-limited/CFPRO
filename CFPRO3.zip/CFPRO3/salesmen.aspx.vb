﻿Imports System.Drawing

Public Class salesmen
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadSalesmen(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadSalesmen(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Salesman  Like '%" & Trim(TextSearch.Text) & "'% "
        End If

        Dim sqlstr As String =
              "Select SalesmanID, Salesman," &
              "Telephone,Email," &
              "Town,Country,ID " &
              "From  Salesmen " &
              "Where CFPROID ='" & CFPROID & "' " &
               tmpstr &
              "Order By SalesmanID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        Dim drow As DataRow

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Salesman") = "No Salesmen"
            tmptable.Rows.Add(drow)
        End If

        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next



        Session("SalesmenTable") = tmptable
        GridSalesmen.DataSource = tmptable
        GridSalesmen.DataBind()

        If GridSalesmen.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridSalesmen.Rows.Count - 1 Then
                Rowindex = GridSalesmen.Rows.Count - 1
            End If

            GridSalesmen.SelectedIndex = Rowindex
            Call ShowSalesman(CFPROID, GridSalesmen.SelectedValue.ToString)
            Dim row As GridViewRow = GridSalesmen.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Salesmen found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Salesmen"
        End If


    End Sub



    Private Sub ShowSalesman(CFPROID As String, SalesmanID As String)

        Dim sqlstr As String =
             "Select SalesmanID, Salesman," &
             "Telephone,Email," &
             "Town,Country " &
             "From  Salesmen " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And SalesmanID = '" & SalesmanID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextSalesman.Text = drow("Salesman")
            TextTelephone.Text = drow("Telephone")
            TextEmail.Text = drow("Email")
            TextTown.Text = drow("Town")
            TextCountry.Text = drow("Country")
        End If


    End Sub



    Private Sub NewSalesman(CFPROID As String)
        Try

            Dim sqlstr As String =
                  "Select SalesmanID, Salesman," &
                   "CFPROID, ID " &
                   "From  Salesmen " &
                   "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("SalesmanID") = GetSalesmanID()
            Drow("CFPROID") = CFPROID
            Drow("Salesman") = "NEW SALES PERSON " & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Salesmen", tmptable, sqlstr, False, clsData.constr)
            Call LoadSalesmen(CFPROID, 0, "")


            TextSalesman.Focus()

        Catch exp As Exception
            MsgBox(exp.Message, , "NewSalesman")
        End Try
    End Sub


    Private Function GetSalesmanID() As String
        Try

            Dim tmpSalesmanID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From Salesmen " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpSalesmanID = drow("ID")
                tmpSalesmanID = tmpSalesmanID + 1
                tmpstr = Format(tmpSalesmanID, "000000#")
            Else
                tmpstr = Format(tmpSalesmanID, "000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetSalesmanID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridSalesmen, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridSalesmen.SelectedIndexChanged
        Dim row As GridViewRow = GridSalesmen.Rows(GridSalesmen.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowSalesman(LabelCFPROID.Text, GridSalesmen.SelectedValue.ToString)

        For a As Integer = 0 To GridSalesmen.Rows.Count - 1
            row = GridSalesmen.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridSalesmen.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub



    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewSalesman(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveSalesman(LabelCFPROID.Text, GridSalesmen.SelectedValue.ToString)
    End Sub

    Private Sub SaveSalesman(CFPROID As String, SalesmanID As String)
        Try


            Dim sqlstr As String =
            "Select SalesmanID, Salesman," &
            "Telephone,Email," &
            "Town,Country,ID " &
            "From  Salesmen " &
            "Where CFPROID ='" & CFPROID & "' " &
            "And SalesmanID = '" & SalesmanID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Salesman") = UCase(Trim(TextSalesman.Text))
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmail.Text)
                drow("Town") = Trim(TextTown.Text)
                drow("Country") = Trim(TextCountry.Text)

                Call clsData.SaveData("Salesmen", tmptable, sqlstr, False, clsData.constr)


                Call clsMSDynamicsNAVint.UpdateNAVSalesman(CFPROID, drow("SalesmanID"), drow("Salesman"), drow("Telephone"), drow("Email"), LabelMessage1.Text)

                Call LoadSalesmen(CFPROID, GridSalesmen.SelectedIndex, TextSearch.Text)

            End If





        Catch exp As Exception
            MsgBox(exp.Message, , "AddSalesman")
        End Try
    End Sub



    Private Sub DeleteSalesman(CFPROID As String, SalesmanID As String)


        Dim sqlstr As String =
        "Select ID " &
        "From  Salesmen " &
        "Where CFPROID ='" & CFPROID & "' " &
        "And SalesmanID = '" & SalesmanID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Salesmen", tmptable, sqlstr, True, clsData.constr)

        Call clsMSDynamicsNAVint.DeleteNAVSalesman(CFPROID, SalesmanID, LabelMessage1.Text)


        Call LoadSalesmen(CFPROID, GridSalesmen.SelectedIndex - 1, TextSearch.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteSalesman(LabelCFPROID.Text, GridSalesmen.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadSalesmen(LabelCFPROID.Text, -1, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadSalesmen(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click

        Dim Fields(5) As String
        Fields(0) = "SalesmanID"
        Fields(1) = "Salesman"
        Fields(2) = "Email"
        Fields(3) = "Telephone"
        Fields(4) = "Town"
        Fields(5) = "Country"


        Dim tmptable As DataTable = Session("SalesmenTable")
        Call clsExportToExcel.ExportToExcel("", "", "", "Salesman", "Salesman",
                                            LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)

    End Sub



End Class