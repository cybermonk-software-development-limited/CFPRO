﻿Imports System.Drawing
Public Class marinecargoinsuranceclaim
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            Dim CFPROID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", False, "", False)
            LabelCFPROID.Text = CFPROID

            Call LoadInsurer()
            Call clsDocuments.LoadDocumentTypes(ComboDocumentType, 1, "Claim", LabelMessage1.Text)
            Call clsDocuments.LoadDocuments(CFPROID, "", "", TextEmailAddress.Text, DataList1, "", LabelDocumentsCaption.Text, "policy", "insurance", LabelMessage1.Text)

            LabelFromPageURL.Text = Page.Request.UrlReferrer.ToString
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub



    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, " & _
            "Insurer,ProductName," & _
            "Description, URL," & _
            "EmailAddress,Telephone, SystemFees " & _
            "FROM MarineCargoInsurer "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)


        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)
            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")

            HyperLinkCompany.Text = drow("Insurer")
            HyperLinkCompany.NavigateUrl = drow("URL")


            LabelContacts.Text = drow("Contacts")
            LabelAboutPolicyURL.Text = "marineproductdesc.aspx?insurerid=" & drow("InsurerID")

        End If

    End Sub

    Private Sub LoadSendMessage(page As String, title As String)
        LableTitle.Text = title
        iframe1.Attributes("src") = page
        ModalPopupExtender3.Show()
    End Sub


    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        LoadSendMessage("sendmessage.aspx?jobid=0&sendercsdid=" & LabelCSDID.Text & "&receivercsdid=" & LabelCFPROID.Text & "&CFPROID=" & LabelCFPROID.Text, "Send Message")
    End Sub

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Call ShowItem(sender)
    End Sub

    Private Sub ShowItem(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim tmpstr As String = link.CommandArgument

            iframe1.Attributes("src") = tmpstr
            ModalPopupExtender2.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Call clsDocuments.FileUpload(LabelCFPROID.Text, "", "", Trim(TextEmailAddress.Text), FileUpload1, TodaysDate.Value, ModalPopupExtender1,
                                 ComboDocumentType, LabelAttachmentMessage, LabelDocumentsCaption.Text,
                                    DataList1, LabelCSDID.Text, LabelCFPROUserID.Text, "claim", "insurance", LabelMessage1.Text)
    End Sub

    Protected Sub Button13_Click(sender As Object, e As EventArgs)
        Dim Button As Button = CType(sender, Button)
        Dim tmpstr As String = Button.CommandArgument
        Call clsDocuments.DeleteDocuments(LabelCFPROID.Text, tmpstr, LabelMessage1.Text)
        Call clsDocuments.LoadDocuments(LabelCFPROID.Text, "", "", TextEmailAddress.Text, DataList1, "", LabelDocumentsCaption.Text, "claim", "insurance", LabelMessage1.Text)
    End Sub

    Protected Sub ButtonAttachDocuments_Click(sender As Object, e As EventArgs) Handles ButtonAttachDocuments.Click
        Call AttachDocuments(TextEmailAddress.Text)
    End Sub

    Private Sub AttachDocuments(EmailAddress As String)
        Try
            LabelAttachMessage.Text = "Click Attach Documents to Add Required Claim Documents"
            LabelAttachMessage.ForeColor = Color.Black

            If Trim(EmailAddress) = "" Then
                LabelAttachMessage.ForeColor = Color.Red
                LabelAttachMessage.Text = "Email Address is required before you can attach policy documents. See 'Claimant Email Address'."
                Exit Sub
            End If


            If InStr(Trim(EmailAddress), "@", CompareMethod.Text) = 0 Then
                LabelAttachMessage.ForeColor = Color.Red
                LabelAttachMessage.Text = "Email address missing - @"
                Exit Sub
            End If



            ModalPopupExtender1.Show()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Protected Sub ComboDocumentType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDocumentType.SelectedIndexChanged
        If ComboDocumentType.SelectedIndex > 0 Then
            LabelAttachmentMessage.Text = "Browse to File & Click 'Upload' (3MB max .pdf .xls/xlsx .doc/docx .jpg & .png format only)"
            LabelAttachmentMessage.ForeColor = Drawing.Color.Black
            ModalPopupExtender1.Show()
        End If
    End Sub
End Class


