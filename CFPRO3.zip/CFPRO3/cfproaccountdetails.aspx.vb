﻿Public Class cfproaccountdetails
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim CFPROID As String = Request.QueryString("CFPROID")
            Dim UserCSDID As String = Request.QueryString("usercsdid")
            Dim AllowRating As Integer = Request.QueryString("allowrating")


            LabelUserCSDID.Text = CFPROID
            LabelCFPROID.Text = UserCSDID
            LabelAllowRating.Text = AllowRating

            ButtonRateCFAgent.Visible = CBool(AllowRating)

            Call LoadCFPROAccount(CFPROID)

        End If

        LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

    End Sub


    Private Sub LoadCFPROAccount(CFPROID As String)

        Try

            Dim sqlstr As String = _
              "SELECT   CFPROID, CFAgentName," &
              "CFAgentAddress, NextPaymentDate," &
              "Telephone, EmailAddress,ProductStatus," &
              "AboutAccount,AccountURL," &
              "AccountStatus,LogoURL," &
              "CreatedOn,OptionID, ID " &
              "FROM  CFPROAccounts " &
              "Where  CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable("CFPROAccounts")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Call BlanksDash(tmptable)
                drow = tmptable.Rows(0)


                LabelAccountName.Text = drow("CFAgentName")
                LabelAccountStatus.Text = drow("AccountStatus")

                LabelEmailAddress.Text = drow("EmailAddress")
                LabelTelephone.Text = drow("Telephone")



                LiteralAddress.Text = clsTextToHtml.ToHtml(drow("CFAgentAddress"))

                LiteralAbout.Text = clsTextToHtml.ToHtml(drow("AboutAccount"))

                drow("AccountURL") = drow("AccountURL").ToString.Replace("http://", "")


                HyperLinkURL.Text = drow("AccountURL")
                HyperLinkURL.NavigateUrl = "http://" & drow("AccountURL")





                Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                Dim b As Integer = tmpstr.GetUpperBound(0)

                If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFPROID") & "." & tmpstr(b)) Then
                    Image5.ImageUrl = "~/cfagentimages/" & drow("CFPROID") & "." & tmpstr(b)
                Else
                    Image5.ImageUrl = "~/cfagentimages/000000000.png"
                End If


            End If


            Dim RatingAvarage As Double = 0
            Dim RatingUsers As Double = 0


            Dim sqlstr1 As String =
              "SELECT CFPROID," &
               "RatingAvarage,ID " &
               "FROM  CFAgentRating " &
               "Where  CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            If tmptable1.Rows.Count > 0 Then
                Dim b As Integer

                For Each drow1 In tmptable1.Rows
                    clsData.NullChecker(tmptable1, b)
                    RatingAvarage = RatingAvarage + drow1("RatingAvarage")
                    b = b + 1
                Next

                RatingAvarage = RatingAvarage / tmptable1.Rows.Count

                If RatingAvarage < 1 Then
                    RatingAvarage = 1.5
                End If

                RatingUsers = tmptable1.Rows.Count
            Else
                RatingAvarage = 1.5

                RatingUsers = 1

            End If

            Dim RatingImageURL() As String = clsCFPROAccount.SetAvarageRating(RatingAvarage)

            Image0.ImageUrl = RatingImageURL(0)
            Image1.ImageUrl = RatingImageURL(1)
            Image2.ImageUrl = RatingImageURL(2)
            Image3.ImageUrl = RatingImageURL(3)
            Image4.ImageUrl = RatingImageURL(4)

            LinkRating.Text = "Rated: " & Format(RatingAvarage, "0.0") & " - " & Format(RatingUsers, "#,#") & " Votes"



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub



    Private Sub BlanksDash(tmptable As DataTable)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            For a = 0 To tmptable.Columns.Count - 1
                If Not IsDate(drow(a)) Then
                    If Not IsNumeric(drow(a)) Then
                        If drow(a) = "" Then
                            drow(a) = "--"

                        End If
                    End If
                End If
            Next
        End If
    End Sub


    Protected Sub ButtonRateCFAgent_Click(sender As Object, e As EventArgs) Handles ButtonRateCFAgent.Click
        call ShowRating
    End Sub


    Protected Sub LinkRating_Click(sender As Object, e As EventArgs) Handles LinkRating.Click
        Call ShowRating()
    End Sub

    Private Sub ShowRating()
        iframe1.Attributes("src") = "cfagentrating.aspx?CFPROID=" & LabelCFPROID.Text &
                                "&usercsdid=" & LabelUserCSDID.Text & "&allowrating=" & LabelAllowRating.Text
        ModalPopupExtender1.Show()
    End Sub
End Class