﻿Public Class clsContainerControlReport

    Shared Sub CreateContainerControlColumns(CFPROID As String, ByRef tmptable1 As DataTable)
        Dim sqlstr As String =
               "SELECT ColumnName, ColumnText," &
               "Show, CFPROID, SortOrder, ID " &
               "FROM  ContainerControlReportColumns " &
               "Where CFPROID ='sys' " &
               "Order By SortOrder Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next

                drow1("CFPROID") = CFPROID
                tmptable1.Rows.Add(drow1)

            Next
        End If

        Call clsData.SaveData("ContainerControlReportColumns", tmptable1, sqlstr, False, clsData.constr)

    End Sub

    Shared Sub ContainerControlReportColumns(CFPROID As String, ByRef columnnames() As String, ByRef columntext() As String)

        Dim sqlstr As String =
               "SELECT ColumnName, ColumnText, Show,ID " &
               "FROM  ContainerControlReportColumns " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And Show = 1 " &
               "Order By Sortorder Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count = 0 Then
            Call clsContainerControlReport.CreateContainerControlColumns(CFPROID, tmptable)
        End If

        Dim a As Integer
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ReDim Preserve columnnames(a), columntext(a)
                columnnames(a) = drow("ColumnName")
                columntext(a) = drow("ColumnText")
                a = a + 1
            Next
        End If



    End Sub

End Class
