﻿Imports System.Drawing


Public Class detailedvisibilityexp
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If Not IsNothing(Request.Cookies("DetVisExp")) Then
                If Request.Cookies("DetVisExp").Value = 0 Then
                    Response.Redirect("detailedvisibility.aspx")
                Else
                    RadioButtonList2.SelectedIndex = 1
                End If
            End If


            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If

            Call LoadShippers(CFPROID)
            Call LoadCFAgentUsers(CFPROID)
            Call LoadVesselStatus(CFPROID)
            Call LoadJobStatus(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadCFS(CFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadJobs(CFPROID As String, CFPROUserID As String)

        Dim dv As DataView

        If CFPROID = "CFPR000000272-80" Then

            dv = clsAGLDetailedVisibilityReport.LoadJobs(CFPROID, ComboPredefine.Text, CheckDispatchDate.Checked,
                                                 TextFromDate.Text, TextToDate.Text, ComboLoadedJobs.Text, ComboMaxRecords.Text, ComboSortOrder.Text,
                                                 RadioButtonList1.SelectedIndex, CheckStorageStartDate.Checked, CFPROUserID, LabelMessage1.Text)

        Else
            dv = clsDetailedVisibilityReport.LoadJobs(CFPROID, ComboPredefine.Text, CheckDispatchDate.Checked,
                                                 TextFromDate.Text, TextToDate.Text, ComboLoadedJobs.Text, ComboMaxRecords.Text, ComboSortOrder.Text,
                                                 RadioButtonList1.SelectedIndex, CheckStorageStartDate.Checked, CFPROUserID, LabelMessage1.Text)

        End If


        LabelSortStr.Text = dv.Sort



        LabelMessage1.Text = ""



        If dv.Count >= 200 Then
            PanelJobs.Height = 1000
        Else
            PanelJobs.Height = Nothing
        End If

        PanelJobs.Width = 1670
        GridJobs.Width = 1650
        GridJobs.DataSource = dv
        GridJobs.DataBind()

        Call Calctotal(dv, "")
    End Sub
    Private Sub LoadShippers(CFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopCombo(ComboCFAgentUsers, sqlstr, clsData.constr, 0)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatus(CFPROID As String)

        Dim sqlstr As String =
       "Select Status,ID " &
       "From CFAgentJobStatus " &
       "Where CFPROID = '" & CFPROID & "' "

        ComboJobStatus.Items.Clear()
        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select ItemDescription,ItemID " &
         "From KPIProgress "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr1, clsData.constr, 0, 1)
        ComboJobStatus.Items.Insert(0, "(All)")
    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    'Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
    '    If GridJobs.SelectedValue Is Nothing Then
    '        LabelJobMessage.ForeColor = Color.Tomato
    '        LabelJobMessage.Text = "Please select an item"
    '    Else
    '        Call GotoJob()
    '    End If
    'End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    'Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
    '    Call RefreshData()
    'End Sub
    Private Sub RefreshData()

        Call ClearFilters()
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day


            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double
            Dim JobCount As Double

            Dim JobID As String

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                If JobID <> dv(a)("JobID") Then
                    JobCount = JobCount + 1
                    JobID = dv(a)("JobID")
                End If


                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")

            Next

            TextQuantity.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextCBM.Text = Format(CBM, "#,##0.00")
            TextTEU.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = JobCount & " Jobs: " & tmpstr

                Else
                    LabelReportCaption.Text = JobCount & " DISPATCHED JOBS: " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = JobCount & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelReportCaption.Text = JobCount & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a As Integer = 0

            Dim CFPROID As String = LabelCFPROID.Text


            If IsNothing(Session("JobTableDetailed")) Then
                Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If


            Dim JobTable As DataTable = Session("JobTableDetailed")

            Dim dv As DataView = New DataView(JobTable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                tmpstr1(a) = "Agent : " & TextAgent.Text
                a = a + 1

            End If


            If Client Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                a = a + 1


            End If

            If Importer Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                a = a + 1
            End If

            If Shipper Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                a = a + 1
            End If

            If ShipStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ShipStatus Like '%" & ComboVesselStatus.Text & "'% "
                Else
                    tmpstr(a) = " And ShipStatus Like '%" & ComboVesselStatus.Text & "'% "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                a = a + 1
            End If

            If JobType Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                a = a + 1
            End If

            If JobStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                a = a + 1
            End If


            If CFS Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                a = a + 1
            End If

            'If EntensionRequested Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
            '    Else
            '        tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
            '    End If

            '    tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
            '    b = b + 1
            'End If

            If OmitDispatched Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Dispatched" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Dispatched" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                a = a + 1
            End If


            If OmitCrossedBorder Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                a = a + 1
            End If

            If CustomsSystem Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "'% "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "'% "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                a = a + 1
            End If


            If CFAgentUser Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)
                If a = 0 Then

                    tmpstr(a) = " (UserID = '" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like '%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like '%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like '%" & UserNames & "%' " &
                                "Or PortStaff Like '%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like '%" & UserNames & "%') "

                Else
                    tmpstr(a) = " (And UserID = '" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like '%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like '%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like  '%" & UserNames & "%' " &
                                "Or PortStaff Like '%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like '%" & UserNames & "%') "

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                a = a + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridJobs.DataSource = dv
            GridJobs.DataBind()



            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub


    Private Sub AppendJobDate(Append As Boolean)
        Dim dv As DataView = GridJobs.DataSource
        If Not IsNothing(dv) Then
            Dim a As Integer
            Dim tmpstr(1)
            For a = 0 To dv.Count - 1
                tmpstr = dv(a)("ReferenceNo").ToString.Split(":")
                ReDim Preserve tmpstr(1)
                If Append Then
                    dv(a)("ReferenceNo") = Trim(tmpstr(0)) & " : " & Format(dv(a)("JobDate"), "dd MMM yyyy")
                Else
                    dv(a)("ReferenceNo") = Trim(tmpstr(0))
                End If
            Next


        End If
    End Sub

    Private Sub SaveSettings()
        Dim tmptable As New DataTable()
        Call clsData.TableData("", tmptable, clsData.constr)
        Dim drow As DataRow = tmptable.Rows(0)
        drow("SortJobsBy") = ComboSortOrder.Text
        drow("SortOrder") = clsDetailedVisibilityReport.nSortOrder(RadioButtonList1.SelectedIndex)
        '  drow("AddJobDatetoRef") = CheckAddJobDatetoRef.Checked

        Call clsData.SaveData("Environment", tmptable, "", False, clsData.constr)
    End Sub



    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click

        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00015") Then

            Call clsDetailedVisibilityReport.ExportToExcel(LabelCFPROID.Text, LabelCFPROUserID.Text, TextWeight.Text,
                                                           TextCBM.Text, TextTEU.Text, TextQuantity.Text,
                                                           LabelFilterStr.Text, LabelSortStr.Text, LabelReportCaption.Text, GridJobs.DataSource)
        Else
            LabelJobMessage.Text = "User Not Allowed"
            LabelJobMessage.ForeColor = Color.Red
        End If


    End Sub

    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckFilterAgent.Checked, CheckFilterClient.Checked, CheckFilterConsignee.Checked, CheckShipper.Checked,
                            CheckShipStatus.Checked, CheckJobType.Checked, CheckJobStatus.Checked, CheckCFS.Checked,
                            CheckOmitDispatched.Checked, CheckOmitCrossedBorder.Checked, CheckCustomsSystem.Checked, CheckCFAgentUser.Checked)

        ModalPopupExtender3.Show()
    End Sub


    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call clsDetailedVisibilityReport.nSortOrder(RadioButtonList1.SelectedIndex)
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboMaxRecords.SelectedIndexChanged
        Call ClearFilters()
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)


        If IsNothing(Session("JobTableDetailed")) Then
            Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If


        Dim JobTable As DataTable = Session("JobTableDetailed")

        Dim dv As DataView = New DataView(JobTable)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "'% " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "'% " &
                        "Or Cargo Like '%" & Trim(SearchStr) & "'% " &
                        "Or Client Like '%" & Trim(SearchStr) & "'% " &
                        "Or BL Like '%" & Trim(SearchStr) & "'% "

        GridJobs.DataSource = dv
        GridJobs.DataBind()

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

    End Sub



    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ModalPopupExtender3.Show()
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ModalPopupExtender3.Show()
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)

    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)

        Dim CFPROID As String = LabelCFPROID.Text


        If dv Is Nothing Then

            If IsNothing(Session("JobTable")) Then
                Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobTable As DataTable = Session("JobTableDetailed")
            dv = New DataView(JobTable)
        End If

        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = clsDetailedVisibilityReport.nSortOrder(RadioButtonList1.SelectedIndex)
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobID" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA " & tmpstrSort
        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridJobs.DataSource = dv
            GridJobs.DataBind()
        End If



        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub


    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub

    Protected Sub ComboCustomsSystem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCustomsSystem.SelectedIndexChanged
        CheckCustomsSystem.Checked = True
    End Sub

    Protected Sub ComboShippers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboShippers.SelectedIndexChanged
        CheckShipper.Checked = True
    End Sub


    Protected Sub ComboCFAgentUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgentUsers.SelectedIndexChanged
        CheckCFAgentUser.Checked = True
    End Sub

    Protected Sub ComboVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVesselStatus.SelectedIndexChanged
        CheckShipStatus.Checked = True
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckFilterClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckFilterAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()
        ModalPopupExtender3.Show()
    End Sub



    Protected Sub ButtonScope_Click(sender As Object, e As EventArgs) Handles ButtonScope.Click
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub RadioButtonList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList2.SelectedIndexChanged
        If RadioButtonList2.SelectedIndex = 0 Then
            Response.Cookies("DetVisExp").Value = 0
            Response.Redirect("detailedvisibility.aspx")
        End If
    End Sub


    Protected Sub ButtonFilters_Click(sender As Object, e As EventArgs) Handles ButtonFilters.Click
        ModalPopupExtender3.Show()
    End Sub

    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call RefreshData()
    End Sub



    Protected Sub ButtonExcelColumns_Click(sender As Object, e As EventArgs) Handles ButtonExcelColumns.Click
        Call LoadDialog("detailedvisibilitycolumns.aspx", "Detailed Visibility Excel Report Columns", 440, 585)
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl

        'ModalPopupExtender4.CancelControlID = "LinkCloseDialog"
        ModalPopupExtender1.Show()
    End Sub
End Class

