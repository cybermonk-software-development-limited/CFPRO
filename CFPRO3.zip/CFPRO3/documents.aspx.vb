﻿Imports System.Drawing

Public Class documents
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadDocumentTypes(CFPROID, "", 0)

        End If

    End Sub

    Private Sub LoadDocumentTypes(CFPROID As String, SearchStr As String, Rowindex As Integer)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "Where DocumentType Like '%" & Trim(SearchStr) & "'% " &
                         "And CFPROID = '" & CFPROID & "' "
            Else
                tmpstr = "Where  CFPROID = '" & CFPROID & "' " 
            End If

            Dim sqlstr As String =
                "SELECT  DocumentType, " &
                "DocumentTypeID, Purpose," &
                "CFPROID, ID " &
                "FROM  DocumentTypes " &
                 tmpstr &
                 "And Purpose = 'Clearing' " &
                "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then
                Call clsSubs.CreateAccountDocumentTypes(CFPROID, tmptable)
            End If

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridDocumentType.DataSource = tmptable
            GridDocumentType.DataBind()


            If GridDocumentType.Rows.Count > 0 Then
                If Rowindex < 0 Then
                    Rowindex = 0
                End If

                If Rowindex > GridDocumentType.Rows.Count - 1 Then
                    Rowindex = GridDocumentType.Rows.Count - 1
                End If

                GridDocumentType.SelectedIndex = Rowindex
                Dim row As GridViewRow = GridDocumentType.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If


            If Not Trim(SearchStr) = "" Then
                LabelCaption.Text = tmptable.Rows.Count & "  Document Type Found matching '" & SearchStr & "'"
            Else
                LabelCaption.Text = tmptable.Rows.Count & "  Document Types"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    
    Protected Sub GridDocumentType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridDocumentType.SelectedIndexChanged
        Dim row As GridViewRow = GridDocumentType.Rows(GridDocumentType.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        Dim CFPROID As String = LabelCFPROID.Text
        Dim CFPROID1 As String = GridDocumentType.SelectedDataKey(1).ToString



        For a As Integer = 0 To GridDocumentType.Rows.Count - 1
            row = GridDocumentType.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridDocumentType.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

        If CFPROID1 = CFPROID Then
            ButtonEdit.Enabled = True
            ButtonRemove.Enabled = True

            ButtonEdit.BackColor = Color.White
            ButtonRemove.BackColor = Color.White
        Else
            ButtonEdit.BackColor = Color.WhiteSmoke
            ButtonRemove.BackColor = Color.WhiteSmoke

            ButtonEdit.Enabled = False
            ButtonRemove.Enabled = False
        End If

    End Sub

    Protected Sub GridShippingDocumentType_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridDocumentType.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridDocumentType, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditDocumentType(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditDocumentType(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridDocumentType.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please SELECT Document Type."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Document Type"
                Dim ID As Integer = GridDocumentType.SelectedValue
                Dim sqlstr As String = "SELECT DocumentType,ID " &
                                        "From  DocumentTypes " &
                                        "Where ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("DocumentType")
                End If

            Else
                LabelAddEdit.Text = "Add  Document Type"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditDocumentType(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveDocumentType(Edit)
    End Sub

    Private Sub SaveDocumentType(Edit As Boolean)

        Dim ID As Integer = -1
        Dim CFPROID As String = LabelCFPROID.Text

        If Not Edit Then
            If DocumentTypeExists(TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridDocumentType.SelectedIndex >= 0 Then
                    ID = GridDocumentType.SelectedDataKey(0)
                End If
            End If


            Dim sqlstr As String = "SELECT DocumentType, " &
                                    "DocumentTypeID,Purpose," &
                                    "CFPROID, ID " &
                                    "From  DocumentTypes " &
                                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("DocumentTypeID") = GetDocumentTypeID()
                drow("Purpose") = "Clearing"
                tmptable.Rows.Add(drow)
            End If

            drow("DocumentType") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("DocumentTypes", tmptable, sqlstr, False, clsData.constr)

            Call LoadDocumentTypes(CFPROID, TextSearch.Text, GridDocumentType.SelectedIndex)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub



    Private Function DocumentTypeExists(DocumentType As String) As Boolean


        Dim sqlstr As String = "SELECT DocumentType, DocumentTypeID " &
                                "From  DocumentTypes " &
                                "Where DocumentType = '" & Trim(DocumentType) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridDocumentType.SelectedIndex >= 0 Then
            Call PromptDeleteDocumentType(GridDocumentType.SelectedValue)
        Else
            LabelMessage.Text = "Please SELECT Document Type to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteDocumentType(ID As Integer)


        Dim row As GridViewRow = GridDocumentType.Rows(GridDocumentType.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteDocumentType(GridDocumentType.SelectedDataKey(0))
    End Sub
    Private Sub DeleteDocumentType(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From DocumentTypes  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("DocumentTypes", tmptable, sqlstr, True, clsData.constr)

            Call LoadDocumentTypes(LabelCFPROID.Text, TextSearch.Text, GridDocumentType.SelectedIndex - 1)

        End If
        ModalPopupExtender3.Hide()

    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadDocumentTypes(LabelCFPROID.Text, TextSearch.Text, 0)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadDocumentTypes(LabelCFPROID.Text, "", GridDocumentType.SelectedIndex)
    End Sub

    Private Function GetDocumentTypeID() As String
        Try

            Dim tmpDocumentTypeID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From DocumentTypes " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpDocumentTypeID = drow("ID")
                tmpDocumentTypeID = tmpDocumentTypeID + 1
                tmpstr = Format(tmpDocumentTypeID, "0000#")
            Else
                tmpstr = Format(tmpDocumentTypeID, "0000#")
            End If

            Return tmpstr

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetDocumentTypeID")
        End Try
    End Function

End Class