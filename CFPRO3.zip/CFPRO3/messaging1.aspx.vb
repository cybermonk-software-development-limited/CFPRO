﻿Public Class messaging1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn("", "", "", LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, True)

            Call LoadMessages()
        End If
    End Sub


    Private Sub LoadMessages()

    End Sub


End Class