﻿

Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Imports System.Web.UI.HtmlControls


Public Class jobdetailedvisibilityexp
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If Not IsNothing(Request.Cookies("DetVisExp")) Then
                If Request.Cookies("DetVisExp").Value = 0 Then
                    Response.Redirect("jobdetailedvisibility.aspx")
                Else
                    RadioButtonList2.SelectedIndex = 1
                End If
            End If

            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Dim CFAgentCFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFAgentCFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

            LabelCFAgentCFPROID.Text = CFAgentCFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFAgentCFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            Call LoadShippers(CFAgentCFPROID)
            Call LoadCFAgentUsers(CFAgentCFPROID)
            Call LoadVesselStatus(CFAgentCFPROID)
            Call LoadJobStatus(CFAgentCFPROID)
            Call LoadJobTypes(CFAgentCFPROID)
            Call LoadCFS(CFAgentCFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFAgentCFPROID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadJobs(Scope As String, ByVal selectClients As Boolean, ByVal selectAgents As Boolean,
                                           dispatchdate As Boolean, CFAgentCFPROID As String, DoPDF As Boolean, ResetCacheTable As Boolean)
        Try
            Dim Opdate As String



            If dispatchdate Then
                Opdate = "DispatchDate"
            Else
                Opdate = "JobDate"
            End If



            Dim tmpstr As String
            Dim tmpstrdate1, tmpstrdate2 As String


            tmpstrdate1 = "'" & TextFromDate.Text & "' "
            tmpstrdate2 = "'" & TextToDate.Text & "' "




            If Not LCase(Scope) = "(all)" Then
                tmpstr = "And Jobs." & Opdate & " >= " & tmpstrdate1 & " " &
                          "And Jobs." & Opdate & " <= " & tmpstrdate2 & " "

            Else
                tmpstr = "And ID > 0 "

            End If


            Select Case ComboLoadedJobs.Text
                Case "Active Jobs"
                    tmpstr = tmpstr & " And Jobs.JobStatus <> '" & "Closed" & "' "


                Case "Active + Closed Jobs"

                    tmpstr = " And Jobs.JobDate >= " & tmpstrdate1 & " " &
                         "And Jobs.JobDate <= " & tmpstrdate2 & " "

                Case "Closed Jobs"
                    tmpstr = tmpstr & " And Jobs.JobStatus = '" & "Closed" & "' "



                Case "Jobs Kept Visible"

                    tmpstr = " And  Jobs.KeepVisible = 1 "

            End Select



            Dim tmpstrClientsAgents As String = ""

            'If selectClients Then
            '    Dim tmpstrSel(), tmpclients() As String
            '    tmpstrSel = clsSubs.SelectedClients()

            '    Dim n As Integer
            '    If Not IsNothing(tmpstrSel) Then
            '        ReDim Preserve tmpclients(n)
            '        LabelVisibilityCaption.Text = "Clients: " & Join(tmpstrSel, ", ")
            '        For n = 0 To tmpstrSel.GetUpperBound(0)
            '            ReDim Preserve tmpclients(n)
            '            If n = 0 Then
            '                tmpclients(n) = "ClientID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                  " And " & tmpstr0
            '            Else
            '                tmpclients(n) = "Or ClientID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                 " And " & tmpstr0
            '            End If
            '        Next
            '        tmpstrClientsAgents = Join(tmpclients, " ")
            '        GoTo skipagent
            '    Else
            '        LabelMessage1.Text = "No Clients Selected."
            '        Exit Sub
            '    End If
            'Else
            '    tmpstrClientsAgents = tmpstr0
            'End If



            'If selectAgents Then
            '    Dim tmpstrSel(), tmpAgents() As String
            '    tmpstrSel = clsSubs.SelectedAgents()
            '    Dim n As Integer
            '    If Not IsNothing(tmpstrSel) Then
            '        ReDim Preserve tmpAgents(n)
            '        LabelVisibilityCaption.Text = "Agents: " & Join(tmpstrSel, ", ")

            '        For n = 0 To tmpstrSel.GetUpperBound(0)
            '            ReDim Preserve tmpAgents(n)
            '            If n = 0 Then
            '                tmpAgents(n) = "AgentID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                  " And " & tmpstr0
            '            Else
            '                tmpAgents(n) = "Or AgentID Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
            '                " And " & tmpstr0
            '            End If
            '        Next
            '        tmpstrClientsAgents = Join(tmpAgents, " ")
            '    Else
            '        LabelMessage1.Text = "No Agents Selected."
            '        Exit Sub
            '    End If
            'Else
            '    tmpstrClientsAgents = tmpstr0
            'End If

skipagent:

            Dim sqlstr As String =
                    "Select Top " & ComboSelectTop.Text & " " &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "CustomsSystem,BL,HouseBL," &
                    "OrderNo, Goods, Destination," &
                    "ShipperID,ReleasePersonnel," &
                    "ReleasedTo, ReleaseDate," &
                    "EntryRegistrationDate,EntryPassDate, EntryNo," &
                    "DeclarationPersonnel,ShippingPersonnel,ShipStatus," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,JobType,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested," &
                    "ManifestNo,ExtensionEndDate," &
                    "RemainingExtensionDays,StatusID,JobStatus," &
                    "DocumentStatus,DocumentsLodgeDate,PortCharges," &
                    "PortChargesStatus,PortChargesPaidDate," &
                    "ReleaseOrderStatus,ReleaseOrderDate," &
                    "PortChargesCurrency,LoadingStatus,LoadingDate," &
                    "PickupOrderStatus,PickUpOrderDate," &
                    "PortStartDate,PortEndDate," &
                    "PortExpenses,PortStaff," &
                    "PortInvoiceNo,WareHouseRent, " &
                    "ShipStatus,ManifestNo,DeliveryOrderStatus," &
                    "DeliveryOrderCharges,DeliveryOrderDate,HandoverFees," &
                    "ContainerDeposit, ContainerDepositDate, " &
                    "ContainerRefundRequestDate,ContainerDepositRefund," &
                    "ContainerDepositRefundDate,ContainerDepositDeductions, " &
                    "ContainerDepositRemarks,ShippingPersonnel," &
                    "ShippingExpenses,ShippingStart,ShippingEnd, " &
                    "ModeofTransport,UserID, ID " &
                    "From Jobs " &
                    "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
            tmpstr


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,Payload,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate,CrossBorderDate, ReturnDate, " &
                  "TransporterID,VehicleNo, " &
                  "ContainerStatusRemarks,DestinationArrivalDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID " &
            tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                        "Select CFS, CFSID " &
                        "From CFS " &
                        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate, VoyageNo  " &
                       "From ShippingVessels " &
                       "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim sqlstr4 As String =
                       "Select JobProgress.JobID," &
                       "Status, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID " &
                        tmpstr &
                       "Order By JobProgress.Date DESC;"


            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)



            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)



            Dim sqlstr5a As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
                    "And IsAgent = 1 "

            Dim tmptable5a As New DataTable()
            Call clsData.TableData(sqlstr5a, tmptable5a, clsData.constr)
            Dim dv5a As New DataView(tmptable5a)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "
            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim sqlstr7 As String =
                 "Select ShipperID, Shipper " &
                 "From Shippers " &
                 "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "
            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)


            Dim sqlstr8 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable8 As New DataTable()
            Call clsData.TableData(sqlstr8, tmptable8, clsData.constr)
            Dim dv8 As New DataView(tmptable8)

            Dim sqlstr9 As String = _
           "Select UserID,UserNames " & _
           "From CFAgentUsers " & _
            "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable9 As New DataTable()
            Call clsData.TableData(sqlstr9, tmptable9, clsData.constr)
            Dim dv9 As New DataView(tmptable9)

            Dim sqlstr10 As String = _
            "Select TransporterID,Transporter " & _
            "From Transporters " & _
            "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable10 As New DataTable()
            Call clsData.TableData(sqlstr10, tmptable10, clsData.constr)
            Dim dv10 As New DataView(tmptable10)



            Dim tmptablejobs As New DataTable


            Call CreateJobTableColumns(tmptablejobs)


            NewAnalysis = True
            Dim portexitdate, crossborderdate, eta, lastsling As String


            Dim cfs, vessel, voyageno, client, agent, importer, shipper, shippingline, jobpersonnel, transporter As String
            Dim vesseleta, berthingdate, exitdate As Date

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now

            Dim CrossedBorder As Boolean
            Dim drow, drow1 As DataRow

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            If tmptable.Rows.Count > 10 Then
                PanelJobs.Height = 350
            Else
                PanelJobs.Height = Nothing
            End If



            Dim nAllcrossedborder, nAllarrived As Boolean
            Dim nLatestCrossBorderDate, nLatestArrivalDate As Date
            Dim tmpstrsoc As String = ""
            Dim tmpstrtin As String = ""
            Dim nCFSStorage As String = ""



            Dim a, b, c, d, e As Integer


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)


                dv1.RowFilter = "JobId = '" & drow("JobId") & "' "
                dv4.RowFilter = "JobID = '" & drow("JobID") & "' "

                nAllcrossedborder = AllCrossedBorder(dv1)
                nAllarrived = AllArrived(dv1)

                nLatestCrossBorderDate = CDate("1-Jan-1800")
                nLatestArrivalDate = CDate("1-Jan-1800")

                nLatestCrossBorderDate = LatestCrossBorderDate(dv1)
                nLatestArrivalDate = LatestArrivalDate(dv1)

                cfs = ""
                vessel = ""
                vesseleta = CDate("1-Jan-1800")
                berthingdate = CDate("1-Jan-1800")
                exitdate = CDate("1-Jan-1800")
                voyageno = ""
                client = ""
                agent = ""
                importer = ""
                shipper = ""
                shippingline = ""
                voyageno = ""
                tmpstrsoc = ""
                tmpstrtin = ""
                jobpersonnel = ""

                If drow("SOC") Then
                    tmpstrsoc = "SOC"
                Else
                    tmpstrsoc = ""
                End If


                d = c

                'row1

                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)

                drow1("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                drow1("Marker") = "Header"
                drow1("NoBreakRow") = 1

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "
                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "
                dv5a.RowFilter = "ClientID = '" & drow("AgentID") & "' "
                dv6.RowFilter = "ImporterID = '" & drow("ImporterID") & "' "
                dv7.RowFilter = "ShipperID = '" & drow("ShipperID") & "' "
                dv8.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "
                dv9.RowFilter = "UserID = '" & drow("UserID") & "' "

                TEU = 0
                CBM = 0
                Weight = 0

                CrossedBorder = True
                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)
                    CBM = CBM + dv1(b)("CBM")
                    Weight = Weight + dv1(b)("Weight")
                    TEU = TEU + Val(dv1(b)("TEU"))

                    If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                        CrossedBorder = False
                    End If
                Next


                drow1("Weight") = Weight
                drow1("CBM") = CBM
                drow1("TEU") = TEU
                drow1("CrossedBorder") = CrossedBorder
                drow1("Quantity") = dv1.Count



                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    cfs = dv2(0)("CFS")
                End If

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)
                    vessel = dv3(0)("Vessel")
                    vesseleta = dv3(0)("ETA")
                    berthingdate = dv3(0)("BerthingDate")
                    exitdate = dv3(0)("ExitDate")
                    voyageno = dv3(0)("VoyageNo")
                End If


                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    client = dv5(0)("Client")
                End If

                If dv5a.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    agent = dv5a(0)("Client")
                End If

                If dv6.Count > 0 Then
                    Call clsData.NullChecker1(dv6, 0)
                    importer = dv6(0)("Importer")
                End If


                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)
                    shipper = dv7(0)("Shipper")
                End If

                If dv8.Count > 0 Then
                    Call clsData.NullChecker1(dv8, 0)
                    shippingline = dv8(0)("ShippingLine")
                End If

                If dv9.Count > 0 Then
                    Call clsData.NullChecker1(dv9, 0)
                    jobpersonnel = dv9(0)("UserNames")
                End If

                drow1("References") = drow("ReferenceNo")
                drow1("Shipping") = shippingline
                drow1("ClientConsigneeShipper") = Mid(client, 1, 25)
                drow1("Transportation") = Format(Weight, "#,##0.#0") & "Kg : " & Format(CBM, "#,##0.#0") & "CbM"

                'If CDate(drow("DocumentsReceivedDate")) = CDate("1-Jan-1800") Then

                'Else
                '    drow1("Entry") = "Docs:" & Format(drow("DocumentsReceivedDate"), "dd MMM yyyy")
                'End If

                drow1("Entry") = drow("DocumentStatus")


                If CDate(drow("DeliveryOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DeliveryOrderStatus")
                Else
                    drow1("Customs") = "D.O:" & Format(drow("DeliveryOrderDate"), "dd MMM yyyy")
                End If

                If CDate(drow("PortChargesPaidDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("PortChargesStatus")
                Else
                    drow1("Port") = "Chgs:" & Format(drow("PortChargesPaidDate"), "dd MMM yyyy")
                End If



                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("Marker") = "Header"
                drow1("JobType") = drow("JobType")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")
                drow1("NoBreakRow") = 1

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")

                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("TIN") = tmpstrtin



                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")

                If nAllcrossedborder Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1
                e = a


                'row2
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1
                'drow1("Id") = c



                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = drow("ReferenceNo1")
                drow1("ClientConsigneeShipper") = importer

                drow1("Transportation") = drow("ModeofTransport")

                If Not Trim(voyageno) = "" Then
                    voyageno = " / VOY:" & voyageno
                End If

                drow1("Shipping") = vessel & voyageno

                If Not CDate(drow("EntryRegistrationDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Lodg:" & Format(drow("EntryRegistrationDate"), "dd MMM yyyy")
                End If

                If CDate(drow("DocumentsLodgeDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DocumentStatus")
                Else
                    drow1("Customs") = "L.R:" & Format(drow("DocumentsLodgeDate"), "dd MMM yyyy")
                End If

                If CDate(drow("LoadingDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("LoadingStatus")
                Else
                    drow1("Port") = "Load:" & Format(drow("LoadingDate"), "dd MMM yyyy")
                End If



                drow1("JobType") = drow("JobType")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")

                If nAllcrossedborder Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                'row3
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1
                'drow1("Id") = c

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = "MBL: " & drow("BL") & " HBL: " & drow("HouseBL")
                drow1("ClientConsigneeShipper") = shipper
                drow1("Transportation") = drow("Destination")

                If Not CDate(vesseleta) = CDate("1-Jan-1800") Then
                    eta = "ETA:" & Format(vesseleta, "dd MMM yyyy")
                Else
                    eta = ""
                End If

                If Not CDate(exitdate) = CDate("1-Jan-1800") Then
                    lastsling = " / LS:" & Format(exitdate, "dd MMM yyyy")
                Else
                    lastsling = ""
                End If

                drow1("Shipping") = eta & lastsling

                If Not CDate(drow("EntryPassDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Pass:" & Format(drow("EntryPassDate"), "dd MMM yyyy")
                End If

                If CDate(drow("ReleaseOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("ReleaseOrderStatus")
                Else
                    drow1("Customs") = "R.O:" & Format(drow("ReleaseOrderDate"), "dd MMM yyyy")
                End If

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = drow("JobType")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")

                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")

                If nAllcrossedborder Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1


                If CheckStorageStartDate.Checked Then
                    nCFSStorage = CFSStorage(drow("ClientID"), drow("CFSID"), drow("JobType"), drow("LastSlingDAte"))
                End If


                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)



                    If b <= 2 Then
                        drow1 = tmptablejobs.Rows(d + b)
                    Else
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1

                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("JobDate") = drow("JobDate")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = drow("JobType")
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")

                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")


                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")

                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If



                    drow1("Cargo") = dv1(b)("ContainerNo") & " " & dv1(b)("Payload") & " " & Format(dv1(b)("Weight"), "#,##0.00") & "Kg " & tmpstrsoc & " " & nCFSStorage

                    If Trim(dv1(b)("ContainerStatusRemarks")) = "" Then
                        drow1("CargoStatus") = dv1(b)("ContainerStatus")
                    Else
                        drow1("CargoStatus") = dv1(b)("ContainerStatusRemarks")
                    End If


                    If Not CDate(dv1(b)("PortExitDate")) = CDate("1-Jan-1800") Then
                        portexitdate = Format(dv1(b)("PortExitDate"), "dd MMM yyyy")
                    Else
                        portexitdate = ""
                    End If

                    If Not CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                        crossborderdate = Format(dv1(b)("CrossBorderDate"), "dd MMM yyyy")
                    Else
                        crossborderdate = ""
                    End If

                    If InStr(drow("JobType"), "Local", CompareMethod.Text) <> 0 Then
                        drow1("Checkpoints") = "MSA:" & portexitdate
                    Else
                        drow1("Checkpoints") = "MSA:" & portexitdate & " / MLB:" & crossborderdate
                    End If

                    transporter = ""
                    dv10.RowFilter = "TransporterID = '" & dv1(b)("TransporterID") & "' "

                    If dv10.Count > 0 Then
                        transporter = dv10(0)("Transporter")
                    End If

                    If Not Trim(transporter) = "" Then
                        transporter = " \ " & transporter
                    Else
                        transporter = ""
                    End If

                    drow1("Transporter") = dv1(b)("VehicleNo") & transporter

                    If nAllcrossedborder Then
                        drow1("CrossBorderDate") = nLatestCrossBorderDate
                        drow1("CrossedBorder") = CBool(1)
                    Else
                        drow1("CrossBorderDate") = CDate("1-Jan-1800")
                        drow1("CrossedBorder") = CBool(0)
                    End If

                    If nAllarrived Then
                        drow1("DestinationArrivalDate") = nLatestArrivalDate
                        drow1("Arrived") = CBool(1)
                    Else
                        drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                        drow1("Arrived") = CBool(0)
                    End If

                Next


                For b = 0 To dv4.Count - 1
                    Call clsData.NullChecker1(dv4, b)
                    If b <= 2 Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b <= (dv1.Count - 1) Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b > (dv1.Count - 4) Then
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1
                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = drow("JobType")
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")
                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")

                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")

                        If nAllcrossedborder Then
                            drow1("CrossBorderDate") = nLatestCrossBorderDate
                            drow1("CrossedBorder") = CBool(1)
                        Else
                            drow1("CrossBorderDate") = CDate("1-Jan-1800")
                            drow1("CrossedBorder") = CBool(0)
                        End If

                        If nAllarrived Then
                            drow1("DestinationArrivalDate") = nLatestArrivalDate
                            drow1("Arrived") = CBool(1)
                        Else
                            drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                            drow1("Arrived") = CBool(0)
                        End If



                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If

                    drow1("JobDate") = drow("JobDate")
                    drow1("Status") = Format(dv4(b)("Date"), "dd MMM yyyy") & " - " & dv4(b)("Status")
                    'drow1("Highlight") = dv4(b)("Highlight")

                Next


                drow1 = tmptablejobs.NewRow
                'drow1("Id") = c
                drow1("Marker") = "Break"
                drow1("NoBreakRow") = 0

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = drow("JobType")
                drow1("JobDate") = drow("JobDate")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")

                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")


                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("KeepVisible") = drow("KeepVisible")
                'drow1("SCT") = SCT(drow("CustomsSystem"))


                If nAllcrossedborder Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                tmptablejobs.Rows.Add(drow1)
                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                a = a + 1

            Next

            Dim dv As New DataView(tmptablejobs)


            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort

            Session("JobTableDetailed") = tmptablejobs

            LabelMessage1.Text = ""

            If ResetCacheTable Then
                Exit Sub
            End If


            If tmptable.Rows.Count >= 10 And tmptable.Rows.Count <= 34 Then
                PanelJobs.Height = (tmptable.Rows.Count * 10) + 25
            ElseIf tmptable.Rows.Count > 100 Then
                PanelJobs.Height = 875
            Else
                PanelJobs.Height = Nothing
            End If

            GridJobs.Width = 1600
            PanelJobs.Width = 1625
            GridJobs.DataSource = dv
            GridJobs.DataBind()

            Call Calctotal(dv, "")



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub



    Private Function AllCrossedBorder(ByVal dv As DataView) As Boolean
        Dim a As Integer
        Dim all As Boolean = True
        For a = 0 To dv.Count - 1
            Call clsData.NullChecker1(dv, a)
            If CDate(dv(a)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                all = False
            End If
        Next
        Return all

    End Function

    Private Function AllArrived(ByVal dv As DataView) As Boolean
        Dim a As Integer
        Dim all As Boolean = True
        For a = 0 To dv.Count - 1
            Call clsData.NullChecker1(dv, a)
            If CDate(dv(a)("DestinationArrivalDate")) = CDate("1-Jan-1800") Then
                all = False
            End If
        Next
        Return all
    End Function

    Private Function LatestCrossBorderDate(ByVal dv As DataView) As String
        Dim tmpstr As String
        If dv.Count > 0 Then
            dv.Sort = "CrossBorderDate DESC"
            tmpstr = dv(0)("CrossBorderDate")
            dv.Sort = Nothing
            Return tmpstr
        Else
            Return "1-Jan-1800"
        End If
    End Function

    Private Function LatestArrivalDate(ByVal dv As DataView) As String
        Dim tmpstr As String
        If dv.Count > 0 Then
            dv.Sort = "DestinationArrivalDate DESC"
            tmpstr = dv(0)("DestinationArrivalDate")
            dv.Sort = Nothing
            Return tmpstr
        Else
            Return "1-Jan-1800"
        End If

    End Function

    Private Function SCT(ByVal CustomsSystem As String) As String
        Select Case CustomsSystem
            Case "KRA Simba System"
                Return ""
            Case "ASSYCUDA Uganda"
                Return "SCT-U"
            Case "ASSYCUDA Rwanda"
                Return "SCT-R"
            Case ""
                Return ""
        End Select
        Return ""
    End Function




    Private tableCFSStorage As New DataTable()
    Private NewAnalysis As Boolean
    Private Function CFSStorage(ClientID As String, CFSID As String, JobType As String, LastSlingDate As Date) As String
        Dim FreeDays As Integer
        Dim nClientstoragedays(1) As Integer
        Dim drow As DataRow

        Dim tmptable As New DataTable
        Dim sqlstr As String = _
             "Select CFSID, CFS, " & _
             "LocalFreeDays, TransitFreeDays,Id  " & _
             "From CFS " & _
             "Order By CFS Asc;"
        Call clsData.TableData(sqlstr, tableCFSStorage, clsData.constr)


        Dim sqlstr1 As String = "Select ClientID, CFSID," & _
        "LocalFreeDays,TransitFreeDays,Id " & _
        "From ClientStorageFreeDays "


        Call clsData.TableData(sqlstr1, tmptable, clsData.constr)


        For Each drow In tableCFSStorage.Rows

            If CFSID = drow("CFSID") Then

                'nClientstoragedays = clsStorageDemmurage.GetClientStorageFreeDays(ClientID, drow("CFSID"), False)

                If InStr(JobType, "transit", CompareMethod.Text) > 0 Then
                    If drow("TransitFreeDays") < nClientstoragedays(1) Then
                        FreeDays = nClientstoragedays(1)
                    Else
                        FreeDays = drow("TransitFreeDays")
                    End If
                Else
                    If drow("LocalFreeDays") < nClientstoragedays(0) Then
                        FreeDays = nClientstoragedays(0)
                    Else
                        FreeDays = drow("LocalFreeDays")
                    End If

                End If

                Exit For
            End If
        Next

        If Not CDate(LastSlingDate) = CDate("1-Jan-1800") Then
            Dim tmpdate As Date = LastSlingDate.AddDays(Val(FreeDays))
            Return "Stch: " & Format(tmpdate, "dd MMM yyyy")
        Else
            Return "--"
        End If

    End Function

    Private Sub CreateJobTableColumns(ByRef tmptablejobs As DataTable)
        Dim col As New DataColumn("JobID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col)

        Dim col1 As New DataColumn("References", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col1)

        Dim col3 As New DataColumn("ClientConsigneeShipper", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col3)


        Dim col4 As New DataColumn("Transportation", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col4)

        Dim col5 As New DataColumn("Shipping", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col5)

        Dim col6 As New DataColumn("Entry", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col6)

        Dim col7 As New DataColumn("Customs", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col7)

        Dim col8 As New DataColumn("Port", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col8)

        Dim col9 As New DataColumn("Cargo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col9)

        Dim col9a As New DataColumn("CargoStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col9a)

        Dim col10 As New DataColumn("Transporter", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col10)

        Dim col11 As New DataColumn("Checkpoints", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col11)

        Dim col12 As New DataColumn("Status", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col12)

        Dim col13 As New DataColumn("TIN", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col13)

        Dim col13a As New DataColumn("SCT", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col13a)

        Dim colm As New DataColumn("Marker", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(colm)

        Dim col14 As New DataColumn("Agent", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14)

        Dim col14a As New DataColumn("AgentID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14a)

        Dim col14b As New DataColumn("Client", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14b)

        Dim col14c As New DataColumn("ClientID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col14c)

        Dim col15 As New DataColumn("Importer", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col15)

        Dim col15b As New DataColumn("ImporterID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col15b)

        Dim col16 As New DataColumn("Shipper", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col16)

        Dim col16b As New DataColumn("ShipperID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col16b)

        Dim col17 As New DataColumn("Weight", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col17)

        Dim col18 As New DataColumn("CBM", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col18)

        Dim col19 As New DataColumn("CFS", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col19)

        Dim col19a As New DataColumn("CFSID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col19a)

        Dim col20 As New DataColumn("JobType", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col20)

        Dim col21 As New DataColumn("JobStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col21)

        Dim col22 As New DataColumn("ShipStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col22)

        Dim col23 As New DataColumn("JobPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col23)

        Dim col24 As New DataColumn("ShippingPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col24)

        Dim col25 As New DataColumn("DeclarationPersonnel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col25)

        Dim col26 As New DataColumn("PortStaff", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col26)


        Dim col28 As New DataColumn("ReferenceNo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col28)

        Dim col29 As New DataColumn("ReferenceNo1", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col29)


        Dim col30 As New DataColumn("BL", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col30)

        Dim col31 As New DataColumn("JobDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col31)

        Dim col32 As New DataColumn("CrossBorderDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col32)

        Dim col32a As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col32a)


        Dim col33 As New DataColumn("DestinationArrivalDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col33)

        Dim col33a As New DataColumn("Arrived", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col33a)


        Dim col34 As New DataColumn("Highlight", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col34)

        Dim col35 As New DataColumn("SOC", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col35)

        '-----
        Dim col36 As New DataColumn("Vessel", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col36)

        Dim col37 As New DataColumn("VoyageNo", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col37)

        Dim col38 As New DataColumn("CustomsSystem", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col38)

        Dim col39 As New DataColumn("KeepVisible", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col39)


        Dim col40 As New DataColumn("TEU", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col40)

        Dim col41 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col41)

        Dim col42 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col42)

        Dim col43 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col43)

        Dim col44 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
        tmptablejobs.Columns.Add(col44)

        Dim col45 As New DataColumn("ContainerReturnDays", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col45)

        Dim col46 As New DataColumn("DaysTaken", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col46)

        Dim col47 As New DataColumn("RemainingDays", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col47)

        Dim col48 As New DataColumn("Quantity", Type.GetType("System.Double"))
        tmptablejobs.Columns.Add(col48)

        Dim col51 As New DataColumn("ProgressStatus", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col51)

        Dim col52 As New DataColumn("ShippingLineID", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col52)

        Dim col53 As New DataColumn("ShippingLine", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col53)

        Dim col54 As New DataColumn("JobUrl", Type.GetType("System.String"))
        tmptablejobs.Columns.Add(col54)

        Dim col55 As New DataColumn("NoBreakRow", Type.GetType("System.Boolean"))
        tmptablejobs.Columns.Add(col55)
    End Sub
    Private Sub LoadShippers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopCombo(ComboCFAgentUsers, sqlstr, clsData.constr, 0)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatus(CFAgentCFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus "
        ComboJobStatus.Items.Clear()
        Call clsData.PopCombo(ComboJobStatus, sqlstr, clsData.constr, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select Status " &
         "From JobStatuses "

        Call clsData.PopCombo(ComboJobStatus, sqlstr1, clsData.constr, 0)
        ComboJobStatus.Items.Insert(0, "(All)")
    End Sub


    Private Sub LoadJobTypes(CFAgentCFPROID As String)
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes " &
         "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "


        Call clsData.PopCombo(ComboJobType, sqlstr, clsData.constr, 0)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    'Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
    '    If GridJobs.SelectedValue Is Nothing Then
    '        LabelJobMessage.ForeColor = Color.Tomato
    '        LabelJobMessage.Text = "Please select an item"
    '    Else
    '        Call GotoJob()
    '    End If
    'End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()
        'Dim a As Integer = GridJobs.SelectedValue.ToString
        'Dim selected As Boolean
        'If a >= 0 Then
        '    selected = GridJobs.SelectedIndex
        'End If

        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)


        '  GridJobs.SelectedIndex = a

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFAgentCFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day


            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, CFAgentCFPROID, False, False)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, CFAgentCFPROID, False, False)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double
            Dim JobCount As Double

            Dim JobID As String

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                If JobID <> dv(a)("JobID") Then
                    JobCount = JobCount + 1
                    JobID = dv(a)("JobID")
                End If


                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")

            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = JobCount & " Jobs: " & tmpstr

                Else
                    LabelReportCaption.Text = JobCount & " DISPATCHED JOBS: " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = JobCount & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelReportCaption.Text = JobCount & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFAgentCFPROID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer

            Dim CFAgentCFPROID As String = LabelCFAgentCFPROID.Text


            If IsNothing(Session("JobTableDetailed")) Then
                Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            End If


            Dim JobTable As DataTable = Session("JobTableDetailed")

            Dim dv As DataView = New DataView(JobTable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                b = b + 1

                tmpstr1(a) = "Agent : " & TextAgent.Text

            End If


            If Client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If Shipper Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                b = b + 1
            End If

            If ShipStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                b = b + 1
            End If

            If JobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobType Like '" & ComboJobType.Text & "%' "
                Else
                    tmpstr(a) = " And JobType Like '" & ComboJobType.Text & "%' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.Text
                b = b + 1
            End If

            If JobStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                b = b + 1
            End If


            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If

            'If EntensionRequested Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
            '    Else
            '        tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
            '    End If

            '    tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
            '    b = b + 1
            'End If

            If OmitDispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Dispatched" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Dispatched" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                b = b + 1
            End If


            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If

            If CustomsSystem Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                b = b + 1
            End If



            If CFAgentUser Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)

                If b = 0 Then

                    tmpstr(a) = "JobPersonnel = Like " & "'%" & UserNames & "%' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                Else
                    tmpstr(a) = " And JobPersonnel = Like " & "'%" & UserNames & "%' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                b = b + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridJobs.DataSource = dv
            GridJobs.DataBind()



            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub


    Protected Sub ButtonSelectAgents_Click(sender As Object, e As EventArgs) Handles ButtonSelectAgents.Click
        Call SelectAgents()
    End Sub

    Private Sub SelectAgents()
        Response.Redirect("selectedclients.aspx")

    End Sub


    Protected Sub ButtonSelectClients_Click(sender As Object, e As EventArgs) Handles ButtonSelectClients.Click
        Call SelectClients()
    End Sub

    Private Sub SelectClients()

    End Sub

    Private Sub ComboLoadedJobs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboLoadedJobs.SelectedIndexChanged
        Static x As Boolean
        If x Then
            Call RefreshData()
        End If
        x = True
    End Sub


    Private Sub AppendJobDate(Append As Boolean)
        Dim dv As DataView = GridJobs.DataSource
        If Not IsNothing(dv) Then
            Dim a As Integer
            Dim tmpstr(1)
            For a = 0 To dv.Count - 1
                tmpstr = dv(a)("ReferenceNo").ToString.Split(":")
                ReDim Preserve tmpstr(1)
                If Append Then
                    dv(a)("ReferenceNo") = Trim(tmpstr(0)) & " : " & Format(dv(a)("JobDate"), "dd MMM yyyy")
                Else
                    dv(a)("ReferenceNo") = Trim(tmpstr(0))
                End If
            Next


        End If
    End Sub

    Private Sub SaveSettings()
        Dim tmptable As New DataTable()
        Call clsData.TableData("", tmptable, clsData.constr)
        Dim drow As DataRow = tmptable.Rows(0)
        drow("SortJobsBy") = ComboSortOrder.Text
        drow("SortOrder") = nSortOrder()
        '  drow("AddJobDatetoRef") = CheckAddJobDatetoRef.Checked

        Call clsData.SaveData("Environment", tmptable, "", False, clsData.constr)
    End Sub


    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobId"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "VesselETA"
        Else
            Return "JobDate"
        End If
    End Function
    Protected Sub CheckSelectedAgents_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSelectedAgents.CheckedChanged
        If CheckSelectedAgents.Checked Then
            CheckSelectedAgents.Checked = Not CheckSelectedClients.Checked
        End If
    End Sub

    Protected Sub CheckSelectedClients_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSelectedClients.CheckedChanged
        If CheckSelectedClients.Checked Then
            CheckSelectedClients.Checked = Not CheckSelectedAgents.Checked
        End If
    End Sub



    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00015") Then

            'Dim tmpstr(6) As String
            'tmpstr(0) = "ID"
            'tmpstr(1) = "ClientID"
            'tmpstr(2) = "AgentID"
            'tmpstr(3) = "VesselID"
            'tmpstr(4) = "ImporterID"
            'tmpstr(5) = "ShippingLineID"
            'tmpstr(6) = "CFSID"

            'Dim CFAgentCFPROID As String = LabelCFAgentCFPROID.Text

            'If Not clsSubs.TableCacheOK(CFAgentCFPROID, TableFilter) Then
            '    Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            'End If

            'For a = 0 To tmpstr.GetUpperBound(0)
            '    If clsExportToExcel.ExcelTable.Columns.Contains(tmpstr(a)) Then
            '        clsExportToExcel.ExcelTable.Columns.Remove(tmpstr(a))
            '    End If
            'Next


            'Call clsExportToExcel.ExportToExcel(TableFilter, LabelFilterStr.Text, LabelSortStr.Text, LabelCFAgent.Text & " - Job Visibility Report - Standard", LabelReportCaption.Text, True)

            Call ExportToExcel()
        Else
            LabelJobMessage.Text = "User Not Allowed"
            LabelJobMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckFilterAgent.Checked, CheckFilterClient.Checked, CheckFilterConsignee.Checked, CheckShipper.Checked,
                            CheckShipStatus.Checked, CheckJobType.Checked, CheckJobStatus.Checked, CheckCFS.Checked,
                            CheckOmitDispatched.Checked, CheckOmitCrossedBorder.Checked, CheckCustomsSystem.Checked, CheckCFAgentUser.Checked)

        ModalPopupExtender3.Show()
    End Sub

    Private Sub LoadPage(page As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = page
        ModalPopupExtender1.Show()
    End Sub
    'Protected Sub ButtonProgressUpdates_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
    '    Try
    '        If GridJobs.SelectedValue Is Nothing Then
    '            LabelJobMessage.Text = "Please select an item"
    '        Else
    '            If GridJobs.SelectedIndex >= 0 Then

    '            End If

    '            Dim row As GridViewRow = GridJobs.SelectedRow

    '            Call LoadPage("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString & "&CFAgentCFPROID=" &
    '                          LabelCFAgentCFPROID.Text & "&referenceno=" & row.Cells(0).Text & "&jobdate=" &
    '                           row.Cells(1).Text & "&client=" &
    '                           row.Cells(2).Text, "Progress Update", 545, 780)
    '        End If
    '    Catch ex As Exception
    '        LabelMessage1.Text = ex.Message
    '    End Try
    'End Sub




    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignOut(LinkSignIn.Text, LabelUser.Text, Image1.ImageUrl, True)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call nSortOrder()
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, False)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)


        If IsNothing(Session("JobTableDetailed")) Then
            Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, LabelCFAgentCFPROID.Text, False, True)
        End If


        Dim JobTable As DataTable = Session("JobTableDetailed")

        Dim dv As DataView = New DataView(JobTable)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or Cargo Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "

        GridJobs.DataSource = dv
        GridJobs.DataBind()

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

    End Sub



    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsSubs.SearchClient(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsSubs.SearchAgent(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsSubs.SearchImporter(LabelCFAgentCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ModalPopupExtender3.Show()
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)
        ModalPopupExtender3.Show()
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsSubs.LoadItems(LabelCFAgentCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, ModalPopupExtender3, LabelMessage1.Text)

    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)

        Dim CFAgentCFPROID As String = LabelCFAgentCFPROID.Text


        If dv Is Nothing Then

            If IsNothing(Session("JobTable")) Then
                Call LoadJobs(ComboPredefine.Text, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, CFAgentCFPROID, False, True)
            End If

            Dim JobTable As DataTable = Session("JobTableDetailed")
            dv = New DataView(JobTable)
        End If

        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA " & tmpstrSort
        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridJobs.DataSource = dv
            GridJobs.DataBind()
        End If

        PanelJobs.Height = 875

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub


    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub

    Protected Sub ComboCustomsSystem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCustomsSystem.SelectedIndexChanged
        CheckCustomsSystem.Checked = True
    End Sub

    Protected Sub ComboShippers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboShippers.SelectedIndexChanged
        CheckShipper.Checked = True
    End Sub


    Protected Sub ComboCFAgentUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgentUsers.SelectedIndexChanged
        CheckCFAgentUser.Checked = True
    End Sub

    Protected Sub ComboVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVesselStatus.SelectedIndexChanged
        CheckShipStatus.Checked = True
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckFilterClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckFilterAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()
        ModalPopupExtender3.Show()
    End Sub

    Private Sub ExportToExcel()

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = GridJobs.Columns.Count
        Dim totalRows = GridJobs.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = GridJobs.Columns(col1 - 2).HeaderText
        Next

        workSheet.Cells("B3:M3").Merge = True
        workSheet.Cells("B4:M4").Merge = True

        workSheet.Cells("B3:M3").Style.Font.Size = 14
        workSheet.Cells("B4:M4").Style.Font.Size = 9
        workSheet.Cells("B3:M4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = "Job Visibility Report - Detailed : " & LabelCFAgent.Text
        workSheet.Cells(4, 2).Value = LabelReportCaption.Text

        Dim row1 As GridViewRow
        Dim row As Integer
        Dim RefNoLink As HyperLink
        ' xlWorkSheet.Cells(i + 1, j + 1) = name.Text
        For row = 5 To totalRows + 4
            row1 = GridJobs.Rows(row - 5)
            For col1 As Integer = 1 To totalCols

                If col1 = 1 Then
                    RefNoLink = DirectCast(GridJobs.Rows(row - 5).Cells(col1 - 1).FindControl("HyperLink1"), HyperLink)
                    workSheet.Cells(row + 1, col1 + 1).Value = RefNoLink.Text
                Else
                    workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1 - 1).Text
                End If

                If row1.Cells(col1 - 1).Text = "&nbsp;" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next
        Next

        Using rng As ExcelRange = workSheet.Cells("B5:M" & GridJobs.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:M5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":M" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        workSheet.Cells("C" & row & ":D" & row).Merge = True
        workSheet.Cells("E" & row & ":F" & row).Merge = True
        workSheet.Cells("G" & row & ":H" & row).Merge = True
        workSheet.Cells("I" & row & ":J" & row).Merge = True

        workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        workSheet.Cells("I" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Job Visibility Report - Detailed  " & Format(Now, "dd MMM yyyy hh:Mm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub


    Protected Sub ButtonScope_Click(sender As Object, e As EventArgs) Handles ButtonScope.Click
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub RadioButtonList2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList2.SelectedIndexChanged
        If RadioButtonList2.SelectedIndex = 0 Then
            Response.Cookies("DetVisExp").Value = 0
            Response.Redirect("jobdetailedvisibility.aspx")
        End If
    End Sub


    Protected Sub ButtonFilters_Click(sender As Object, e As EventArgs) Handles ButtonFilters.Click
        ModalPopupExtender3.Show()
    End Sub
End Class

