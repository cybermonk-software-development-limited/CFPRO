﻿Public Class clsMSDynamicsNAVint


    Shared Function AllowHost(CFPROID As String) As Boolean
        Dim host As String = HttpContext.Current.Request.Url.Host

        If host.Contains("cfproonline") Then
            If CFPROID = "CFPR000000273-46" Then
                Return True

            ElseIf CFPROID = "CFPR000000065-29" Then
                Return True

            Else
                Return False

            End If
        Else
            Return True
        End If




    End Function

    Shared Sub UpdateNAVCustomer(CFPROID As String, drow As DataRow, ByRef ErrMsg As String)
        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CFPROID, ErrMsg)

            If Trim(drow("Country")) = "" Then
                drow("Country") = "KE"
            End If


            DynamicsNAVInt1.CreateUpdateCustomer(drow("ClientID"), drow("Client"), drow("Box"), drow("Town"), drow("Telephone"), drow("Country"), drow("Email"), CFPROID)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Customer Integration Error"
            ErrMsg = ErrMsg & " " & ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Sub UpdateNAVCustomer1(CFPROID As String, ClientID As String, ByRef ErrMsg As String)
        Try
            Dim sqlstr As String = _
                "Select ClientID, Client," & _
                "Box,Telephone,Email," & _
                "Town,Country, ID " & _
                "From  Clients " & _
                "Where ClientID = '" & ClientID & "' " & _
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)

                If Trim(drow("Country")) = "" Then
                    drow("Country") = "KE"
                End If

                If drow("Country") = "(Select Country)" Then
                    drow("Country") = "KE"
                End If

                Call UpdateNAVCustomer(CFPROID, drow, ErrMsg)

            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Customer Integration Error"
            ' ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub
    Shared Sub UpdateNAVVendor(CFPROID As String, Prefix As String, VendorID As String,
                               Vendor As String, Address As String, Town As String, Telephone As String, CountryCode As String, Email As String, ByRef ErrMsg As String)
        Try
            ErrMsg = ""

            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CFPROID, ErrMsg)

            If Trim(CountryCode) = "" Then
                CountryCode = "KE"
            End If

            If Trim(CountryCode) = "(Select Country)" Then
                CountryCode = "KE"
            End If


            DynamicsNAVInt1.CreateUpdateVendor(Prefix & VendorID, Vendor, Address, Town, Telephone, CountryCode, Email, "-", CFPROID)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Vendor Integration Error"
            'ErrMsg = ErrMsg & " " & ex.Message & ex.StackTrace
        End Try

    End Sub




    Shared Sub UpdateNAVSalesman(CFPROID As String, SalesmanID As String,
                             Salesman As String, Telephone As String, Email As String, ByRef ErrMsg As String)

        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CFPROID, ErrMsg)

            DynamicsNAVInt1.CreateUpdateSalesPerson(SalesmanID, Salesman, Telephone, Email)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Sales Perosn Integration Error"
        End Try
    End Sub


    Shared Sub DeleteNAVSalesman(CFPROID As String, SalesmanID As String, ByRef ErrMsg As String)

        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CFPROID, ErrMsg)

            DynamicsNAVInt1.DeleteSalesPerson(SalesmanID)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Sales Perosn Integration Error"
        End Try
    End Sub

    Shared Sub UpdateNAVInvoiceHeader(CFPROID As String, InvoiceID As String,
                                               JobID As String, CompanyID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If


            Dim sqlstr As String =
                   "Select JobInvoiceHeader.JobID, CompanyID," &
                   "InvoiceID,ClientID," &
                   "JobDate, JobInvoiceHeader.InvoiceNo,  " &
                   "InvoiceDate, Cost, Total, " &
                   "Paid, Balance, SubTotal, VAT," &
                   "InvoiceParticulars, ApplyVAT," &
                   "VATinclusive, UserID,SalesmanID," &
                   "CurrencyID, InvoiceHeader," &
                   "InvoiceDueDate, VATAmount," &
                   "CurrencyRate,ReferenceNo," &
                   "InvoicetypeID, JobInvoiceHeader.ID " &
                   "FROM JobInvoiceHeader,Jobs " &
                   "Where InvoiceID ='" & InvoiceID & "' " &
                   "And JobInvoiceHeader.JobID ='" & JobID & "'" &
                   "And Jobs.JobID ='" & JobID & "'" &
                   "And JobInvoiceHeader.CFPROID ='" & CFPROID & "' " &
                   "And Jobs.CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                Call UpdateNAVCustomer1(CFPROID, drow("ClientID"), ErrMsg)



                Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CompanyID, ErrMsg)

                Dim InvoicedateDue As String = Format(CDate(drow("InvoiceDate")).AddMonths(1), "MMddyyyy")
                Dim Invoicedate As String = Format(drow("InvoiceDate"), "MMddyyyy")



                Dim CurrencyCode As String = ""
                Dim tmpstr() As String = clsAccounts.GetLocalCurrency(CFPROID)
                ReDim Preserve tmpstr(2)

                If tmpstr(2) <> drow("CurrencyID") Then
                    Dim tmpstr1() As String = clsAccounts.GetCUrrencyNameandCode(drow("CurrencyID"))
                    ReDim Preserve tmpstr1(0)
                    CurrencyCode = tmpstr1(0)
                End If


                DynamicsNAVInt1.CreateUpdateSalesInvoiceHeader(drow("ClientID"), InvoiceID,
                                                                            Invoicedate, InvoicedateDue, CurrencyCode, drow("InvoiceNo"),
                                                                             drow("ReferenceNo"), drow("SalesmanID"), CFPROID)
                DynamicsNAVInt1.Close()


                Call clsMSDynamicsNAVint.UpdateNAVInvoiceItems(CFPROID, InvoiceID, JobID, CompanyID, ErrMsg)


            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Invoice Header Integration Error"
            ' ErrMsg = ErrMsg & " " & ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Function NAVInvoiceisPosted(CFPROID As String, InvoiceID As String,
                                               JobID As String, CompanyID As String, Optional ByRef Reply As String = Nothing, Optional ByRef ErrMsg As String = Nothing) As Boolean
        Try

            If AllowHost(CFPROID) Then
                GoTo checkposted
            Else
                Return False
            End If


checkposted:

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CompanyID, ErrMsg)
            Reply = DynamicsNAVInt1.CheckifInvoiceCompleted(InvoiceID)

            If Reply = "Posted" Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Invoice Header Integration Error"
            ' ErrMsg = ErrMsg & " " & ex.Message & ex.StackTrace
        End Try
    End Function


    Shared Sub UpdateNAVInvoiceItems(CFPROID As String, InvoiceID As String, JobID As String, CompanyID As String, Optional ByRef ErrMsg As String = Nothing)
        Try

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CompanyID, ErrMsg)



            Dim sqlstr As String =
             "SELECT JobInvoiceItems.ItemID, Item," &
             "Cost,CostRate,ExchangeRate,SaleRate," &
             "Quantity, JobInvoiceItems.Amount," &
             "JobInvoiceItems.ApplyTax, " &
             "JobInvoiceItems.TaxPercent," &
             "TaxAmount, JobInvoiceItems.TaxType," &
             "Total,InvoiceID,VendorID," &
             "VendorType,VendorInvoiceNo,JobInvoiceItems.ID  " &
             "FROM  InvoiceItems, JobInvoiceItems " &
             "Where InvoiceID = '" & InvoiceID & "' " &
             "And JobInvoiceItems.JobID = '" & JobID & "' " &
             "And JobInvoiceItems.CFPROID = '" & CFPROID & "' " &
             "And InvoiceItems.CFPROID ='" & CFPROID & "' " &
             "And JobInvoiceItems.ItemID = InvoiceItems.ItemID " &
             "And JobInvoiceItems.CFPROID = InvoiceItems.CFPROID " &
             "Order By JobInvoiceItems.ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            Dim drow As DataRow


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                If drow("VendorID") = "" Then
                    drow("VendorID") = "-"
                End If

                Dim Pref As String = ""
                If drow("VendorType") = "supplier" Then
                    Call UpdateNAVSupplierVendor(CFPROID, drow("VendorID"))
                    Pref = "V-"

                ElseIf drow("VendorType") = "transporter" Then
                    Call UpdateNAVTransporterVendor(CFPROID, drow("VendorID"))
                    Pref = "T-"

                ElseIf drow("VendorType") = "shippingline" Then
                    Call UpdateNAVShippingLineVendor(CFPROID, drow("VendorID"))
                    Pref = "S-"

                ElseIf drow("VendorType") = "cfs" Then
                    Call UpdateNAVCFSVendor(CFPROID, drow("VendorID"))
                    Pref = "C-"

                End If


                Dim Cost As Double = drow("CostRate") * drow("ExchangeRate")

                DynamicsNAVInt1.CreateUpdateSalesInvoiceLines(InvoiceID, drow("ID"),
                    drow("ItemID"), drow("Item"), drow("Quantity"), drow("SaleRate"), Pref & drow("VendorID"), Cost, drow("VendorInvoiceNo"), CFPROID)

                a = a + 1
            Next


            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Invoice Item Integration Error"
            ErrMsg = ErrMsg & " " & ex.Message & ex.StackTrace
        End Try

    End Sub
    Shared Sub UpdateNAVTransporterVendor(CFPROID As String, TransporterID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            Dim sqlstr As String =
                "Select TransporterID, Transporter," &
                "Box,Telephone,Email," &
                "Town,Country, ID " &
                "From  Transporters " &
                "Where TransporterID = '" & TransporterID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)

                If Trim(drow("Country")) = "" Then
                    drow("Country") = "KE"
                End If

                Call UpdateNAVVendor(CFPROID, "T-", drow("TransporterID"), drow("Transporter"), drow("Box"),
                                                         drow("Town"), drow("Telephone"), drow("Country"), drow("Email"), ErrMsg)

            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Transporter Vendor Integration Error"
            ' ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Sub UpdateNAVSupplierVendor(CFPROID As String, SupplierID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            Dim sqlstr As String =
                "Select SupplierID, Supplier," &
                "Box,Telephone,Email," &
                "Town,Country, ID " &
                "From  Suppliers " &
                "Where SupplierID = '" & SupplierID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)

                If Trim(drow("Country")) = "" Then
                    drow("Country") = "KE"
                End If

                Call UpdateNAVVendor(CFPROID, "V-", drow("SupplierID"), drow("Supplier"), drow("Box"),
                                                         drow("Town"), drow("Telephone"), drow("Country"), drow("Email"), ErrMsg)

            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Supplier Vendor Integration Error"
            ' ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub


    Shared Sub UpdateNAVShippingLineVendor(CFPROID As String, ShippingLineID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            Dim sqlstr As String =
                "Select ShippingLineID, ShippingLine, ID " &
                 "From  ShippingLines " &
                "Where ShippingLineID = '" & ShippingLineID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)


                Call UpdateNAVVendor(CFPROID, "S-", drow("ShippingLineID"), drow("ShippingLine"), "", "",
                                                         "", "KE", "", ErrMsg)

            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV ShippingLine Vendor Integration Error"
            ' ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Sub UpdateNAVCFSVendor(CFPROID As String, CFSID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            Dim sqlstr As String =
                "Select CFS, CFS, ID " &
                "From  CFS " &
                "Where CFSID = '" & CFSID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)


                Call UpdateNAVVendor(CFPROID, "C-", drow("CFSID"), drow("CFS"), "", "",
                                                         "", "KE", "", ErrMsg)

            End If

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV CFS Vendor Integration Error"
            ' ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub
    Shared Sub DeleteNAVInvoice(CFPROID As String, InvoiceID As String, CompanyID As String, Optional ByRef ErrMsg As String = Nothing)
        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CompanyID, ErrMsg)

            DynamicsNAVInt1.DeleteInvoiceHeader(InvoiceID)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Delete Invoice Integration Error"
            'ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub


    Shared Sub DeleteNAVInvoiceItem(CFPROID As String, InvoiceID As String, CompanyID As String, ItemLineNo As Integer, Optional ByRef ErrMsg As String = Nothing)
        Try
            If Not AllowHost(CFPROID) Then
                Exit Sub
            End If

            Dim DynamicsNAVInt1 As DynamicsNAVInt.CFPROINTERGRATION_PortClient = nDynamicsNAVInt(CFPROID, CompanyID, ErrMsg)

            DynamicsNAVInt1.DeleteInvoiceLines(InvoiceID, ItemLineNo)
            DynamicsNAVInt1.Close()

        Catch ex As Exception
            ErrMsg = "MS Dynamics NAV Invoice Integration Error"
            'ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Function MSDNAvEndPoint(CFPROID As String, CompanyID As String) As String()

        Dim sqlstr As String =
                   "SELECT CompanyID, DynamicsNAVUrl, " &
                   "CFPROID,UserName,Password, ID " &
                   "FROM DynamicsNAVUrls " &
                   "Where  CompanyID='" & CompanyID & "' " &
                   "And CFPROID= '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr(2) As String

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            tmpstr(0) = drow("DynamicsNAVUrl")
            tmpstr(1) = drow("UserName")
            tmpstr(2) = clsEncr.DecryptString(drow("Password"))
        End If

        Return tmpstr

    End Function

    Shared Function nDynamicsNAVInt(CFPROID As String, CompanyID As String, ByRef ErrMsg As String) As DynamicsNAVInt.CFPROINTERGRATION_PortClient
        Try

            Dim tmpstr() As String = MSDNAvEndPoint(CFPROID, CFPROID)
            ReDim Preserve tmpstr(2)

            If Not Trim(tmpstr(0)) = "" Then
                Dim DynamicsNAVInt1 As New DynamicsNAVInt.CFPROINTERGRATION_PortClient("CFPROINTERGRATION_Port", tmpstr(0))

                With DynamicsNAVInt1.ClientCredentials.Windows
                    .ClientCredential.UserName = tmpstr(1)
                    .ClientCredential.Password = tmpstr(2)
                    .AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation
                End With

                Return DynamicsNAVInt1
            Else
                Return Nothing
            End If
        Catch ex As Exception
            ErrMsg = ErrMsg = "MS Dynamics NAV Endpoint Error"
            Return Nothing
        End Try
    End Function
End Class
