﻿


Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf

Public Class clsJobProgressStatusPDF

    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.SetLineWidth(0.001)
        contentByte.SetRGBColorStroke(130, 130, 130)
        contentByte.Stroke()
    End Sub

    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - (y1 + height))
        contentByte.LineTo(x1, 595 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 595 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Function JobProgressStatus(JobID As String, CFPROID As String, ByRef nProgressReportPath As String, Optional ByRef ErrMsg As String = Nothing) As String
        Try



            Dim ProgressReportsDv As New DataView()
            Dim ProgressCargoDv As New DataView()
            Dim ProgressDv As New DataView()

            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)


            Dim font6b As New Font(customfontb, 6)
            Dim font7b As New Font(customfontb, 7.4)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfontb, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            Dim font11c As New Font(customfontc, 10.5)
            Dim font10b As New Font(customfontb, 10)
            Dim font16a As New Font(customfont, 16)
            Dim font16b As New Font(customfontb, 16)

            Dim drf As New Drawing.StringFormat()

            Dim brush1 As Drawing.Color = Drawing.Color.Black
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)



            Dim ProgressReportPDF As New Document(PageSize.A4.Rotate(), 0, 0, 0, 10)


            Using memoryStream As New System.IO.MemoryStream()
                Dim PDFwriter As PdfWriter = PDFwriter.GetInstance(ProgressReportPDF, memoryStream)
                ProgressReportPDF.Open()


                'Create line pens
                Dim pen As PdfContentByte = PDFwriter.DirectContent


                Static d, f, g, pages, pages1 As Integer
                Dim a, b, c As Integer

                c = 0
                Dim sqlstr1 As String =
                   "Select JobId,ReferenceNo," &
                   "JobDate,ClientID,ImporterID," &
                   "BL,JobStatus," &
                   "BLCountry,EntryNo," &
                   "Goods,VesselID,CFSID," &
                   "DispatchDate,ShipStatus," &
                   "OrderNo,ManifestNo,ID " &
                   "From Jobs " &
                   "Where CFPROID = '" & CFPROID & "' " &
                   "And JobID ='" & JobID & "' "


                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
                ProgressReportsDv = New DataView(tmptable1)

                Dim col1 As New DataColumn("Client", Type.GetType("System.String"))
                Dim col2 As New DataColumn("Importer", Type.GetType("System.String"))
                Dim col3 As New DataColumn("CFS", Type.GetType("System.String"))
                Dim col4 As New DataColumn("DaysTaken", Type.GetType("System.String"))
                Dim col5 As New DataColumn("Vessel", Type.GetType("System.String"))
                Dim col6 As New DataColumn("VoyageNo", Type.GetType("System.String"))
                Dim col7 As New DataColumn("VesselETA", Type.GetType("System.String"))
                Dim col8 As New DataColumn("BerthingDate", Type.GetType("System.String"))


                tmptable1.Columns.Add(col1)
                tmptable1.Columns.Add(col2)
                tmptable1.Columns.Add(col3)
                tmptable1.Columns.Add(col4)
                tmptable1.Columns.Add(col5)
                tmptable1.Columns.Add(col6)
                tmptable1.Columns.Add(col7)
                tmptable1.Columns.Add(col8)

                Dim sqlstr2 As String =
                     "Select CFS,CFSID " &
                     "From CFS " &
                     "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable2 As New DataTable()
                Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
                Dim dv2 As New DataView(tmptable2)


                Dim sqlstr3 As String =
                           "Select Vessel,VoyageNo," &
                           "VesselID, ETA," &
                           "BerthingDate, ExitDate  " &
                           "From ShippingVessels " &
                           "Where CFPROID = '" & CFPROID & "' "
                Dim tmptable3 As New DataTable()
                Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
                Dim dv3 As New DataView(tmptable3)


                Dim sqlstr4 As String =
                        "Select ClientID, Client " &
                         "From Clients " &
                         "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable4 As New DataTable()
                Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                Dim dv4 As New DataView(tmptable4)


                Dim sqlstr5 As String =
                     "Select ImporterID, Importer " &
                      "From Importers " &
                      "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable5 As New DataTable()
                Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
                Dim dv5 As New DataView(tmptable5)



                Dim sqlstr7 As String =
                "Select JobId,Status," &
                "ReportedBy,Date," &
                "RecordStatus," &
                "UserID,JobStatus,ID " &
                "From JobProgress " &
                "Where CFPROID = '" & CFPROID & "' " &
                "And JobID = '" & JobID & "' " &
                "Order By Date Desc;"
                Dim tmptable7 As New DataTable()
                Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
                ProgressDv = New DataView(tmptable7)



                Dim sqlstr8 As String = "Select JobId,ContainerNo," &
                "Weight,VehicleNo," &
                "Driver,Tonnage," &
                "PortExitDate,CrossBorderDate," &
                "ContainerStatus," &
                "Payload,ID " &
                "From JobCargo " &
                "Where CFPROID = '" & CFPROID & "' " &
                "And JobId = '" & JobID & "' "


                Dim tmptable8 As New DataTable()
                Call clsData.TableData(sqlstr8, tmptable8, clsData.constr)
                ProgressCargoDv = New DataView(tmptable8)


                Dim sqlstr9 As String =
                    "Select CFAgentName,CFAgentAddress,LogoURL,ID " &
                    "From CFPROAccounts " &
                    "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable9 As New DataTable()
                Call clsData.TableData(sqlstr9, tmptable9, clsData.constr)



                Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

                Dim pageLimit As Integer = 100
                Dim sectionBCount As Integer = 0
                Dim sectionCCount As Integer = 0
                Dim proceedB As Boolean = True
                Dim proceedC As Boolean = True

                Dim nCFAgent As String
                Dim nClient As String
                Dim nReferenceNo As String

                For a = 0 To ProgressReportsDv.Count - 1
                    Call clsData.NullChecker1(ProgressReportsDv, a)



                    dv2.RowFilter = "CFSID = '" & ProgressReportsDv(a)("CFSID") & "'"

                    If dv2.Count > 0 Then
                        Call clsData.NullChecker1(dv2, 0)
                        ProgressReportsDv(a)("CFS") = dv2(0)("CFS")
                    End If


                    dv3.RowFilter = "VesselID = '" & ProgressReportsDv(a)("VesselID") & "'"

                    If dv3.Count > 0 Then
                        Call clsData.NullChecker1(dv3, 0)
                        ProgressReportsDv(a)("Vessel") = dv3(0)("Vessel")
                        ProgressReportsDv(a)("VoyageNo") = dv3(0)("VoyageNo")
                        ProgressReportsDv(a)("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                        ProgressReportsDv(a)("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                        ProgressReportsDv(a)("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), ProgressReportsDv(a)("DispatchDate")).ToString
                    End If


                    dv4.RowFilter = "ClientID = '" & ProgressReportsDv(a)("ClientID") & "'"

                    If dv4.Count > 0 Then
                        Call clsData.NullChecker1(dv4, 0)
                        ProgressReportsDv(a)("Client") = dv4(0)("Client")
                        nClient = dv4(0)("Client")
                    End If


                    dv5.RowFilter = "ImporterID = '" & ProgressReportsDv(a)("ImporterID") & "'"

                    If dv5.Count > 0 Then
                        Call clsData.NullChecker1(dv5, 0)
                        ProgressReportsDv(a)("Importer") = dv5(0)("Importer")
                    End If

                    For pageCount As Integer = 0 To pageLimit Step 1
                        If tmptable9.Rows.Count > 0 Then
                            Dim drow9 As DataRow = tmptable9.Rows(0)
                            Call clsData.NullChecker(tmptable9, 0)

                            Dim logopath As String = ""
                            Dim cfagentlogo As String
                            nCFAgent = drow9("CFAgentName")

                            Dim files() As String = Directory.GetFiles(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\")
                            Dim nfile As String = ""


                            For Each nfile In files
                                cfagentlogo = Path.GetFileName(nfile)
                                If InStr(cfagentlogo, CFPROID, CompareMethod.Text) > 0 Then
                                    logopath = nfile
                                    Exit For
                                End If
                            Next


                            If logopath = "" Then
                                logopath = HttpContext.Current.Server.MapPath(".") & "\companyplaceholder.png"
                            End If


                            Dim logo As Image = Image.GetInstance(logopath)
                            logo.ScaleToFit((logo.Width * 60 / logo.Height), 60)
                            logo.SetAbsolutePosition(25, 520)
                            ProgressReportPDF.Add(logo)



                            Dim ct As New ColumnText(StringWriter)
                            ct.SetSimpleColumn(25, 550, 820, 50, 5, Element.ALIGN_RIGHT)
                            ct.AddText(New Paragraph(drow9("CFAgentName"), font16a))
                            ct.Go()

                            Dim Ct1 As New ColumnText(StringWriter)
                            Ct1.SetSimpleColumn(25, 536, 820, 50, 5, Element.ALIGN_RIGHT)
                            Ct1.AddText(New Paragraph(drow9("CFAgentAddress"), font7))
                            Ct1.Go()

                        End If

                        '#Region "Section A"
                        If pageCount = 0 Then
                            DrawString("DAILY CARGO STATUS REPORT", font16b, brush1, 32, 120, StringWriter)
                            DrawString("Report Date:" & " " & Format(Now, "dd MMM yyyy hh:mm tt"), font8i, Drawing.Color.Black, 35, 145, StringWriter)

                            Call clsData.NullChecker1(ProgressReportsDv, a)

                            DrawString("Reference No:", font6b, brush1, 30, 180, StringWriter)
                            DrawString(ProgressReportsDv(a)("ReferenceNo"), font8b, brush1, 30, 190, StringWriter)
                            nReferenceNo = ProgressReportsDv(a)("ReferenceNo")

                            DrawString("Client:", font6b, brush1, 30, 220, StringWriter)
                            DrawString(ProgressReportsDv(a)("Client"), font8, brush1, 30, 230, StringWriter)

                            DrawString("Consignee:", font6b, brush1, 30, 260, StringWriter)
                            DrawString(ProgressReportsDv(a)("Importer"), font8, brush1, 30, 270, StringWriter)

                            DrawString("Days Taken:", font6b, brush1, 30, 300, StringWriter)
                            DrawString(ProgressReportsDv(a)("DaysTaken"), font8, brush1, 30, 310, StringWriter)

                            DrawString("Order No:", font6b, brush1, 170, 300, StringWriter)
                            DrawString(ProgressReportsDv(a)("OrderNo"), font8, brush1, 170, 310, StringWriter)

                            DrawString("Job Date:", font6b, brush1, 520, 180, StringWriter)
                            If Not CDate(ProgressReportsDv(a)("JobDate")) = CDate("1/Jan/1800") Then
                                DrawString(Format(ProgressReportsDv(a)("JobDate"), "dd MMM yyyy"), font8, brush1, 520, 190, StringWriter)
                            End If

                            DrawString("Vessel ETA:", font6b, brush1, 360, 180, StringWriter)
                            If Not Trim(ProgressReportsDv(a)("VesselETA")) = "" Then
                                DrawString(ProgressReportsDv(a)("VesselETA"), font8, brush1, 360, 190, StringWriter)
                            End If

                            DrawString("Vessel:", font6b, brush1, 360, 220, StringWriter)
                            DrawString(Mid(ProgressReportsDv(a)("Vessel"), 1, 20), font8, brush1, 360, 230, StringWriter)

                            DrawString("Origin:", font6b, brush1, 520, 220, StringWriter)
                            DrawString(ProgressReportsDv(a)("BLCountry"), font8, brush1, 520, 230, StringWriter)


                            DrawString("Vessel Status:", font6b, brush1, 360, 260, StringWriter)
                            DrawString(ProgressReportsDv(a)("ShipStatus"), font8, brush1, 360, 270, StringWriter)

                            DrawString("Entry No:", font6b, brush1, 520, 260, StringWriter)
                            DrawString(ProgressReportsDv(a)("EntryNo"), font8, brush1, 520, 270, StringWriter)

                            DrawString("Bill of Lading:", font6b, brush1, 360, 300, StringWriter)
                            DrawString(ProgressReportsDv(a)("BL"), font8, brush1, 360, 310, StringWriter)

                            DrawString("Manifest No:", font6b, brush1, 520, 300, StringWriter)
                            DrawString(ProgressReportsDv(a)("ManifestNo"), font8, brush1, 520, 310, StringWriter)



                            DrawString("Description of Goods:", font6b, brush1, 30, 340, StringWriter)
                            Dim ct1 As ColumnText = New ColumnText(StringWriter)
                            ct1.SetSimpleColumn(23, 85, 380, 337)
                            ct1.AddElement(New Paragraph(ProgressReportsDv(a)("Goods"), font8))
                            ct1.Go()

                            DrawString("CFS:", font6b, brush1, 520, 340, StringWriter)
                            DrawString(ProgressReportsDv(a)("CFS"), font8, brush1, 520, 350, StringWriter)

                            DrawLine(pen, 30, 175, 650, 175)
                            DrawLine(pen, 30, 215, 650, 215)
                            DrawLine(pen, 350, 255, 650, 255)
                            DrawLine(pen, 30, 295, 650, 295)
                            DrawLine(pen, 30, 335, 650, 335)
                            DrawLine(pen, 30, 404, 650, 404)


                            DrawLine(pen, 165, 295, 165, 335)
                            DrawLine(pen, 350, 175, 350, 335)
                            DrawLine(pen, 510, 175, 510, 335)
                            ' DrawLine(pen, 510, 255, 510, 335)

                            ' DrawLine(pen, 510, 375, 650, 375)
                        End If
                        '#End Region

                        '#Region "Section B"


                        Dim ypoint, ypoint1, ypoint2 As Integer
                        If pageCount = 0 Then
                            ypoint = 412
                            ypoint1 = 438
                            ypoint2 = 466
                        Else
                            ypoint = 139
                            ypoint1 = 168
                            ypoint2 = 166
                        End If

                        If proceedB Then

                            DrawString("CARGO INFORMATION:", font9b, brush1, 30, ypoint, StringWriter)
                            If pageCount = 0 Then
                                DrawLine(pen, 30, 430, 650, 430)
                                DrawLine(pen, 30, 455, 650, 455)
                            Else
                                DrawLine(pen, 30, 125, 650, 125)
                                DrawLine(pen, 30, 150, 650, 150)
                                DrawLine(pen, 30, 175, 650, 175)
                            End If


                            DrawString("Container No.", font8b, brush1, 55, ypoint1, StringWriter)
                            DrawString("Weight", font8b, brush1, 220, ypoint1, StringWriter)
                            DrawString("Payload", font8b, brush1, 320, ypoint1, StringWriter)
                            DrawString("VehicleNo", font8b, brush1, 420, ypoint1, StringWriter)


                            DrawLine(pen, 30, 765, 650, 765)

                            Dim crossborder As Boolean
                            If Not Trim(ProgressReportsDv(a)("JobStatus")) = "Crossed Border" Then
                                DrawString("Port Exit Date", font8b, brush1, 560, ypoint1, StringWriter)
                                crossborder = False
                            Else
                                crossborder = True
                                DrawString("Crossed Border", font8b, brush1, 560, ypoint1, StringWriter)
                            End If

                            ProgressCargoDv.RowFilter = "JobId = " & "'" & ProgressReportsDv(a)("JobId") & "'"
                            b = 0

                            For c = 0 To ProgressCargoDv.Count - 1
                                If c >= f Then
                                    Call clsData.NullChecker1(ProgressCargoDv, c)
                                    DrawString(c + 1 & ".", font8, brush1, 30, (b * 25) + ypoint2, StringWriter)
                                    DrawString(ProgressCargoDv(c)("ContainerNo"), font8, brush1, 55, (b * 25) + ypoint2, StringWriter)
                                    DrawString(Format(ProgressCargoDv(c)("Weight"), "#,###.#0"), font8, brush1, 220, (b * 25) + ypoint2, StringWriter)
                                    DrawString(ProgressCargoDv(c)("Payload"), font8, brush1, 320, (b * 25) + ypoint2, StringWriter)
                                    DrawString(ProgressCargoDv(c)("VehicleNo"), font8, brush1, 420, (b * 25) + ypoint2, StringWriter)

                                    If Not crossborder Then
                                        If Not CDate(ProgressCargoDv(c)("PortExitDate")) = CDate("1/Jan/1800") Then
                                            DrawString(Format(ProgressCargoDv(c)("PortExitDate"), "dd MMM yyyy"), font8, brush1, 560, (b * 25) + ypoint2, StringWriter)
                                        End If

                                    Else
                                        If Not CDate(ProgressCargoDv(c)("CrossBorderDate")) = CDate("1/Jan/1800") Then
                                            DrawString(Format(ProgressCargoDv(c)("CrossBorderDate"), "dd MMM yyyy"), font8, brush1, 560, (b * 25) + ypoint2, StringWriter)
                                        End If
                                    End If

                                    b = b + 1
                                    f = f + 1

                                    If b = 12 Then
                                        If ProgressCargoDv.Count > b Then
                                            proceedB = True
                                            sectionBCount = b
                                            Exit For
                                        Else
                                            proceedB = False
                                        End If
                                        'ProgressReportPDF.NewPage()
                                    Else
                                        proceedB = False
                                    End If
                                End If

                            Next

                            If pageCount > 0 Then
                                If b > 0 And b < 5 Then
                                    DrawLine(pen, 30, (b * 25) + ypoint2, 650, (b * 25) + ypoint2)
                                End If
                            ElseIf pageCount > 1 Then
                                If b > 0 And b < 5 Then
                                    DrawLine(pen, 30, (b * 25) + ypoint2, 650, (b * 25) + ypoint2)
                                End If
                            End If

                            DrawLine(pen, 665, 125, 1100, 125)

                        End If
                        '#End Region

                        '#Region "Section C"

                        If proceedC Then
                            DrawString("STATUS UPDATES:", font9b, brush1, 700, 135, StringWriter)
                            DrawLine(pen, 665, 155, 1100, 155)
                            DrawLine(pen, 665, 765, 1100, 765)

                            b = 0

                            ProgressDv.RowFilter = "JobId = " & "'" & ProgressReportsDv(a)("JobId") & "'"

                            DrawLine(pen, 690, 125, 690, 765)

                            Dim ct2 As ColumnText
                            Dim ct3 As ColumnText
                            Dim ct4 As ColumnText
                            For c = 0 To ProgressDv.Count - 1
                                If c >= g Then
                                    Call clsData.NullChecker1(ProgressDv, c)
                                    'DrawString(c + 1 & ".", font7, brush1, 668, (b * 29) + 163, StringWriter)
                                    'DrawString(Format(ProgressDv(c)("Date"), "dd MMM yyyy") & "  - ", font7b, brush1, 700, (b * 20) + 163, StringWriter)

                                    ct2 = New ColumnText(StringWriter)
                                    ct2.SetSimpleColumn(500, 25, 825, 475 - (b * 23))
                                    ct2.AddElement(New Paragraph(c + 1 & ".", font7b))
                                    ct2.Go()

                                    ct3 = New ColumnText(StringWriter)
                                    ct3.SetSimpleColumn(525, 25, 825, 475 - (b * 23))
                                    ct3.AddElement(New Paragraph(Format(ProgressDv(c)("Date"), "dd MMM yyyy") & "  - ", font7b))
                                    ct3.Go()

                                    ct4 = New ColumnText(StringWriter)
                                    ct4.SetSimpleColumn(582, 25, 825, 475 - (b * 23), 1, Element.ALIGN_LEFT)
                                    ct4.AddElement(New Paragraph(ProgressDv(c)("Status"), font7))
                                    ct4.Go()


                                    b = b + 1
                                    g = g + 1

                                    If b = 18 Then
                                        If ProgressDv.Count > b Then
                                            proceedC = True
                                            sectionCCount = b
                                            Exit For
                                        Else
                                            proceedC = False
                                        End If
                                        'ProgressReportPDF.NewPage()
                                    Else
                                        proceedC = False
                                    End If
                                End If

                            Next

                        End If
                        '#End Region


                        DrawString("Page " & pageCount + 1, font8i, brush1, 1065, 772, StringWriter)
                        If proceedB = False And proceedC = False Then
                            Exit For
                        ElseIf proceedB = True Or proceedC = True Then
                            ProgressReportPDF.NewPage()
                        End If
                    Next
                    '#End Region
                    b = c = d = f = g = pages = pages1 = sectionBCount = sectionCCount = 0
                    proceedB = proceedC = True

                    ProgressReportPDF.NewPage()
                Next

                pages = 0
                pages1 = 0
                d = 0
                f = 0
                g = 0


                ProgressReportPDF.AddTitle(nCFAgent & " | " & nClient)
                ProgressReportPDF.AddSubject("Progress Status Report | Job Ref No: " & nReferenceNo)
                ProgressReportPDF.AddAuthor("Gamonki")
                ProgressReportPDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")

                ProgressReportPDF.Close()
                Dim bytes As Byte() = memoryStream.ToArray()



                Dim ProgressReportPath As String = HttpContext.Current.Server.MapPath(".") & "\progressreports"
                If Not Directory.Exists(ProgressReportPath) Then
                    Directory.CreateDirectory(ProgressReportPath)
                End If

                If Not Directory.Exists(ProgressReportPath & "\" & CFPROID) Then
                    Directory.CreateDirectory(ProgressReportPath & "\" & CFPROID)
                End If


                Dim ProgressPDFReport As String = ProgressReportPath & "\" & CFPROID & "\" & JobID & ".pdf"


                If File.Exists(ProgressPDFReport) Then
                    File.Delete(ProgressPDFReport)
                End If


                ' Write out PDF from memory stream. 
                Using fs As FileStream = File.Create(ProgressPDFReport)
                    fs.Write(bytes, 0, CInt(bytes.Length))
                End Using


                memoryStream.Close()

                nProgressReportPath = ProgressPDFReport
                Return "~/progressreports/" & CFPROID & "/" & JobID & ".pdf"

            End Using

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function


End Class


