﻿

Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf

Public Class clsJobPDF

    Friend Progresstmpdate1 As DateTime
    Friend Progresstmpdate2 As DateTime
    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75

        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub RightAligned(txt As String, sw As PdfContentByte, rect As Rectangle, fnt As Font)

        Dim ct As ColumnText = New ColumnText(sw)
        ct.SetSimpleColumn(rect)
        'ct.Alignment = HorizontalAlign.Right
        Dim par As New Paragraph(txt, fnt)
        par.Alignment = Element.ALIGN_RIGHT
        ct.AddElement(par)
        ct.Go()
    End Sub

    Private Shared Sub RightAligned1(txt As String, sw As PdfContentByte, rect As Rectangle, fnt As Font)

        Dim ct As ColumnText = New ColumnText(sw)
        ct.SetSimpleColumn(rect)
        'ct.Alignment = HorizontalAlign.Right
        Dim par As New Paragraph(txt, fnt)
        'par.Alignment = Element.ALIGN_RIGHT
        ct.AddElement(par)
        ct.Go()
    End Sub

    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single, lineWidth As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.SetLineWidth(lineWidth)
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - (y1 + height))
        contentByte.LineTo(x1, 595 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 595 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Function StandardVisibilityPDFReport(CFPROID As String, ByRef JobsTable As DataTable,
                                                Caption As String, FilterStr As String, SortStr As String,
                                                ByRef StandardVisibilityPDFPath As String, ByRef ErrMsg As String) As String
        Try


            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)


            Dim font6b As New Font(customfontb, 6)
            Dim font7b As New Font(customfontb, 7.4)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfont, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            Dim font11c As New Font(customfontc, 10.5)
            Dim font10b As New Font(customfontb, 10)
            Dim font12b As New Font(customfontb, 12)
            Dim font22 As New Font(customfontb, 16)

            Dim drf As New Drawing.StringFormat()


            Dim brush1 As Drawing.Color = Drawing.Color.Black
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)

            'Dim PDFReader As PdfReader = Nothing 'Read File

            ' Document starts here
            Dim logospath As String = ""

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".jpg") Then
                logospath = HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".jpg"
            ElseIf File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".png") Then
                logospath = HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".png"
            Else
                logospath = HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp"
            End If


            Dim logo As Image = Image.GetInstance(logospath)

            Dim nJobsPDFReport As New Document(PageSize.A4.Rotate(), 0, 0, 0, 10)


            'New FileStream(regdocpath, FileMode.Create)

            Using memoryStream As New System.IO.MemoryStream()
                Dim PDFwriter As PdfWriter = PDFwriter.GetInstance(nJobsPDFReport, memoryStream)
                nJobsPDFReport.Open()






                'Create line pens
                Dim pen As PdfContentByte = PDFwriter.DirectContent
                Dim pen1 As PdfContentByte = PDFwriter.DirectContent
                Dim pen2 As PdfContentByte = PDFwriter.DirectContent
                Dim pen3 As PdfContentByte = PDFwriter.DirectContent

                pen.SetRGBColorStroke(195, 195, 195)
                pen1.SetRGBColorStroke(195, 195, 195)
                pen2.SetRGBColorStroke(0, 0, 0)
                pen3.SetRGBColorStroke(0, 0, 0)

                pen.SetLineWidth(0)
                pen1.SetLineWidth(0.5)
                pen2.SetLineWidth(0.5)

                Static d, f As Integer
                Dim a, b As Integer

                Dim sqlstr As String = ""

                Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

                Dim pageLimit As Integer = 100
                Dim sectionBCount As Integer = 0
                Dim sectionCCount As Integer = 0
                Dim proceedB As Boolean = True
                Dim proceedC As Boolean = True
                ' Dim docfooterpath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp"


                logo.ScaleToFit((logo.Width * 60 / logo.Height), 60)
                logo.SetAbsolutePosition(25, 520)
                nJobsPDFReport.Add(logo)

                DrawLine(pen2, 30, 180, 1100, 180, 1)
                DrawLine(pen2, 30, 205, 1100, 205, 1)

                DrawString("STARDARD JOB VISIBILITY REPORT", font12b, brush1, 35, 120, StringWriter)

                DrawString(Format(Now, "dd MMM yyyy"), font8i, brush1, 1040, 120, StringWriter)
                DrawString(Caption, font8b, Drawing.Color.Black, 35, 145, StringWriter)




                DrawString("Ref No.", font8b, brush1, 75, 188, StringWriter)

                DrawString("Client", font8b, brush1, 225, 188, StringWriter)

                DrawString("Vessel", font8b, brush1, 380, 188, StringWriter)
                DrawString("Vess. ETA", font8b, brush1, 530, 188, StringWriter)



                DrawString("BL", font8b, brush1, 655, 188, StringWriter)
                ' DrawString("CFS", font8b, brush1, 830, 188, StringWriter)


                'Dim rect As Rectangle
                'rect = New Rectangle(757 * 0.75, 0.75 * 157, 0.75 * 820, 595 - 0.75 * 177)
                'Call RightAligned("R. Days", StringWriter, rect, font8b)

                'rect = New Rectangle(815 * 0.75, 0.75 * 157, 0.75 * 865, 595 - 0.75 * 177)
                'Call RightAligned("D.Taken", StringWriter, rect, font8b)

                'rect = New Rectangle(870 * 0.75, 0.75 * 157, 0.75 * 895, 595 - 0.75 * 177)
                'Call RightAligned("Qty", StringWriter, rect, font8b)

                DrawString("Latest Status", font8b, brush1, 800, 188, StringWriter)




                'rect = New Rectangle(1000 * 0.75, 595 - 0.75 * 760, 0.75 * 1100, 595 - 0.75 * 795)
                'Call RightAligned("Page " & f, StringWriter, rect, font8i)

                Dim dv As New DataView(JobsTable)

                dv.Sort = SortStr
                dv.RowFilter = FilterStr

                b = 0

                Dim totalpages As Integer = clsSubs.GetTotalPages(dv.Count, 20)
                Dim currentpage As Integer = 0

                For a = 0 To dv.Count - 1
                    If a >= d Then
                        Call clsData.NullChecker1(dv, a)

                        Dim tmpstr() As String = dv(a)("Client").ToString.Split(vbCrLf)
                        ReDim Preserve tmpstr(0)

                        DrawString(a + 1 & ".", font8, brush1, 40, (b * 25) + 215, StringWriter)
                        DrawString(Mid(dv(a)("ReferenceNo"), 1, 25), font8, brush1, 75, (b * 25) + 215, StringWriter)
                        DrawString(Mid(dv(a)("Client"), 1, 21), font8, brush1, 225, (b * 25) + 215, StringWriter)
                        DrawString(Mid(dv(a)("Vessel"), 1, 21), font8, brush1, 380, (b * 25) + 215, StringWriter)

                        If Not CDate(dv(a)("VesselETA")) = CDate("1-Jan-1800") Then
                            DrawString(Format(dv(a)("VesselETA"), "dd MMM yyyy"), font8, brush1, 530, (b * 25) + 215, StringWriter)
                        End If

                        DrawString(dv(a)("BL"), font8, brush1, 651, (b * 25) + 215, StringWriter)

                        'DrawString(Mid(dv(a)("CFS"), 1, 12), font8, brush1, 827, (b * 25) + 215, StringWriter)


                        'rect = New Rectangle(757 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 820, 595 - 0.75 * (b * 25 + 207))
                        'Call RightAligned("0", StringWriter, rect, font8)

                        ''DrawString(tmptbl(a)("RemDays"), font8, brush1, 765, (b * 25) + 215, StringWriter)

                        'rect = New Rectangle(820 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 865, 595 - 0.75 * (b * 25 + 207))
                        'Call RightAligned(dv(a)("DaysTaken"), StringWriter, rect, font8)

                        'rect = New Rectangle(870 * 0.75, 0.75 * (b * 25 + 187), 0.75 * 895, 595 - 0.75 * (b * 25 + 207))
                        'Call RightAligned("0", StringWriter, rect, font8)


                        'DrawString(tmptbl(a)("DaysTaken"), font8, brush1, 827, (b * 25) + 215, StringWriter)
                        'DrawString(Format(Val(tmptbl(a)("Qty")), "#,##0"), font8, brush1, 879, (b * 25) + 215, StringWriter)

                        ' DrawString(Mid(dv(a)("ProgressStatus"), 1, 102), font6b, brush1, 927, (b * 25) + 215, StringWriter)

                        '   Dim cb As PdfContentByte = PDFwriter.DirectContent
                        '   Dim ct As New ColumnText(cb)
                        '   ct.SetSimpleColumn(New Phrase(New Chunk(dv(a)("ProgressStatus").ToString, FontFactory.GetFont(FontFactory.HELVETICA, 8, Font.NORMAL))),
                        '746, 439, 700, 6, 10, Element.ALIGN_LEFT)
                        '   ct.Go()




                        Dim ct1 As ColumnText = New ColumnText(StringWriter)
                        ct1 = New ColumnText(StringWriter)
                        ct1.SetSimpleColumn(600, 25, 830, 437 - ((b * 25) * 0.75), 0.85, Element.ALIGN_LEFT)
                        ct1.AddElement(New Paragraph(Mid(dv(a)("ProgressStatus"), 1, 200), font6b))
                        ct1.Go()




                        b = b + 1
                        d = d + 1

                        If b >= 20 Then

                            currentpage = currentpage + 1
                            DrawLine(pen2, 30, (b * 25) + 218, 1100, (b * 25) + 218)
                            DrawString(currentpage & " of " & totalpages, font8, brush1, 1040, (b * 25) + 225, StringWriter)

                            b = 0

                            If d >= 20 Then

                                logo.ScaleToFit((logo.Width * 60 / logo.Height), 60)
                                logo.SetAbsolutePosition(25, 520)
                                nJobsPDFReport.Add(logo)

                                DrawLine(pen2, 30, 180, 1100, 180, 1)
                                DrawLine(pen2, 30, 205, 1100, 205, 1)
                                DrawString("STARDARD JOB VISIBILITY REPORT", font12b, brush1, 35, 120, StringWriter)

                                DrawString(Format(Now, "dd MMM yyyy"), font8i, brush1, 1040, 120, StringWriter)
                                DrawString(Caption, font8b, Drawing.Color.Black, 35, 145, StringWriter)

                                DrawString("Ref No.", font8b, brush1, 75, 188, StringWriter)

                                DrawString("Client", font8b, brush1, 225, 188, StringWriter)

                                DrawString("Vessel", font8b, brush1, 380, 188, StringWriter)
                                DrawString("Vess. ETA", font8b, brush1, 530, 188, StringWriter)



                                DrawString("BL", font8b, brush1, 655, 188, StringWriter)

                                'DrawString("CFS", font8b, brush1, 830, 188, StringWriter)

                                DrawString("Latest Status", font8b, brush1, 800, 188, StringWriter)
                            End If


                            nJobsPDFReport.NewPage()
                        End If

                    End If
                Next

                currentpage = currentpage + 1

                If currentpage > 1 Then
                    logo.ScaleToFit((logo.Width * 60 / logo.Height), 60)
                    logo.SetAbsolutePosition(25, 520)
                    nJobsPDFReport.Add(logo)

                    DrawLine(pen2, 30, 180, 1100, 180, 1)
                    DrawLine(pen2, 30, 205, 1100, 205, 1)

                    DrawString("STARDARD JOB VISIBILITY REPORT", font12b, brush1, 35, 120, StringWriter)

                    DrawString(Format(Now, "dd MMM yyyy"), font8i, brush1, 1040, 120, StringWriter)
                    DrawString(Caption, font8b, Drawing.Color.Black, 35, 145, StringWriter)

                    DrawString("Ref No.", font8b, brush1, 75, 188, StringWriter)

                    DrawString("Client", font8b, brush1, 225, 188, StringWriter)

                    DrawString("Vessel", font8b, brush1, 380, 188, StringWriter)
                    DrawString("Vess. ETA", font8b, brush1, 530, 188, StringWriter)


                    DrawString("BL", font8b, brush1, 655, 188, StringWriter)

                    DrawString("Latest Status", font8b, brush1, 800, 188, StringWriter)

                End If


                DrawLine(pen2, 30, (b * 25) + 218, 1100, (b * 25) + 218)
                DrawString(currentpage & " of " & totalpages, font8, brush1, 1040, (b * 25) + 225, StringWriter)

                'b = b + 1
                'DrawLine(StringWriter, 30, (b * 25) + 212, 1120, (b * 25) + 212)
                d = 0
                f = 0

                nJobsPDFReport.Close()




                Dim bytes As Byte() = memoryStream.ToArray()



                Dim StandardVisibilityDocPath As String = HttpContext.Current.Server.MapPath(".") & "\StandardVisibilityDocs"

                If Not Directory.Exists(StandardVisibilityDocPath) Then
                    Directory.CreateDirectory(StandardVisibilityDocPath)
                End If

                If Not Directory.Exists(StandardVisibilityDocPath & "\" & CFPROID) Then
                    Directory.CreateDirectory(StandardVisibilityDocPath & "\" & CFPROID)
                End If

                Dim JobPDFName As String = "Standard Visibility Report - " & Format(Now, "dd MMM yyyy")
                Dim StandardVisibilityPDF As String = StandardVisibilityDocPath & "\" & CFPROID & "\" & JobPDFName & ".pdf"


                If File.Exists(StandardVisibilityPDF) Then
                    File.Delete(StandardVisibilityPDF)
                End If


                ' Write out PDF from memory stream. 
                Using fs As FileStream = File.Create(StandardVisibilityPDF)
                    fs.Write(bytes, 0, CInt(bytes.Length))
                End Using


                memoryStream.Close()

                StandardVisibilityPDFPath = StandardVisibilityPDF

                Return "~/StandardVisibilityDocs/" & CFPROID & "/" & JobPDFName & ".pdf"

            End Using

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function



End Class
