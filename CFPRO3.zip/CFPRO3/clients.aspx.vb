﻿Imports System.Drawing

Public Class clients
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)

            End If


            Dim CFPROID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, "", LabelCFAgent.Text, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID

            Call clsSubs.CountryList(ComboCountry)
            Call LoadClients(CFPROID, 0, "")


        End If

    End Sub


    Private Sub LoadClients(CFPROID As String, Rowindex As Integer, SearchStr As String, Optional FilterIndex As Integer = 0)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Client  Like '%" & TextSearch.Text & "%' "
        End If

        If FilterIndex = 1 Then
            tmpstr = " And SendReports  = 1"
        End If

        Dim sqlstr As String =
              "Select ClientID, Client," &
              "Box,Telephone,Email," &
              "Town,Country," &
              "AgreedKPIDays,IsAgent,ID " &
              "From  Clients " &
              "Where CFPROID ='" & CFPROID & "' " &
              tmpstr &
              "Order By ID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next


        Session("ClientsTable") = tmptable


        GridClients.DataSource = tmptable
        GridClients.DataBind()

        If GridClients.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridClients.Rows.Count - 1 Then
                Rowindex = GridClients.Rows.Count - 1
            End If

            GridClients.SelectedIndex = Rowindex
            Call ShowClient(GridClients.SelectedValue)
            Dim row As GridViewRow = GridClients.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If


        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Clients found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Clients"
        End If



    End Sub


    Private Sub ShowClient(ID As Integer)
        Try
            LabelMessage1.Text = ""
            Dim sqlstr As String =
                 "Select ClientID, Client," &
                 "Box,Telephone,Email," &
                 "Town,Country," &
                 "AgreedKPIDays, IsAgent," &
                 "SendReports, DenyAccess, ID " &
                 "From  Clients " &
                 "Where ID = '" & ID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                TextClientName.Text = drow("Client")
                TextAddress.Text = drow("Box")
                TextTelephone.Text = drow("Telephone")
                TextEmailAddress.Text = drow("Email")
                TextTown.Text = drow("Town")

                TextAgreedKPIDays.Text = drow("AgreedKPIDays")
                CheckIsAgent.Checked = drow("IsAgent")
                CheckDenyAccess.Checked = drow("DenyAccess")
                CheckSendReports.Checked = drow("SendReports")

                If drow("Country").ToString.Length > 0 And drow("Country").ToString.Length <= 2 Then
                    ComboCountry.Text = Trim(drow("Country"))
                Else
                    ComboCountry.SelectedIndex = 0
                End If

                TextClientAcessCode.Text = clsEncr.EncryptString(LabelCFPROID.Text & "|" & drow("ClientID") & "|" & "importer")

            End If

            LabelDialogTitle.Text = "Client Access Code"
            LabelDialogTitle.ForeColor = Color.Gray

            LabelMessage.ForeColor = Color.Black
            LabelMessage.Text = ""

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Private Sub NewClient(CFPROID As String)
        Try

            Dim nClientID As String = clsSubs.GetLastID(CFPROID, "", "ClientID")

            Dim sqlstr As String =
                  "Select ClientID, Client," &
                   "CFPROID, SendReports,ID " &
                   "From  Clients " &
                   "Where CFPROID = '" & CFPROID & "' " &
                   "And ClientID = '" & nClientID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("ClientID") = nClientID
            Drow("CFPROID") = CFPROID
            Drow("SendReports") = 0
            Drow("Client") = "New Client " & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Clients", tmptable, sqlstr, False, clsData.constr)
            Call LoadClients(CFPROID, 0, "")


            TextClientName.Focus()



        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridClients, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridClients.SelectedIndexChanged
        Dim row As GridViewRow

        Dim Rowindex As Integer = 0

        If IsNumeric(LabelSelectedIndex.Text) Then
            Rowindex = LabelSelectedIndex.Text
        End If

        row = GridClients.Rows(Rowindex)
        If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
            row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
            row.ToolTip = "Click to select"
        End If
        row = GridClients.Rows(GridClients.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        LabelSelectedIndex.Text = GridClients.SelectedIndex


        Call ShowClient(GridClients.SelectedValue)


    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadClients(LabelCFPROID.Text, GridClients.SelectedIndex, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub ButtonNewClient_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewClient(LabelCFPROID.Text)
    End Sub


    Private Sub SaveClient(CFPROID As String, ID As String)
        Try

            LabelMessage.ForeColor = Color.Black
            LabelMessage.Text = ""

            If Not Trim(TextEmailAddress.Text) = "" Then
                If Not Trim(TextEmailAddress.Text).Contains("@") Then
                    LabelMessage.Text = "Invalid Email Address"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If


            Dim sqlstr As String =
            "Select ClientID, Client," &
            "Box,Telephone,Email," &
            "Town,Country, AgreedKPIDays," &
            "IsAgent,SendReports," &
            "DenyAccess, ID " &
            "From  Clients " &
            "Where ID = " & ID & " "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Client") = Trim(TextClientName.Text)
                drow("Box") = Trim(TextAddress.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Town") = Trim(TextTown.Text)

                drow("IsAgent") = CheckIsAgent.Checked
                drow("AgreedKPIDays") = TextAgreedKPIDays.Text
                drow("DenyAccess") = CheckDenyAccess.Checked
                drow("SendReports") = CheckSendReports.Checked

                drow("Country") = ComboCountry.Text
                Call clsData.SaveData("Clients", tmptable, sqlstr, False, clsData.constr)
                Call clsMSDynamicsNAVint.UpdateNAVCustomer(CFPROID, drow, LabelMessage1.Text)

            End If

            Call LoadClients(CFPROID, GridClients.SelectedIndex, TextSearch.Text, ComboFilterBy.SelectedIndex)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveClient(LabelCFPROID.Text, GridClients.SelectedValue)
    End Sub


    Private Sub DeleteClient(ID As Integer)
        Dim sqlstr As String = _
        "Select ID, Client " & _
        "From  Clients " & _
        "Where ID = " & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Clients", tmptable, sqlstr, True, clsData.constr)
        Call LoadClients(LabelCFPROID.Text, GridClients.SelectedIndex - 1, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteClient(GridClients.SelectedValue)
    End Sub


    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        TextSearch.Text = ""
        ComboFilterBy.SelectedIndex = 0
        Call LoadClients(LabelCFPROID.Text, 0, "")
    End Sub


    Protected Sub ButtonRefresh0_Click(sender As Object, e As EventArgs) Handles ButtonImporterCode.Click
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonEmailCode_Click(sender As Object, e As EventArgs) Handles ButtonEmailCode.Click
        Call EmailCode()
    End Sub


    Private Sub EmailCode()


        If InStr(TextEmailAddress.Text, "@", CompareMethod.Text) = 0 Then
            LabelDialogTitle.Text = "Client Email Address does not appear to be valid. Please Check"
            LabelDialogTitle.ForeColor = Color.Red
            Exit Sub
        End If

        If Trim(TextEmailAddress.Text) = "" Then
            LabelDialogTitle.Text = "Client Email Not Provided. Please Check"
            LabelDialogTitle.ForeColor = Color.Red
            Exit Sub
        End If

        If Len(TextClientAcessCode.Text) > 500 Then
            LabelDialogTitle.Text = "Code is too Long. Allowed Maximum length is 500 characters including spaces"
            LabelDialogTitle.ForeColor = Color.Red
            Exit Sub
        End If

        Dim CFAgent As String = LabelCFAgent.Text

        Dim eBody As String = vbCrLf & Trim(TextClientAcessCode.Text) & vbCrLf & vbCrLf & " - " & CFAgent
        Dim eSubject As String = "Your Client  Access Code - C&F PRO Online from " & CFAgent


        Try

            Dim SendResult As String = ""
            Call clsEmail.SendEmail(Trim(TextEmailAddress.Text), eSubject, eBody, TextClientName.Text, "", "", False, LabelCFPROID.Text, SendResult, True)
            If SendResult = "Email Sent" Then
                LabelDialogTitle.Text = "Code Sent Succesfuly!"
                LabelDialogTitle.ForeColor = Color.Green
            Else
                LabelDialogTitle.Text = "Code Not Sent. Please Check all Items and try again"
                LabelDialogTitle.ForeColor = Color.Red
            End If

            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelDialogTitle.Text = "Code Send Error. Please Check all Items and try again"
            LabelDialogTitle.ForeColor = Color.Red
        End Try

    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click
        Dim Fields(7) As String
        Fields(0) = "ClientID"
        Fields(1) = "Client"
        Fields(2) = "Email"
        Fields(3) = "Telephone"
        Fields(4) = "AgreedKPIDays"
        Fields(5) = "IsAgent"
        Fields(6) = "Town"
        Fields(7) = "Country"


        Dim tmptable As New DataTable("ClientsTable")
        tmptable = DirectCast(Session("ClientsTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Clients", "Clients",
                                            LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)


    End Sub


    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle1.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender2.Show()
    End Sub

    Protected Sub ButtonEmailAddresses_Click(sender As Object, e As EventArgs) Handles ButtonEmailAddresses.Click

        If GridClients.SelectedIndex >= 0 Then
            Dim OwnerID As String = GridClients.SelectedValue
            LoadDialog("emailaddresses.aspx?ownertype=client&ownerid=" & OwnerID, "Additional Email Addresses", 400, 550)
        End If
    End Sub

    Protected Sub ButtonAutomatedReports_Click(sender As Object, e As EventArgs) Handles ButtonAutomatedReports.Click
        Dim RecipientID As String = GridClients.SelectedValue
        Call LoadDialog("optionalalertsettings.aspx?recipientid=" & RecipientID & "&recipienttype=client", "Optional Alert Settings", 418, 585)

    End Sub

    Protected Sub ComboFilterUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboFilterBy.SelectedIndexChanged
        Call LoadClients(LabelCFPROID.Text, GridClients.SelectedIndex, TextSearch.Text, ComboFilterBy.SelectedIndex)
    End Sub

    Protected Sub LinkClientID_Click(sender As Object, e As EventArgs)
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim tmpstr As String = linkbutton.CommandArgument.ToString
        Call ShowClient(tmpstr)
    End Sub

    Protected Sub ButtonPhoneNumbers_Click(sender As Object, e As EventArgs) Handles ButtonPhoneNumbers.Click

        If GridClients.SelectedIndex >= 0 Then
            Dim OwnerID As String = GridClients.SelectedValue
            LoadDialog("telephonenos.aspx?ownertype=client&ownerid=" & OwnerID, "Additional Phone Numbers", 400, 550)
        End If
    End Sub
End Class