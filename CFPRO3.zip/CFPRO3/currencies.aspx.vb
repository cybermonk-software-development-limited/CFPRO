﻿
Imports System.Drawing

Public Class currencies
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", CFAgentName, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID
            LabelDetails.Text = "Add / Currencies & Exchange Rates"

            Call clsAccounts.LoadCurrencies(ComboCurrencies, "")
            ComboCurrencies1.Items.Insert(0, "(Set Local Currency)")
            Call LocalCurrency(CFPROID, False)

            Call LoadAccountCurrencies(CFPROID)
        End If
    End Sub



    Private Sub LoadAccountCurrencies(ByVal CFPROID As String)

        Try
            Dim sqlstr As String =
                "SELECT AccountCurrencies.CurrencyID, ExchangeRate," &
                "Currency, CurrencyCode,  AccountCurrencies.ID " &
                "FROM  AccountCurrencies, Currencies  " &
                "Where AccountCurrencies.CFPROID ='" & CFPROID & "' " &
                "And AccountCurrencies.CurrencyID = Currencies.CurrencyID " &
                "Order By Currencies.Currency Asc; "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            LabelCaption.Text = tmptable.Rows.Count & " Active Account Currencies"

            Dim a As Integer
            Dim drow As DataRow


            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Currency") = "No Account Currencies Set"
                tmptable.Rows.Add(drow)
            End If

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next

            GridAccountCurrencies.DataSource = tmptable
            GridAccountCurrencies.DataBind()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditAccountCurrency(LabelCFPROID.Text, False)
    End Sub
    Protected Sub GridNAVSettings_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridAccountCurrencies.SelectedIndexChanged
        Dim row As GridViewRow = GridAccountCurrencies.Rows(GridAccountCurrencies.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridAccountCurrencies.Rows.Count - 1
            row = GridAccountCurrencies.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridAccountCurrencies.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub GridNAVSettings_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridAccountCurrencies.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridAccountCurrencies, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditAccountCurrency(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditAccountCurrency(CFPROID As String, Edit As Boolean)
        Try

            Call clsAccounts.LoadCurrencies(ComboCurrencies1, "")
            ComboCurrencies1.Items.Insert(0, "(Select Currency)")

            If Edit Then
                If GridAccountCurrencies.SelectedIndex < 0 Then
                    LabelMessage3.Text = "Please Select Currency"
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Account Currency"
                Dim ID As Integer = GridAccountCurrencies.SelectedValue

                Dim sqlstr As String =
                   "SELECT CurrencyID,ExchangeRate, " &
                   "CFPROID, ID " &
                   "FROM AccountCurrencies " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    ComboCurrencies1.SelectedValue = drow("CurrencyID")
                    TextExchangeRate.Text = drow("ExchangeRate")
                End If

            Else
                LabelAddEdit.Text = "Add Account Currency "
                ComboCurrencies1.SelectedIndex = 0
                TextExchangeRate.Text = ""
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSave0_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveAccountCurrency(LabelCFPROID.Text)
    End Sub

    Private Sub SaveAccountCurrency(CFPROID As String)

        Try

            Dim ID As Integer = -1

            If LabelAddEdit.Text.Contains("Edit") Then
                ID = GridAccountCurrencies.SelectedValue
            End If

            Dim sqlstr As String =
               "SELECT CurrencyID, ExchangeRate, " &
               " CFPROID, ID " &
               "FROM AccountCurrencies " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("CurrencyID") = GetCurrencyID()
                tmptable.Rows.Add(drow)
            End If

            drow("CurrencyID") = ComboCurrencies1.SelectedValue
            drow("ExchangeRate") = Trim(TextExchangeRate.Text)


            Call clsData.SaveData("AccountCurrencies", tmptable, sqlstr, False, clsData.constr)

            Call LoadAccountCurrencies(CFPROID)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub




    Private Sub LocalCurrency(CFPROID As String, Save As Boolean)
        Dim sqlstr As String =
                        "Select LocalCurrencyID,ID " &
                        "From CFPROAccounts " &
                        "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)

            If Save Then
                If ComboCurrencies.SelectedIndex > 0 Then
                    drow("LocalCurrencyID") = ComboCurrencies.SelectedValue
                    Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, False, clsData.constr)
                End If
            Else
                Call clsData.NullChecker(tmptable, 0)
                If Not drow("LocalCurrencyID") = "" Then
                    ComboCurrencies.SelectedValue = drow("LocalCurrencyID")
                End If
            End If
        End If



    End Sub

    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridAccountCurrencies.SelectedIndex >= 0 Then
            Call PromptDeleteCurrency(LabelCFPROID.Text)
        Else
            LabelMessage3.Text = "No Selection"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteCurrency(CFPROID As String)

        Dim row As GridViewRow = GridAccountCurrencies.Rows(GridAccountCurrencies.SelectedIndex)

        LabelDeleteMessage.Text = "Delete Currency " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteAccountCurrencies(GridAccountCurrencies.SelectedValue)
    End Sub
    Private Sub DeleteAccountCurrencies(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From AccountCurrencies  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("AccountCurrencies", tmptable, sqlstr, True, clsData.constr)

            Call LoadAccountCurrencies(LabelCFPROID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Private Function GetCurrencyID() As String
        Try

            Dim tmpCurrencyID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From AccountCurrencies " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpCurrencyID = drow("ID")
                tmpCurrencyID = tmpCurrencyID + 1
                tmpstr = Format(tmpCurrencyID, "00000000#")
            Else
                tmpstr = Format(tmpCurrencyID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Function





    Protected Sub ButtonSave1_Click(sender As Object, e As EventArgs) Handles ButtonSave1.Click
        Call LocalCurrency(LabelCFPROID.Text, True)
    End Sub

    Protected Sub ButtonLiveRate_Click(sender As Object, e As EventArgs) Handles ButtonLiveRate.Click

        Dim LCCode As String() = clsAccounts.GetCUrrencyNameandCode(ComboCurrencies.Text)
        Dim FCCode As String() = clsAccounts.GetCUrrencyNameandCode(ComboCurrencies1.Text)

        TextExchangeRate.Text = clsAccounts.convertCurrency(FCCode(0), LCCode(0), LabelMessage5.Text)

        ModalPopupExtender2.Show()
    End Sub
End Class