﻿Imports System.Drawing

Public Class telephonenos
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



        If Not IsPostBack Then


            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Dim OwnerID As String = Request.QueryString("ownerid")
            Dim OwnerType As String = Request.QueryString("ownertype")

            LabelOwnerID.Text = OwnerID
            LabelOwnerType.Text = OwnerType

            Call LoadTelephoneNos(CFPROID, OwnerID, OwnerType, "")

        End If

    End Sub

    Private Sub LoadTelephoneNos(ByVal CFPROID As String, OwnerID As String, OwnerType As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Telephone Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select OwnerID, Telephone," &
                                      "OwnerType, CFPROID,ID " &
                                      "From  TelephoneNos " &
                                      "Where OwnerID ='" & OwnerID & "' " &
                                      "And OwnerType ='" & OwnerType & "' " &
                                      "And CFPROID ='" & CFPROID & "' " &
                                      tmpstr &
                                      "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridTelephoneNos.DataSource = tmptable
            GridTelephoneNos.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Phone Numberes"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingTelephoneNos_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridTelephoneNos.SelectedIndexChanged
        Dim row As GridViewRow = GridTelephoneNos.Rows(GridTelephoneNos.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridTelephoneNos.Rows.Count - 1
            row = GridTelephoneNos.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridTelephoneNos.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingTelephoneNos_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridTelephoneNos.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridTelephoneNos, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditTelephone(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditTelephone(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridTelephoneNos.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select Phone Number."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Telephone"
                Dim ID As Integer = GridTelephoneNos.SelectedValue

                Dim sqlstr As String = "SELECT OwnerID, Telephone," &
                                        "OwnerType, CFPROID,ID " &
                                        "From  TelephoneNos " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("Telephone")
                End If

            Else
                LabelAddEdit.Text = "Add Phone Number"
                TextAddEdit.Text = ""

            End If


            ModalPopupExtender2.Show()
            TextAddEdit.Focus()



        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditTelephone(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveTelephone(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, Edit)
    End Sub

    Private Sub SaveTelephone(CFPROID As String, OwnerID As String, OwnerType As String, Edit As Boolean)

        Dim ID As Integer = -1

        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Black


        If Not Edit Then
            If TelephoneExists(CFPROID, OwnerID, OwnerType, TextAddEdit.Text) Then
                LabelMessage.Text = "Phone Number Exists"
                LabelMessage.ForeColor = Color.Red
                ModalPopupExtender2.Show()
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridTelephoneNos.SelectedIndex >= 0 Then
                    ID = GridTelephoneNos.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT OwnerID, Telephone," &
                                    "OwnerType, CFPROID, ID " &
                                    "From  TelephoneNos " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("OwnerID") = OwnerID
                drow("OwnerType") = OwnerType
                tmptable.Rows.Add(drow)
            End If

            drow("Telephone") = Trim(LCase(TextAddEdit.Text))


            Call clsData.SaveData("TelephoneNos", tmptable, sqlstr, False, clsData.constr)

            Call LoadTelephoneNos(CFPROID, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function TelephoneExists(CFPROID As String, OwnerID As String, OwnerType As String, Telephone As String) As Boolean


        Dim sqlstr As String = "OwnerID, Telephone," &
                                        "OwnerType, CFPROID,ID " &
                                        "From  TelephoneNos " &
                                        "Where OwnerID ='" & OwnerID & "' " &
                                        "And OwnerType ='" & OwnerType & "' " &
                                        "And CFPROID ='" & CFPROID & "' " &
                                         "And Telephone = " & Trim(Telephone) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridTelephoneNos.SelectedIndex >= 0 Then
            Call PromptDeleteTelephone(GridTelephoneNos.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Phone Number to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteTelephone(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridTelephoneNos.Rows(GridTelephoneNos.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteTelephone(GridTelephoneNos.SelectedValue)
    End Sub
    Private Sub DeleteTelephone(ID As Integer)

        Dim sqlstr As String =
                 "Select  ID " &
                  "From TelephoneNos  " &
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("TelephoneNos", tmptable, sqlstr, True, clsData.constr)

            Call LoadTelephoneNos(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetTelephoneID() As String
    '    Try

    '        Dim tmpTelephoneID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From TelephoneNos " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpTelephoneID = drow("ID")
    '            tmpTelephoneID = tmpTelephoneID + 1
    '            tmpstr = Format(tmpTelephoneID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpTelephoneID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadTelephoneNos(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadTelephoneNos(LabelCFPROID.Text, LabelOwnerID.Text, LabelOwnerType.Text, "")
    End Sub



End Class