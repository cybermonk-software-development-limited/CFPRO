﻿Imports System.Net
Imports System.Drawing
Public Class inputsrefencessettings
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginFromDesktop(Request.QueryString("logintoken"))
            End If


            Dim CFAgentCFPROID As String = ""
            Dim CFPROUserID As String = ""



            Call clsAuth.UserLoggedIn("", CFAgentCFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

            LabelCFAgentCFPROID.Text = CFAgentCFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If clsAuth.ReadOnlyUser(CFAgentCFPROID, CFPROUserID) Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            If Not clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00011") Then
                LinkEmailServer0.Enabled = False
                LinkEmailServer0.ForeColor = Color.Gray
            End If


            If Not clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00012") Then
                LinkAccountSettings0.Enabled = False
                LinkAccountSettings0.ForeColor = Color.Gray
            End If



            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
            LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"




        End If
    End Sub

    Protected Sub LinkClients_Click(sender As Object, e As EventArgs) Handles LinkClients.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00001") Then
            LoadInputs("Clients.aspx", "Clients", False)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub
    Private Sub LoadInputs(funcsource As String, cfFunction As String, ChangeToSize As Integer)

        If ChangeToSize = 1 Then
            PanelInputs.Attributes("style") = "height:538px; width:598px;"
            Panel1.Attributes("style") = "width:588px;"
            iframe1.Attributes("style") = "height:455px; width:588px;" & LabeliFrameBgStyle.Text
        ElseIf ChangeToSize = 0 Then
            PanelInputs.Attributes("style") = "height:650px; width:919px;"
            Panel1.Attributes("style") = "width:910px;"
            iframe1.Attributes("style") = "height:566px; width:906px;" & LabeliFrameBgStyle.Text
        End If

        LabelInput.Text = cfFunction
        iframe1.Attributes("src") = funcsource
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub LinkImporters_Click(sender As Object, e As EventArgs) Handles LinkImporters.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00002") Then
            LoadInputs("importers.aspx", "Consignees", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkShippers_Click(sender As Object, e As EventArgs) Handles LinkShippers.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00002") Then
            LoadInputs("shippers.aspx", "Shippers", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub


    Protected Sub LinkShippingsLines_Click(sender As Object, e As EventArgs) Handles LinkShippingsLines.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00003") Then
            LoadInputs("shippinglines.aspx", "Shipping Lines", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkCFS_Click(sender As Object, e As EventArgs) Handles LinkCFS.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00004") Then
            LoadInputs("cfs.aspx", "CFSs", False)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkTransporters_Click(sender As Object, e As EventArgs) Handles LinkTransporters.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("transporters.aspx", "Transporters", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkUsers_Click(sender As Object, e As EventArgs) Handles LinkUsers.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00010") Then
            LoadInputs("cfagentusers.aspx", "C&F Agent Users / Staff", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkVehicles_Click(sender As Object, e As EventArgs) Handles LinkVehicles.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("vehicles.aspx", "Vehicles", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If


    End Sub

    Protected Sub LinkShippingsVessels_Click(sender As Object, e As EventArgs) Handles LinkShippingsVessels.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00005") Then
            LoadInputs("shippingvessels.aspx", "Vessel Schedules", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignOut(LinkSignIn.Text, LabelUser.Text, Image1.ImageUrl, 1)
    End Sub

    Protected Sub LinkJobTypes_Click(sender As Object, e As EventArgs) Handles LinkJobTypes.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("jobtypes.aspx", "Job Types", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub


    Protected Sub LinkJobStatus_Click(sender As Object, e As EventArgs) Handles LinkJobStatus.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("jobstatus.aspx", "Job Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub
    Protected Sub LinkPayloads_Click(sender As Object, e As EventArgs) Handles LinkPayloads.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("payloads.aspx", "Payloads", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkVesselStatus_Click(sender As Object, e As EventArgs) Handles LinkVesselStatus.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("vesselstatus.aspx", "Vessel Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub Link_Click(sender As Object, e As EventArgs) Handles Link.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("containerstatus.aspx", "Container Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub


    Protected Sub LinkROStatus_Click(sender As Object, e As EventArgs) Handles LinkROStatus.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("releaseorderstatus.aspx", "Release Order Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkDOStatus_Click(sender As Object, e As EventArgs) Handles LinkDOStatus.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("deliveryorderstatus.aspx", "Delivery Order Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkSpecialCargo_Click(sender As Object, e As EventArgs) Handles LinkSpecialCargo.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("specialcargo.aspx", "Special Cargo", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkBonds_Click(sender As Object, e As EventArgs) Handles LinkBonds.Click
        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00013") Then
            LoadInputs("bonds.aspx", "Bonds", 0)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkBonds0_Click(sender As Object, e As EventArgs) Handles LinkBonds0.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("bondstatus.aspx", "Bonds Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkDocuments_Click(sender As Object, e As EventArgs) Handles LinkDocuments.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("documentstatus.aspx", "Document Status", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinVesselStatus0_Click(sender As Object, e As EventArgs) Handles LinVesselStatus0.Click
        LoadInputs("depots.aspx", "Depots", 1)
    End Sub

    Protected Sub Link0_Click(sender As Object, e As EventArgs) Handles Link0.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("destinations.aspx", "Destinations", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkGoodsDesc_Click(sender As Object, e As EventArgs) Handles LinkGoodsDesc.Click

        If clsAuth.UserAllowed(LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadInputs("goodsdescription.aspx", "Goods Descriptions", 1)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub


    Protected Sub LinkAccountSettings0_Click(sender As Object, e As EventArgs) Handles LinkAccountSettings0.Click
        ModalPopupExtender2.Show()
        Call CFPROAccountSettings(LabelCFAgentCFPROID.Text, False)

    End Sub

    Protected Sub LinkEmailServer0_Click(sender As Object, e As EventArgs) Handles LinkEmailServer0.Click
        ModalPopupExtender3.Show()
        Call EmailServer(LabelCFAgentCFPROID.Text, False)
    End Sub
    Protected Sub ButtonSaveAccountSettings_Click(sender As Object, e As EventArgs) Handles ButtonSaveAccountSettings.Click
        Call CFPROAccountSettings(LabelCFAgentCFPROID.Text, True)
    End Sub
    Private Sub CFPROAccountSettings(CFAgentCFPROID As String, Save As Boolean)

        Dim sqlstr As String = "SELECT  CFAgentCFPROID, IPAddress," &
                               "LockIP, ID " &
                               "FROM CFPROAccounts " &
                               "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            If drow("IPAddress") = "" Then
                drow("IPAddress") = Request.UserHostAddress
            End If

            If Not Save Then

                TextAccountIPAddress.Text = drow("IPAddress")
                CheckLockToIP.Checked = drow("LockIP")

            Else
                drow("IPAddress") = Trim(TextAccountIPAddress.Text)
                drow("LockIP") = CheckLockToIP.Checked
                Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, False, clsData.constr)
                ModalPopupExtender2.Show()
            End If

        End If


    End Sub
    Private Function GetExternalIp() As String
        Try
            Dim ExternalIP As String
            ExternalIP = (New WebClient()).DownloadString("http://checkip.dyndns.org/")
            ExternalIP = (New Regex("\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")) _
                         .Matches(ExternalIP)(0).ToString()
            Return ExternalIP
        Catch
            Return ""
        End Try
    End Function
    Protected Sub ButtonSaveEmailServer_Click(sender As Object, e As EventArgs) Handles ButtonSaveEmailServer.Click
        Call EmailServer(LabelCFAgentCFPROID.Text, True)
    End Sub
    Private Sub EmailServer(CFAgentCFPROID As String, Save As Boolean)
        Dim sqlstr As String = "SELECT CFAgentCFPROID," &
                                "Server, Port,EnableSSL," &
                                "EmailAddress,EmailSender," &
                                "UserName,Password," &
                                "ExchangeServer,ID " &
                                "FROM EmailServer " &
                                "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("CFAgentCFPROID") = CFAgentCFPROID
            tmptable.Rows.Add(drow)
        Else
            drow = tmptable.Rows(0)
        End If


        Call clsData.NullChecker(tmptable, 0)

        If Not Save Then
            TextEmailServer.Text = drow("Server")
            TextEmailPortNo.Text = drow("Port")
            TextEmailAddress.Text = drow("EmailAddress")
            TextEmailSender.Text = drow("EmailSender")
            TextUserName.Text = drow("UserName")
            TextPassword.Text = drow("Password")
            CheckUseSSL.Checked = drow("EnableSSL")
            CheckExchangeServer.Checked = drow("ExchangeServer")

        Else
            drow("Server") = Trim(TextEmailServer.Text)
            drow("Port") = Trim(TextEmailPortNo.Text)
            drow("EmailAddress") = Trim(TextEmailAddress.Text)
            drow("EmailSender") = Trim(TextEmailSender.Text)
            drow("UserName") = Trim(TextUserName.Text)
            drow("Password") = Trim(TextPassword.Text)
            drow("EnableSSL") = CheckUseSSL.Checked
            drow("ExchangeServer") = CheckExchangeServer.Checked

            Call clsData.SaveData("EmailServer", tmptable, sqlstr, False, clsData.constr)

            ModalPopupExtender3.Show()
        End If


    End Sub
    Protected Sub ButtonResetAccountIP_Click(sender As Object, e As EventArgs) Handles ButtonResetAccountIP.Click
        TextAccountIPAddress.Text = Request.UserHostAddress
        ModalPopupExtender2.Show()
    End Sub

  
  
End Class