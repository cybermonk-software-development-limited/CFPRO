﻿Imports System.IO
Imports System.Net

Public Class clsAuth


    Shared Sub UserLogin(ByRef CSDID As String, ByRef CFPROID As String, ByRef CFPROUserID As String, ByRef UserName As String, ByRef CFAgentName As String,
                                   ByRef SignIn As String, ByRef UserImgurl As String, ByRef CFAgentImageURL As String,
                                   ByVal AuthAgent As Boolean, ByVal UserTypeComp As String, ToHome As Boolean,
                                   Optional ByVal UserEmailAddress As String = "", Optional ByVal MarineCargo As Integer = 0, Optional Tracking As Boolean = False,
                                   Optional ByRef AlertCount As String = "0", Optional ByRef MessageCount As String = "0", Optional ByRef ErrMsg As String = Nothing)


        Try


            If Not UserTypeComp = "" Then
                Dim UserType As String
                If HttpContext.Current.Request.Cookies("UserType") Is Nothing Then
                    UserType = ""
                Else
                    UserType = HttpContext.Current.Request.Cookies("UserType").Value
                End If

                If UserType = "" Then
                    HttpContext.Current.Response.Redirect("index.aspx")
                Else
                    If LCase(UserTypeComp) <> LCase(UserType) Then
                        HttpContext.Current.Response.Redirect("index.aspx")
                    End If
                End If
            End If

            If IsNothing(HttpContext.Current.Request.Cookies("CFPROToken")) Then

                SignIn = "Sign In"
                UserName = "Guest"
                CFAgentName = ""
                UserImgurl = "imageplaceholder.png"
                CFAgentImageURL = "companyplaceholder.png"
                CSDID = ""

                If ToHome Then
                    HttpContext.Current.Response.Redirect("index.aspx")
                End If

            ElseIf HttpContext.Current.Request.Cookies("CFPROToken").Value.Length > 0 Then

                Dim Logintoken As String = HttpContext.Current.Request.Cookies("CFPROToken").Value
                Dim Logintoken1 As String = clsEncr.DecryptString(clsEncr.DecryptString(Logintoken))


                Dim tmpstr() As String = Logintoken1.Split("|")

                ReDim Preserve tmpstr(4)
                If Not IsNothing(tmpstr) Then

                    CSDID = tmpstr(0)
                    UserName = tmpstr(1)
                    UserEmailAddress = tmpstr(2)

                    If clsSubs.RemoteFileExists(tmpstr(3)) Then
                        UserImgurl = tmpstr(3)
                    Else
                        UserImgurl = "imageplaceholder.png"
                    End If

                    SignIn = "Sign Out"


                    If AuthAgent Then
                        Dim GoToStart As Boolean

                        Call AuthCFAgent(CFPROID, CFAgentName, "", CFPROUserID, CFAgentImageURL, "", GoToStart, CSDID, AlertCount, MessageCount)

                        If GoToStart Then
                            If MarineCargo = 0 Then
                                HttpContext.Current.Response.Redirect("cfprodashboard.aspx")
                            End If
                        End If

                    Else
                        CFPROID = ""
                        CFAgentName = ""
                        CFPROUserID = ""
                        CFAgentImageURL = "companyplaceholder.png"
                        MessageCount = "0"
                        AlertCount = "0"
                    End If

                End If
            Else
                CSDID = ""
                SignIn = "Sign In"
                UserName = "Guest"
                UserEmailAddress = ""
                CFAgentName = "Cybermonk SD Test"
                UserImgurl = "imageplaceholder.png"
                CFAgentImageURL = "companyplaceholder.png"

                CFPROID = ""
                CFAgentName = ""
                CFPROUserID = ""
                CFAgentImageURL = "companyplaceholder.png"

            End If

        Catch ex As Exception

            ErrMsg = "Login Service Timed Out - Try Again."
            'ErrMsg = ex.Message & ex.StackTrace
            'HttpContext.Current.Server.Transfer("errorcatch.html")
        End Try

    End Sub

    Shared Sub AuthCFAgent(ByRef CFPROID As String, ByRef CFAgentName As String, ByRef CFAgentAddress As String, _
                         ByRef CFPROUserID As String, ByRef CFAgentImageURL As String, AuthDetStr As String,
                         ByRef GotoDashBoard As Boolean, Optional ByRef CSDID As String = "", Optional ByRef AlertCount As String = "0", Optional ByRef MessageCount As String = "0")


        Dim nAuthCFAgent As String = ""

        If Not AuthDetStr = "" Then
            nAuthCFAgent = AuthDetStr

        Else
            If Not IsNothing(HttpContext.Current.Request.Cookies("CFAgent")) Then
                nAuthCFAgent = HttpContext.Current.Request.Cookies("CFAgent").Value
            Else
                nAuthCFAgent = ""
                GotoDashBoard = True
            End If

        End If

        If nAuthCFAgent = "" Then
            CFPROID = ""
            CFAgentName = ""
            CFPROUserID = ""
            CFAgentImageURL = "companyplaceholder.png"
            CFAgentAddress = ""
            MessageCount = "0"
            AlertCount = "0"
            GotoDashBoard = True
        Else
            Dim tmpstr1() As String = nAuthCFAgent.Split("|")
            ReDim Preserve tmpstr1(4)

            CFPROID = tmpstr1(0)
            CFAgentName = tmpstr1(1)
            CFPROUserID = tmpstr1(2)
            'UserType = tmpstr1(3)
            CFAgentAddress = tmpstr1(4)

            MessageCount = clsActionCenter.MessageAlerts(CSDID, CFPROID)
            AlertCount = clsActionCenter.ActionAlerts(CFPROID)

            GotoDashBoard = False

            If IO.File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".jpg") Then
                CFAgentImageURL = "\cfagentimages\" & tmpstr1(0) & ".jpg"
            ElseIf IO.File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".png") Then
                CFAgentImageURL = "\cfagentimages\" & tmpstr1(0) & ".png"
            Else
                CFAgentImageURL = "companyplaceholder.png"
            End If

            If Not AllowIPAccess(tmpstr1(0), tmpstr1(2), "") Then
                GotoDashBoard = True
            End If

        End If

    End Sub

    Shared Sub LoginToken(ByVal LoginTokenID As String, ByVal External As Boolean, Optional ByRef ErrMsg As String = "", Optional tmpDateTime As String = "")


        Try

            Dim CSDEndPoint As String = "" '"http://csdwcfservice.cybermonksd.com/"
            Dim EndPointConfigName As String = "BasicHttpBinding_ICSDService1"


            Dim host As String = HttpContext.Current.Request.Url.Host
            Dim host1 As String = ""

            Dim nLoginURL As String = LoginURL()

            If nLoginURL = "" Then
                host1 = host
            Else
                host1 = nLoginURL
            End If



            If host1.Contains("com") Then
                CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"

            ElseIf host1.Contains("azurewebsites") Then
                CSDEndPoint = "http://csdwcfservice.azurewebsites.net/CSDService1.svc"

            ElseIf host.Contains("localhost") Then
                If nLoginURL = "" Then
                    CSDEndPoint = "http://localhost:98/CSDService1.svc"
                Else
                    CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"
                End If

            ElseIf IsIPAdress(host) Then
                If nLoginURL.Contains("cybermonksd") Then
                    CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"

                ElseIf nLoginURL.Contains("azurewebsites") Then
                    CSDEndPoint = "http://csdwcfservice.azurewebsites.net/CSDService1.svc"
                Else
                    CSDEndPoint = nLoginURL & ":98"
                End If

            Else
                CSDEndPoint = "http://csdwcfservice.cybermonksd.com/CSDService1.svc"
            End If


            Dim IsAdmin As Integer = 0


            Dim CSDWCFService1 As New CSDWCFService.CSDService1Client(EndPointConfigName, CSDEndPoint)

            If Not tmpDateTime = "" Then
                HttpContext.Current.Session("logintimedate") = tmpDateTime
            Else
                tmpDateTime = HttpContext.Current.Session("logintimedate")

                If Not IsDate(tmpDateTime) Then
                    tmpDateTime = Format(Now, "M d yyyy hh:mm tt")
                End If
            End If


            Dim Logintoken1 As String = CSDWCFService1.LoginToken(LoginTokenID, tmpDateTime, IsAdmin)
            CSDWCFService1.Close()


            If Logintoken1.Contains("Error") Then
                ErrMsg = Logintoken1
                Exit Sub
            Else

                Logintoken1 = clsEncr.DecryptString(clsEncr.DecryptString(Logintoken1))
                ErrMsg = Logintoken1
            End If


            Dim tmpstr() As String = Logintoken1.Split("|")
            ReDim Preserve tmpstr(9)

            Dim Logintoken2 As String = clsEncr.EncryptString(clsEncr.EncryptString(tmpstr(0) & "|" & tmpstr(1) & "|" &
                                                              tmpstr(2) & "|" & tmpstr(3) & "|" & tmpstr(4) & "|" & tmpstr(5)))

            HttpContext.Current.Response.Cookies("CSDAdmin").Value = IsAdmin
            HttpContext.Current.Response.Cookies("CSDAdmin").Expires = Now.AddHours(3)


            HttpContext.Current.Response.Cookies("CFPROToken").Value = Logintoken2
            HttpContext.Current.Response.Cookies("CFPROToken").Expires = Now.AddHours(94)


            If External Then
                Dim AuthCFAgent As String = tmpstr(6) & "|" & tmpstr(7) & "|" & tmpstr(8)

                HttpContext.Current.Response.Cookies("CFAgent").Value = AuthCFAgent
                HttpContext.Current.Response.Cookies("CFAgent").Expires = Now.AddHours(9)

                If Not tmpstr(9) = "" Then
                    HttpContext.Current.Response.Cookies("UserType").Value = tmpstr(9)
                End If

            Else
                Try
                    If Not IsNothing(tmpstr) Then
                        If clsSubs.RemoteFileExists(tmpstr(3)) Then
                            Dim a As Integer
                            Dim tmpstr1(0) As String
                            Dim userimageurl As String = ""
                            userimageurl = tmpstr(3)

                            If InStr(userimageurl, ".", CompareMethod.Text) > 0 Then

                                tmpstr1 = userimageurl.Split(".")
                                a = tmpstr1.GetUpperBound(0)
                                ReDim Preserve tmpstr1(a)

                                Dim tmpstr2() As String = IO.Directory.GetFiles(HttpContext.Current.Server.MapPath(".") & "\userimages\")

                                For Each tmpstr3 In tmpstr2
                                    If InStr(tmpstr3, tmpstr(0), CompareMethod.Text) > 0 Then
                                        IO.File.Delete(tmpstr3)
                                    End If
                                Next

                                Using nClient As New WebClient()
                                    nClient.DownloadFile(userimageurl, HttpContext.Current.Server.MapPath(".") & "\userimages\" & tmpstr(0) & "." & tmpstr1(a))
                                End Using
                            End If
                        Else
                            ErrMsg = tmpstr(3)
                        End If
                    End If


                    If Not IsNothing(HttpContext.Current.Request.QueryString("gotooption")) Then
                        HttpContext.Current.Response.Redirect(HttpContext.Current.Request.QueryString("gotooption"))
                    End If

                Catch ex As Exception
                    ErrMsg = tmpstr(3) 'ex.Message & ex.StackTrace
                End Try
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub


    Shared Sub SignInOut(ByRef LinkSignInText As String, ByRef LabelUserText As String, ByRef ImageUrl As String, ByVal ToHome As Boolean, Optional gotooption As String = "")

        If LinkSignInText = "Sign In" Then
            If Not gotooption = "" Then

                Dim tmpDateTime As String = HttpContext.Current.Session("logintimedate")

                HttpContext.Current.Response.Redirect(clsAuth.UserAuthURL(gotooption, tmpDateTime))
            End If
        Else
            HttpContext.Current.Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            HttpContext.Current.Response.Cookies("CFAgent").Expires = Now.AddDays(-1)
            HttpContext.Current.Response.Cookies("CSDAdmin").Expires = Now.AddDays(-1)
            HttpContext.Current.Response.Cookies("CFPROMCI").Expires = Now.AddDays(-1)
            HttpContext.Current.Response.Cookies("UserType").Expires = Now.AddDays(-1)

            LabelUserText = "Guest"
            LinkSignInText = "Sign In"
            ImageUrl = "imageplaceholder.png"
            If ToHome Then
                HttpContext.Current.Response.Redirect("index.aspx")
            End If
        End If

    End Sub


    Shared Function UserAuthURL(gotooption As String, tmpDateTime As String) As String


        Dim host As String = HttpContext.Current.Request.Url.Host
        Dim fromurl As String = "?fromurl=" & HttpUtility.UrlEncode(clsEncr.EncryptString("http://" & host & "?"))

        Try

            HttpContext.Current.Session("logintimedate") = tmpDateTime

            If Not gotooption = "" Then
                gotooption = "&gotooption=" & gotooption
            Else
                gotooption = "&gotooption=index.aspx"
            End If

            Dim csdhost As String = "http://cybermonksd.com/usersignin.aspx" & fromurl & gotooption

            Dim nLoginURL As String = LoginURL()


            If host.Contains("cfpro") Then

                If nLoginURL = "" Then
                    csdhost = "http://cybermonksd.com/usersignin.aspx" & fromurl & gotooption
                Else
                    csdhost = nLoginURL & "/usersignin.aspx" & fromurl & gotooption
                End If

            ElseIf InStr(host, "localhost", CompareMethod.Text) > 0 Or IsIPAdress(host) Then
                fromurl = "?fromurl=" & HttpUtility.UrlEncode(clsEncr.EncryptString("http://" & host & ":90/?"))

                If nLoginURL = "" Then
                    csdhost = "http://" & host & ":84/usersignin.aspx" & fromurl & gotooption
                Else
                    csdhost = nLoginURL & "/usersignin.aspx" & fromurl & gotooption
                End If

            Else
                csdhost = "http://cybermonksd.com/usersignin.aspx" & fromurl & gotooption
            End If


            Return csdhost

        Catch ex As Exception
            Return "http://cybermonksd.com/usersignin.aspx" & fromurl & gotooption
        End Try
    End Function

    Shared Function LoginURL() As String
        Try

            If File.Exists(HttpRuntime.AppDomainAppPath & "\LoginURL.txt") Then
                Dim nLoginURL As String = ""
                Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "\LoginURL.txt")
                nLoginURL = reader.ReadToEnd
                reader.Close()
                Return nLoginURL
            Else
                Return ""
            End If


        Catch exp As Exception
            Return ""
        End Try
    End Function


    Shared Function IsIPAdress(host) As Boolean

        Dim address As IPAddress

        If IPAddress.TryParse(host, address) Then

            Select Case address.AddressFamily
                Case System.Net.Sockets.AddressFamily.InterNetwork
                    Return True
                Case System.Net.Sockets.AddressFamily.InterNetworkV6
                    Return True
                Case Else
                    Return False
            End Select
        End If
    End Function

    Shared Function GetUserIP() As String
        Try
            Return HttpContext.Current.Request.UserHostAddress
        Catch
            Return "0.0.0.0"
        End Try
    End Function
    Shared Function AllowIPAccess(CFPROID As String, UserID As String, ByRef ErrMsg As String) As Boolean
        Try
            Dim UserIPAddress As String = HttpContext.Current.Request.UserHostAddress
            Dim SystemIPAddress As String = ""

            Dim sqlstr As String = "SELECT  CFPROID, IPAddress," &
                                      "LockIP, ID " &
                                      "FROM CFPROAccounts " &
                                      "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                If drow("IPAddress") = "" Then
                    SystemIPAddress = HttpContext.Current.Request.UserHostAddress
                Else
                    SystemIPAddress = drow("IPAddress")
                End If
            Else
                Return False
            End If


            Dim sqlstr1 As String =
                        "SELECT  IPAddress," &
                        "LockedToIP, Role," &
                        "CFPROAccountAdmin, ID " &
                        "FROM CFAgentUsers " &
                        "Where CFPROID ='" & CFPROID & "' " &
                        "And UserID = '" & UserID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim drow1 As DataRow

            If tmptable1.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable1, 0)
                drow1 = tmptable1.Rows(0)

                If drow1("CFPROAccountAdmin") Then
                    If drow1("Role") = "Super Administrator" Then
                        Return True
                    End If
                End If

                If drow1("IPAddress") = "" Then
                    If drow("LockIP") Then
                        If UserIPAddress = SystemIPAddress Then
                            Return True
                        Else
                            Return False
                        End If
                    ElseIf drow1("LockedToIP") Then
                        If UserIPAddress = SystemIPAddress Then

                            Return True
                        Else

                            Return False
                        End If
                    Else

                        Return True
                    End If
                Else
                    If drow1("LockedToIP") Then
                        If drow1("IPAddress") = UserIPAddress Then
                            Return True
                        Else
                            Return False
                        End If
                    Else
                        Return True
                    End If

                End If
            Else
                Return True
            End If


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Function


    Shared Function OwnRecordsOnly(CFPROID As String, UserID As String) As Boolean
        Dim sqlstr As String = _
                 "Select Role, OwnRecordsOnly " &
                 "From CFAgentUsers " &
                 "Where CFPROID ='" & CFPROID & "' " &
                 "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            If drow("Role") = "Super Administrator" Then
                Return False
            Else
                Return drow("OwnRecordsOnly")
            End If
        End If
    End Function


    Shared Function UserAllowed(CFPROID As String, UserID As String, PermissionID As String) As Boolean

        Dim sqlstr As String = _
            "Select UserID, Role, OwnRecordsOnly " &
             "From CFAgentUsers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim sqlstr1 As String =
                "SELECT PermissionID," &
                "Permission, AllowNormalAdmin," &
                "AllowOperator,ID " &
                "FROM Permissions " &
                "Order By SortOrder Asc;"

        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
        Dim dv1 As New DataView(tmptable1)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            Dim sqlstr2 As String =
                   "SELECT PermissionID, " &
                   "Allow,ID " &
                   "From  UserPermissions " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And UserID = '" & UserID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim dv2 As New DataView(tmptable2)
            dv2.RowFilter = "PermissionID = '" & PermissionID & "' "

            If dv2.Count = 0 Then
                dv1.RowFilter = "PermissionID = '" & PermissionID & "' "

                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    If drow("Role") = "Administrator" Then
                        Return dv1(0)("AllowNormalAdmin")

                    ElseIf drow("Role") = "Operator" Then
                        Return dv1(0)("AllowOperator")

                    ElseIf drow("Role") = "Super Administrator" Then
                        Return True
                    End If
                Else
                    Return True
                End If
            Else
                Call clsData.NullChecker1(dv2, 0)
                Return dv2(0)("Allow")
            End If

        Else
            Return False
        End If
        Return False

    End Function

    Shared Function ReadOnlyUser(CFPROID As String, UserID As String) As Boolean

        Dim sqlstr As String = _
            "Select UserID, ReadOnlyUser " &
             "From CFAgentUsers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            Return drow("ReadOnlyUser")
        Else
            Return False
        End If


    End Function



    Shared Function TransitUpdateUser(CFPROID As String, UserID As String) As Boolean

        Dim sqlstr As String =
            "Select UserID, TransitUpdateUser " &
             "From CFAgentUsers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            Return drow("TransitUpdateUser")
        Else
            Return False
        End If

    End Function
    Shared Function UserRole(CFPROID As String, UserID As String) As String

        Dim sqlstr As String = _
            "Select UserID, Role " &
             "From CFAgentUsers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            Return drow("Role")
        Else
            Return ""
        End If

    End Function

    Shared Sub SendToPayment(Names As String, EmailAddress As String, Telephone As String, CSDID As String, _
                            PaymentID As String, Amount As String, ItemURL As String, ItemRefID As String, Optional ByRef ErrMsg As String = "")

        Try



            Dim UserAuthToken As String = Names & "|" & EmailAddress & "|" & Telephone & "|" & CSDID
            UserAuthToken = clsEncr.EncryptString(UserAuthToken)



            Dim CSDEndPoint As String = "http://csdwcfservice.cybermonksd.com/"

            Dim host As String = HttpContext.Current.Request.Url.Host


            If InStr(host, ".com", CompareMethod.Text) > 0 Then
                CSDEndPoint = "http://csdwcfservice.cybermonksd.com/"
            Else
                CSDEndPoint = "http://" & host & "/CSDWCFService/"
            End If


            If CSDID = "-" Then
                Dim CSDWCFService As New CSDWCFService.CSDService1Client("BasicHttpBinding_ICSDService1", CSDEndPoint)

                Dim nCSDID As String = clsEncr.DecryptString(CSDWCFService.CreateSignInCSDUser(UserAuthToken, ErrMsg))

                If Not nCSDID = "-" Then
                    CSDID = nCSDID
                End If

                CSDWCFService.Close()
            End If



            If Not CSDID = "-" Then
                Dim PayHost As String = ""
                Dim Host1 As String = ""

                If InStr(host, ".com", CompareMethod.Text) = 0 Then
                    PayHost = host & ":84"
                    Host1 = host & ":90"
                Else
                    PayHost = "cybermonksd.com"
                    Host1 = "cfproonline.com"
                End If

                ItemURL = "http://" & Host1 & "/" & ItemURL

                Dim PaymentToken As String = PaymentID & "|" & Amount & "|" & ItemURL & "|" & ItemRefID
                PaymentToken = clsEncr.EncryptString(PaymentToken)


                PayHost = "http://" & PayHost & "/shoppingitems.aspx?ExtCSDID=" & HttpUtility.UrlEncode(clsEncr.EncryptString(CSDID)) & "&PaymentToken=" & HttpUtility.UrlEncode(PaymentToken)

                Dim UserAuthToken1 As String = CSDID & "|" & Names & "|" & EmailAddress & "|" & "imageplaceholder.png"
                Dim Logintoken As String = clsEncr.EncryptString(clsEncr.EncryptString(UserAuthToken1))

                HttpContext.Current.Response.Cookies("CFPROToken").Value = Logintoken

                If IsNothing(HttpContext.Current.Request.Cookies("UserType")) Then
                    HttpContext.Current.Response.Cookies("UserType").Value = "insurer"
                End If

                ErrMsg = CSDID
                HttpContext.Current.Response.Redirect(PayHost)

            End If



        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub
    Shared Function PaymentWarning(CFPROID As String, ByRef DaysLeft As Integer) As Boolean

        Dim sqlstr As String = "SELECT  Warning,WarningDate," &
                                      "WarningCountMax, ID " &
                                      "FROM CFPROAccounts " &
                                      "Where CFPROID ='" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)




        If tmptable.Rows.Count > 0 Then

            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            If drow("Warning") Then
                If Not IsNothing(HttpContext.Current.Request.Cookies("TodaysDate")) Then
                    Dim TodaysDate As String = HttpContext.Current.Request.Cookies("TodaysDate").Value
                    If IsDate(TodaysDate) Then
                        Dim ts As TimeSpan
                        Dim WarningDate As DateTime = drow("WarningDate")
                        Dim WarningCountMax As Double = drow("WarningCountMax")

                        ts = CDate(TodaysDate).Subtract(WarningDate)
                        DaysLeft = WarningCountMax - ts.Days + 1

                        Return True
                    Else
                        Return True
                    End If
                Else
                    Return True
                End If
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function
End Class
