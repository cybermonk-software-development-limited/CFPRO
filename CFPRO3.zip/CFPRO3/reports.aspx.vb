﻿Public Class reports
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub

End Class