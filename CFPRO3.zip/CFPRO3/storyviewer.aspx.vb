﻿Public Class storyviewer
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then


            Dim CFPROID As String = ""
            Dim StoryID As String = Request.QueryString("storyid")
            Dim CSDID As String = ""


            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", False, "", False)
            LabelCFPROID.Text = CFPROID


            Call LoadStory(StoryID)

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If

    End Sub



    Private Sub LoadStory(StoryID As String)

        Try
            iframe1.Attributes("style") = "height:" & 650 & "px; width:" & 1196 & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"


            Dim sqlstr As String = _
              "SELECT  MainArticleViewCount, StoryURL, ID " &
              "FROM  Stories " &
              "Where StoryID = '" & StoryID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                drow("MainArticleViewCount") = drow("MainArticleViewCount") + 1

                iframe1.Attributes("src") = drow("StoryURL").ToString
                Call clsData.SaveData("Stories", tmptable, sqlstr, False, clsData.constr)


            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

End Class