﻿Imports System.Data.SqlClient

Public Class clsActionCenter


    Shared Function ProcessCFAgentAlertSummaryEmails(Optional CFPROID As String = Nothing, Optional ByVal ErrMsg As String = Nothing) As String
        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "And CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  "Where ProcessAlerts = 1 " &
                   tmpstr



            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Dim a As Integer

                For Each drow In tmptable.Rows
                    clsData.NullChecker(tmptable, a)
                    ErrMsg = SendCFAgentAlertSummaryEmail(drow("CFPROID"), False)
                    a = a + 1
                Next

                If a >= tmptable.Rows.Count Then
                    Return "Processed"
                End If
            Else
                Return "Not Found"
            End If


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
            Return "Failed"
        End Try

    End Function


    Shared Function SendCFAgentAlertSummaryEmail(CFPROID As String, DefaultEmailServer As Boolean) As String

        Try

            If clsEmail.SendCFAgentAlerts() Then
                Dim AlertName(0) As String
                Dim NoofJobs(0) As String
                Dim LastProcessed(0) As String
                Dim Condition(0) As String

                If AlertsandJobs(CFPROID, AlertName, NoofJobs, LastProcessed, Condition) Then
                    ReDim Preserve AlertName(4)
                    ReDim Preserve NoofJobs(4)
                    ReDim Preserve LastProcessed(4)
                    ReDim Preserve Condition(4)


                    Dim CFAgentLogo As String = ""
                    Dim UserImage As String = ""
                    Dim CFAgentName As String = ""
                    Dim CFAgentAddress As String = ""
                    Dim CFAgentEmailAddress As String = ""

                    Dim UserEmailAddress As String = ""
                    Dim UserNames As String = ""


                    If clsSubs.RemoteFileExists("http://cfproonline.com/emails/sentby.png") Then
                        UserImage = "http://cfproonline.com/emails/sentby.png"
                    Else
                        UserImage = "http://cfproonline.com/userimages/000000000.png"
                    End If


                    Dim sqlstr As String =
                    "Select CFAgentName, CFAgentAddress," &
                    "EmailAddress, LogoURL " &
                    "From CFPROAccounts " &
                    "Where CFPROID = '" & CFPROID & "' "

                    Dim tmptable As New DataTable()
                    Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                    If tmptable.Rows.Count > 0 Then
                        Dim drow As DataRow = tmptable.Rows(0)
                        Call clsData.NullChecker(tmptable, 0)

                        Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                        ReDim Preserve tmpstr(1)

                        If clsSubs.RemoteFileExists("http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)) Then
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)
                        Else
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/000000000.png"
                        End If

                        CFAgentName = drow("CFAgentName")
                        CFAgentAddress = drow("CFAgentAddress")
                        CFAgentEmailAddress = drow("EmailAddress")

                    End If


                    Dim SendtoEmailAdress As String = CFAgentEmailAddress
                    Dim SendtoNames As String = ""



                    Dim sqlstr1 As String = _
                             "Select Email, Role, NoAlerts, ID " & _
                             "From CFAgentUsers " & _
                             "Where CFPROID ='" & CFPROID & "' " &
                             "And Role = 'Super Administrator' "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                    Dim a As Integer
                    Dim drow1 As DataRow
                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, a)
                        If drow1("Email").ToString.Contains("@") Then
                            If Not drow1("NoAlerts") Then
                                SendtoEmailAdress = SendtoEmailAdress & ", " & drow1("Email")
                            End If

                        End If
                        a = a + 1
                    Next

                    SendtoEmailAdress = SendtoEmailAdress


                    'SendtoEmailAdress = "mulela.michael@gmail.com"

                    Dim Subject As String = "C&F Agent Action Center Alerts - " & Format(Now, "dd MMM yyyy") & ": Action Required on C&F PRO"

                    Dim Signature As String = "C&F PRO System"

                    Dim EmailBody As String = clsEmail.CFAgentAlertsEmail(CFAgentLogo, AlertName, NoofJobs, LastProcessed,
                                    Condition, Signature, UserImage, CFAgentName, CFAgentAddress)


                    Dim tmpSendtoEmailAdress() As String = SendtoEmailAdress.Split(",")
                    For a = 0 To tmpSendtoEmailAdress.GetUpperBound(0)
                        If tmpSendtoEmailAdress(a).Contains("@") Then
                            tmpSendtoEmailAdress(a) = Trim(tmpSendtoEmailAdress(a))
                        Else
                            tmpSendtoEmailAdress(a) = ""
                        End If

                    Next

                    Dim SendResult As String = ""

                    SendtoEmailAdress = Join(tmpSendtoEmailAdress, ", ")
                    Call clsEmail.SendEmail(SendtoEmailAdress, Subject, EmailBody, SendtoNames,
                                            CFAgentEmailAddress, CFAgentName, True, CFPROID, SendResult, DefaultEmailServer)

                    If SendResult = "Email Sent!" Then
                        Return "Sent"
                    ElseIf SendResult = "Email Not Sent" Then
                        Return "Not Sent"
                    Else
                        Return SendResult
                    End If
                End If
            End If


        Catch ex As Exception
            Return ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function ProcessClientProgressReportEmail(Optional CFPROID As String = "", Optional ByVal ErrMsg As String = "") As String
        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "And CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  "Where ProcessAlerts = 1 " &
                   tmpstr



            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim a, b, c, d As Integer
            Dim Result As String = ""


            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    clsData.NullChecker(tmptable, d)

                    Dim sqlstr1 As String =
                      "Select ClientID, Client," &
                      "Email, ID " &
                      "From Clients " &
                      "Where CFPROID ='" & drow("CFPROID") & "' "


                    Dim tmptable1 As New DataTable
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                    Dim sqlstr2 As String =
                        "SELECT OwnerID, EmailAddress," &
                        "OwnerType, CFPROID " &
                        "FROM EmailAddresses " &
                        "Where CFPROID ='" & drow("CFPROID") & "' "

                    Dim tmptable2 As New DataTable
                    Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
                    Dim dv2 As New DataView(tmptable2)

                    'get status updates
                    Dim tmptableprogress As DataTable = ClientProgressUpdates(CFPROID, "", "", ErrMsg)
                    Dim dv As New DataView(tmptableprogress)


                    Dim nClientProgressUpdate As String = ""


                    Dim ReportCount As Integer
                    Dim tmpdate As Date = Now
                    tmpdate = tmpdate.AddDays(-2)

                    Dim tmpemailAddresses(0) As String
                    Dim emailaddresses As String = ""

                    For Each drow1 In tmptable1.Rows
                        clsData.NullChecker(tmptable1, a)

                        If Not Trim(drow1("Email")) = "" Then
                            tmpemailAddresses(0) = drow1("Email")


                            dv2.RowFilter = "OwnerID = '" & drow1("ID") & "' " &
                                                  "And OwnerType ='client' "

                            c = 1
                            For b = 0 To dv2.Count - 1
                                clsData.NullChecker1(dv2, b)
                                If Not Trim(dv2(b)("EmailAddress")) = "" Then
                                    ReDim Preserve tmpemailAddresses(c)
                                    tmpemailAddresses(c) = dv2(b)("EmailAddress")
                                    c = c + 1
                                End If

                            Next

                            emailaddresses = Join(tmpemailAddresses, ", ")

                            dv.RowFilter = "ClientID = '" & drow1("ClientID") & "' " &
                                        "And Date >= '" & Format(tmpdate, "dd MMM yyyy") & "' "

                            dv.Sort = "JobDate DESC "

                            If dv.Count > 0 Then
                                'filter  client report
                                nClientProgressUpdate = ClientProgressBody(dv)

                                Call SendClientProgressReportEmail(CFPROID, nClientProgressUpdate, drow1("Client"), emailaddresses, False, Result, ErrMsg)
                                ReportCount = ReportCount + 1

                            End If
                        End If
                        a = a + 1

                    Next

                    Dim sqlstr4 As String =
                                        "SELECT  AlertID, CFPROID," &
                                        "JobCount, LastProcessed," &
                                        "Exclusive, ID " &
                                        "FROM   AccountAlerts " &
                                        "Where CFPROID = '" & CFPROID & "' " &
                                        "And AlertID = '0019' "

                    Dim tmptable4 As New DataTable()
                    Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                    Dim drow4 As DataRow

                    If tmptable4.Rows.Count > 0 Then
                        drow4 = tmptable4.Rows(0)
                    Else
                        drow4 = tmptable4.NewRow
                        drow4("CFPROID") = CFPROID
                        drow4("AlertID") = "0019"
                        drow4("Exclusive") = 1
                        tmptable4.Rows.Add(drow4)
                    End If


                    drow4("CFPROID") = CFPROID
                    drow4("JobCount") = ReportCount
                    drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

                    Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)

                    d = d + 1
                Next

                Return Result
            Else
                Return "No OP"

            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
            Return "Failed"
        End Try

    End Function
    Shared Function SendClientProgressReportEmail(CFPROID As String, ByVal ProgressUpdateBody As String, ClientName As String,
                                             nSendtoEmailAdress As String, DefaultEmailServer As Boolean,
                                            Optional ByRef Result As String = Nothing, Optional ByRef ErrMsg As String = Nothing) As String

        Try

            If clsEmail.SendCFAgentAlerts() Then



                Dim CFAgentLogo As String = ""
                Dim UserImage As String = ""
                Dim CFAgentName As String = ""
                Dim CFAgentAddress As String = ""
                Dim CFAgentEmailAddress As String = ""

                Dim UserEmailAddress As String = ""
                Dim UserNames As String = ""


                If clsSubs.RemoteFileExists("http://cfproonline.com/emails/sentby.png") Then
                    UserImage = "http://cfproonline.com/emails/sentby.png"
                Else
                    UserImage = "http://cfproonline.com/userimages/000000000.png"
                End If


                Dim sqlstr As String =
                "Select CFAgentName, CFAgentAddress," &
                "EmailAddress, LogoURL " &
                "From CFPROAccounts " &
                "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)

                    Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                    ReDim Preserve tmpstr(1)

                    If clsSubs.RemoteFileExists("http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)) Then
                        CFAgentLogo = "http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)
                    Else
                        CFAgentLogo = "http://cfproonline.com/cfagentimages/000000000.png"
                    End If

                    CFAgentName = drow("CFAgentName")
                    CFAgentAddress = drow("CFAgentAddress")
                    CFAgentEmailAddress = drow("EmailAddress")

                End If



                Dim SendtoNames As String = ""

                'nSendtoEmailAdress = CFAgentEmailAddress
                'nSendtoEmailAdress = "mulela.michael@gmail.com"

                Dim Subject As String = "Cargo Status Progress Update: " & Format(Now, "dd MMM yyyy")
                Dim Signature As String = "C&F PRO System"

                Dim Lastprocessed As String = "Processed: " & Format(Now, "dd MMM yyyy hh:mm tt")

                Dim EmailBody As String = clsEmail.ClientProgressReportEmail(CFAgentLogo, ProgressUpdateBody, Lastprocessed,
                                 ClientName, Signature, UserImage, CFAgentName, CFAgentAddress)


                Dim tmpSendtoEmailAdress() As String = nSendtoEmailAdress.Split(",")
                For a = 0 To tmpSendtoEmailAdress.GetUpperBound(0)
                    If tmpSendtoEmailAdress(a).Contains("@") Then
                        tmpSendtoEmailAdress(a) = Trim(tmpSendtoEmailAdress(a))
                    Else
                        tmpSendtoEmailAdress(a) = ""
                    End If

                Next

                Dim SendResult As String = ""

                nSendtoEmailAdress = Join(tmpSendtoEmailAdress, ", ")
                Call clsEmail.SendEmail(nSendtoEmailAdress, Subject, EmailBody, SendtoNames,
                                        CFAgentEmailAddress, CFAgentName, True, CFPROID, SendResult,
                                        DefaultEmailServer, CFAgentEmailAddress)

                If SendResult = "Email Sent!" Then
                    Return "Sent"
                ElseIf SendResult = "Email Not Sent" Then
                    Return "Not Sent"
                Else
                    Return SendResult
                End If

            End If
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function


    Shared Function ClientProgressBody(ByRef dv As DataView, Optional ErrMsg As String = "") As String
        Try
            Dim a As Integer
            Dim rowString As String = ""

            For a = 0 To dv.Count - 1

                rowString = rowString & "<tr>" &
                                "<td  align='left' valign='top'><table width='100%' border='0' cellpadding='0' cellspacing='0'>" &
                                "<tbody><tr>" &
                                "<td width='100'%  valign='top' class='referenceno ' height='25'>" & a + 1 & ".  Reference Nos: " & dv(a)("ReferenceNo") & " </td>" &
                                "</tr>" &
                                "<tr>" &
                               "</tr>" &
                                "<tr>" &
                                "<td valign='bottom' class='headers'>Description of Goods:</td>" &
                                "</tr>" &
                                "<tr>" &
                                "<td valign='top' class='goods' height='30'>" &
                                dv(a)("Goods") &
                                "</td>" &
                                "</tr>" &
                                "<tr>" &
                                "<td  valign='bottom' class='headers'>Latest Update (Less than 3 Days Old):</td>" &
                                "</tr>" &
                                "<tr>" &
                                "<td class='progressreport' height='45' valign='top'>" &
                                dv(a)("Status") & "</td>" &
                                "</tr>" &
                                "<tr>" &
                                "<td valign='bottom' class='items'>Status Date: </td>" &
                                "</tr>" &
                                "<tr>" &
                                "<td  valign='bottom' class='items' >" &
                                dv(a)("StatusDate") & "</td>" &
                    "</tr>" &
                    "<tr>" &
                    "<td><hr align='left' width='100%' size='1' color='#CCCCCC'></td>" &
                    "</tr>" &
                    "</tbody></table></td>" &
                    "</tr>"
            Next



            Return rowString

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function GetActionsFunction(UpdateIdentifier As String) As String
        'Replace this String with the real SQL String for Getting Actions
        Dim sqlstr As String = "SELECT ActionItem FROM Wherever WHERE UpdateIdentifier = '" & UpdateIdentifier & "'"

        Dim tmptable1 As New DataTable
        clsData.TableData(sqlstr, tmptable1, clsData.constr)

        Dim a As Integer = 0
        Dim actionsString As String = ""
        For Each drow1 As DataRow In tmptable1.Rows
            a = a + 1
            actionsString = actionsString & a & ". " & drow1("ActionItem")
            If tmptable1.Rows.Count < a Then
                actionsString = actionsString & "<br/>"
            End If

        Next
        Return actionsString
    End Function


    Shared Function AlertsandJobs(CFPROID As String, ByRef AlertName() As String, ByRef NoofJobs() As String,
                            ByRef LastProcessed() As String, ByRef Condition() As String, Optional AlertID As String = "") As Boolean

        Dim tmpstr As String = ""
        If Not AlertID = "" Then
            tmpstr = "And AccountAlerts.AlertID = '" & AlertID & "' "
        Else
            tmpstr = "AND (AccountAlerts.Exclusive IS NULL  " &
                     "OR AccountAlerts.Exclusive <> 1) "

        End If

        Dim sqlstr As String =
                               "SELECT AlertName,Condition, AccountAlerts.AlertID,  " &
                               "JobCount, LastProcessed " &
                               "FROM   AccountAlerts, Alerts " &
                               "Where CFPROID = '" & CFPROID & "' " &
                               "And AccountAlerts.AlertID = Alerts.AlertID " &
                                tmpstr &
                               "Order By AccountAlerts.AlertID Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        Dim drow As DataRow
        Dim a As Integer
        Dim DoSend As Boolean
        If tmptable.Rows.Count > 0 Then
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ReDim Preserve AlertName(a), NoofJobs(a), LastProcessed(a), Condition(a)
                AlertName(a) = drow("AlertName")
                NoofJobs(a) = drow("JobCount")
                Condition(a) = drow("Condition")
                LastProcessed(a) = "Processed: " & Format(CDate(drow("LastProcessed")), "dd MMM yyyy hh:mm tt")
                a = a + 1
                If drow("JobCount") > 0 Then
                    DoSend = True
                End If
            Next

            Return DoSend
        Else
            Return False
        End If

    End Function

    Shared Function ActionAlerts(CFPROID As String) As String

        Dim sqlstr As String =
                              "SELECT  " &
                              "JobCount " &
                              "FROM   AccountAlerts " &
                              "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim JobCount As Integer
        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            If drow("JobCount") > 0 Then
                JobCount = JobCount + 1
            End If
            a = a + 1
        Next

        If JobCount > 9 Then
            Return "9+"
        Else
            Return JobCount
        End If

    End Function


    Shared Function MessageAlerts(CSDID As String, CFPROID As String) As String
        Return "0"
    End Function

    Shared Function ProcessReceivedJobDocuments(Optional CFPROID As String = "") As String

        Dim ErrMsg As String = ""

        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "Where CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  tmpstr

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call ReceivedJobDocuments(drow("CFPROID"), "", "", "", "", True, ErrMsg)
                a = a + 1
            Next

            Return "Processed"
        Catch ex As Exception
            Return ErrMsg
        End Try

    End Function

    Shared Sub ReceivedJobDocuments(CFPROID As String, JobID As String, JobTypeID As String, ByRef Status As String, ByRef Status1 As String,
                                      SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)
        Try


            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""
            Dim tmpstr2 As String = ""

            If Not JobID = "" Then
                tmpstr = "And Jobs.JobID  = '" & JobID & "' "
                tmpstr1 = "And JobTypeID ='" & JobTypeID & "' "
                tmpstr2 = "And Jobs.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)
                tmpstr = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
                tmpstr2 = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
            End If



            Dim tmpStatus(1) As String
            tmpStatus(0) = ""
            tmpStatus(1) = ""

            Dim sqlstr As String =
                  "Select  JobID, JobTypeID, JobDate, ID  " &
                  "From Jobs " &
                  "Where CFPROID = '" & CFPROID & "' " &
                  tmpstr

            Dim tmptable As New DataTable("Jobs")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)

                Dim sqlstr1 As String =
                          "SELECT DocumentTypeID,JobTypeID " &
                          "From  JobTypeDocuments " &
                          "Where CFPROID ='" & CFPROID & "' " &
                           tmpstr1

                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                Dim sqlstr2 As String =
                        "SELECT  DocumentTypeID,JobDocumentsReceived.JobTypeID, " &
                        "JobDocumentsReceived.JobID " &
                        "FROM JobDocumentsReceived,Jobs " &
                        "Where JobDocumentsReceived.CFPROID ='" & CFPROID & "' " &
                        "And Jobs.CFPROID ='" & CFPROID & "' " &
                        "And JobDocumentsReceived.JobID = Jobs.JobID " &
                        tmpstr2

                Dim tmptable2 As New DataTable()
                Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


                Dim sqlstr2a As String =
                      "SELECT  KPIItemID, KPIProgressUpdates.JobID " &
                      "FROM  KPIProgressUpdates,Jobs " &
                      "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                      "And Jobs.CFPROID = '" & CFPROID & "' " &
                      "And KPIProgressUpdates.JobID = Jobs.JobID " &
                      "And KPIItemID = '000026' " &
                       tmpstr2

                Dim tmptable2a As New DataTable()
                Call clsData.TableData(sqlstr2a, tmptable2a, clsData.constr)

                If Not JobID = "" Then
                    Status = "Received Docs " & tmptable2.Rows.Count & " / " & tmptable1.Rows.Count

                    If tmptable2a.Rows.Count > 0 Then
                        Status1 = "File Closed"
                    Else
                        If tmptable2.Rows.Count = 0 And tmptable1.Rows.Count = 0 Then
                            Status1 = "Not Set"
                        ElseIf tmptable2.Rows.Count < tmptable1.Rows.Count Then
                            Status1 = "Incomplete"
                        Else
                            Status1 = "All Received"
                        End If
                    End If

                Else
                    If SaveAlert Then

                        Dim sqlstr3 As String =
                           "SELECT  AlertID, JobID," &
                           "CFPROID, AlertReason, ID " &
                           "FROM  AlertJobs " &
                           "Where CFPROID ='" & CFPROID & "' " &
                           "And AlertID = '0003' "

                        Dim tmptable3 As New DataTable()
                        Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)

                        Dim JobCount As Integer
                        Dim a As Integer

                        Dim drow3, drow3a As DataRow
                        For a = 0 To tmptable3.Rows.Count - 1
                            drow3 = tmptable3.Rows(a)
                            drow3.Delete()
                        Next

                        a = 0

                        Dim dv1 As New DataView(tmptable1)
                        Dim dv2 As New DataView(tmptable2)
                        Dim dv2a As New DataView(tmptable2a)

                        Dim AlertReason As String = ""

                        For Each drow In tmptable.Rows
                            Call clsData.NullChecker(tmptable, a)


                            dv2a.RowFilter = "JobID = '" & drow("JobID") & "' "

                            If dv2a.Count = 0 Then

                                dv1.RowFilter = "JobTypeID = '" & drow("JobTypeID") & "' "

                                dv2.RowFilter = "JobID = '" & drow("JobID") & "' " &
                                                "And JobTypeID = '" & drow("JobTypeID") & "' "

                                If dv2.Count < dv1.Count Then
                                    AlertReason = "Received " & dv2.Count & " / " & dv1.Count & " Documents"
                                    drow3a = tmptable3.NewRow
                                    drow3a("CFPROID") = CFPROID
                                    drow3a("JobID") = drow("JobID")
                                    drow3a("AlertReason") = AlertReason
                                    drow3a("AlertID") = "0003"
                                    tmptable3.Rows.Add(drow3a)
                                    JobCount = JobCount + 1
                                End If
                            End If
                            a = a + 1
                        Next

                        Dim sqlstr4 As String =
                                "SELECT  AlertID, CFPROID," &
                                "JobCount, LastProcessed,ID " &
                                "FROM   AccountAlerts " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And AlertID = '0003'"

                        Dim tmptable4 As New DataTable()
                        Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                        Dim drow4 As DataRow

                        If tmptable4.Rows.Count > 0 Then
                            drow4 = tmptable4.Rows(0)
                        Else
                            drow4 = tmptable4.NewRow
                            drow4("CFPROID") = CFPROID
                            drow4("AlertID") = "0003"
                            tmptable4.Rows.Add(drow4)
                        End If


                        drow4("CFPROID") = CFPROID
                        drow4("JobCount") = JobCount
                        drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

                        Call clsData.SaveData("AlertJobs", tmptable3, sqlstr3, True, clsData.constr)
                        Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)


                    End If
                End If
            Else
                Status = "Received Docs"
                Status1 = "Not Found"
            End If


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Function ProcessProgressUpdateStatus(Optional CFPROID As String = "") As String

        Try
            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "Where CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  tmpstr

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call ProgressUpdateStatus(drow("CFPROID"), "", "", True)
                a = a + 1
            Next

            Return "Processed"
        Catch ex As Exception
            Return "Failed"
        End Try

    End Function

    Shared Sub ProgressUpdateStatus(CFPROID As String, JobID As String, ByRef Status As String, SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)
        Try


            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""

            If Not JobID = "" Then
                tmpstr = "And JobProgress.JobID = '" & JobID & "' "
                tmpstr1 = "And Jobs.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)
                tmpstr = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
                tmpstr1 = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
            End If


            Dim sqlstr As String = _
                       "Select TOP 1 WITH TIES " &
                       "JobProgress.JobID, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                       "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID " &
                       tmpstr &
                       "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
                       "SELECT   JobID, " &
                       "Jobs.VesselID,  ETA, BerthingDate " &
                       "FROM   Jobs " &
                       "LEFT Join ShippingVessels " &
                       "On Jobs.VesselID = ShippingVessels.VesselID " &
                       "Where Jobs.CFPROID = '" & CFPROID & "' " &
                       "And ShippingVessels.CFPROID = '" & CFPROID & "' " &
                        tmpstr1


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim sqlstr2 As String =
                     "SELECT  KPIItemID, KPIProgressUpdates.JobID " &
                     "FROM  KPIProgressUpdates,Jobs " &
                     "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                     "And Jobs.CFPROID = '" & CFPROID & "' " &
                     "And KPIProgressUpdates.JobID = Jobs.JobID " &
                     "And KPIItemID = '000026' " &
                      tmpstr1

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            Dim tmpdate As Date = Now
            If tmptable.Rows.Count > 0 Then

                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                If Not JobID = "" Then
                    If tmptable2.Rows.Count > 0 Then
                        Status = "File Closed"
                    Else
                        Dim days As Integer = tmpdate.Subtract(CDate(drow("date"))).Days

                        If days < 3 Then
                            Status = "Up to date"
                        ElseIf days >= 3 And days <= 6 Then
                            Status = "Last Update 3+ Days"
                        ElseIf days >= 7 Then
                            Status = "Last Update 7+ Days"
                        End If

                        If days >= 3 Then
                            If tmptable1.Rows.Count > 0 Then
                                Call clsData.NullChecker(tmptable1, 0)
                                Dim drow1 As DataRow = tmptable1.Rows(0)
                                If CDate(drow1("BerthingDate")) = CDate("1-Jan-1800") Then
                                    Dim days1 As Integer = CDate(drow1("ETA")).Subtract(tmpdate).Days
                                    If days1 >= 2 Then
                                        Status = "Not Berthed"
                                    End If
                                End If
                            End If
                        End If
                    End If

                Else
                    If SaveAlert Then

                        Dim dv1 As New DataView(tmptable1)
                        Dim dv2 As New DataView(tmptable2)
                        Dim AlertReason As String = ""

                        Dim sqlstr3 As String =
                           "SELECT  AlertID, JobID," &
                           "AlertReason, CFPROID,ID " &
                           "FROM  AlertJobs " &
                           "Where CFPROID ='" & CFPROID & "' " &
                           "And AlertID = '0001'"

                        Dim tmptable3 As New DataTable()
                        Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)

                        Dim JobCount As Integer = 0
                        Dim a As Integer

                        Dim drow3, drow3a As DataRow
                        For a = 0 To tmptable3.Rows.Count - 1
                            drow3 = tmptable3.Rows(a)
                            drow3.Delete()
                        Next

                        a = 0
                        Dim days, days1 As Integer
                        For Each drow In tmptable.Rows
                            Call clsData.NullChecker(tmptable, a)

                            dv2.RowFilter = "JobID = '" & drow("JobID") & "' "

                            If dv2.Count = 0 Then

                                days = tmpdate.Subtract(CDate(drow("Date"))).Days

                                If days >= 3 Then

                                    dv1.RowFilter = "JobID = '" & drow("JobID") & "' "
                                    AlertReason = "Last Update 3+ Days"

                                    If days >= 7 Then
                                        AlertReason = "Last Update 7+ Days"
                                    End If

                                    If dv1.Count > 0 Then
                                        Call clsData.NullChecker1(dv1, 0)
                                        If CDate(dv1(0)("BerthingDate")) = CDate("1-Jan-1800") Then
                                            days1 = CDate(dv1(0)("ETA")).Subtract(tmpdate).Days
                                            If days1 >= 2 Then
                                                GoTo skipjob
                                            End If
                                        End If
                                    End If
addjob:
                                    drow3a = tmptable3.NewRow
                                    drow3a("CFPROID") = CFPROID
                                    drow3a("JobID") = drow("JobID")
                                    drow3a("AlertReason") = AlertReason
                                    drow3a("AlertID") = "0001"
                                    tmptable3.Rows.Add(drow3a)
                                    JobCount = JobCount + 1

                                End If


skipjob:

                            End If

                            a = a + 1
                        Next

                        Dim sqlstr4 As String =
                                "SELECT  AlertID, CFPROID," &
                                "JobCount, LastProcessed," &
                                 "Exclusive,ID " &
                                "FROM   AccountAlerts " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And AlertID = '0001'"

                        Dim tmptable4 As New DataTable()
                        Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                        Dim drow4 As DataRow

                        If tmptable4.Rows.Count > 0 Then
                            drow4 = tmptable4.Rows(0)
                        Else
                            drow4 = tmptable4.NewRow
                            drow4("CFPROID") = CFPROID
                            drow4("AlertID") = "0001"
                            drow4("Exclusive") = 0
                            tmptable4.Rows.Add(drow4)
                        End If


                        drow4("CFPROID") = CFPROID
                        drow4("JobCount") = JobCount
                        drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

                        Call clsData.SaveData("AlertJobs", tmptable3, sqlstr3, True, clsData.constr)

                        Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)

                    End If
                End If

            Else
                Status = "Not Updated"
            End If



        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub
    Shared Function ProcessMissingShippingInformation(Optional CFPROID As String = "") As String

        Dim ErrMsg As String = ""

        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "Where CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  tmpstr

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call MissingShippingInformation(drow("CFPROID"), "", "", True, ErrMsg)
                a = a + 1
            Next

            Return "Processed"

        Catch ex As Exception
            Return ErrMsg
        End Try

    End Function
    Shared Sub MissingShippingInformation(CFPROID As String, JobID As String, ByRef Status As String, SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)
        Try


            Dim tmpstr As String = ""
            If Not JobID = "" Then
                tmpstr = "And Jobs.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)
                tmpstr = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
            End If



            Dim sqlstr As String =
                            "SELECT  JobID " &
                            "FROM  Jobs " &
                            "Where Jobs.CFPROID = '" & CFPROID & "' " &
                             tmpstr

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
                           "SELECT  JobID,ShippinglineID, " &
                           "Jobs.VesselID,  ETA, BerthingDate,ExitDate " &
                           "FROM  Jobs " &
                           "LEFT Join ShippingVessels " &
                           "On Jobs.VesselID = ShippingVessels.VesselID " &
                           "Where Jobs.CFPROID = '" & CFPROID & "' " &
                           "And ShippingVessels.CFPROID = '" & CFPROID & "' " &
                            tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim sqlstr2 As String =
                           "SELECT  KPIItemID, KPIProgressUpdates.JobID " &
                           "FROM  KPIProgressUpdates,Jobs " &
                           "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                           "And Jobs.CFPROID = '" & CFPROID & "' " &
                           "And KPIProgressUpdates.JobID = Jobs.JobID " &
                           "And KPIItemID = '000026' " &
                            tmpstr

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)



            Dim drow As DataRow
            Dim tmpdate As Date = Now
            Dim days As Integer
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                If Not JobID = "" Then
                    If tmptable2.Rows.Count > 0 Then
                        Status = "File Closed"
                    Else
                        If tmptable1.Rows.Count > 0 Then
                            Call clsData.NullChecker(tmptable1, 0)
                            Dim drow1 As DataRow = tmptable1.Rows(0)

                            If CDate(drow1("ETA")) = CDate("1-Jan-1800") Then
                                Status = "No ETA"
                            ElseIf CDate(drow1("BerthingDate")) = CDate("1-Jan-1800") Then
                                days = tmpdate.Subtract(CDate(drow1("ETA"))).Days
                                If days >= 2 Then
                                    Status = "No Berthing Date"
                                Else
                                    Status = "Up to date"
                                End If

                            ElseIf drow1("ShippingLineID") = "" Then
                                Status = "No Shipping Line"

                            ElseIf CDate(drow1("ExitDate")) = CDate("1-Jan-1800") Then
                                Status = "No Last Sling Date"
                            Else
                                Status = "Up to date"
                            End If
                        Else
                            Status = "Not Updated"
                        End If
                    End If

                Else
                    If SaveAlert Then

                        Dim sqlstr3 As String =
                           "SELECT  AlertID, JobID," &
                           "AlertReason, CFPROID, ID " &
                           "FROM  AlertJobs " &
                           "Where CFPROID ='" & CFPROID & "' " &
                           "And AlertID = '0002' "

                        Dim tmptable3 As New DataTable()
                        Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)

                        Dim JobCount As Integer
                        Dim a As Integer


                        Dim drow3, drow3a As DataRow
                        For a = 0 To tmptable3.Rows.Count - 1
                            drow3 = tmptable3.Rows(a)
                            drow3.Delete()
                        Next

                        a = 0
                        Dim dv1 As New DataView(tmptable1)
                        Dim dv2 As New DataView(tmptable2)

                        Dim AlertReason As String = ""

                        For Each drow In tmptable.Rows
                            Call clsData.NullChecker(tmptable, a)

                            dv2.RowFilter = "JobID = '" & drow("JobID") & "' "
                            If dv2.Count = 0 Then

                                dv1.RowFilter = "JobID = '" & drow("JobID") & "' "

                                If dv1.Count > 0 Then
                                    Call clsData.NullChecker1(dv1, 0)

                                    If CDate(dv1(0)("ETA")) = CDate("1-Jan-1800") Then
                                        AlertReason = "No ETA"
                                    ElseIf CDate(dv1(0)("BerthingDate")) = CDate("1-Jan-1800") Then
                                        days = tmpdate.Subtract(CDate(dv1(0)("ETA"))).Days
                                        If days >= 2 Then
                                            AlertReason = "No Berthing Date"
                                        Else
                                            GoTo skipjob
                                        End If

                                    ElseIf dv1(0)("ShippingLineID") = "" Then
                                        AlertReason = "No Shipping Line"

                                    ElseIf CDate(dv1(0)("ExitDate")) = CDate("1-Jan-1800") Then
                                        AlertReason = "No Last Sling Date"
                                    Else
                                        GoTo skipjob
                                    End If
                                Else
                                    AlertReason = "Not Updated"
                                End If

                                drow3a = tmptable3.NewRow
                                drow3a("CFPROID") = CFPROID
                                drow3a("JobID") = drow("JobID")
                                drow3a("AlertReason") = AlertReason
                                drow3a("AlertID") = "0002"
                                tmptable3.Rows.Add(drow3a)
                                JobCount = JobCount + 1

                            End If
skipjob:
                            a = a + 1
                        Next

                        Dim sqlstr4 As String =
                                "SELECT  AlertID, CFPROID," &
                                "JobCount, LastProcessed," &
                                "Exclusive, ID " &
                                "FROM   AccountAlerts " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And AlertID = '0002'"

                        Dim tmptable4 As New DataTable()
                        Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                        Dim drow4 As DataRow

                        If tmptable4.Rows.Count > 0 Then
                            drow4 = tmptable4.Rows(0)
                        Else
                            drow4 = tmptable4.NewRow
                            drow4("CFPROID") = CFPROID
                            drow4("AlertID") = "0002"
                            drow4("Exclusive") = 0
                            tmptable4.Rows.Add(drow4)
                        End If


                        drow4("CFPROID") = CFPROID
                        drow4("JobCount") = JobCount
                        drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

                        Call clsData.SaveData("AlertJobs", tmptable3, sqlstr3, True, clsData.constr)

                        Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)


                    End If

                End If
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub


    Shared Function ProcessStorageandDemurrage(Optional CFPROID As String = "", Optional ByVal ErrMsg As String = Nothing) As String

        Try
            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "Where CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  tmpstr


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call StorageandDemurrage(drow("CFPROID"), "", "", "", True, ErrMsg)
                a = a + 1
            Next

            Return "Processed"
        Catch ex As Exception
            Return "Failed"
        End Try

    End Function



    Shared Sub StorageandDemurrage(CFPROID As String, JobID As String, ByRef StorageStatus As String,
                                                           ByRef DemurrageStatus As String, SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)
        Try
            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""

            If Not JobID = "" Then
                tmpstr = "And Jobs.JobID = '" & JobID & "' "
                tmpstr1 = "And Jobs.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)

                'Dim nFromDate As Date = CDate(FromDate).AddMonths(-1)
                'FromDate = Format(nFromDate, "dd MMM yyyy hh:mm tt")

                tmpstr = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "
            End If



            Dim sqlstr As String =
                    "Select JobID, " &
                    "ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,CFSID, " &
                    "VesselID, ShippingLineID, " &
                    "JobTypeID,SOC,KeepVisible," &
                    "DispatchDate,JobStatus," &
                    "UserID, ID " &
                    "From Jobs " &
                    "Where CFPROID = '" & CFPROID & "' " &
                     tmpstr


            Dim tmptable As New DataTable("JobsData")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate, CrossBorderDate,ReturnDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID " &
                  tmpstr1

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                      "Select CFSID, CFS, " &
                      "LocalFreeDays, TransitFreeDays,ID " &
                      "From CFS " &
                      "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr7 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)


            Dim drow As DataRow
            Dim a, b, c As Integer


            Dim found As Boolean
            Dim tmpstr3(0) As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
            Dim col20 As New DataColumn("PortExitDate", Type.GetType("System.DateTime"))
            Dim col30 As New DataColumn("CrossBorderDate", Type.GetType("System.DateTime"))

            Dim col10 As New DataColumn("DaysTaken", Type.GetType("System.Double"))


            Dim col16 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))

            Dim col18 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col19 As New DataColumn("ShippingLine", Type.GetType("System.String"))


            Dim col7 As New DataColumn("DemurrageFreeDays", Type.GetType("System.Int32"))
            Dim col11 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
            Dim col28 As New DataColumn("StorageDays", Type.GetType("System.Double"))
            Dim col29 As New DataColumn("StorageFreeDays", Type.GetType("System.Double"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)

            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col16)

            tmptable.Columns.Add(col18)
            tmptable.Columns.Add(col19)
            tmptable.Columns.Add(col20)

            tmptable.Columns.Add(col28)
            tmptable.Columns.Add(col29)
            tmptable.Columns.Add(col30)

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now

            Dim ts, ts1 As TimeSpan

            Dim CrossedBorder As Boolean


            Dim sqlstr4 As String =
                        "SELECT  KPIItemID, KPIProgressUpdates.JobID " &
                        "FROM  KPIProgressUpdates,Jobs " &
                        "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                        "And Jobs.CFPROID = '" & CFPROID & "' " &
                        "And KPIProgressUpdates.JobID = Jobs.JobID " &
                        "And KPIItemID = '000026' " &
                        tmpstr

            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)


            Dim dv As New DataView(tmptable)
            Dim dv4 As New DataView(tmptable4)

            Dim sqlstr8 As String =
                                       "SELECT  AlertID, CFPROID," &
                                       "JobCount, LastProcessed, ID " &
                                       "FROM   AccountAlerts " &
                                       "Where (CFPROID = '" & CFPROID & "') " &
                                       "And (AlertID = '0008' " &
                                       "Or AlertID = '0012') "

            Dim tmptable8 As New DataTable()
            Call clsData.TableData(sqlstr8, tmptable8, clsData.constr)


            Dim drow8, drow8a As DataRow
            For a = 0 To tmptable8.Rows.Count - 1
                drow8 = tmptable8.Rows(a)
                drow8.Delete()
            Next


            Dim sqlstr9 As String =
                       "SELECT  AlertID, JobID," &
                       "AlertReason, CFPROID, ID " &
                       "FROM  AlertJobs " &
                       "Where (CFPROID ='" & CFPROID & "') " &
                       "And (AlertID = '0008' " &
                       "Or AlertID = '0012') "

            Dim tmptable9 As New DataTable()
            Call clsData.TableData(sqlstr9, tmptable9, clsData.constr)



            Dim drow9, drow9a As DataRow
            For a = 0 To tmptable9.Rows.Count - 1
                drow9 = tmptable9.Rows(a)
                drow9.Delete()
            Next

            Dim dv9 As New DataView(tmptable9)


            Dim JobCount, JobCount1 As Integer
            Dim AlertReason, AlertReason1 As String


            a = 0
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                AlertReason = ""
                AlertReason1 = ""

                drow("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")
                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"

                c = 0
                TEU = 0
                CBM = 0
                Weight = 0


                CrossedBorder = True

                If dv1.Count > 0 Then
                    For b = 0 To dv1.Count - 1
                        Call clsData.NullChecker1(dv1, b)
                        c = c + 1

                        If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                            CrossedBorder = False
                        End If
                    Next

                    dv1.Sort = "PortExitDate DESC"

                    drow("PortExitDate") = Format(dv1(0)("PortExitDate"), "dd MMM yyyy")

                    dv1.Sort = "CrossBorderDate DESC"
                    drow("CrossBorderDate") = Format(dv1(0)("CrossBorderDate"), "dd MMM yyyy")

                End If

                drow("CrossedBorder") = CrossedBorder


                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")
                    drow("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), drow("DispatchDate"))
                End If

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")

                    drow("StorageFreeDays") = clsShippingStorage.StorageFreeDays(CFPROID, drow("ClientID"), drow("CFSID"), drow("JobType"), dv2(0)("TransitFreeDays"), dv2(0)("LocalFreeDays"))

                    If CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                        drow("StorageDays") = 0
                    Else
                        dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "' "
                        dv1.Sort = "PortExitDate DESC"

                        If dv1.Count > 0 Then
                            drow("PortExitDate") = dv1(0)("PortExitDate")

                            Call clsData.NullChecker1(dv1, 0)

                            drow("StorageDays") = clsShippingStorage.GetStorageDays(drow("LastSlingDate"), drow("StorageFreeDays"), drow("PortExitDate"), ErrMsg)

                        End If
                    End If

                End If

                found = False



                dv7.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "

                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)

                    drow("ShippingLine") = dv7(0)("ShippingLine")

                    drow("DemurrageFreeDays") = clsShippingStorage.DemurrageFreeDays(CFPROID, drow("ClientID"), drow("ShippingLineID"), drow("JobType"), dv7(0)("TransitReturnDays"), dv7(0)("LocalReturnDays"))


                    If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                        drow("DemurrageDays") = 0
                    Else
                        dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "' "
                            dv1.Sort = "ReturnDate DESC"

                        If dv1.Count > 0 Then
                            drow("ReturnDate") = dv1(0)("ReturnDate")

                            Call clsData.NullChecker1(dv1, 0)

                            drow("DemurrageDays") = clsShippingStorage.GetDemurrageDays(tmptable1, drow("JobID"), drow("BerthingDate"),
                                                drow("ReturnDate"), drow("DemurrageFreeDays"), -1,
                                                drow("SOC"), drow("JobType"), drow("PortExitDate"), drow("CrossBorderDate"), ErrMsg)

                        End If
                    End If

                    End If


                tmpdate = Now
                dv4.RowFilter = "JobID = '" & drow("JobID") & "' "

                If dv4.Count = 0 Then
                    If CDate(drow("VesselETA")) = CDate("1-Jan-1800") Then
                        GoTo skipjob
                    End If

                    ts1 = tmpdate.Subtract(CDate(drow("VesselETA")))


                    If ts1.Days >= 2 Then

                        If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                            AlertReason = "Berthing Date Not Set"
                        Else


                            Dim DemurrageDays As Integer = drow("DemurrageDays")
                            If DemurrageDays > 3 Then

                                GoTo skipjob

                            ElseIf DemurrageDays > 0 And DemurrageDays <= 3 Then
                                AlertReason = "Demurrage Begin In Less Than " & DemurrageDays & " Days "

                            ElseIf DemurrageDays = 0 Then
                                If dv7.Count > 0 Then
                                    AlertReason = "Demurrage Charges Begin Today"
                                Else
                                    AlertReason = "Shipping Line Not Set"
                                End If

                            ElseIf DemurrageDays < 0 Then
                                AlertReason = "Demurrage Charges Incurred for  " & DemurrageDays * -1 & " Days"
                            Else
                                GoTo skipjob
                            End If
                        End If
                    Else
                        GoTo skipjob
                    End If

                    If SaveAlert Then
                        drow9a = tmptable9.NewRow
                        drow9a("CFPROID") = CFPROID
                        drow9a("JobID") = drow("JobID")
                        drow9a("AlertReason") = AlertReason
                        drow9a("AlertID") = "0012"
                        tmptable9.Rows.Add(drow9a)
                        JobCount = JobCount + 1
                    End If

skipjob:


                    If CDate(drow("VesselETA")) = CDate("1-Jan-1800") Then
                        GoTo skipjob1
                    End If

                    If ts1.Days >= 1 Then

                        If CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                            AlertReason1 = "Last Sling Date Not Set"
                        Else

                            Dim StorageDays As Integer = drow("StorageDays")

                            If StorageDays > 3 Then
                                ' AlertReason1 = "Storage Charges Being In " & StorageDays & " Days "
                                GoTo skipjob1

                            ElseIf StorageDays > 0 And StorageDays <= 3 Then
                                AlertReason1 = "Storage Charges Being In Less Than " & StorageDays & " Days "


                            ElseIf StorageDays = 0 Then
                                If dv2.Count > 0 Then
                                    AlertReason1 = "Storage Charges Begin Today"
                                Else
                                    AlertReason1 = "CFS Not Set"
                                End If
                            ElseIf StorageDays < 0 Then
                                AlertReason1 = "Storage Charges Incurred for " & StorageDays * -1 & " Days "
                            Else
                                GoTo skipjob1
                            End If

                        End If
                    Else
                        GoTo skipjob1
                    End If

                    If SaveAlert Then
                        drow9a = tmptable9.NewRow
                        drow9a("CFPROID") = CFPROID
                        drow9a("JobID") = drow("JobID")
                        drow9a("AlertReason") = AlertReason1
                        drow9a("AlertID") = "0008"
                        tmptable9.Rows.Add(drow9a)
                        JobCount1 = JobCount1 + 1
                    End If
                End If

skipjob1:
                a = a + 1

            Next

            'for one job - job entry  smart status
            If Not JobID = "" Then
                If tmptable4.Rows.Count > 0 Then
                    StorageStatus = "File Closed"
                    DemurrageStatus = "File Closed"
                Else
                    If tmptable.Rows.Count > 0 Then
                        Call clsData.NullChecker(tmptable, 0)
                        drow = tmptable.Rows(0)

                        If CDate(drow("VesselETA")) <> CDate("1-Jan-1800") Then
                            ts1 = tmpdate.Subtract(CDate(drow("VesselETA")))

                            If ts1.Days >= 2 Then
                                If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                                    DemurrageStatus = "Berthing Date ?"
                                Else
                                    Dim DemurrageDays As Integer = drow("DemurrageDays")

                                    If DemurrageDays > 3 Then
                                        DemurrageStatus = "In " & DemurrageDays & " Days "

                                    ElseIf DemurrageDays > 0 And DemurrageDays <= 3 Then
                                        DemurrageStatus = "Less Than " & DemurrageDays & " Days "

                                    ElseIf DemurrageDays = 0 Then
                                        If dv7.Count > 0 Then
                                            DemurrageStatus = "Begins Today"
                                        Else
                                            DemurrageStatus = "Shipping line ?"
                                        End If

                                    ElseIf DemurrageDays < 0 Then
                                        DemurrageStatus = DemurrageDays * -1 & " Days Incurred"
                                    End If
                                End If
                            Else
                                DemurrageStatus = "In ETA"
                            End If
                        Else
                            StorageStatus = "No ETA"
                        End If


                        If CDate(drow("VesselETA")) <> CDate("1-Jan-1800") Then
                            ts1 = tmpdate.Subtract(CDate(drow("VesselETA")))
                            If ts1.Days >= 2 Then
                                If CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                                    StorageStatus = "Last Sling ?"
                                Else

                                    Dim StorageDays As Integer = drow("StorageDays")

                                    If StorageDays > 3 Then
                                        StorageStatus = "In " & StorageDays & " Days "

                                    ElseIf StorageDays > 0 And StorageDays <= 3 Then
                                        StorageStatus = "Less Than " & StorageDays & " Days "

                                    ElseIf StorageDays = 0 Then
                                        If dv2.Count > 0 Then
                                            StorageStatus = "Begins Today"
                                        Else
                                            StorageStatus = "CFS ?"
                                        End If
                                    ElseIf StorageDays < 0 Then
                                        StorageStatus = StorageDays * -1 & " Days Incurred"
                                    End If

                                End If
                            Else
                                StorageStatus = "In ETA"
                            End If
                        Else
                            StorageStatus = "No ETA"
                        End If

                    End If
                End If
            Else

                If SaveAlert Then
                    'add demurrage alert

                    drow8a = tmptable8.NewRow
                    drow8a("CFPROID") = CFPROID
                    drow8a("AlertID") = "0012"
                    drow8a("CFPROID") = CFPROID
                    drow8a("JobCount") = JobCount
                    drow8a("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")
                    tmptable8.Rows.Add(drow8a)

                    'add storage alert

                    drow8a = tmptable8.NewRow
                    drow8a("CFPROID") = CFPROID
                    drow8a("AlertID") = "0008"
                    drow8a("CFPROID") = CFPROID
                    drow8a("JobCount") = JobCount1
                    drow8a("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")
                    tmptable8.Rows.Add(drow8a)


                    Call clsData.SaveData("AccountAlerts", tmptable8, sqlstr8, True, clsData.constr)

                    Call clsData.SaveData("AlertJobs", tmptable9, sqlstr9, True, clsData.constr)

                End If
            End If
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Function ProcessCFAgentInvoiceAlertEmails(Optional CFPROID As String = Nothing, Optional ByVal ErrMsg As String = Nothing) As String
        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "And CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  "Where SendInvoiceAlerts = 1 " &
                  tmpstr


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Dim a As Integer

                For Each drow In tmptable.Rows
                    clsData.NullChecker(tmptable, a)
                    ErrMsg = SendCFAgentInvoiceAlertEmail(drow("CFPROID"), False)
                    a = a + 1
                Next

                If a >= tmptable.Rows.Count Then
                    Return "SENT!"
                End If
            Else
                Return "Not Found"
            End If


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
            Return "Failed"
        End Try

    End Function

    Shared Function ProcessCFAgentInvoices(Optional CFPROID As String = "", Optional ByVal ErrMsg As String = Nothing) As String

        Try
            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "And CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  "Where SendInvoiceAlerts = 1 " &
                  "And ProcessAlerts = 1 " &
                   tmpstr



            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call InvoiceAlerts(drow("CFPROID"), "", "", True, ErrMsg)
                a = a + 1
            Next

            Return "Processed"
        Catch ex As Exception
            Return "Failed"
        End Try

    End Function

    Shared Sub InvoiceAlerts(CFPROID As String, JobID As String, ByRef InvoiceStatus As String,
                                                             SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)

        Try

            Dim tmpstr As String = ""

            If Not JobID = "" Then
                tmpstr = "And Jobs.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)

                'Dim tmpdate As Date = CDate(FromDate).AddMonths(-1)
                'FromDate = Format(tmpdate, "dd MMM yyyy hh:mm tt")

                tmpstr = "And Jobs.JobDate >= '" & FromDate & "' And Jobs.JobDate <= '" & ToDate & "' "
            End If


            Dim sqlstr As String =
                "Select  " &
                "JobID,Jobs.ClientID, Client,  " &
                "JobTypeID,BL,ReferenceNo,EntryPassDate, " &
                "ReferenceNo1, JobStatus," &
                "JobDate,Jobs.ID  " &
                "From Jobs,Clients " &
                "Where Jobs.ClientID = Clients.ClientID " &
                "And Jobs.CFPROID = '" & CFPROID & "' " &
                "And Clients.CFPROID  = '" & CFPROID & "' " &
                 tmpstr &
                "Order by Jobs.ID Desc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
                "SELECT InvoiceID, JobInvoiceHeader.JobID," &
                "JobInvoiceHeader.InvoiceNo,Total " &
                "From  Jobs, JobInvoiceHeader " &
                "Where JobInvoiceHeader.JobID = Jobs.JobID   " &
                "And JobInvoiceHeader.CFPROID  = '" & CFPROID & "' " &
                 tmpstr &
                 "Order by JobInvoiceHeader.ID Desc;"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim sqlstr2 As String =
                           "SELECT  KPIItemID, KPIProgressUpdates.JobID " &
                           "FROM  KPIProgressUpdates,Jobs " &
                           "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                           "And Jobs.CFPROID = '" & CFPROID & "' " &
                           "And KPIProgressUpdates.JobID = Jobs.JobID " &
                           "And KPIItemID = '000026' " &
                            tmpstr

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                If Not JobID = "" Then
                    If tmptable2.Rows.Count > 0 Then
                        InvoiceStatus = "File Closed"
                    Else

                        If Not CDate(drow("EntryPassDate")) = CDate("1-Jan-1800") Then
                            Dim dv1 As New DataView(tmptable1)
                            dv1.RowFilter = "JobID = '" & drow("JobID") & "' "

                            If dv1.Count = 0 Then
                                InvoiceStatus = "Not Invoiced"
                            Else
                                dv1.Sort = "Total DESC"
                                Call clsData.NullChecker1(dv1, 0)

                                If dv1(0)("Total") > 0 Then
                                    InvoiceStatus = "Invoiced"
                                Else
                                    InvoiceStatus = "Invoiced 0 Total"
                                End If
                            End If

                        Else
                            InvoiceStatus = "Entry Not Passed"
                        End If
                    End If

                Else
                    If SaveAlert Then

                        Dim sqlstr3 As String =
                           "SELECT  AlertID, JobID," &
                           "AlertReason, CFPROID, ID " &
                           "FROM  AlertJobs " &
                           "Where CFPROID ='" & CFPROID & "' " &
                           "And AlertID = '0015' "

                        Dim tmptable3 As New DataTable()
                        Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)

                        Dim JobCount As Integer
                        Dim a As Integer


                        Dim drow3, drow3a As DataRow
                        For a = 0 To tmptable3.Rows.Count - 1
                            drow3 = tmptable3.Rows(a)
                            drow3.Delete()
                        Next


                        Dim dv1 As New DataView(tmptable1)
                        Dim dv2 As New DataView(tmptable2)

                        Dim AlertReason As String = ""
                        a = 0
                        For Each drow In tmptable.Rows
                            Call clsData.NullChecker(tmptable, a)

                            dv2.RowFilter = "JobID = '" & drow("JobID") & "' "
                            If dv2.Count = 0 Then
                                AlertReason = ""
                                If Not CDate(drow("EntryPassDate")) = CDate("1-Jan-1800") Then

                                    dv1.RowFilter = "JobID = '" & drow("JobID") & "' "

                                    If dv1.Count = 0 Then
                                        AlertReason = "Not Invoiced"
                                    Else

                                        dv1.Sort = "Total DESC "
                                        Call clsData.NullChecker1(dv1, 0)

                                        If dv1(0)("Total") <= 0 Then
                                            AlertReason = "Invoiced 0 Total"
                                        Else
                                            GoTo skipjob
                                        End If
                                    End If

                                Else
                                    GoTo skipjob
                                End If

                                drow3a = tmptable3.NewRow
                                drow3a("CFPROID") = CFPROID
                                drow3a("JobID") = drow("JobID")
                                drow3a("AlertReason") = AlertReason
                                drow3a("AlertID") = "0015"
                                tmptable3.Rows.Add(drow3a)
                                JobCount = JobCount + 1

                            End If
skipjob:
                            a = a + 1
                        Next

                        Dim sqlstr4 As String =
                                "SELECT  AlertID, CFPROID," &
                                "JobCount, LastProcessed," &
                                "Exclusive, ID " &
                                "FROM   AccountAlerts " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And AlertID = '0015' "

                        Dim tmptable4 As New DataTable()
                        Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                        Dim drow4 As DataRow

                        If tmptable4.Rows.Count > 0 Then
                            drow4 = tmptable4.Rows(0)
                        Else
                            drow4 = tmptable4.NewRow
                            drow4("CFPROID") = CFPROID
                            drow4("AlertID") = "0015"
                            drow4("Exclusive") = 1
                            tmptable4.Rows.Add(drow4)
                        End If


                        drow4("CFPROID") = CFPROID
                        drow4("JobCount") = JobCount
                        drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

                        Call clsData.SaveData("AlertJobs", tmptable3, sqlstr3, True, clsData.constr)

                        Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)


                    End If

                End If
            End If

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub



    Shared Function SendCFAgentInvoiceAlertEmail(CFPROID As String, DefaultEmailServer As Boolean) As String

        Try

            If clsEmail.SendCFAgentAlerts() Then
                Dim AlertName(0) As String
                Dim NoofJobs(0) As String
                Dim LastProcessed(0) As String
                Dim Condition(0) As String

                If AlertsandJobs(CFPROID, AlertName, NoofJobs, LastProcessed, Condition, "0015") Then
                    ReDim Preserve AlertName(0)
                    ReDim Preserve NoofJobs(0)
                    ReDim Preserve LastProcessed(0)
                    ReDim Preserve Condition(0)


                    Dim CFAgentLogo As String = ""
                    Dim UserImage As String = ""
                    Dim CFAgentName As String = ""
                    Dim CFAgentAddress As String = ""
                    Dim CFAgentEmailAddress As String = ""

                    Dim UserEmailAddress As String = ""
                    Dim UserNames As String = ""


                    If clsSubs.RemoteFileExists("http://cfproonline.com/emails/sentby.png") Then
                        UserImage = "http://cfproonline.com/emails/sentby.png"
                    Else
                        UserImage = "http://cfproonline.com/userimages/000000000.png"
                    End If


                    Dim sqlstr As String =
                    "Select CFAgentName, CFAgentAddress," &
                    "EmailAddress, LogoURL " &
                    "From CFPROAccounts " &
                    "Where CFPROID = '" & CFPROID & "' "

                    Dim tmptable As New DataTable()
                    Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                    If tmptable.Rows.Count > 0 Then
                        Dim drow As DataRow = tmptable.Rows(0)
                        Call clsData.NullChecker(tmptable, 0)

                        Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                        ReDim Preserve tmpstr(1)

                        If clsSubs.RemoteFileExists("http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)) Then
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)
                        Else
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/000000000.png"
                        End If

                        CFAgentName = drow("CFAgentName")
                        CFAgentAddress = drow("CFAgentAddress")
                        CFAgentEmailAddress = drow("EmailAddress")

                    End If


                    Dim SendtoEmailAdress As String = CFAgentEmailAddress
                    Dim SendtoNames As String = ""



                    Dim sqlstr1 As String =
                             "SELECT  Email, Role, NoAlerts, ID " &
                             "FROM  CFAgentUsers " &
                              "WHERE (CFPROID ='" & CFPROID & "') " &
                              "And (Role = 'Super Administrator') " &
                              "OR (CFPROID ='" & CFPROID & "') " &
                              "And (Department Like '%Account%') "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                    Dim a As Integer
                    Dim drow1 As DataRow
                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, a)
                        If Not Trim(drow1("Email")) = "" Then
                            If Not drow1("NoAlerts") Then
                                SendtoEmailAdress = SendtoEmailAdress & ", " & drow1("Email")
                            End If

                        End If
                        a = a + 1
                    Next


                    ' SendtoEmailAdress = "mulela.michael@gmail.com"

                    Dim Subject As String = "Invoice Alerts (C&F Agent) - " & Format(Now, "dd MMM yyyy") & " : Invoicing Required "

                    Dim Signature As String = "C&F PRO System"

                    Dim EmailBody As String = clsEmail.CFAgentInvoiceAlertEmail(CFAgentLogo, AlertName, NoofJobs, LastProcessed,
                                    Condition, Signature, UserImage, CFAgentName, CFAgentAddress)


                    Dim tmpSendtoEmailAdress() As String = SendtoEmailAdress.Split(",")
                    For a = 0 To tmpSendtoEmailAdress.GetUpperBound(0)
                        If tmpSendtoEmailAdress(a).Contains("@") Then
                            tmpSendtoEmailAdress(a) = Trim(tmpSendtoEmailAdress(a))
                        Else
                            tmpSendtoEmailAdress(a) = ""
                        End If

                    Next

                    Dim SendResult As String = ""

                    SendtoEmailAdress = Join(tmpSendtoEmailAdress, ", ")

                    Call clsEmail.SendEmail(SendtoEmailAdress, Subject, EmailBody, SendtoNames,
                                                     CFAgentEmailAddress, CFAgentName, True, CFPROID,
                                                     SendResult, DefaultEmailServer)

                    If SendResult = "Email Sent!" Then
                        Return "Sent"
                    ElseIf SendResult = "Email Not Sent" Then
                        Return "Not Sent"
                    Else
                        Return SendResult
                    End If
                End If
            End If


        Catch ex As Exception
            Return ex.Message & ex.StackTrace
        End Try
    End Function
    Shared Function ClientProgressUpdates(CFPROID As String, JobID As String,
                             ByRef Status As String, Optional ByRef ErrMsg As String = Nothing) As DataTable
        Try

            Dim tmpstr As String = ""

            If Not JobID = "" Then
                tmpstr = "And JobProgress.JobID = '" & JobID & "' "
            Else
                Dim FromDate As String = ""
                Dim ToDate As String = ""
                Call LastOneMonth(FromDate, ToDate)
                tmpstr = "And Jobs.JobDate >= '" & FromDate & "' And Jobs.JobDate <= '" & ToDate & "' "

            End If


            Dim sqlstr As String =
                       "Select TOP 1 WITH TIES " &
                       "JobProgress.JobID,Jobs.ClientID," &
                       "JobDate,Status, Date," &
                       "ReferenceNo, Goods " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                       "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID " &
                       tmpstr &
                       "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                     "SELECT Top 1 KPIItemID, Jobs.JobID " &
                     "FROM  KPIProgressUpdates,Jobs " &
                     "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                     "And Jobs.CFPROID = '" & CFPROID & "' " &
                     "And KPIProgressUpdates.JobID = Jobs.JobID " &
                     "And ClientID <> '' " &
                     "And KPIItemID = '000026' " &
                      tmpstr



            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim dv1 As New DataView(tmptable1)

            Dim col As New DataColumn("StatusDate", Type.GetType("System.String"))
            tmptable.Columns.Add(col)


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                Dim a As Integer

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    dv1.RowFilter = "JobID = '" & drow("JobID") & "' "
                    If dv1.Count = 0 Then
                        drow("StatusDate") = Format(drow("Date"), "dd MMM yyyy hh:mm tt")
                    Else
                        drow("StatusDate") = ""
                    End If
                Next

            End If


            Return tmptable
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function

    Shared Function GetAlerts(ByVal prefixText As String, ByVal count As Integer) As List(Of String)

        Try
            Dim sqlstr As String =
                     "SELECT  Top 5 AlertName, AlertID " &
                     "FROM Alerts " &
                     "Where AlertName Like  '%' + @SearchText + '%'  " &
                     "Order by AlertName Asc;"

            Dim conn As SqlConnection = New SqlConnection
            Dim connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader

            Dim Command1 As New SqlCommand(sqlstr, connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim ActionAlerts As List(Of String) = New List(Of String)


            While Reader1.Read
                If Not IsDBNull(Reader1("AlertName")) Then
                    ActionAlerts.Add(AjaxControlToolkit.AutoCompleteExtender _
                   .CreateAutoCompleteItem(Reader1("AlertName"), Reader1("AlertID")))
                End If
            End While

            connection1.Close()

            Return ActionAlerts
        Catch ex As Exception

        End Try
    End Function


    Shared Function GetJobs(ByVal prefixText As String, ByVal count As Integer) As List(Of String)

        Try
            Dim CFPROID As String = ""
            Dim AlertID As String = HttpContext.Current.Session("AlertID")

            If Not IsNothing(HttpContext.Current.Request.Cookies("CFAgent")) Then
                Dim nAuthCFAgent As String = HttpContext.Current.Request.Cookies("CFAgent").Value
                Dim tmpstr() As String = nAuthCFAgent.Split("|")
                ReDim Preserve tmpstr(0)
                CFPROID = tmpstr(0)
            End If

            Dim sqlstr As String =
                       "SELECT TOP 5 ReferenceNo, Jobs.JobID " &
                        "FROM Jobs " &
                         "Left Join AlertJobs on Jobs.JobID = AlertJobs.JobID " &
                         "Where Jobs.CFPROID = '" & CFPROID & "'  " &
                         "And AlertJobs.CFPROID = '" & CFPROID & "'  " &
                         "And (ReferenceNo Like  '%' + @SearchText + '%'  " &
                         "Or ReferenceNo1 Like  '%' + @SearchText + '%')  " &
                         "And AlertID ='" & AlertID & "' " &
                         "Order by ReferenceNo Desc;"

            Dim conn As SqlConnection = New SqlConnection
            Dim connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader

            Dim Command1 As New SqlCommand(sqlstr, connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim tmpJobs As List(Of String) = New List(Of String)

            While Reader1.Read

                If Not IsDBNull(Reader1("ReferenceNo")) Then
                    tmpJobs.Add(AjaxControlToolkit.AutoCompleteExtender _
                   .CreateAutoCompleteItem(Reader1("ReferenceNo"), Reader1("JobID")))
                End If

            End While

            connection1.Close()

            Return tmpJobs
        Catch ex As Exception

        End Try


    End Function

    Shared Sub LastOneMonth(ByRef FromDate As String, ByRef ToDate As String)

        Dim tmpstr(12) As String
        tmpstr(1) = "Jan"
        tmpstr(2) = "Feb"
        tmpstr(3) = "Mar"
        tmpstr(4) = "Apr"
        tmpstr(5) = "May"
        tmpstr(6) = "Jun"
        tmpstr(7) = "Jul"
        tmpstr(8) = "Aug"
        tmpstr(9) = "Sep"
        tmpstr(10) = "Oct"
        tmpstr(11) = "Nov"
        tmpstr(12) = "Dec"

        Dim tmpdate, tmpdate1, tmpdate2 As DateTime
        tmpdate = Format(Now, "MMM dd yyyy hh:mm:ss tt")

        Dim a As Integer


        tmpdate = CDate(tmpdate.Date)
        tmpdate2 = tmpdate
        tmpdate = tmpdate.AddMonths(-1)
        a = tmpdate.Month
        tmpdate1 = CDate("1/" & tmpstr(a) & "/" & tmpdate.Year)
        tmpdate1 = tmpdate1.AddDays(tmpdate.Day)
        tmpdate2 = CDate(tmpdate2.Date)
        tmpdate2 = tmpdate2.AddHours(23)
        tmpdate2 = tmpdate2.AddMinutes(59)
        tmpdate2 = tmpdate2.AddSeconds(59)
        tmpdate2 = tmpdate2

        FromDate = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
        ToDate = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

    End Sub

    Shared Function ProcessDetailedVisibilityEmails(Optional CFPROID As String = Nothing) As String
        Try

            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "Where CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  tmpstr


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Dim a, b, c, d, e As Integer

                For Each drow In tmptable.Rows
                    clsData.NullChecker(tmptable, a)


                    Dim sqlstr1 As String =
                          "Select ClientID, Client," &
                          "Email, ID " &
                          "From Clients " &
                          "Where CFPROID ='" & drow("CFPROID") & "' " &
                          "And SendReports = 1 "


                    Dim tmptable1 As New DataTable
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                    Dim sqlstr2 As String =
                          "Select ImporterID, Importer," &
                          "Email, ID " &
                          "From Importers " &
                          "Where CFPROID ='" & drow("CFPROID") & "' " &
                          "And SendReports = 1 "


                    Dim tmptable2 As New DataTable
                    Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


                    Dim sqlstr3 As String =
                        "SELECT OwnerID, EmailAddress," &
                        "OwnerType, CFPROID " &
                        "FROM EmailAddresses " &
                        "Where CFPROID ='" & drow("CFPROID") & "' "

                    Dim tmptable3 As New DataTable
                    Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)

                    Dim dv3 As New DataView(tmptable3)


                    Dim sqlstr4 As String =
                        "SELECT  CFPROID, ClientID," &
                        "ImporterID, AlertID, ID " &
                        "FROM  SendAlerts " &
                        "Where CFPROID ='" & drow("CFPROID") & "' " &
                        "And AlertID = '0020' "

                    Dim tmptable4 As New DataTable()
                    Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
                    Dim dv4 As New DataView(tmptable4)

                    b = 0
                    Dim tmpemailAddresses(0) As String
                    Dim emailAddresses As String = ""
                    Dim FileName As String = ""

                    For Each drow1 In tmptable1.Rows
                        clsData.NullChecker(tmptable1, b)

                        FileName = GetSavedReport(CFPROID, drow1("ClientID"), "Detailed_Visibility_Report")


                        If Not FileName = "" Then
                            If tmptable4.Rows.Count > 0 Then
                                dv4.RowFilter = "ClientID = '" & drow1("ID") & "' "

                                If dv4.Count > 0 Then

                                    If Not Trim(drow1("Email")) = "" Then
                                        tmpemailAddresses(0) = drow1("Email")
                                    End If

                                    dv3.RowFilter = "OwnerID = '" & drow1("ID") & "' " &
                                                  "And OwnerType ='client' "

                                    e = 1
                                    For c = 0 To dv3.Count - 1
                                        clsData.NullChecker1(dv3, c)
                                        If Not Trim(dv3(c)("EmailAddress")) = "" Then
                                            ReDim Preserve tmpemailAddresses(e)
                                            tmpemailAddresses(e) = dv3(c)("EmailAddress")
                                            e = e + 1
                                        End If

                                    Next

                                    emailAddresses = Join(tmpemailAddresses, ", ")

                                    Call SendDetailedVisibilityEmails(drow("CFPROID"), drow1("ClientID"), drow1("Client"), FileName, emailAddresses, False)

                                End If

                            End If
                        End If
                        b = b + 1
                    Next

                    d = 0

                    ReDim tmpemailAddresses(0)
                    emailAddresses = ""

                    For Each drow2 In tmptable2.Rows
                        clsData.NullChecker(tmptable2, d)

                        FileName = GetSavedReport(CFPROID, drow2("ImporterID"), "Detailed_Visibility_Report")
                        If Not FileName = "" Then
                            If tmptable4.Rows.Count > 0 Then

                                dv4.RowFilter = "ImporterID = '" & drow2("ID") & "' "

                                If dv4.Count > 0 Then
                                    If Not Trim(drow2("Email")) = "" Then
                                        tmpemailAddresses(0) = drow2("Email")
                                    End If


                                    dv3.RowFilter = "OwnerID = '" & drow2("ID") & "' " &
                                                  "And OwnerType ='importer' "

                                    e = 1
                                    For c = 0 To dv3.Count - 1
                                        clsData.NullChecker1(dv3, c)
                                        If Not Trim(dv3(c)("EmailAddress")) = "" Then
                                            ReDim Preserve tmpemailAddresses(e)
                                            tmpemailAddresses(e) = dv3(c)("EmailAddress")
                                            e = e + 1
                                        End If
                                    Next

                                    emailAddresses = Join(tmpemailAddresses, ", ")
                                    Call SendDetailedVisibilityEmails(drow("CFPROID"), drow2("ImporterID"), drow2("Importer"), FileName, emailAddresses, False)
                                End If

                            End If
                        End If
                        d = d + 1
                    Next
                    a = a + 1
                Next

                If a >= tmptable.Rows.Count Then
                    Return "SENT!"
                Else
                    Return "Not Found"
                End If
            Else
                Return "Not Found"
            End If


        Catch ex As Exception
            Return "Failed. " & ex.Message & ex.StackTrace

        End Try

    End Function

    Shared Function SendDetailedVisibilityEmails(CFPROID As String, RecipientID As String, RecipientName As String,
                                                 Filename As String, RecipientEmailAddresses As String, DefaultEmailServer As Boolean) As String

        Try

            If clsEmail.SendCFAgentAlerts() Then
                Dim AlertName(0) As String
                Dim NoofJobs(0) As String
                Dim LastProcessed(0) As String
                Dim Condition(0) As String

                If AlertsandJobs(CFPROID, AlertName, NoofJobs, LastProcessed, Condition, "0020") Then
                    ReDim Preserve AlertName(0)
                    ReDim Preserve NoofJobs(0)
                    ReDim Preserve LastProcessed(0)
                    ReDim Preserve Condition(0)


                    Dim CFAgentLogo As String = ""
                    Dim UserImage As String = ""
                    Dim CFAgentName As String = ""
                    Dim CFAgentAddress As String = ""
                    Dim CFAgentEmailAddress As String = ""

                    Dim UserEmailAddress As String = ""
                    Dim UserNames As String = ""


                    If clsSubs.RemoteFileExists("http://cfproonline.com/emails/sentby.png") Then
                        UserImage = "http://cfproonline.com/emails/sentby.png"
                    Else
                        UserImage = "http://cfproonline.com/userimages/000000000.png"
                    End If


                    Dim sqlstr As String =
                    "Select CFAgentName, CFAgentAddress," &
                    "EmailAddress, LogoURL " &
                    "From CFPROAccounts " &
                    "Where CFPROID = '" & CFPROID & "' "

                    Dim tmptable As New DataTable()
                    Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                    If tmptable.Rows.Count > 0 Then
                        Dim drow As DataRow = tmptable.Rows(0)
                        Call clsData.NullChecker(tmptable, 0)

                        Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                        ReDim Preserve tmpstr(1)

                        If clsSubs.RemoteFileExists("http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)) Then
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)
                        Else
                            CFAgentLogo = "http://cfproonline.com/cfagentimages/000000000.png"
                        End If

                        CFAgentName = drow("CFAgentName")
                        CFAgentAddress = drow("CFAgentAddress")
                        CFAgentEmailAddress = drow("EmailAddress")

                    End If



                    If Filename.Contains(Format(Now, "dd_MMM_yyyy")) Then


                        Dim Subject As String = "Detailed Visibility Report " & Format(Now, "dd MMM yyyy") & " - Download"

                        Dim Signature As String = "C&F PRO System"


                        Dim ReportHeader As String = "Detailed Visibility Report"
                        Dim ReportDate As String = "Sent on: " & Format(Now, "dd MMM yyyy")
                        Dim Message As String = "Download Detailed Visibility Report"
                        Dim nActionMessage As String = clsEmail.ActionMessage(CFPROID)


                        Dim Host As String = ""

                        If HttpRuntime.AppDomainAppPath.Contains("CFPRO3") Then
                            Host = "http://localhost:90"

                        ElseIf HttpRuntime.AppDomainAppPath.Contains("L365") Then
                            Host = "http://41.207.81.182:90"

                        ElseIf HttpRuntime.AppDomainAppPath.Contains("cfproonline") Then
                            Host = "http://cfproonline.com"

                        ElseIf HttpRuntime.AppDomainAppPath.Contains("wwwroot") Then
                            Host = "https://cfproonline.azurewebsites.net/"

                        End If

                        Dim Reportlink As String = Host & "/exceldocuments/" & CFPROID & "/" & Filename

                        Dim EmailBody As String = clsEmail.DetailedVisibilityEmail(CFAgentLogo, UserImage, ReportHeader, RecipientName,
                                              nActionMessage, Message, Reportlink, Signature, CFAgentName, CFAgentAddress, ReportDate)



                        Dim SendResult As String = ""

                        Call clsEmail.SendEmail(RecipientEmailAddresses, Subject, EmailBody, RecipientName,
                                                         CFAgentEmailAddress, CFAgentName, True, CFPROID, SendResult,
                                                         DefaultEmailServer, CFAgentEmailAddress)




                        If SendResult = "Email Sent!" Then
                            Return "Sent"
                        ElseIf SendResult = "Email Not Sent" Then
                            Return "Not Sent"
                        Else
                            Return SendResult
                        End If

                    End If
                Else
                    Return "Not Sent"
                End If
            End If


        Catch ex As Exception
            Return ex.Message & ex.StackTrace
        End Try
    End Function




    Shared Function ProcessDetailedVisibilityReports(Optional CFPROID As String = "", Optional ByVal ErrMsg As String = Nothing) As String

        Try
            Dim tmpstr As String = ""

            If Not CFPROID = "" Then
                tmpstr = "And CFPROID ='" & CFPROID & "' "
            End If

            Dim sqlstr As String =
                  "Select CFPROID, ID " &
                  "From CFPROAccounts " &
                  "Where ProcessAlerts = 1 " &
                   tmpstr

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                Call DetailedVisibilityReports(drow("CFPROID"), True, ErrMsg)
                a = a + 1
            Next

            Return "Processed"
        Catch ex As Exception
            Return "Failed"
        End Try

    End Function

    Shared Sub DetailedVisibilityReports(CFPROID As String, SaveAlert As Boolean, Optional ByRef ErrMsg As String = Nothing)

        Try

            Dim tmpstr As String = ""

            Dim FromDate As String = ""
            Dim ToDate As String = ""
            Call LastOneMonth(FromDate, ToDate)

            Dim tmpdate As Date = CDate(FromDate).AddMonths(-3)
            FromDate = Format(tmpdate, "dd MMM yyyy hh:mm tt")

            tmpstr = "And Jobs.JobDate >= '" & FromDate & "' And Jobs.JobDate <= '" & ToDate & "' "




            Dim dv As DataView

            If CFPROID = "CFPR000000272-80" Then

                dv = clsAGLDetailedVisibilityReport.LoadJobs(CFPROID, "Last 3 Months", False,
                                                FromDate, ToDate, "Open + Jobs Kept Visible", 1000, "Z-A",
                                                                  0, False, "", ErrMsg)

            Else
                dv = clsDetailedVisibilityReport.LoadJobs(CFPROID, "Last 3 Months", False,
                                                FromDate, ToDate, "Open + Jobs Kept Visible", 1000, "Z-A",
                                                                  0, False, "", ErrMsg)
            End If





            Dim tmptable As DataTable = dv.Table

            Dim b, d As Integer

            Dim sqlstr1 As String =
                      "Select ClientID, Client," &
                      "Email, ID " &
                      "From Clients " &
                      "Where CFPROID ='" & CFPROID & "' " &
                      "And SendReports = 1 "


            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim sqlstr2 As String =
                  "Select ImporterID, Importer," &
                   "Email, ID " &
                  "From Importers " &
                  "Where CFPROID ='" & CFPROID & "' " &
                  "And SendReports = 1 "


            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim sqlstr3 As String =
                    "SELECT  CFPROID, ClientID," &
                    "ImporterID, AlertID, ID " &
                    "FROM  SendAlerts " &
                    "Where CFPROID ='" & CFPROID & "' " &
                    "And AlertID = '0020' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)

            b = 0

            Dim tmpfilter(1) As String


            Dim ReportCount As Integer


            Dim FileName As String = ""
            For Each drow1 In tmptable1.Rows
                clsData.NullChecker(tmptable1, b)

                If tmptable3.Rows.Count > 0 Then

                    dv3.RowFilter = "ClientID = '" & drow1("ID") & "' "

                    If dv3.Count > 0 Then

                        tmpfilter = clsDetailedVisibilityReport.FilterDetailedReport(True, drow1("ClientID"),
                                                                                         drow1("Client"), False, "", "", False, True, True)

                        dv.RowFilter = tmpfilter(0)

                        If dv.Count > 0 Then

                            ReDim Preserve tmpfilter(1)
                            FileName = "Detailed_Visibility_Report_" & drow1("ClientID") & "_" & Format(Now, "dd_MMM_yyyy_HH_mm")


                            Dim tmptotals() As String = clsDetailedVisibilityReport.Calctotal(dv, tmpfilter(1), "Last 3 Months",
                                                                                               FromDate, ToDate, ErrMsg)
                            ReDim Preserve tmptotals(4)


                            Call clsDetailedVisibilityReport.ExportToExcel(CFPROID, "", tmptotals(0), tmptotals(1),
                                                                               tmptotals(2), tmptotals(3), tmpfilter(0), "", tmptotals(4), dv, True, FileName, ErrMsg)

                            Call SaveReportToLog(CFPROID, drow1("ClientID"), FileName & ".xlsx", "Detailed_Visibility_Report")

                            ReportCount = ReportCount + 1

                        End If
                    End If

                End If
                b = b + 1
            Next

            d = 0

            For Each drow2 In tmptable2.Rows
                clsData.NullChecker(tmptable1, d)

                If tmptable3.Rows.Count > 0 Then

                    dv3.RowFilter = "ImporterID = '" & drow2("ID") & "' "

                    If dv3.Count > 0 Then

                        tmpfilter = clsDetailedVisibilityReport.FilterDetailedReport(False, "",
                        "", True, drow2("ImporterID"), drow2("Importer"), False, True, True)
                        FileName = "Detailed_Visibility_Report_" & drow2("ImporterID")

                        dv.RowFilter = tmpfilter(0)
                        If dv.Count > 0 Then

                            ReDim Preserve tmpfilter(1)

                            Dim tmptotals() As String = clsDetailedVisibilityReport.Calctotal(dv, tmpfilter(1), "Last 3 Months",
                                                                                              FromDate, ToDate, ErrMsg)
                            ReDim Preserve tmptotals(4)

                            FileName = "Detailed_Visibility_Report_" & drow2("ImporterID") & "_" & Format(Now, "dd_MMM_yyyy_HH_mm")

                            Call clsDetailedVisibilityReport.ExportToExcel(CFPROID, "", tmptotals(0), tmptotals(1),
                                                                           tmptotals(2), tmptotals(3), tmpfilter(0), "",
                                                                           tmptotals(4), dv, True, FileName, ErrMsg)

                            Call SaveReportToLog(CFPROID, drow2("ImporterID"), FileName & ".xlsx", "Detailed_Visibility_Report")
                            ReportCount = ReportCount + 1
                        End If
                    End If

                End If
                d = d + 1
            Next

            Dim sqlstr4 As String =
                                "SELECT  AlertID, CFPROID," &
                                "JobCount, LastProcessed," &
                                "Exclusive, ID " &
                                "FROM   AccountAlerts " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And AlertID = '0020' "

            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim drow4 As DataRow

            If tmptable4.Rows.Count > 0 Then
                drow4 = tmptable4.Rows(0)
            Else
                drow4 = tmptable4.NewRow
                drow4("CFPROID") = CFPROID
                drow4("AlertID") = "0020"
                drow4("Exclusive") = 1
                tmptable4.Rows.Add(drow4)
            End If


            drow4("CFPROID") = CFPROID
            drow4("JobCount") = ReportCount
            drow4("LastProcessed") = Format(Now, "dd MMM yyyy hh:mm tt")

            Call clsData.SaveData("AccountAlerts", tmptable4, sqlstr4, False, clsData.constr)


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub



    Shared Sub SaveReportToLog(CFPROID As String, OwnerID As String, FileName As String, ReportType As String)

        Dim sqlstr As String =
            "SELECT  CFPROID, OwnerID," &
            "ReportName, ReportType," &
            "DateCreated,Sent,ID " &
            "FROM  ReportCreationLog " &
            "Where CFPROID = '" & CFPROID & "' " &
            "And OwnerID = '" & OwnerID & "' " &
            "And ReportType = '" & ReportType & "' " &
            "And Sent = 0 " &
            "Order By DateCreated Desc; "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)
        Else
            drow = tmptable.NewRow
            drow("CFPROID") = CFPROID
            drow("OwnerID") = OwnerID
            drow("ReportType") = ReportType
            drow("Sent") = 0
            tmptable.Rows.Add(drow)
        End If

        drow("ReportName") = FileName
        drow("DateCreated") = Format(Now, "dd-MMM-yyyy hh:mm:ss tt")
        Call clsData.SaveData("ReportCreationLog", tmptable, sqlstr, False, clsData.constr)
    End Sub


    Shared Function GetSavedReport(CFPROID As String, OwnerID As String, ReportType As String) As String

        Dim sqlstr As String =
            "SELECT  Top 1 ReportName," &
            "Sent, ID " &
            "FROM  ReportCreationLog " &
            "Where CFPROID = '" & CFPROID & "' " &
            "And OwnerID = '" & OwnerID & "' " &
            "And ReportType = '" & ReportType & "' " &
            "And ReportName Like '%" & OwnerID & "_" & Format(Now, "dd_MMM_yyyy") & "%' " &
            "And Sent = 0 " &
            "Order By DateCreated Desc; "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)

            If drow("Sent") = 0 Then
                drow("Sent") = 1
                Call clsData.SaveData("ReportCreationLog", tmptable, sqlstr, False, clsData.constr)
                Return drow("ReportName")
            Else
                Return ""
            End If

        Else
            Return ""
        End If

    End Function



End Class
