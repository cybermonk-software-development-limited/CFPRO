﻿Imports System.Net

Public Class cfprocfagentprofile
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            Call clsAuth.UserLoggedIn(LabelUserCSDID.Text, "", "", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, "", False)
            Call LoadCFAgentProfile(Request.QueryString("usertype"), LabelUserCSDID.Text)
        End If

    End Sub


    Private Sub LoadCFAgentProfile(UserType As String, CFPROAgentCSDID As String)
        Try
            Dim sqlstr As String = _
                "Select CFPROAccountConnect.CFAgentCFPROID, CFAgentName," & _
                "CFAgentAddress,CFPROUserID,UserCSDID, " & _
                "UserType, DateAdded " & _
                "FROM CFPROAccountConnect, CFPROAccount  " & _
                "Where  CFPROAccountConnect.CFAgentCFPROID = CFPROAccount.CFAgentCFPROID " & _
                "And  CFPROAccountConnect.UserCSDID = '" & CFPROAgentCSDID & "' " & _
                "And CFPROAccountConnect.Usertype = '" & UserType & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("Destination", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ImageURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Added", Type.GetType("System.String"))
            Dim col3 As New DataColumn("AuthDet", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)

            Dim a As Integer



            Dim imageurl As String = ""
            For Each drow In tmptable.Rows
                clsSubs.NullChecker(tmptable, a)

                If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentCFPROID") & ".jpg") Then
                    imageurl = "~/cfagentimages/" & drow("CFAgentCFPROID") & ".jpg"
                ElseIf IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentCFPROID") & ".png") Then
                    imageurl = "~/cfagentimages/" & drow("CFAgentCFPROID") & ".png"
                Else
                    imageurl = "~/cfagentimages/000000000.png"
                End If

                drow("ImageURL") = imageurl


                drow("AuthDet") = drow("CFAgentCFPROID") & "|" & drow("CFAgentName") & "|" & drow("CFPROUserID") & "|" & UserType
                drow("Added") = "Added -" & Format(drow("DateAdded"), "dd MMM yyyy")
                a = a + 1
            Next

           
            DataList1.DataSource = tmptable
            DataList1.DataBind()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Private Sub LoadKeyContacts()

    End Sub
    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub


    Private Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "selected" Then
            Call SetAgent(e.CommandArgument)
        End If
    End Sub

    Private Sub SetAgent(AuthDet As String)

        Response.Cookies("CFAgent").Value = AuthDet
        Response.Cookies("CFAgent").Expires = Now.AddHours(94)

        Dim tmpstr() As String = AuthDet.Split("|")
        ReDim Preserve tmpstr(3)
        Dim UserType As String = tmpstr(3)


        Dim importerdashboard As String = Request.QueryString("importerdashboard")
        If UserType = "importer" Then
            If importerdashboard = "normal" Then
                Response.Redirect("actioncenter.aspx?usertype=" & UserType)
            Else
                Response.Redirect("importerdashboard1.aspx")
            End If

        ElseIf UserType = "staff" Then
            Response.Redirect("actioncenter.aspx?usertype=" & UserType)
        End If


    End Sub



End Class