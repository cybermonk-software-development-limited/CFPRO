﻿Imports System.IO

Public Class progresskpiupdate
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim OpenDirect As Integer = 0
            If Request.QueryString("opendirect") = "yes" Then
                OpenDirect = 1
            End If

            LabelOpenDirect.Text = OpenDirect
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim JobID As String = ""


            If Not IsNothing(Request.QueryString("jobid")) Then
                JobID = Request.QueryString("jobid")
            End If


            Dim PolicyID As String = ""

            If Not IsNothing(Request.QueryString("policyid")) Then
                PolicyID = Request.QueryString("policyid")
            End If

            Dim AuthAgent As Boolean

            If Not IsNothing(Request.Cookies("UserType")) Then
                If Request.Cookies("UserType").Value = "cfagent" Then
                    AuthAgent = True
                End If

                If Request.Cookies("UserType").Value = "importer" Then
                    AuthAgent = True
                End If
            End If

            Dim MarineCargo As Integer = 0

            If Not IsNothing(Request.QueryString("marinecargo")) Then
                MarineCargo = Request.QueryString("marinecargo")
            End If



            Dim CFPROID As String = ""

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, "", "", "", "", "", AuthAgent, "", False, MarineCargo)

            LabelCFPROID.Text = CFPROID
            LabelJobID.Text = JobID
            LabelPolicyID.Text = PolicyID

            Dim DocumentType As String = ""
            Dim DocumentPurpose As String = ""
            Dim Insurance As Integer = 0

            If Not JobID = "" Then
                DocumentType = "jobdocuments"
            ElseIf Not PolicyID = "" Then
                DocumentType = "insurance"
                DocumentPurpose = "policy"
                Insurance = 1
            End If

            LabelDocumentType.Text = DocumentType
            LabelDocumentPurpose.Text = DocumentPurpose


            Call clsDocuments.LoadDocumentTypes(ComboDocumentType, Insurance, DocumentPurpose, LabelMessage1.Text)
            Call clsDocuments.LoadDocuments(CFPROID, JobID, "", PolicyID, DataList1, "", LabelDocumentsCaption.Text, DocumentPurpose, DocumentType, LabelMessage1.Text, OpenDirect)


        End If
    End Sub


    Protected Sub ButtonImportDocument_Click(sender As Object, e As EventArgs) Handles ButtonAddDocument.Click
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call clsDocuments.FileUpload(LabelCFPROID.Text, LabelJobID.Text, "", LabelPolicyID.Text, FileUpload1, TodaysDate.Value, ModalPopupExtender1,
                                           ComboDocumentType, LabelAttachmentMessage, LabelDocumentsCaption.Text,
                                              DataList1, LabelCSDID.Text, LabelCFPROUserID.Text, LabelDocumentPurpose.Text,
                                              LabelDocumentType.Text, LabelMessage1.Text, LabelOpenDirect.Text)
    End Sub


    Protected Sub ComboDocumentType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDocumentType.SelectedIndexChanged
        If ComboDocumentType.SelectedIndex > 0 Then
            LabelAttachmentMessage.Text = "Browse to File & Click 'Upload' (3MB max .pdf .xls/xlsx .doc/docx .jpg & .png format only)"
            LabelAttachmentMessage.ForeColor = Drawing.Color.Black
            ModalPopupExtender1.Show()
        End If
    End Sub

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Call ShowItem(sender)

    End Sub

    Private Sub ShowItem(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            If link.Visible Then
                Dim tmpstr As String = link.CommandArgument
                HyperLink1.NavigateUrl = tmpstr
                iframe1.Attributes("src") = tmpstr
                ModalPopupExtender2.Show()
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    



End Class