﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing
Public Class cargoclearingperformance
    Inherits System.Web.UI.Page
    Friend Shared TableFilter As DataTable
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            If Not IsPostBack Then

                If clsData.constr = "" Then
                    clsData.constr = clsEncr.constr
                End If

                Dim CFAgentCFPROID As String = ""
                Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFAgentCFPROID, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

                LabelCFAgentCFPROID.Text = CFAgentCFPROID

                Call LoadAgents(CFAgentCFPROID)
                Call LoadClients(CFAgentCFPROID)
                Call LoadImporters(CFAgentCFPROID)
                Call LoadShippers(CFAgentCFPROID)
                Call LoadCFAgentUsers(CFAgentCFPROID)
                Call LoadVesselStatus(CFAgentCFPROID)
                Call LoadJobStatuses(CFAgentCFPROID)
                Call LoadJobTypes(CFAgentCFPROID)
                Call LoadCFS(CFAgentCFPROID)
                Call LoadJobTypes(CFAgentCFPROID)

                ComboPredefine.SelectedIndex = 5

                Call PreDefine(ComboPredefine.Text, CFAgentCFPROID)
                LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
            End If

        End If



    End Sub

    Private Sub LoadClearingPerformance(AllCargo As Boolean, ByVal selectClients As Boolean, ByVal selectAgents As Boolean,
                                           dispatchdate As Boolean, ApplyDates As Boolean, CFAgentCFPROID As String)


        Dim SortBy As String = nSortOrder()



        Dim tmpstr0, tmpstr1 As String
        Dim tmpstrdate1, tmpstrdate2 As String

        Dim tmpdatecri As String

        If ApplyDates Then


            Dim tmpid As Integer = -1

            tmpstrdate1 = "'" & TextFromDate.Text & "' "
            tmpstrdate2 = "'" & TextToDate.Text & "' "
            If Not AllCargo Then
                tmpdatecri = "JobCargo.PortExitDate >= " & tmpstrdate1 & _
                         " And JobCargo.PortExitDate <= " & tmpstrdate2

            Else
                tmpdatecri = "JobCargo.ID >= " & tmpid

            End If
        End If


        Select Case ComboLoadedJobs.Text
            Case "Active Jobs"
                tmpstr0 = " Jobs.JobStatus <> '" & "Closed" & "' " & _
                                       " And " & tmpdatecri

            Case "Active + Closed Jobs"
                tmpstr0 = tmpdatecri


            Case "Closed Jobs"
                tmpstr0 = " Jobs.JobStatus = '" & "Closed" & "' " & _
                                       " And " & tmpdatecri
            Case "Jobs Kept Visible"

                tmpstr0 = "  Jobs.KeepVisible = 1 "


        End Select


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC;"
        Else
            tmpstrSort = " ASC;"
        End If


        If SortBy = "JobDate" Then
            tmpstr1 = " ORDER BY  Jobs.JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            tmpstr1 = " ORDER BY  Jobs.ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            tmpstr1 = " ORDER BY  Jobs.JobId " & tmpstrSort
        End If

        Dim tmpstr As String = " And " & tmpstr0 & _
            tmpstr1


        Dim sqlstr As String = _
            "Select JobCargo.JobId," & _
            "JobCargo.ContainerNo,Payload," & _
            "JobCargo.PortExitDate,JobCargo.CrossBorderDate," & _
            "JobCargo.DestinationArrivalDate," & _
            "Jobs.JobDate,ReferenceNo," & _
            "ReferenceNo1,DocumentsReceivedDate," & _
            "Jobs.Client,Jobs.JobStatus," & _
            "Jobs.BL,Jobs.ShippingVessel," & _
            "Jobs.VoyageNo,Jobs.JobType, Jobs.Importer," & _
            "ShippingLine, CFS, Shipper, Agent, " & _
            "Jobs.BerthingDate, Jobs.Destination " & _
            "From JobCargo, Jobs " & _
            "Where JobCargo.JobId  = Jobs.JobId " & _
            tmpstr

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        Dim col1 As New DataColumn("DaysToPortExit", Type.GetType("System.String"))
        Dim col2 As New DataColumn("TotalDaysTaken", Type.GetType("System.String"))
        Dim col3 As New DataColumn("DocsLate", Type.GetType("System.Boolean"))

        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)

        Dim ts, ts1 As TimeSpan
        Dim tmpdate3, tmpdate4, tmpdate5 As Date

        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)


            Dim tmpstr5() As String = drow("Importer").ToString.Split(vbCrLf)
            ReDim Preserve tmpstr5(0)
            drow("Importer") = tmpstr5(0)

            If Not CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                If Not CDate(drow("DocumentsReceivedDate")) = CDate("1-Jan-1800") Then

                    If CDate(drow("BerthingDate")) >= CDate(drow("DocumentsReceivedDate")) Then
                        tmpdate3 = drow("BerthingDate")
                    Else
                        drow("DocsLate") = CBool(1)
                        tmpdate3 = drow("DocumentsReceivedDate")
                    End If

                    If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                        tmpdate4 = drow("PortExitDate")
                        ts = tmpdate4.Subtract(tmpdate3)
                        drow("DaysToPortExit") = ts.TotalDays
                    Else
                        drow("DaysToPortExit") = "N/A"
                    End If

                    If Not CDate(drow("DestinationArrivalDate")) = CDate("1-Jan-1800") Then
                        tmpdate5 = drow("DestinationArrivalDate")

                        ts1 = tmpdate5.Subtract(tmpdate3)

                        drow("TotalDaysTaken") = ts1.TotalDays
                    Else
                        drow("TotalDaysTaken") = "N/A"
                    End If
                Else
                    drow("DaysToPortExit") = "N/A"
                    drow("TotalDaysTaken") = "N/A"
                End If
            Else
                drow("DaysToPortExit") = "N/A"
                drow("TotalDaysTaken") = "N/A"
            End If

        Next

        Dim dv As New DataView(tmptable)
        dv.AllowDelete = False
        dv.AllowNew = False

        GridJobCargo.DataSource = dv

        LabelReportCaption.Text = "Clearing perfomance  Report " & dv.Count & " Cargo Items | PORT EXIT DATE: " & TextFromDate.Text & " - " & TextToDate.Text

    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobId"
        Else
            Return "JobDate"
        End If
    End Function
    Private Sub LoadAgents(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Client,ClientID From Clients " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "And IsAgent = 1" &
        "Order By Client Asc; "

        Call clsData.PopComboWithValue(ComboAgents, sqlstr, clsData.constr, 0, 1)
        ComboAgents.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadClients(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Client,ClientID From Clients " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By Client Asc; "


        Call clsData.PopComboWithValue(ComboClients, sqlstr, clsData.constr, 0, 1)
        ComboClients.Items.Insert(0, "(All)")
        ComboClients.Items.Insert(0, "(Selected Clients)")
    End Sub

    Private Sub LoadImporters(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Importer,ImporterID From Importers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By Importer Asc;"

        Call clsData.PopComboWithValue(ComboImporters, sqlstr, clsData.constr, 0, 1)
        ComboImporters.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadShippers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopComboWithValue(ComboCFAgentUsers, sqlstr, clsData.constr, 0, 1)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatuses(CFAgentCFPROID As String)
        Dim sqlstr As String =
         "Select Status, StatusID " &
         "From JobStatuses "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 1)
        ComboJobStatus.Items.Insert(0, "(All)")
    End Sub


    Private Sub LoadJobTypes(CFAgentCFPROID As String)
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes " &
         "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' "


        Call clsData.PopCombo(ComboJobType, sqlstr, clsData.constr, 0)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFAgentCFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFAgentCFPROID = '" & CFAgentCFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridJobCargo.SelectedValue Is Nothing Then
            LabelMessage3.ForeColor = Color.Tomato
            LabelMessage3.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobCargo.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobCargo.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()
        'Dim a As Integer = GridJobCargo.SelectedValue.ToString
        'Dim selected As Boolean
        'If a >= 0 Then
        '    selected = GridJobCargo.SelectedIndex
        'End If

        Call ClearFilters()
        Call LoadClearingPerformance(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, False, LabelCFAgentCFPROID.Text)


        '  GridJobCargo.SelectedIndex = a

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFAgentCFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadClearingPerformance(True, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, False, CFAgentCFPROID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 3 months"

                    Dim tmpstr(12) As String
                    tmpstr(1) = "Jan"
                    tmpstr(2) = "Feb"
                    tmpstr(3) = "Mar"
                    tmpstr(4) = "Apr"
                    tmpstr(5) = "May"
                    tmpstr(6) = "Jun"
                    tmpstr(7) = "Jul"
                    tmpstr(8) = "Aug"
                    tmpstr(9) = "Sep"
                    tmpstr(10) = "Oct"
                    tmpstr(11) = "Nov"
                    tmpstr(12) = "Dec"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadClearingPerformance(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, False, CFAgentCFPROID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadClearingPerformance(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked, True, LabelCFAgentCFPROID.Text)
    End Sub

    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Qty = Qty + drow("Quantity")
                Weight = Weight + drow("Weight")
                CBM = CBM + drow("CBM")
                TEU = TEU + drow("TEU")
                a = a + 1
            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            If LabelReportCaption.Text = "" And tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = tmptable.Rows.Count & " Jobs: " &
                                     TextFromDate.Text & " | " & tmpstr
                Else
                    LabelReportCaption.Text = tmptable.Rows.Count & " DISPATCHED JOBS: " &
                                     TextFromDate.Text & " | " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = tmptable.Rows.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelReportCaption.Text = tmptable.Rows.Count & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFAgentCFPROID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer
            Dim dv As DataView = New DataView(TableFilter)
            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & ComboAgents.SelectedValue & "' "
                tmpstr1(a) = "Agent: " & ComboAgents.SelectedItem.ToString
                b = b + 1

            End If


            If Client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & ComboClients.SelectedValue & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & ComboClients.SelectedValue & "' "
                End If

                tmpstr1(a) = "Client: " & ComboClients.SelectedItem.ToString
                b = b + 1


            End If

            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & ComboImporters.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & ComboImporters.SelectedValue & "' "
                End If

                tmpstr1(a) = "Consignee: " & ComboImporters.SelectedItem.ToString
                b = b + 1
            End If

            If Shipper Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                b = b + 1
            End If

            If ShipStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipStatus Like " & "'%" & ComboVesselStatus.Text & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like " & "'%" & ComboVesselStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                b = b + 1
            End If

            If JobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobType Like " & "'" & ComboJobType.Text & "%' "
                Else
                    tmpstr(a) = " And JobType Like " & "'" & ComboJobType.Text & "%' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.Text
                b = b + 1
            End If

            If JobStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "StatusID = " & "'" & ComboJobStatus.SelectedValue & "' "
                Else
                    tmpstr(a) = " And StatusID = " & "'" & ComboJobStatus.SelectedValue & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                b = b + 1
            End If


            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If

            'If EntensionRequested Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
            '    Else
            '        tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
            '    End If

            '    tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
            '    b = b + 1
            'End If

            If OmitDispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "StatusID <> '" & "0011b" & "' "
                Else
                    tmpstr(a) = " And StatusID <> '" & "0011b" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                b = b + 1
            End If


            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "StatusID <> '" & "0012b" & "' "
                Else
                    tmpstr(a) = " And StatusID <> '" & "0012b" & "' "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If

            If CustomsSystem Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                b = b + 1
            End If



            If CFAgentUser Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)

                If b = 0 Then




                    tmpstr(a) = "UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                Else
                    tmpstr(a) = " And UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                b = b + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")


            dv.RowFilter = tmpstr2
            GridJobCargo.DataSource = dv
            GridJobCargo.DataBind()

            If Not CheckDispatchDate.Checked Then
                LabelReportCaption.Text = dv.Count & " Jobs: " & tmpstr3 & " | " & TextFromDate.Text & " to " & TextToDate.Text & ""
            Else
                LabelReportCaption.Text = dv.Count & " DISPATCHED Jobs: " & tmpstr3 & " | " & TextFromDate.Text & " to " & TextToDate.Text & ""
            End If

            'Call Calctotal(tm)

        Catch exp As Exception
            LabelVisibilityCaption0.Text = "<b>Error</b>|" & exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click

    End Sub
End Class