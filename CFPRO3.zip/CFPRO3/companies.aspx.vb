﻿
Imports System.Drawing
Public Class companies
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", CFAgentName, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID
            LabelDetails.Text = "Add / Edit Internal Companies providing various services on behalf of " & CFAgentName &
                              " to easily generate Invoices for them on C&F PRO for the corresponding Jobs."

            Call LoadCompanies(CFPROID)
        End If
    End Sub




    Private Sub LoadCompanies(ByVal CFPROID As String)

        Try


            Dim sqlstr As String =
                "SELECT CompanyID, CompanyName," &
                "CFPROID, ID " &
                "FROM Companies " &
                "Where CFPROID ='" & CFPROID & "' " &
                "Order By ID Desc "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim a As Integer
            Dim drow As DataRow

            LabelCaption.Text = tmptable.Rows.Count & " Companies"

            If tmptable.Rows.Count = 0 Then

                Dim CFAgentName As String = ""
                Dim nCFPROID As String = ""
                Call clsAuth.AuthCFAgent(nCFPROID, CFAgentName, "", "", "", "", False)

                If CFAgentName.Length > 25 Then
                    CFAgentName = Trim(Mid(CFAgentName, 1, 25))
                End If

                drow = tmptable.NewRow
                drow("CompanyName") = CFAgentName
                drow("CompanyID") = nCFPROID
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)

                Call clsData.SaveData("Companies", tmptable, sqlstr, False, clsData.constr)
            End If

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next

            GridCompanies.DataSource = tmptable
            GridCompanies.DataBind()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditCompany(LabelCFPROID.Text, False)
    End Sub
    Protected Sub GridCompanies_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridCompanies.SelectedIndexChanged
        Dim row As GridViewRow = GridCompanies.Rows(GridCompanies.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridCompanies.Rows.Count - 1
            row = GridCompanies.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridCompanies.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridCompanies_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridCompanies.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCompanies, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditCompany(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditCompany(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridCompanies.SelectedIndex < 0 Then
                    LabelMessage3.Text = "Please Select Company"
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Company"
                Dim ID As Integer = GridCompanies.SelectedValue

                Dim sqlstr As String =
                   "SELECT CompanyID, CompanyName," &
                   "CFPROID, ID " &
                   "FROM Companies " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextCompanyName.Text = drow("CompanyName")
                End If

            Else
                LabelAddEdit.Text = "Add Company"
                TextCompanyName.Text = ""
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveCompanies(LabelCFPROID.Text)
    End Sub

    Private Sub SaveCompanies(CFPROID As String)

        Try

            Dim ID As Integer = -1

            If LabelAddEdit.Text.Contains("Edit") Then
                ID = GridCompanies.SelectedValue
            End If

            Dim sqlstr As String =
               "SELECT CompanyID, CompanyName," &
               "CFPROID, ID " &
               "FROM Companies " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("CompanyID") = GetCompanyID()
                tmptable.Rows.Add(drow)
            End If

            drow("CompanyName") = Trim(TextCompanyName.Text)

            Call clsData.SaveData("Companies", tmptable, sqlstr, False, clsData.constr)

            Call LoadCompanies(CFPROID)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridCompanies.SelectedIndex >= 0 Then
            Call PromptDeleteCompanies(GridCompanies.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage3.Text = "No Selection"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteCompanies(ID As Integer, CFPROID As String)
        Dim row As GridViewRow = GridCompanies.Rows(GridCompanies.SelectedIndex)

        LabelDeleteMessage.Text = "Delete Company " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteCompanies(GridCompanies.SelectedValue)
    End Sub
    Private Sub DeleteCompanies(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From Companies  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("Companies", tmptable, sqlstr, True, clsData.constr)

            Call LoadCompanies(LabelCFPROID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Private Function GetCompanyID() As String
        Try

            Dim tmpCompanyID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From Companies " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpCompanyID = drow("ID")
                tmpCompanyID = tmpCompanyID + 1
                tmpstr = Format(tmpCompanyID, "00000000#")
            Else
                tmpstr = Format(tmpCompanyID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetCompanyID")
        End Try
    End Function


End Class