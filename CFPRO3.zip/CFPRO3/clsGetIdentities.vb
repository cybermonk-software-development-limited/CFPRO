﻿Imports AjaxControlToolkit
Imports System.Data.SqlClient


Public Class clsGetIdentities

    Shared Sub LoadItems(CFPROID As String, ItemType As String,
                             Optional DataListItems As DataList = Nothing, Optional LabelItemType As Label = Nothing,
                                            Optional LabelItemMessage As Label = Nothing, Optional ByRef LabelItemHeader As Label = Nothing, Optional ByRef ModalPopupExtender1 As ModalPopupExtender = Nothing,
                                            Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = "", Optional SortByClient As Boolean = False)
        Try
            ModalPopupExtender1.Show()

            If Not IsNothing(ModalPopupExtender2) Then
                ModalPopupExtender2.Show()
            End If


            Dim sqlstr As String = ""
            Dim ItemID As String = ""
            Dim Item As String = ""
            Dim Item1 As String = ""
            Dim tmpstr As String = ""

            If SortByClient Then
                tmpstr = "Order By Client Asc;"
            Else
                tmpstr = "Order By ClientID Desc;"
            End If

            If ItemType = "client" Then
                LabelItemType.Text = "Search / Select Client"
                ItemID = "ClientID"
                Item = "Client"
                Item1 = "Client"
                sqlstr =
                        "Select Top 250 ClientID,Client " &
                        "From Clients " &
                        "Where CFPROID ='" & CFPROID & "' " &
                         tmpstr


            ElseIf ItemType = "agent" Then
                LabelItemType.Text = "Search / Select Agent / Broker"
                ItemID = "ClientID"
                Item = "Client"
                Item1 = "Agent / Broker"
                sqlstr =
                        "Select Top 200 ClientID,Client " &
                        "From Clients " &
                        "Where CFPROID ='" & CFPROID & "' " &
                        "And IsAgent = 1 " &
                        "Order By Client Asc;"

            ElseIf ItemType = "consignee" Then
                LabelItemType.Text = "Search / Select Consignee / Importer"
                ItemID = "ImporterID"
                Item = "Importer"
                Item1 = "Consignee"

                sqlstr =
                       "Select ImporterID,Importer " &
                       "From Importers " &
                       "Where CFPROID ='" & CFPROID & "' " &
                       "Order By Importer Asc;"


            ElseIf ItemType = "cfs" Then
                LabelItemType.Text = "Search / Select CFS"
                ItemID = "CFSID"
                Item = "CFS"
                Item1 = "CFS"

                sqlstr =
                       "Select  CFSID,CFS,ID " &
                       "From CFS " &
                       "Where CFPROID ='" & CFPROID & "' " &
                       "Order By CFS Asc;"


            ElseIf ItemType = "shipper" Then
                LabelItemType.Text = "Search / Select Shipper"
                ItemID = "ShipperID"
                Item = "Shipper"
                Item1 = "Shipper"

                sqlstr =
                        "Select ShipperID, Shipper " &
                        "From Shippers " &
                        "Where CFPROID ='" & CFPROID & "' " &
                        "Order By ShipperID Desc;"


            ElseIf ItemType = "jobstatus" Then
                LabelItemType.Text = "Search / Select Job Status"
                ItemID = "ID"
                Item = "Status"
                Item1 = "Status"

                sqlstr =
                        "Select  Status,ID " &
                        "From CFAgentJobStatus " &
                        "Where CFPROID ='" & CFPROID & "' " &
                        "Order By Status Asc;"


            ElseIf ItemType = "country" Then
                LabelItemType.Text = "Search / Select Country"
                ItemID = "Code"
                Item = "Country"
                Item1 = "Country"

                sqlstr =
                        "Select Code, Country " &
                        "From Countries " &
                        "Order By Country Asc;"



            ElseIf ItemType = "vehicleno" Then
                LabelItemType.Text = "Search / Select Vehicle"
                ItemID = "ID"
                Item = "VehicleNo"
                Item1 = "Vehicle No."

                sqlstr =
                        "Select VehicleNo, ID " &
                        "From Vehicles " &
                        "Where CFPROID ='" & CFPROID & "' " &
                        "Order By VehicleNo Asc;"



            ElseIf ItemType = "transporter" Then
                LabelItemType.Text = "Search / Select Transporter"
                ItemID = "TransporterID"
                Item = "Transporter"
                Item1 = "Transporter"

                sqlstr =
                       "Select Top 250 TransporterID,Transporter " &
                       "From Transporters " &
                       "Where CFPROID ='" & CFPROID & "' " &
                       "Order By Transporter Asc;"


            ElseIf ItemType = "shippingline" Then
                LabelItemType.Text = "Search / Select Shipping Line"
                ItemID = "ShippingLineID"
                Item = "ShippingLine"
                Item1 = "Shipping Line"

                sqlstr =
                       "Select Top 25 ShippingLineID,ShippingLine " &
                       "From ShippingLines " &
                       "Where CFPROID ='" & CFPROID & "' " &
                       "Order By ShippingLine Asc;"

            ElseIf ItemType = "supplier" Then
                LabelItemType.Text = "Search / Select Supplier / Vendor"
                ItemID = "SupplierID"
                Item = "Supplier"
                Item1 = "Supplier"

                sqlstr =
                       "Select Top 250 SupplierID,Supplier " &
                       "From Suppliers " &
                       "Where CFPROID ='" & CFPROID & "' " &
                       "Order By Supplier Asc;"


            ElseIf ItemType = "jobtype" Then
                LabelItemType.Text = "Search / Select Job Type"
                ItemID = "JobTypeID"
                Item = "JobType"
                Item1 = "Job Type"

                sqlstr = _
                       "Select JobTypeID,JobType " &
                       "From JobTypes " & _
                       "Where CFPROID ='" & CFPROID & "' " & _
                       "Order By ID Asc;"

            ElseIf ItemType = "user" Then
                LabelItemType.Text = "Search / Select User"
                ItemID = "UserID"
                Item = "UserNames"
                Item1 = "User Names"

                sqlstr = _
                       "Select UserID,UserNames " &
                       "From CFAgentUsers " & _
                       "Where CFPROID ='" & CFPROID & "' " & _
                       "Order By UserNames Asc;"


            ElseIf ItemType = "statusupdate" Then
                LabelItemType.Text = "Search / Status Update"
                ItemID = "StatusID"
                Item = "StatusUpdate"
                Item1 = "Status Update"

                sqlstr = _
                       "Select StatusID,StatusUpdate " &
                       "From StatusUpdates " & _
                       "Order By StatusID Asc;"
            End If



            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            Dim a As Integer

            Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemID") = (Trim(drow(ItemID)))
                drow("Item") = (Trim(drow(Item)))
                a = a + 1
            Next


            LabelItemMessage.Text = tmptable.Rows.Count & " " & Item1 & "(s) Loaded."


            LabelItemHeader.Text = Item1

            DataListItems.DataSource = tmptable
            DataListItems.DataBind()




        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Shared Sub SearchUsers(CFPROID As String, SearchStr As String, DataListItems As DataList, LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender)

        Dim sqlstr As String = _
                       "Select UserID,UserNames " &
                       "From CFAgentUsers " & _
                       "Where UserNames  Like '%" & SearchStr & "%' " & _
                       "And CFPROID ='" & CFPROID & "' " & _
                       "Order By UserNames Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)


        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("UserID")))
            drow("Item") = (Trim(drow("UserNames")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " User(s)  found matching '" & SearchStr & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If

        LabelItemHeader.Text = "User"


        DataListItems.DataSource = tmptable
        DataListItems.DataBind()

        If Not IsNothing(ModalPopupExtender1) Then
            ModalPopupExtender1.Hide()
        End If
    End Sub


    Shared Sub SearchAgent(CFPROID As String, SearchStr As String, DatalistItems As DataList,
                                      LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender,
                                       Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = "")
        Try
            Dim sqlstr As String = _
                    "Select ClientID,Client,Box," & _
                    "Telephone,Town,Email,Id " & _
                    "From Clients " & _
                    "Where Client  Like '%" & SearchStr & "%' " & _
                    "And CFPROID = '" & CFPROID & "' " & _
                    "And IsAgent = 1" & _
                    "Order By Client Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            Dim a As Integer

            Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)



            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemID") = (Trim(drow("ClientID")))
                drow("Item") = (Trim(drow("Client")))
                a = a + 1
            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ItemID") = Nothing
                drow("Item") = "No Names found for '" & SearchStr & "'"
                tmptable.Rows.Add(drow)
            End If


            LabelItemMessage.Text = tmptable.Rows.Count & " Agent(s)  found matching '" & SearchStr & "' "





            LabelItemHeader.Text = "Agent / Broker"

            DatalistItems.DataSource = tmptable
            DatalistItems.DataBind()



            ModalPopupExtender1.Show()

            If Not IsNothing(ModalPopupExtender2) Then
                ModalPopupExtender2.Show()
            End If
        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Shared Sub SearchClient(CFPROID As String, SearchStr As String, DataListItems As DataList,
                                          LabelItemMessage As Label, LabelItemHeader As Label, ByRef ModalPopupExtender1 As ModalPopupExtender,
                                          Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = "")
        Try


            Dim sqlstr As String = _
                    "Select Top 50 ClientID,Client,Box," & _
                    "Telephone,Town,Email,Id " & _
                    "From Clients " & _
                    "Where Client  Like '%" & SearchStr & "%' " & _
                    "And CFPROID = '" & CFPROID & "' " & _
                    "Order By Client Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            Dim a As Integer

            Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)



            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemID") = (Trim(drow("ClientID")))
                drow("Item") = (Trim(drow("Client")))
                a = a + 1
            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ItemID") = Nothing
                drow("Item") = "No Names found for '" & SearchStr & "'"
                tmptable.Rows.Add(drow)
            End If


            LabelItemMessage.Text = tmptable.Rows.Count & " Client(s)  found matching '" & SearchStr & "' "


            LabelItemHeader.Text = "Client"

            DataListItems.DataSource = tmptable
            DataListItems.DataBind()


            ModalPopupExtender1.Show()

            If Not IsNothing(ModalPopupExtender2) Then
                ModalPopupExtender2.Show()
            End If
        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub
    Shared Sub SearchImporter(CFPROID As String, SearchStr As String, DatalistItems As DataList, LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender,
                              Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = "")

        Dim sqlstr As String = _
                "Select ImporterID,Importer,Box," & _
                "Telephone,Town,Email,Id " & _
                "From Importers " & _
                "Where Importer  Like '%" & SearchStr & "%' " & _
                "And CFPROID = '" & CFPROID & "' " & _
                "Order By Importer Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("ImporterID")))
            drow("Item") = (Trim(drow("Importer")))
            a = a + 1
        Next


        LabelItemMessage.Text = tmptable.Rows.Count & " Consignee(s) found matching '" & SearchStr & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If




        LabelItemHeader.Text = "Consignee"

        DatalistItems.DataSource = tmptable
        DatalistItems.DataBind()


        ModalPopupExtender1.Show()

        If Not IsNothing(ModalPopupExtender2) Then
            ModalPopupExtender2.Show()
        End If
    End Sub


    Shared Sub SearchCFS(CFPROID As String, SearchStr As String, DataListItems As DataList,
                                           LabelItemMessage As Label, LabelItemHeader As Label,
                                           ModalPopupExtender1 As ModalPopupExtender, Optional ByRef ErrMsg As String = Nothing)

        Dim sqlstr As String = _
                "Select Top 50 CFSID,CFS,ID " &
                "From CFS " & _
                "Where CFS  Like '%" & SearchStr & "%' " & _
                "And CFPROID = '" & CFPROID & "' " & _
                "Order By CFS Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("CFSID")))
            drow("Item") = (Trim(drow("CFS")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " CFSs found matching '" & SearchStr & "' "


        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If

        LabelItemHeader.Text = "CFS"

        DataListItems.DataSource = tmptable
        DataListItems.DataBind()


        ModalPopupExtender1.Show()
    End Sub


    Shared Sub SearchShippingLine(CFPROID As String, SearchStr As String, DataListItems As DataList, LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender)

        Dim sqlstr As String =
                       "Select ShippingLineID, ShippingLine,ID " &
                       "From ShippingLines " &
                       "Where ShippingLine  Like '%" & SearchStr & "%' " &
                       "And CFPROID = '" & CFPROID & "' " &
                       "Order By ShippingLine Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)


        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("ShippingLineID")))
            drow("Item") = (Trim(drow("ShippingLine")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Shipping Line(s) found matching '" & SearchStr & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If

        LabelItemHeader.Text = "Shipping Line"


        DataListItems.DataSource = tmptable
        DataListItems.DataBind()

        ModalPopupExtender1.Show()

    End Sub



    Shared Sub SearchTransporter(CFPROID As String, SearchStr As String, DataListItems As DataList, LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender)

        Dim sqlstr As String =
                       "Select TransporterID, Transporter,ID " &
                       "From Transporters " &
                       "Where Transporter  Like '%" & SearchStr & "%' " &
                       "And CFPROID = '" & CFPROID & "' " &
                       "Order By Transporter Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)


        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("TransporterID")))
            drow("Item") = (Trim(drow("Transporter")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Transporter(s) found matching '" & SearchStr & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If

        LabelItemHeader.Text = "Transporter"


        DataListItems.DataSource = tmptable
        DataListItems.DataBind()

        ModalPopupExtender1.Show()

    End Sub
    Shared Sub SetTransporter(CFPROID As String, TransporterID As String, VehicleNo As String, ByRef Transporter As String, ByRef TransporterID1 As String,
                              ModalPopupExtender1 As ModalPopupExtender, Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = Nothing)
        Try
            If Not IsNothing(ModalPopupExtender1) Then
                ModalPopupExtender1.Hide()
            End If


            Dim sqlstr As String

            If Not Trim(VehicleNo) = "" Then
                sqlstr =
                    "Select Vehicles.TransporterID, Transporter " &
                    "From Vehicles, Transporters " &
                    "Where VehicleNo = '" & VehicleNo & "' " &
                    "And Vehicles.CFPROID = '" & CFPROID & "' " &
                    "And Vehicles.TransporterID = Transporters.TransporterID " &
                    "And Vehicles.CFPROID = Transporters.CFPROID "
            Else
                sqlstr =
                   "Select TransporterID, Transporter " &
                   "From Transporters " &
                   "Where TransporterID = '" & TransporterID & "' " &
                   "And CFPROID = '" & CFPROID & "' "

            End If


            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                Transporter = drow("Transporter")
                TransporterID1 = drow("TransporterID")
            End If

            If Trim(VehicleNo) = "" Then
                If Not IsNothing(ModalPopupExtender2) Then
                    ModalPopupExtender2.Show()
                End If
            End If


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Sub


    Shared Sub SearchVehicle(CFPROID As String, SearchStr As String, DataListItems As DataList, LabelItemMessage As Label, LabelItemHeader As Label, ModalPopupExtender1 As ModalPopupExtender)

        Dim sqlstr As String = _
                       "Select VehicleNo,ID " & _
                       "From Vehicles " & _
                       "Where VehicleNo  Like '%" & SearchStr & "%' " & _
                       "And CFPROID = '" & CFPROID & "' " & _
                       "Order By VehicleNo Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("ID")))
            drow("Item") = (Trim(drow("VehicleNo")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Vehicles No(s) found matching '" & SearchStr & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & SearchStr & "'"
            tmptable.Rows.Add(drow)
        End If



        LabelItemHeader.Text = "Vehicle No"


        DataListItems.DataSource = tmptable
        DataListItems.DataBind()


        If Not IsNothing(ModalPopupExtender1) Then
            ModalPopupExtender1.Show()
        End If

    End Sub

    Shared Sub SetVehicleNo(CFPROID As String, ItemID As String, ByRef VehicleNo As String,
                            ByRef Transporter As String, ByRef TransporterID As String,
                              ModalPopupExtender1 As ModalPopupExtender, Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = Nothing)
        Try
            If Not IsNothing(ModalPopupExtender1) Then
                ModalPopupExtender1.Hide()
            End If

            Dim sqlstr As String =
               "Select ID, VehicleNo " &
               "From Vehicles " &
               "Where ID = " & CDbl(ItemID) & " " &
               "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                VehicleNo = drow("VehicleNo")

                Call SetTransporter(CFPROID, "", drow("VehicleNo"), Transporter, TransporterID,
                                              ModalPopupExtender1, ModalPopupExtender2, ErrMsg)
            End If

            If Not IsNothing(ModalPopupExtender2) Then
                ModalPopupExtender2.Show()
            End If


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try



    End Sub


    Shared Function SetShippingLine(CFPROID As String, JobID As String, ShippingLineID As String, ByRef ErrMsg As String) As String
        Try

            Dim sqlstr As String =
                    "Select ShippingLineID,ShippingLine,ID " &
                    "From ShippingLines " &
                    "Where ShippingLineID = '" & ShippingLineID & "' " &
                    "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Return drow("ShippingLine")

            End If

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

        Return ""
    End Function



    Shared Function SetImporter(CFPROID As String, JobID As String, ImporterID As String, ByRef ErrMsg As String) As String
        Try

            Dim sqlstr As String = _
                    "Select ImporterID,Importer,ID " & _
                    "From Importers " & _
                    "Where ImporterID = '" & ImporterID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Return drow("Importer")

            End If

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

        Return ""
    End Function

    Shared Function SetClient(CFPROID As String, JobID As String, ClientID As String, ByRef ErrMsg As String) As String
        Try

            Dim sqlstr As String = _
                    "Select ClientID,Client,ID " & _
                    "From Clients " & _
                    "Where ClientID = '" & ClientID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Return drow("Client")

            End If

            Return ""
        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Function

    Shared Function SetJobType(JobTypeID As String, CFPROID As String, Optional ByRef ErrMsg As String = Nothing) As String

        Try

            If IsNothing(HttpContext.Current.Session("JobTypeTable")) Or HttpContext.Current.Session("ResetCaches") = "1" Then
                Dim sqlstr As String =
                                   "Select JobTypeID, JobType " &
                                   "From JobTypes " &
                                   "Where CFPROID = '" & CFPROID & "' "

                Dim tmptable As New DataTable("JobType")
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                HttpContext.Current.Session("JobTypeTable") = tmptable
            End If

            Dim tmptable1 As DataTable = DirectCast(HttpContext.Current.Session("JobTypeTable"), DataTable)
            HttpContext.Current.Session("ResetCaches") = "0"

            Dim dv As New DataView(tmptable1)
            dv.RowFilter = "JobTypeID = '" & JobTypeID & "' "
            If dv.Count > 0 Then
                Call clsData.NullChecker(tmptable1, 0)
                Return dv(0)("JobType")
            Else
                Return "NOT SET"
            End If

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function

    Shared Function SetCFPROuser(CFPROID As String, UserID As String, JobID As String, ByRef UserNames As String, SaveUser As Boolean) As String

        Dim sqlstr As String = _
        "Select UserID, UserNames " & _
        "From CFAgentUsers " & _
        "Where UserID = '" & UserID & "' " & _
        "And CFPROID = '" & CFPROID & "' "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)



            If SaveUser Then
                Dim sqlstr1 As String = _
                                "Select UserID, ID " & _
                                "From Jobs " & _
                                "Where JobID ='" & JobID & "' " & _
                                "And CFPROID = '" & CFPROID & "' "

                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                If tmptable1.Rows.Count > 0 Then
                    Dim drow1 As DataRow = tmptable1.Rows(0)
                    drow1("UserID") = UserID
                    Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)
                End If
            End If
            UserNames = drow("UserNames")
        Else
            UserNames = ""
        End If

        Return UserNames
    End Function

    Shared Sub SearchSupplier(CFPROID As String, SearchStr As String, DataListItems As DataList,
                                         LabelItemMessage As Label, LabelItemHeader As Label, ByRef ModalPopupExtender1 As ModalPopupExtender,
                                         Optional ModalPopupExtender2 As ModalPopupExtender = Nothing, Optional ErrMsg As String = "")
        Try


            Dim sqlstr As String =
                    "Select Top 50 SupplierID,Supplier,Box," &
                    "Telephone,Town,Email,Id " &
                    "From Suppliers " &
                    "Where Supplier  Like '%" & SearchStr & "%' " &
                    "And CFPROID = '" & CFPROID & "' " &
                    "Order By Supplier Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            Dim a As Integer

            Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)



            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemID") = (Trim(drow("SupplierID")))
                drow("Item") = (Trim(drow("Supplier")))
                a = a + 1
            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ItemID") = Nothing
                drow("Item") = "No Names found for '" & SearchStr & "'"
                tmptable.Rows.Add(drow)
            End If


            LabelItemMessage.Text = tmptable.Rows.Count & " Supplier(s)  found matching '" & SearchStr & "' "


            LabelItemHeader.Text = "Supplier"

            DataListItems.DataSource = tmptable
            DataListItems.DataBind()


            ModalPopupExtender1.Show()

            If Not IsNothing(ModalPopupExtender2) Then
                ModalPopupExtender2.Show()
            End If
        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub



    Shared Function SearchTransporter(ByVal prefixText As String, ByVal count As Integer, ByVal CFPROID As String) As List(Of String)

        Try

            Dim sqlstr As String =
                "SELECT   Top 15 TransporterID, Transporter " &
                "FROM Transporters " &
                "Where Transporter Like + '%' + @SearchText + '%'  " &
                "And CFPROID = '" & CFPROID & "' " &
                "Order by Transporter Asc;"

            Dim Conn As SqlConnection = New SqlConnection
            Dim Connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, Connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            Connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim Transporter As List(Of String) = New List(Of String)

            While Reader1.Read
                If Not IsDBNull(Reader1("Transporter")) Then
                    Transporter.Add(AjaxControlToolkit.AutoCompleteExtender _
               .CreateAutoCompleteItem(Reader1("Transporter"), Reader1("TransporterID")))
                End If
            End While

            Connection1.Close()

            Return Transporter

        Catch ex As Exception
            Return Nothing
        End Try

        Return Nothing



    End Function
    Shared Function GetTransporter(CFPROID As String, TransporterID As String, Optional ErrMsg As String = Nothing) As String
        Try


            Dim sqlstr As String =
                   "Select Transporter " &
                   "From Transporters " &
                   "Where TransporterID = '" & TransporterID & "' " &
                   "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                Return drow("Transporter")
            End If

            Return ""

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Function



End Class
