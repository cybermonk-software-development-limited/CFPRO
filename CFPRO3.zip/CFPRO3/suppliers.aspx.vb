﻿Imports System.Drawing

Public Class suppliers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call clsSubs.CountryList(ComboCountry)
            Call LoadSuppliers(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadSuppliers(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Supplier  Like '%" & Trim(TextSearch.Text) & "'% "
        End If

        Dim sqlstr As String =
              "Select SupplierID, Supplier," &
              "Box,Telephone,Email," &
              "Town,Country,ID " &
              "From  Suppliers " &
              "Where CFPROID ='" & CFPROID & "' " &
               tmpstr &
              "Order By SupplierID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        Dim drow As DataRow

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Supplier") = "No Suppliers"
            tmptable.Rows.Add(drow)
        End If

        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next



        Session("SuppliersTable") = tmptable
        GridSuppliers.DataSource = tmptable
        GridSuppliers.DataBind()

        If GridSuppliers.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridSuppliers.Rows.Count - 1 Then
                Rowindex = GridSuppliers.Rows.Count - 1
            End If

            GridSuppliers.SelectedIndex = Rowindex
            Call ShowSupplier(CFPROID, GridSuppliers.SelectedValue.ToString)
            Dim row As GridViewRow = GridSuppliers.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Suppliers found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Suppliers"
        End If


    End Sub



    Private Sub ShowSupplier(CFPROID As String, SupplierID As String)

        Dim sqlstr As String =
             "Select SupplierID, Supplier," &
             "Box,Telephone,Email," &
             "Town,Country " &
             "From  Suppliers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And SupplierID = '" & SupplierID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextSupplier.Text = drow("Supplier")
            TextAddress.Text = drow("Box")
            TextTelephone.Text = drow("Telephone")
            TextEmailAddress.Text = drow("Email")
            TextTown.Text = drow("Town")

            If drow("Country").ToString.Length > 0 And drow("Country").ToString.Length <= 2 Then
                ComboCountry.Text = Trim(drow("Country"))
            Else
                ComboCountry.SelectedIndex = 0
            End If

        End If

        LabelMessage.ForeColor = Color.Black
        LabelMessage.Text = ""
    End Sub



    Private Sub NewSupplier(CFPROID As String)
        Try

            Dim sqlstr As String =
                  "Select SupplierID, Supplier," &
                   "CFPROID,Country, ID " &
                   "From  Suppliers " &
                   "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("SupplierID") = clsSubs.GetLastID(CFPROID, "", "SupplierID")
            Drow("CFPROID") = CFPROID
            Drow("Supplier") = "NEW SUPPLIER " & tmptable.Rows.Count
            Drow("Country") = "KE"

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Suppliers", tmptable, sqlstr, False, clsData.constr)
            Call LoadSuppliers(CFPROID, 0, "")


            TextSupplier.Focus()

        Catch exp As Exception
            MsgBox(exp.Message, , "NewSupplier")
        End Try
    End Sub


    Private Function GetSupplierID() As String
        Try

            Dim tmpSupplierID As Integer

            Dim sqlstr As String =
             "Select top 1 Id " &
             "From Suppliers " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpSupplierID = drow("ID")
                tmpSupplierID = tmpSupplierID + 1
                tmpstr = Format(tmpSupplierID, "000000#")
            Else
                tmpstr = Format(tmpSupplierID, "000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetSupplierID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridSuppliers, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridSuppliers.SelectedIndexChanged
        Dim row As GridViewRow = GridSuppliers.Rows(GridSuppliers.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowSupplier(LabelCFPROID.Text, GridSuppliers.SelectedValue.ToString)

        For a As Integer = 0 To GridSuppliers.Rows.Count - 1
            row = GridSuppliers.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridSuppliers.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub



    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewSupplier(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveSupplier(LabelCFPROID.Text, GridSuppliers.SelectedValue.ToString)
    End Sub

    Private Sub SaveSupplier(CFPROID As String, SupplierID As String)
        Try
            LabelMessage.ForeColor = Color.Black
            LabelMessage.Text = ""

            If Not Trim(TextEmailAddress.Text) = "" Then
                If Not Trim(TextEmailAddress.Text).Contains("@") Then
                    LabelMessage.Text = "Invalid Email Address"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If

            Dim sqlstr As String =
            "Select SupplierID, Supplier," &
            "Box,Telephone,Email," &
            "Town,Country,ID " &
            "From  Suppliers " &
            "Where CFPROID ='" & CFPROID & "' " &
            "And SupplierID = '" & SupplierID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Supplier") = UCase(Trim(TextSupplier.Text))
                drow("Box") = Trim(TextAddress.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Town") = Trim(TextTown.Text)
                drow("Country") = ComboCountry.Text


                Call clsData.SaveData("Suppliers", tmptable, sqlstr, False, clsData.constr)

                Call clsMSDynamicsNAVint.UpdateNAVVendor(CFPROID, "V-", drow("SupplierID"), drow("Supplier"), drow("Box"),
                                                         drow("Town"), drow("Telephone"), drow("Country"), drow("Email"), LabelMessage1.Text)

                Call LoadSuppliers(CFPROID, GridSuppliers.SelectedIndex, TextSearch.Text)

            End If




        Catch exp As Exception
            MsgBox(exp.Message, , "SaveSupplier")
        End Try
    End Sub



    Private Sub DeleteSupplier(CFPROID As String, SupplierID As String)


        Dim sqlstr As String =
        "Select ID " &
        "From  Suppliers " &
        "Where CFPROID ='" & CFPROID & "' " &
        "And SupplierID = '" & SupplierID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Suppliers", tmptable, sqlstr, True, clsData.constr)
        Call LoadSuppliers(CFPROID, GridSuppliers.SelectedIndex - 1, TextSearch.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteSupplier(LabelCFPROID.Text, GridSuppliers.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadSuppliers(LabelCFPROID.Text, -1, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadSuppliers(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click

        Dim Fields(5) As String
        Fields(0) = "SupplierID"
        Fields(1) = "Supplier"
        Fields(2) = "Email"
        Fields(3) = "Telephone"
        Fields(4) = "Town"
        Fields(5) = "Country"


        Dim tmptable As DataTable = Session("SuppliersTable")
        Call clsExportToExcel.ExportToExcel("", "", "", "Supplier", "Supplier",
                                            LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)

    End Sub



End Class