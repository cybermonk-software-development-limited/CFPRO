﻿Public Class agentstable
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            'Dim imgurl As String = ""
            'Dim CSDID As String = ""
            '' Call clsSubs.CheckAndSetUser(CSDID, LabelUser.Text, "", LinkSignIn.Text, imgurl, False)
            'Image1.ImageUrl = imgurl

            Call LoadVessels()

            Dim JobId As String = Request.QueryString("jobid")
            Call LoadShipping(JobId)

            LabelFromPageURL.Text = Page.Request.UrlReferrer.ToString & "?jobid=" & JobId

        End If

    End Sub


    Private Sub LoadShipping(JobId As String)

        Dim sqlstr As String =
        "Select VesselID, ShippingVessel," &
        "ShippingLineID,ShippingLine," &
        "ShipStatus,ManifestNo," &
        "VesselETA,LastSlingDate,BerthingDate," &
        "ShipExitDate,VoyageNo," &
        "DeliveryOrderStatus,DeliveryOrderCharges," &
        "DeliveryOrderDate,HandoverFees," &
        "ContainerReturnDays,ContainerReturnDate," &
        "ContainerDeposit, ContainerDepositDate, " &
        "ContainerRefundRequestDate,ContainerDepositRefund," &
        "ContainerDepositRefundDate,ContainerDepositDeductions, " &
        "ContainerDepositRemarks,ShippingPersonnel,ShippingExpenses," &
        "ShippingStart,ShippingEnd,Id " &
        "From Jobs " &
        "Where JobId ='" & JobId & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsSubs.NullChecker(tmptable, 0)

            ComboFilterTransporterVehicles.Text = drow("ShippingVessel")

            TextVoyageNo.Text = drow("VoyageNo")



            TextFilterSearchVehicle.Text = drow("ShippingLine")

            ComboShipStatus.Text = drow("ShipStatus")

            TextShipETA.Text = Format(drow("VesselETA"), "dd-MMM-yyyy")

            TextBerthingDate.Text = Format(drow("BerthingDate"), "dd-MMM-yyyy")
            TextLastSlingDate.Text = Format(drow("LastSlingDate"), "dd-MMM-yyyy")
            TextShipExitDate.Text = Format(drow("ShipExitDate"), "dd-MMM-yyyy")

            TextContainerReturnDate.Text = Format(drow("ContainerReturnDate"), "dd-MMM-yyyy")
            TextContainerReturnDays.Text = drow("ContainerReturnDays")
            TextManifestNo.Text = drow("ManifestNo")

            ComboDeliveryOrderStatus.Text = drow("DeliveryOrderStatus")
            TextOrderRecieveDate.Text = Format(drow("DeliveryOrderDate"), "dd-MMM-yyyy")
            TextDeliveryOrderCharges.Text = Format(drow("DeliveryOrderCharges"), "#,##0.#0")
            TextHandOverFees.Text = Format(drow("HandoverFees"), "###,##0.#0")



            TextContainerDeposit.Text = Format(drow("ContainerDeposit"), "#,##0.#0")
            TextContainerDepositDate.Text = Format(drow("ContainerDepositDate"), "dd-MMM-yyyy")

            TextRefundRequestDate.Text = Format(drow("ContainerRefundRequestDate"), "dd-MMM-yyyy")
            TextContainerDepositRefund.Text = Format(drow("ContainerDepositRefund"), "#,##0.#0")
            TextContainerDepositRefundDate.Text = Format(drow("ContainerDepositRefundDate"), "dd-MMM-yyyy")
            TextDeductions.Text = Format(drow("ContainerDepositDeductions"), "#,##0.#0")
            TextRemarks.Text = drow("ContainerDepositRemarks")


            TextExpenses.Text = Format(drow("Shippingexpenses"), "#,##0.#0")
            TextDate.Text = Format(drow("ShippingStart"), "dd-MMM-yyyy")
            TextDate1.Text = Format(drow("ShippingEnd"), "dd-MMM-yyyy")
            TextPersonnel.Text = drow("ShippingPersonnel")

            If CDate(TextDate.Text) = CDate("1-Jan-1800") Then
                TextDate.Text = Format(Now, "dd-MMM-yyyy")
                'TextPersonnel.Text = User
            End If

            If Not Trim(drow("VoyageNo")) = "" Then
                Call UpdateShippingVessel(drow("ShippingVessel"), drow("VoyageNo"))
            End If
        End If

    End Sub



    Private Sub UpdateShippingVessel(ByVal Vessel As String, ByVal VoyageNo As String)
        Dim tmptable As New DataTable()
        Dim sqlstr As String = "Select " &
            "VesselID,Vessel,VoyageNo," &
            "ETA,BerthingDate," &
            "ExitDate,Id " &
            "From  ShippingVessels " &
            "Where Vessel ='" & Trim(Vessel) & "' " &
            "And VoyageNo ='" & Trim(VoyageNo) & "' "

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsSubs.NullChecker(tmptable, 0)
            ComboFilterTransporterVehicles.Text = drow("Vessel")
            TextVoyageNo.Text = drow("VoyageNo")
            TextShipETA.Text = Format(drow("ETA"), "dd-MMM-yyyy")
            TextBerthingDate.Text = Format(drow("BerthingDate"), "dd-MMM-yyyy")
            TextShipExitDate.Text = Format(drow("ExitDate"), "dd-MMM-yyyy")
            TextLastSlingDate.Text = Format(drow("ExitDate"), "dd-MMM-yyyy")

            Call ReturnDate(CDate(TextBerthingDate.Text), Val(TextContainerReturnDays.Text))

        End If
    End Sub

    Private Sub ReturnDate(ByVal BerthingDate As Date, ByVal ReturnDays As Integer)
        If Not CDate(BerthingDate) = CDate("1-Jan-1800") Then
            Dim tmpdate As Date = BerthingDate.AddDays(ReturnDays)
            TextContainerReturnDate.Text = Format(tmpdate, "dd-MMM-yyyy")
        Else
            TextContainerReturnDate.Text = "1-Jan-1800"
        End If

    End Sub


    Private Sub LoadVessels()
        Dim sqlstr As String =
         "Select Vessel " &
         "From ShippingVessels " &
         "Where Active = " & 1 & " "
        ComboFilterTransporterVehicles.Items.Clear()
        Call clsData.PopCombo(ComboFilterTransporterVehicles, sqlstr, clsData.constr, 0)
    End Sub

    Protected Sub ButtonBack_Click(sender As Object, e As EventArgs) Handles ButtonBack.Click
        Response.Redirect(LabelFromPageURL.Text)
    End Sub
End Class