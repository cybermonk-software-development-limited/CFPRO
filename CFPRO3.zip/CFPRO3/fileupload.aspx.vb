﻿Public Class fileuploader
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim filetype As String = Request.QueryString("filetype")
            If filetype = "businesslogo" Then

                LabelFileDest.Text = Server.MapPath(".") & "\cfagentimages\"
                LabelMessage.Text = "Browse to File & Click 'Upload' (3MB max .jpg .jpeg .png formats only)"
                LabelFileName.Text = clsEncr.DecryptString(Request.QueryString("productaccountid"))

            End If

        End If


    End Sub

    Private Sub FileUpload()

        Dim filename As String = FileUpload1.FileName
        Dim filetype As String = Request.QueryString("filetype")




        If FileUpload1.FileContent.Length <= 3145728 Then
            Dim tmpstr() As String = filename.Split(".")
            Dim a As Integer = tmpstr.GetUpperBound(0)
            ReDim Preserve tmpstr(a)

            If filetype = "profilepic" Or filetype = "businesslogo" Then
                If LCase(tmpstr(a)) = "jpg" Or LCase(tmpstr(a)) = "png" Then

                    Panel1.Visible = False
                    Dim UniqueID As String = DateTime.Now.Ticks.ToString

                    Dim filepath As String = LabelFileDest.Text & LabelFileName.Text & "-" & UniqueID & "-1." & tmpstr(1)
                    Dim filepath1 As String = LabelFileDest.Text & LabelFileName.Text & "-" & UniqueID & "." & tmpstr(1)
                    'LabelMessage1.Text = clsEncr.DecryptString(Request.QueryString("csdid"))

                    Try

                        Dim tmpdir() As String = IO.Directory.GetFiles(LabelFileDest.Text)
                        For Each tmpfile In tmpdir
                            If InStr(tmpfile, LabelFileName.Text, CompareMethod.Text) > 0 Then
                                IO.File.Delete(tmpfile)
                            End If
                        Next

                    Catch exp As Exception
                        ' LabelMessage1.Text = exp.Message & exp.StackTrace
                    Finally

                        FileUpload1.SaveAs(filepath)
                        Call clsSubs.ResizeImage(filepath, filepath1, 400, 0, 400)

                        If filetype = "businesslogo" Then
                            Call SavelogoURL(LabelFileName.Text & "-" & UniqueID & "." & tmpstr(1))
                        End If

                    End Try

                    Panel3.Visible = True
                    Button2.Visible = False
                Else
                    LabelMessage.Text = "Error! - Image  is Not In JPEG or PNG format"
                    LabelMessage.ForeColor = Drawing.Color.Red
                End If

            ElseIf filetype = "pdfinvoice" Then

                If LCase(tmpstr(a)) = "pdf" Then


                    Dim DocumentsPath As String = HttpContext.Current.Server.MapPath(".") & "\documents\"

                    If Not IO.Directory.Exists(DocumentsPath) Then
                        IO.Directory.CreateDirectory(DocumentsPath)
                    End If



                    Dim FileID As String = clsDocuments.GetFileID
                    Dim tmpfile As String = FileID & "." & tmpstr(a)
                    Dim filepath As String = DocumentsPath & "\" & tmpfile


                    Call SavePDFInvoice(LabelFileName.Text & "-" & UniqueID & "." & tmpstr(1))
                    FileUpload1.SaveAs(filepath)

                    Panel3.Visible = True
                    Button2.Visible = False

                Else
                    LabelMessage.Text = "Error! - Document  is Not In PDF format"
                    LabelMessage.ForeColor = Drawing.Color.Red
                End If

            End If
        Else
            'Panel1.Visible = True
            LabelMessage.Text = "Error! - File Size exceeds 3MB"
            LabelMessage.ForeColor = Drawing.Color.Red
        End If


    End Sub

    Private Sub SavePDFInvoice(PDFInvoiceName)
        Try

            Dim CFPROID As String = Request.QueryString("cfproid")
            Dim JobID As String = Request.QueryString("jobid")

            Dim sqlstr As String = _
                    "Select PDFInvoiceName, ID " & _
                    "From Jobs  " & _
                    "Where JobID = '" & JobID & "' " &
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("PDFInvoiceName") = PDFInvoiceName
                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Private Sub SavelogoURL(LogoURL)
        Try

            Dim CFPROID As String = clsEncr.DecryptString(Request.QueryString("cfproid"))

            Dim sqlstr As String = _
                    "Select LogoURL, ID " & _
                    "From CFPROAccounts  " & _
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("LogoURL") = LogoURL
                Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, False, clsData.constr)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call FileUpload()

    End Sub


    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs) Handles LinkButton1.Click
        Call Proceed()
    End Sub
    Private Sub Proceed()


        If Not IsNothing(Request.QueryString("filetype")) Then

            Panel2.Visible = False

            Dim filetype As String = Request.QueryString("filetype")

            Dim destpage As String = ""
            If filetype = "businesslogo" Then
                Dim ProductaccountID As String = Request.QueryString("productaccountid")
                destpage = "productaccount.aspx?productaccountid=" & HttpUtility.UrlEncode(ProductaccountID) & "&csdid=" & HttpUtility.UrlEncode(Request.QueryString("csdid"))

            ElseIf filetype = "pdfinvoice" Then
                Dim ProductaccountID As String = Request.QueryString("productaccountid")
                destpage = "productaccount.aspx?productaccountid=" & HttpUtility.UrlEncode(ProductaccountID) & "&csdid=" & HttpUtility.UrlEncode(Request.QueryString("csdid"))

            Else
                If Not IsNothing(Request.QueryString("adminuserprofile")) Then
                    destpage = "adminuserprofile.aspx?csdid=" & HttpUtility.UrlEncode(Request.QueryString("csdid"))
                Else
                    destpage = "userprofile.aspx"
                End If
            End If


            Page.ClientScript.RegisterClientScriptBlock(GetType(String), "", "self.parent.location='" & destpage & "';", True)

        End If
    End Sub


End Class


