﻿Imports System.IO
Imports System.Security.Cryptography

Public Class clsEncr



    Shared Function EncryptString(ByVal plainText As String) As String

        'keys removed 


        Return Convert.ToBase64String(encrypted.ToArray())

    End Function 'EncryptStringToBytes

    Shared Function DecryptString(ByVal cipherText As String) As String

        Try


            'keys removed

            Return plaintext

        Catch ex As Exception
            Return ""
        End Try

    End Function 'DecryptStringFromBytes 


End Class

