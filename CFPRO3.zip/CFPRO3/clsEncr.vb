﻿Imports System.IO
Imports System.Security.Cryptography

Public Class clsEncr


    'Shared Function csdurl() As String

    '    Dim csdurlx As String = IO.File.ReadAllText(HttpContext.Current.Server.MapPath(".") & "/csdurl.txt")

    '    If InStr(csdurlx, "http") > 0 Then
    '        IO.File.WriteAllText(HttpContext.Current.Server.MapPath(".") & "/csdurl.txt", EncryptString(csdurlx))
    '    Else
    '        csdurlx = DecryptString(csdurlx)
    '    End If

    '    Return csdurlx
    'End Function

    Shared Function EncryptString(ByVal plainText As String) As String
        'key Removed'
        Return Convert.ToBase64String(encrypted.ToArray())

    End Function 'EncryptStringToBytes

    Shared Function DecryptString(ByVal cipherText As String) As String

        Try


            'key Removed'

            Return plaintext

        Catch ex As Exception
            Return ""
        End Try

    End Function 'DecryptStringFromBytes 


End Class

