﻿Imports System.Drawing
Public Class progressupdates
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then
            Try
                Dim CFPROID As String = ""
                Dim CFPROUserID As String = ""
                Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, "", "", "", "", True, "cfagent", True)

                Dim JobID As String = Request.QueryString("jobid")



                LabelCFPROID.Text = CFPROID
                LabelJobID.Text = JobID
                LabelCFPROUserID.Text = CFPROUserID

                TextReferenceNo.Text = Request.QueryString("referenceno")
                TextClient.Text = Request.QueryString("client")
                LabelJobDate.Text = Request.QueryString("jobdate")

                ' TextStatusUpdate.Attributes.Add("onfocus", "this.select();")
                TextStatusUpdate.Attributes.Add("onfocus", "this.setSelectionRange(this.value.length,this.value.length);")


                TextSearch.Attributes.Add("value", "Search Performance Indicator ..")
                TextSearch.Style.Add("color", "LightGrey")
                TextSearch.Attributes.Add("onFocus", "if(this.value == 'Search Performance Indicator ..') {this.value = '';}")
                TextSearch.Attributes.Add("onBlur", "if (this.value == '') {this.value = 'Search Performance Indicator ..';}")
                TextSearch.Attributes.Add("onClick", "this.style.color = '';")



                Dim host As String = Request.Url.Host

                If Not host.Contains("cfproonline") Then
                    host = host & ":90"
                End If

                host = "http://" & host
                HyperLinkProgressReport.NavigateUrl = host & "/progressreport.aspx?loadedbyimporter=0&jobid=" & JobID


                Call LoadJobProgress(JobID, CFPROID, -1)

                ButtonAdd.Enabled = clsAuth.UserAllowed(CFPROID, CFPROUserID, "00007")
                ButtonEdit.Enabled = clsAuth.UserAllowed(CFPROID, CFPROUserID, "00008")



                Dim ReadOnlyUser As Boolean = Not clsAuth.ReadOnlyUser(CFPROID, CFPROUserID)
                ButtonAdd.Enabled = ReadOnlyUser
                ButtonEdit.Enabled = ReadOnlyUser
                ButtonRemove.Enabled = ReadOnlyUser

            Catch ex As Exception
            End Try

        End If
    End Sub

    Private Sub LoadJobProgress(JobID As String, CFPROID As String, Rowindex As Integer)
        Try

            Dim sqlstr As String = _
               "Select JobID,Status," & _
               "UserID,Date," & _
               "KPIProgressID, ID " & _
               "From JobProgress " & _
               "Where JobID = '" & JobID & "' " &
               "And CFPROID = '" & CFPROID & "' " & _
               "Order By Date Desc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String = _
             "Select UserID,UserNames " & _
             "From CFAgentUsers " & _
             "Where CFAgentUsers.CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)

            Dim col1 As New DataColumn("UserNames", Type.GetType("System.String"))
            tmptable.Columns.Add(col1)


            Dim col2 As New DataColumn("KPIStatus", Type.GetType("System.String"))
            tmptable.Columns.Add(col2)

            Dim sqlstr2 As String =
             "SELECT  ItemID, ItemDescription, KPIProgressID " &
             "FROM KPIProgressUpdates,  KPIProgress  " &
             "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
             "And KPIProgressUpdates.JobID = '" & JobID & "' " &
             "And KPIProgressUpdates.KPIItemID = KPIProgress.ItemID " &
             "And KPIProgressUpdates.CFPROID = KPIProgress.CFPROID " &
             "Order by UpdateDate Desc "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            LabelCount.Text = tmptable.Rows.Count & " Updates"
            If tmptable.Rows.Count > 0 Then
                Dim a As Integer
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    dv1.RowFilter = "UserID = " & "'" & drow("UserID") & "'"

                    If dv1.Count > 0 Then
                        drow("UserNames") = dv1(0)("UserNames")
                    End If

                    dv2.RowFilter = "KPIProgressID = '" & drow("KPIProgressID") & "' "

                    If dv2.Count > 0 Then
                        drow("KPIStatus") = "KPI: " & dv2(0)("ItemDescription")
                    End If

                    a = a + 1

                Next
            Else
                Dim drow As DataRow
                drow = tmptable.NewRow
                drow("Status") = "No Status Updates"
                tmptable.Rows.Add(drow)
            End If


            GridProgressUpdates.DataSource = tmptable
            GridProgressUpdates.DataBind()

            If Not Rowindex < 0 Then
                If GridProgressUpdates.Rows.Count > 0 Then
                    If Rowindex < 0 Then
                        Rowindex = 0
                    End If

                    If Rowindex > GridProgressUpdates.Rows.Count - 1 Then
                        Rowindex = GridProgressUpdates.Rows.Count - 1
                    End If

                    GridProgressUpdates.SelectedIndex = Rowindex

                    Dim row As GridViewRow = GridProgressUpdates.Rows(Rowindex)
                    row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
                End If
            End If


            ModalPopupExtender1.Hide()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try


    End Sub
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click
        Call DeleteUpdateStatus()
    End Sub


    Private Sub DeleteUpdateStatus()
        LabelUpdateEdit.Text = ""
        If GridProgressUpdates.SelectedIndex >= 0 Then
            Dim Index As Integer = GridProgressUpdates.SelectedIndex
            Dim ID As Integer = GridProgressUpdates.DataKeys(Index).Values(0)
            Dim KPIProgressID As String = GridProgressUpdates.DataKeys(Index).Values(1)

            Call clsProgressUpdates.SaveProgressUpdate(LabelCFPROID.Text, LabelJobID.Text, ID, KPIProgressID, "", "", "", True, LabelMessage1.Text)
            Dim Rowindex As Integer = GridProgressUpdates.SelectedIndex
            Call LoadJobProgress(LabelJobID.Text, LabelCFPROID.Text, Rowindex)
        Else
            LabelMessage.Text = "No Item Selected."
        End If

    End Sub
    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditUpdate(LabelJobID.Text, True)
    End Sub
    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        AddEditUpdate(LabelJobID.Text, False)
    End Sub

    Private Sub AddEditUpdate(JobID As String, Edit As Boolean)
        Try

            TextStatusUpdate.Text = ""
            TextUpdateDate.Text = ""

            Call LoadJobKPIs(LabelCFPROID.Text, JobID, "", "")

            LabelUpdateMessage.Text = "Select Appropriate Performance Indicator below for your status update."
            LabelUpdateMessage.ForeColor = Color.Black

            If Not Edit Then
                LabelUpdateEdit.Text = "Add"
                LabelUpdateAddEditStatus.Text = "Add Progress Update"

                If IsDate(TodaysDate.Value) Then
                    TextUpdateDate.Text = Format(CDate(clsSubs.AbsoluteDateTime(TodaysDate.Value)), "dd MMM yyyy hh:mm tt")
                Else
                    TextUpdateDate.Text = Format(Now, "dd MMM yyyy hh:mm tt")
                End If

            Else

                If GridProgressUpdates.SelectedIndex >= 0 Then

                    LabelUpdateEdit.Text = "Edit"
                    LabelUpdateAddEditStatus.Text = "Edit Progress Update"


                    Dim Index As Integer = GridProgressUpdates.SelectedIndex
                    Dim KPIItemID As String = GetKPIItemID(GridProgressUpdates.DataKeys(Index).Values(1))

                    Dim Row As GridViewRow = GridProgressUpdates.SelectedRow

                    Dim LabelStatus As Label = DirectCast(Row.FindControl("LabelStatus"), Label)
                    Dim LabelStatusDate As Label = DirectCast(Row.FindControl("LabelStatusDate"), Label)


                    TextStatusUpdate.Text = labelStatus.Text
                    TextUpdateDate.Text = Format(CDate(LabelStatusDate.Text), "dd MMM yyyy hh:mm tt")

                    Call SetSelectedKPIItem(KPIItemID)
                    ' Call CompletedKPIs(LabelCFPROID.Text, JobID)
                Else
                    LabelMessage.Text = "No selection Made."
                    Exit Sub
                End If
            End If


            LabelMessage.Text = ""
            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelMessage1.Text = ""
        End Try
    End Sub

    Private Sub SetSelectedKPIItem(KPIItemID As String)


        Dim radbut1 As RadioButton
        Dim fieldDocTypeID As HiddenField
        Dim item As DataListItem

        For Each item In DataListKPIs.Items

            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                radbut1 = DirectCast(item.FindControl("RadioSelectKPI"), RadioButton)
                fieldDocTypeID = DirectCast(item.FindControl("FieldDocumentTypeID"), HiddenField)

                If fieldDocTypeID.Value = KPIItemID Then
                    LabelItemIDText.Text = KPIItemID
                    item.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    radbut1.Checked = True
                    Exit For
                End If
            End If

        Next




    End Sub


    Private Function GetKPIItemID(KPIProgressID As String) As String

        Dim sqlstr As String =
            "SELECT KPIItemID " &
            "FROM KPIProgressUpdates " &
            "Where KPIProgressID = '" & KPIProgressID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            Return drow("KPIItemID")

        Else
            Return "-1"
        End If

    End Function
    Protected Sub ButtonSaveUpdate_Click(sender As Object, e As EventArgs) Handles ButtonSaveUpdate.Click
        Call SaveUpdate()
    End Sub

    Private Sub SaveUpdate()

        If LabelItemIDText.Text = "" Then
            LabelUpdateMessage.ForeColor = Color.Red
            LabelUpdateMessage.Text = " Please Select Appropriate Performace Indicator. Not Saved."
            ModalPopupExtender1.Show()
            Exit Sub
        End If


        If Trim(TextStatusUpdate.Text) = "" Then
            LabelUpdateMessage.ForeColor = Color.Red
            LabelUpdateMessage.Text = " Please Enter or Select Status Update. Not Saved."
            ModalPopupExtender1.Show()
            Exit Sub
        End If


        LabelUpdateMessage.Text = "Select Appropriate Performance Indicator below for your status update."
        LabelUpdateMessage.ForeColor = Color.Black
        Dim edit As Boolean
        Dim Index As Integer = GridProgressUpdates.SelectedIndex
        Dim ID As Integer

        Dim KPIProgressID As String = "-1"
        Dim Rowindex As Integer
        If LabelUpdateEdit.Text = "Add" Then
            edit = False
            Rowindex = 0
            ID = -1
        Else
            edit = True
            Rowindex = GridProgressUpdates.SelectedIndex
            ID = GridProgressUpdates.DataKeys(Index).Values(0)
            KPIProgressID = LabelKPIProgressID.Text
        End If

        ModalPopupExtender1.Hide()

        Call clsProgressUpdates.UpdateKPIProgress(LabelCFPROID.Text, LabelJobID.Text, LabelItemIDText.Text, KPIProgressID,
                                                   Trim(TextStatusUpdate.Text), Trim(TextUpdateDate.Text), LabelCFPROUserID.Text, ID, edit, False, LabelMessage1.Text)

        Call LoadJobProgress(LabelJobID.Text, LabelCFPROID.Text, Rowindex)

    End Sub


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridProgressUpdates, "Select$" & e.Row.RowIndex)
            e.Row.ToolTip = "Click to select this row."
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridProgressUpdates.SelectedIndexChanged
        Dim row As GridViewRow = GridProgressUpdates.Rows(GridProgressUpdates.SelectedIndex)
        LabelKPIProgressID.Text = GridProgressUpdates.DataKeys(GridProgressUpdates.SelectedIndex).Values(1)

        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridProgressUpdates.Rows.Count - 1
            row = GridProgressUpdates.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridProgressUpdates.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub
    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadJobKPIs(LabelCFPROID.Text, LabelJobID.Text, Trim(TextSearch.Text), ItemIDField.Value)
    End Sub

    'Protected Sub TextSearch_TextChanged(sender As Object, e As EventArgs) Handles TextSearch.TextChanged
    '    Call LoadJobKPIs(LabelCFPROID.Text, LabelJobID.Text, Trim(TextSearch.Text), ItemIDField.Value)

    '    ModalPopupExtender1.Show()
    'End Sub


    Private Sub LoadJobKPIs(CFPROID As String, JobID As String, SearchStr As String, ItemID As String)

        Try



            Dim tmpstr As String = ""

            If Not ItemID = "" Then
                tmpstr = "And ItemID = '" & ItemID & "' "
            Else
                If Not SearchStr = "" Then
                    tmpstr = "And ItemDescription Like '%" & SearchStr & "%' "
                End If
            End If


            Dim sqlstr As String =
                    "Select ItemID, ItemDescription " &
                    "FROM KPIProgress " &
                    "Where CFPROID = '" & CFPROID & "' " &
                     tmpstr &
                    "Order By SortOrder Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then
                Call clsProgressUpdates.CreateAccountKpiSettings(CFPROID, tmptable)
            End If

            Dim col As New DataColumn("ItemCount", Type.GetType("System.String"))
            tmptable.Columns.Add(col)

            Dim col1 As New DataColumn("ID", Type.GetType("System.String"))
            tmptable.Columns.Add(col1)

            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemCount") = a + 1 & "."
                a = a + 1
            Next

            DataListKPIs.DataSource = tmptable
            DataListKPIs.DataBind()

            ModalPopupExtender1.Show()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Protected Sub RadioSelectKPI_CheckedChanged(sender As Object, e As EventArgs)
        Call SetKPISelected(sender)
    End Sub

    Private Sub SetKPISelected(sender As Object)

        Dim radbut As RadioButton = (CType(sender, RadioButton))
        Dim item As DataListItem = (CType(radbut.NamingContainer, DataListItem))
        If radbut.Checked Then
            item.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        End If

        Dim fieldDocTypeID As HiddenField
        fieldDocTypeID = DirectCast(item.FindControl("FieldDocumentTypeID"), HiddenField)
        LabelItemIDText.Text = fieldDocTypeID.Value

        Dim itemtext As Label
        itemtext = DirectCast(item.FindControl("LabelKPIItem"), Label)



        Dim radbut1 As RadioButton


        Dim a As Integer
        Dim itemindex As Integer = item.ItemIndex

        For Each item1 As DataListItem In DataListKPIs.Items

            If item1.ItemType = ListItemType.Item OrElse item1.ItemType = ListItemType.AlternatingItem Then
                radbut1 = DirectCast(item1.FindControl("RadioSelectKPI"), RadioButton)

                If a <> itemindex Then
                    item1.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    radbut1.Checked = False
                End If
                a = a + 1
            End If
        Next

        LabelItemIndex.Text = itemindex
        TextStatusUpdate.Focus()
        ' TextStatusUpdate.Text = itemtext.Text




        ModalPopupExtender1.Show()

    End Sub

    Private Sub CompletedKPIs(CFPROID As String, JobID As String)

        Try
            If GridProgressUpdates.SelectedIndex > 0 Then
                Dim sqlstr As String =
                  "SELECT  KPIItemID, UpdateDate, ID " &
                  "FROM KPIProgressUpdates " &
                  "Where JobID = '" & JobID & "' " & _
                  "And CFPROID = '" & CFPROID & "' " & _
                  "Order by UpdateDate Desc;"

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)
                Dim drow As DataRow

                Dim item As DataListItem
                Dim labitemid As Label

                Dim a As Integer

                Dim KPIItemID As String = GetKPIItemID(GridProgressUpdates.DataKeys(GridProgressUpdates.SelectedIndex).Values(1))

                For Each item In DataListKPIs.Items
                    For Each drow In tmptable.Rows
                        Call clsData.NullChecker(tmptable, a)
                        If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                            labitemid = TryCast(item.FindControl("LabelItemID"), Label)
                            If CInt(labitemid.Text) <= KPIItemID Then
                                item.BackColor = ColorTranslator.FromHtml("#EEEEEE")
                            End If
                        End If
                        a = a + 1
                    Next
                Next
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonStatusSuggestion_Click(sender As Object, e As EventArgs) Handles ButtonStatusSuggestion.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "statusupdate", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ModalPopupExtender1.Show()
    End Sub


    <System.Web.Script.Services.ScriptMethod(), _
  System.Web.Services.WebMethod()> _
    Public Shared Function SearchStatusUpdate(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return clsProgressUpdates.GetStatusUpdate(prefixText, count)
    End Function

    <System.Web.Script.Services.ScriptMethod(), _
System.Web.Services.WebMethod()> _
    Public Shared Function SearchPI(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return clsProgressUpdates.GetKPI(prefixText, count)
    End Function


    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetStatusUpdate(sender)
    End Sub


    Private Sub SetStatusUpdate(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim ItemID As String = link.CommandArgument.ToString
            Dim statusupdate As String = link.Text

            TextStatusUpdate.Text = statusupdate

            ModalPopupExtender2.Hide()
            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Dim Rowindex As Integer = GridProgressUpdates.SelectedIndex
        Call LoadJobProgress(LabelJobID.Text, LabelCFPROID.Text, Rowindex)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        Call SearchUpdate()
    End Sub


    Private Sub SearchUpdate()

        Dim sqlstr As String = _
                "Select StatusID,StatusUpdate,ID  " & _
                "From StatusUpdates " & _
                "Where StatusUpdate  Like '%" & Trim(TextSearchItem.Text) & "%' " & _
                "Order By StatusID Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("StatusID")))
            drow("Item") = (Trim(drow("StatusUpdate")))
            a = a + 1
        Next


        LabelItemMessage.Text = tmptable.Rows.Count & " Status Updates found matching '" & Trim(TextSearchItem.Text) & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & TextSearchItem.Text & "'"
            tmptable.Rows.Add(drow)
        End If


        LabelItemHeader.Text = "Status Updates"

        DataList2.DataSource = tmptable
        DataList2.DataBind()

        ModalPopupExtender2.Show()
        ModalPopupExtender1.Show()
    End Sub



    'Private Sub ViewProgressReport()
    '    GridProgressUpdates.Visible = False
    '    Dim host As String = Request.Url.Host

    '    If Not host.Contains("cfproonline") Then
    '        host = host & ":90"
    '    End If

    '    host = "http://" & host

    '    Dim ProgressReport As String = host & "/progressreport.aspx?loadedbyimporter=0&jobid=" & LabelJobID.Text
    '    Page.ClientScript.RegisterClientScriptBlock(GetType(String), "", "self.parent.location='" & ProgressReport & "';", True)

    'End Sub
End Class