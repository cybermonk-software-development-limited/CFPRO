﻿Imports System.IO
Imports System.Drawing


Public Class standardvisibility
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If

            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If


            Call LoadShippers(CFPROID)
            Call LoadCFAgentUsers(CFPROID)
            Call LoadVesselStatus(CFPROID)
            Call LoadJobStatus(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadCFS(CFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadJobs(Scope As String, DispatchDate As Boolean, CFPROID As String, CFPROUserID As String)

        Dim tmpstr As String = ""
        Dim tmpstrA As String = ""
        Dim tmpstrB As String = ""

        Dim tmpstrC As String = ""
        Dim sqlstr As String = ""
        Dim sqlstr1 As String = ""
        Dim sqlstr4 As String = ""
        Try
            Dim Opdate As String


            If DispatchDate Then
                Opdate = "DispatchDate"
            Else
                Opdate = "JobDate"
            End If




            If Not Scope = "(All)" Then
                tmpstr = " And Jobs." & Opdate & " >= '" & TextFromDate.Text & "' " &
                          " And Jobs." & Opdate & " <= '" & TextToDate.Text & "' "

                tmpstrB = "From Jobs "

            Else
                tmpstr = " And ID > 0 "
                tmpstrB = "From Jobs "

            End If



            Select Case ComboLoadedJobs.Text
                Case "Open + Jobs Kept Visible"
                    tmpstr = tmpstr &
                                " And Jobs.JobStatus Not Like '%Closed%' "

                    tmpstrA = " And Jobs.KeepVisible = 1  "

                    tmpstrB = "From Jobs "

                Case "Open Jobs"
                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "

                    tmpstrB = "From Jobs "

                Case "All Jobs"

                    tmpstr = tmpstr & ""

                    tmpstrB = "From Jobs "

                Case "Closed Jobs"

                    tmpstrC =
                        "And (Jobs.JobStatus Like '%Closed%'  " &
                        "Or JobProgress.KPIProgressID = '000026') " &
                        "And JobProgress.JobID = Jobs.JobID " &
                        "And JobProgress.CFPROID = '" & CFPROID & "' " &
                        "And JobProgress.Date  >= '" & TextFromDate.Text & "' " &
                        "And JobProgress.Date <= '" & TextToDate.Text & "' "

                    tmpstrB = "From Jobs,JobProgress "

                Case "Jobs Kept Visible Only"
                    tmpstr = "And  Jobs.KeepVisible = 1  "
                    tmpstrB = "From Jobs "

            End Select

            Dim tmpstr1 As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr1 = "And UserID = '" & CFPROUserID & "' "




            End If

            Dim sqlstrA As String = ""


            sqlstr =
               "Select Top " & ComboSelectTop.Text & " " &
               "Jobs.JobID, ReferenceNo,ReferenceNo1," &
               "Jobs.JobDate, Jobs.ClientID, " &
               "ImporterID,AgentID," &
               "CFSID, VesselID, ShippingLineID, " &
               "CustomsSystem,BL,OrderNo,Goods," &
               "ShipperID,DeclarationPersonnel," &
               "ShippingPersonnel,ShipStatus," &
               "VerificationPersonnel,RegistrationPersonnel," &
               "PortStaff,Jobs.JobTypeID,SOC,Jobs.KeepVisible," &
               "DispatchDate,EntensionRequested," &
               "EntryRegistrationDate,EntryPassDate," &
               "ManifestNo,ExtensionEndDate," &
               "RemainingExtensionDays,Jobs.JobStatus," &
               "Jobs.UserID, Jobs.ID " &
               tmpstrB &
               "Where Jobs.CFPROID = '" & CFPROID & "' "


            sqlstrA = sqlstr & tmpstr & tmpstrC & " " & tmpstr1

            Dim tmptable As New DataTable("JobsData")
            Call clsData.TableData(sqlstrA, tmptable, clsData.constr)


            If ComboLoadedJobs.Text = "Open + Jobs Kept Visible" Then
                sqlstrA = sqlstr & tmpstrA & " " & tmpstr1
                Dim tmptableA As New DataTable("JobsData1")
                Call clsData.TableData(sqlstrA, tmptableA, clsData.constr)
                tmptable.Merge(tmptableA)
            End If


            Dim sqlstrB As String

            sqlstr1 =
                 "Select JobCargo.JobID,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate, CrossBorderDate,ReturnDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID "


            sqlstrB = sqlstr1 & tmpstr
            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstrB, tmptable1, clsData.constr)

            If ComboLoadedJobs.Text = "Open + Jobs Kept Visible" Then
                sqlstrB = sqlstr1 & tmpstrA
                Dim tmptable1A As New DataTable()
                Call clsData.TableData(sqlstrB, tmptable1A, clsData.constr)
                tmptable1.Merge(tmptable1A)
            End If

            Dim dv1 As New DataView(tmptable1)

            Dim sqlstr2 As String =
                      "Select CFSID, CFS, " &
                      "LocalFreeDays, TransitFreeDays,ID " &
                      "From CFS " &
                      "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)

            Dim sqlstrC As String
            sqlstr4 =
                       "Select TOP 1 WITH TIES JobProgress.JobID," &
                       "Status,KPIProgressID, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                        "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID "


            sqlstrC = sqlstr4 & tmpstr &
                      "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"
            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstrC, tmptable4, clsData.constr)


            If ComboLoadedJobs.Text = "Open + Jobs Kept Visible" Then
                sqlstrC = sqlstr4 & tmpstrA &
                    "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"
                Dim tmptable4A As New DataTable()
                Call clsData.TableData(sqlstrC, tmptable4A, clsData.constr)

                tmptable4.Merge(tmptable4A)
            End If

            Dim dv4 As New DataView(tmptable4)


            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "


            Dim sqlstr7 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)





            Dim drow As DataRow
            Dim a, b, c As Integer


            Dim found As Boolean
            Dim tmpdate3 As Date
            Dim tmpstr3(0) As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
            Dim col20 As New DataColumn("PortExitDate", Type.GetType("System.DateTime"))
            Dim col30 As New DataColumn("CrossBorderDate", Type.GetType("System.DateTime"))

            Dim col8 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col9 As New DataColumn("ContainerNos", Type.GetType("System.String"))
            Dim col10 As New DataColumn("DaysTaken", Type.GetType("System.Double"))

            Dim col12 As New DataColumn("Quantity", Type.GetType("System.Double"))

            Dim col13 As New DataColumn("CBM", Type.GetType("System.Double"))
            Dim col14 As New DataColumn("Weight", Type.GetType("System.Double"))
            Dim col15 As New DataColumn("ProgressStatus", Type.GetType("System.String"))
            Dim col16 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col17 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col18 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col19 As New DataColumn("ShippingLine", Type.GetType("System.String"))



            Dim col21 As New DataColumn("DutyPaid", Type.GetType("System.String"))
            Dim col22 As New DataColumn("BIFValue", Type.GetType("System.String"))
            Dim col23 As New DataColumn("T812", Type.GetType("System.String"))
            Dim col24 As New DataColumn("Accounts", Type.GetType("System.String"))
            Dim col25 As New DataColumn("Receiving", Type.GetType("System.String"))
            Dim col26 As New DataColumn("Invoicing", Type.GetType("System.String"))
            Dim col27 As New DataColumn("BIFCancellation", Type.GetType("System.String"))

            Dim col7 As New DataColumn("DemurrageFreeDays", Type.GetType("System.Double"))
            Dim col11 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
            Dim col28 As New DataColumn("StorageDays", Type.GetType("System.Double"))
            Dim col29 As New DataColumn("StorageFreeDays", Type.GetType("System.Double"))

            Dim col31 As New DataColumn("IsFileClosed", Type.GetType("System.Boolean"))
            Dim col32 As New DataColumn("FileClosedStatus", Type.GetType("System.String"))


            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)
            tmptable.Columns.Add(col17)
            tmptable.Columns.Add(col18)
            tmptable.Columns.Add(col19)
            tmptable.Columns.Add(col20)


            tmptable.Columns.Add(col21)
            tmptable.Columns.Add(col22)
            tmptable.Columns.Add(col23)
            tmptable.Columns.Add(col24)
            tmptable.Columns.Add(col25)
            tmptable.Columns.Add(col26)
            tmptable.Columns.Add(col27)
            tmptable.Columns.Add(col28)
            tmptable.Columns.Add(col29)
            tmptable.Columns.Add(col30)

            tmptable.Columns.Add(col31)
            tmptable.Columns.Add(col32)

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now
            Dim ts As TimeSpan

            Dim CrossedBorder As Boolean

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                If Not CDate(drow("ExtensionEndDate")) = CDate("1-Jan-1800") Then
                    tmpdate3 = drow("ExtensionEndDate")
                    drow("RemainingExtensionDays") = CInt((tmpdate3.Subtract(CDate(Now)).TotalDays))
                Else
                    drow("RemainingExtensionDays") = "0"
                End If

                drow("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")
                drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")

                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"

                c = 0
                TEU = 0
                CBM = 0
                Weight = 0




                CrossedBorder = True

                If dv1.Count > 0 Then
                    For b = 0 To dv1.Count - 1
                        Call clsData.NullChecker1(dv1, b)
                        c = c + 1
                        CBM = CBM + dv1(b)("CBM")
                        Weight = Weight + dv1(b)("Weight")
                        TEU = TEU + Val(dv1(b)("TEU"))

                        If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                            CrossedBorder = False
                        End If

                        ReDim Preserve tmpstr3(b)
                        tmpstr3(b) = dv1(b)("ContainerNo")



                    Next

                    dv1.Sort = "PortExitDate DESC"


                    drow("PortExitDate") = Format(dv1(0)("PortExitDate"), "dd MMM yyyy")

                    dv1.Sort = "CrossBorderDate DESC"
                    drow("CrossBorderDate") = Format(dv1(0)("CrossBorderDate"), "dd MMM yyyy")


                End If

                drow("CrossedBorder") = CrossedBorder


                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Quantity") = dv1.Count
                drow("TEU") = TEU
                drow("CBM") = CBM
                drow("Weight") = Weight


                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")
                    drow("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), drow("DispatchDate"))
                End If

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")

                    drow("StorageFreeDays") = clsShippingStorage.StorageFreeDays(CFPROID, drow("ClientID"), drow("CFSID"), drow("JobType"), dv2(0)("TransitFreeDays"), dv2(0)("LocalFreeDays"))

                    If CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                        drow("StorageDays") = 0
                    Else
                        dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "' "
                        dv1.Sort = "PortExitDate DESC"

                        If dv1.Count > 0 Then
                            drow("PortExitDate") = dv1(0)("PortExitDate")


                            Call clsData.NullChecker1(dv1, 0)
                            If CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                                tmpdate = Now
                            Else
                                tmpdate = drow("PortExitDate")
                            End If

                            ts = tmpdate.Subtract(CDate(drow("LastSlingDate")))
                            ' drow("StorageDays") = drow("StorageFreeDays") - (ts.Days)
                            drow("StorageDays") = clsShippingStorage.GetStorageDays(drow("LastSlingDate"), drow("StorageFreeDays"), drow("PortExitDate"), LabelMessage1.Text)

                        End If
                    End If

                End If




                dv4.RowFilter = "JobID = '" & drow("JobID") & "' "


                If InStr(drow("JobStatus"), "Clos", CompareMethod.Text) > 0 Then
                    drow("FileClosedStatus") = "fileclosed"
                    drow("IsFileClosed") = CBool(1)
                Else
                    drow("FileClosedStatus") = "filenotclosed"
                    drow("IsFileClosed") = CBool(0)
                End If


                If dv4.Count > 0 Then
                    Call clsData.NullChecker1(dv4, 0)
                    dv4.Sort = "Date DESC"
                    drow("ProgressStatus") = dv4(0)("Status")

                    If dv4(0)("KPIProgressID") = "000026" Then
                        drow("FileClosedStatus") = "fileclosed"
                        drow("IsFileClosed") = CBool(1)
                    End If
                End If

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Client") = Mid(dv5(0)("Client"), 1, 25)
                End If


                found = False
                tmpdate = Now


                dv7.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "

                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)

                    drow("ShippingLine") = dv7(0)("ShippingLine")

                    drow("DemurrageFreeDays") = clsShippingStorage.DemurrageFreeDays(CFPROID, drow("ClientID"), drow("ShippingLineID"), drow("JobType"), dv7(0)("TransitReturnDays"), dv7(0)("LocalReturnDays"))


                    If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                        drow("DemurrageDays") = 0
                    Else
                        dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "' "
                        dv1.Sort = "ReturnDate DESC"

                        If dv1.Count > 0 Then
                            drow("ReturnDate") = dv1(0)("ReturnDate")


                            Call clsData.NullChecker1(dv1, 0)
                            If CDate(drow("ReturnDate")) = CDate("1-Jan-1800") Then
                                tmpdate = Now
                            Else
                                tmpdate = drow("ReturnDate")
                            End If

                            ts = tmpdate.Subtract(CDate(drow("BerthingDate")))
                            ' drow("DemurrageDays") = drow("DemurrageFreeDays") - (ts.Days)

                            drow("DemurrageDays") = clsShippingStorage.GetDemurrageDays(tmptable1, drow("JobID"), drow("BerthingDate"),
                                            drow("ReturnDate"), drow("DemurrageFreeDays"), -1,
                                            drow("SOC"), drow("JobType"), drow("PortExitDate"), drow("CrossBorderDate"), LabelMessage1.Text)

                        End If
                    End If

                End If
                a = a + 1

            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
                Call clsData.NullChecker(tmptable, 0)
            End If


            If tmptable.Rows.Count > 10 Then
                PanelJobs.Height = 300
            Else
                PanelJobs.Height = Nothing
            End If



            Dim dv As New DataView(tmptable)


            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort
            GridJobs.DataSource = dv
            GridJobs.DataBind()

            Call Calctotal(dv, "")


            Session("JobsTable") = tmptable

            LabelMessage1.Text = ""


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Private Sub LoadShippers(CFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopComboWithValue(ComboCFAgentUsers, sqlstr, clsData.constr, 0, 1)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatus(CFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus " &
       "Where CFPROID = '" & CFPROID & "' "

        ComboJobStatus.Items.Clear()
        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select ItemDescription,ItemID " &
         "From KPIProgress "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr1, clsData.constr, 0, 1)

        ComboJobStatus.Items.Insert(0, "(All)")
        ComboJobStatus.Items(ComboJobStatus.Items.Count - 1).Value = "0"
    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()

        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If
                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If


                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterAgent" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterClient" Then
                    Continue For
                End If

                If cont.ID = "CheckJobStatus" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterConsignee" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterJobType" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterShipper" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCFS" Then
                    Continue For
                End If

                If cont.ID = "CheckCFAgentUser" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCustomsSystem" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitCrossedBorder" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitDispatched" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM dd yyyy hh:mm:ss tt")

            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFPROID, CFPROUserID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFPROID, CFPROUserID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")

            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & ")"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & ")"
            End If

            If tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = dv.Count & " Jobs: " & tmpstr

                Else
                    LabelReportCaption.Text = dv.Count & " DISPATCHED JOBS: " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelReportCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelReportCaption.Text = dv.Count & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a As Integer = 0

            Dim CFPROID As String = LabelCFPROID.Text

            'If Not clsData.TableCacheOK(CFPROID, clsData.JobsTable) Then
            '    Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, CFPROID, False, True)
            'End If

            If IsNothing(Session("JobsTable")) Then
                Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If


            Dim JobsTable As New DataTable("JobsTable")
            JobsTable = DirectCast(Session("JobsTable"), DataTable)

            Dim dv As New DataView(JobsTable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                tmpstr1(a) = "Agent : " & TextAgent.Text
                a = a + 1
            End If


            If Client Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                a = a + 1


            End If

            If Importer Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                a = a + 1
            End If

            If Shipper Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                a = a + 1
            End If

            If ShipStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                a = a + 1
            End If

            If JobType Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                a = a + 1
            End If

            If JobStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                a = a + 1
            End If


            If CFS Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                a = a + 1
            End If

            'If EntensionRequested Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
            '    Else
            '        tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
            '    End If

            '    tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
            '    b = b + 1
            'End If

            If OmitDispatched Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus  Not LIKE '%Dispatched%' "
                Else
                    tmpstr(a) = " And JobStatus Not LIKE '%Dispatched%' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                a = a + 1
            End If


            If OmitCrossedBorder Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                a = a + 1
            End If

            If CustomsSystem Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CustomsSystem Like '%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like '%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                a = a + 1
            End If



            If CFAgentUser Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)

                If a = 0 Then

                    tmpstr(a) = " (UserID = '" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like '%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like '%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like '%" & UserNames & "%' " &
                                "Or PortStaff Like '%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like '%" & UserNames & "%') "

                Else
                    tmpstr(a) = " (And UserID = '" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like '%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like '%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like  '%" & UserNames & "%' " &
                                "Or PortStaff Like '%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like '%" & UserNames & "%') "

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                a = a + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridJobs.DataSource = dv
            GridJobs.DataBind()


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobID"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "VesselETA"

        ElseIf RadioButtonList1.SelectedIndex = 4 Then
            Return "StorageDays"

        ElseIf RadioButtonList1.SelectedIndex = 5 Then
            Return "DemurrageDays"
        Else
            Return "JobDate"
        End If
    End Function


    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckAgent.Checked, CheckClient.Checked, CheckConsignee.Checked, CheckShipper.Checked,
                            CheckShipStatus.Checked, CheckJobType.Checked, CheckJobStatus.Checked, CheckCFS.Checked,
                            CheckOmitDispatched.Checked, CheckOmitCrossedBorder.Checked, CheckCustomsSystem.Checked, CheckCFAgentUser.Checked)
    End Sub

    Protected Sub ButtonProgressReports_Click(sender As Object, e As EventArgs) Handles ButtonProgressReports.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            If Not IsNothing(GridJobs.SelectedValue.ToString) Then
                Response.Redirect("progressreport.aspx?loadedbyimporter=0&jobid=" & GridJobs.SelectedValue.ToString())
            End If
        End If

    End Sub
    Private Sub LoadPage(page As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = page
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonProgressUpdates_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
        Try
            If GridJobs.SelectedValue Is Nothing Then
                LabelJobMessage.Text = "Please select an item"
            Else
                If GridJobs.SelectedIndex >= 0 Then

                End If

                Dim row As GridViewRow = GridJobs.SelectedRow

                Call LoadPage("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString & "&CFPROID=" &
                              LabelCFPROID.Text & "&referenceno=" & row.Cells(0).Text & "&jobdate=" &
                               row.Cells(1).Text & "&client=" &
                               row.Cells(2).Text, "Progress Update", 580, 780)
            End If
        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try
    End Sub




    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call nSortOrder()
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call ClearFilters()
        Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("JobsTable")) Then
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If

        Dim tmptable As DataTable = Session("JobsTable")
        Dim dv As DataView = New DataView(tmptable)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or ContainerNos Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "

        GridJobs.DataSource = dv
        GridJobs.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching " & " " & Trim(SearchStr)

        Call Calctotal(dv, tmpstr)

    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)


        If dv Is Nothing Then

            If IsNothing(Session("JobsTable")) Then
                Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobsTable As DataTable = Session("JobsTable")
            dv = New DataView(JobsTable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA " & tmpstrSort

        ElseIf SortBy = "DemurrageDays" Then
            dv.Sort = "DemurrageDays " & tmpstrSort

        ElseIf SortBy = "StorageDays" Then
            dv.Sort = "StorageDays " & tmpstrSort
        End If



        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridJobs.DataSource = dv
            GridJobs.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub

    Protected Sub ButtonPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonPDFReport.Click

        If IsNothing(Session("JobsTable")) Then
            Call LoadJobs(ComboPredefine.Text, CheckDispatchDate.Checked, LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If

        Dim JobsTable As DataTable = Session("JobsTable")

        Dim StandardVisibilityPDFPath As String = ""

        Dim StandardVisibilityPDFPath1 As String =
         clsJobPDF.StandardVisibilityPDFReport(LabelCFPROID.Text, JobsTable, LabelReportCaption.Text, LabelFilterStr.Text, LabelSortStr.Text, StandardVisibilityPDFPath, LabelMessage1.Text)

        If File.Exists(StandardVisibilityPDFPath) Then
            Call LoadDialog(StandardVisibilityPDFPath1, "Standard Visibility Report ", 600, 900)
        End If

    End Sub
    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub


    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub

    Protected Sub ComboCustomsSystem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCustomsSystem.SelectedIndexChanged
        CheckCustomsSystem.Checked = True
    End Sub

    Protected Sub ComboShippers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboShippers.SelectedIndexChanged
        CheckShipper.Checked = True
    End Sub


    Protected Sub ComboCFAgentUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgentUsers.SelectedIndexChanged
        CheckCFAgentUser.Checked = True
    End Sub

    Protected Sub ComboVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVesselStatus.SelectedIndexChanged
        CheckShipStatus.Checked = True
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub
    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click

        Select Case ComboExcelReportOptions.SelectedIndex
            Case 0
                Call ExcelVisibiltyReport()
            Case 1
                Call ExcelGeneralRegister(LabelMessage1.Text)
        End Select

    End Sub
    Private Sub ExcelVisibiltyReport()
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00015") Then
            Dim totals(5) As String

            totals(0) = "Total Weight: " & TextWeight.Text & " (Kgs)"
            totals(1) = "Total CBM: " & TextTotalCbm.Text & " Cb.M"
            totals(2) = "Total TEU: " & TextTotalTeu.Text
            totals(3) = "Total Qty: " & TextTotalQty.Text

            Dim tmpfields(13) As String
            tmpfields(0) = "ReferenceNo"
            tmpfields(1) = "JobDate"
            tmpfields(2) = "Client"
            tmpfields(3) = "Vessel"
            tmpfields(4) = "VesselETA"
            tmpfields(5) = "LastSlingDate"
            tmpfields(6) = "CFS"
            tmpfields(7) = "BL"
            tmpfields(8) = "StorageDays"
            tmpfields(9) = "DemurrageDays"
            tmpfields(10) = "DaysTaken"
            tmpfields(11) = "TEU"
            tmpfields(12) = "Quantity"
            tmpfields(13) = "ProgressStatus"


            Dim tmptable As New DataTable("JobsTable")
            tmptable = DirectCast(Session("JobsTable"), DataTable)

            Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Stardard Visibility", "Stardard Visibility",
                                                LabelReportCaption.Text, True, totals, 0, "", tmpfields, Nothing, tmptable, False)
        Else
            LabelJobMessage.Text = "User Not Allowed"
            LabelJobMessage.ForeColor = Color.Red
        End If

    End Sub

    Private Sub ExcelGeneralRegister(ByRef ErrMsg As String)

        Try

            Dim tmptable As New DataTable("JobsTable")
            tmptable = DirectCast(Session("JobsTable"), DataTable)

            Dim tmpfields(19) As String
            tmpfields(0) = "ReferenceNo"
            tmpfields(1) = "Client"
            tmpfields(2) = "ShippingLine"
            tmpfields(3) = "BL"
            tmpfields(4) = "Goods"
            tmpfields(5) = "ContainerNos"
            tmpfields(6) = "Vessel"
            tmpfields(7) = "VesselETA"
            tmpfields(8) = "JobType"
            tmpfields(9) = "EntryRegistrationDate"
            tmpfields(10) = "EntryPassDate"
            tmpfields(11) = "DutyPaid"
            tmpfields(12) = "BIFValue"
            tmpfields(13) = "T812"
            tmpfields(14) = "PortExitDate"
            tmpfields(15) = "Accounts"
            tmpfields(16) = "Receiving"
            tmpfields(17) = "Invoicing"
            tmpfields(18) = "BIFCancellation"
            tmpfields(19) = "ProgressStatus"

            Dim Columns(19) As String
            Columns(0) = "File Ref"
            Columns(1) = "Client Name"
            Columns(2) = "Shipping Line"
            Columns(3) = "BL/BW"
            Columns(4) = "Cargo Description"
            Columns(5) = "Marks & Numbers"
            Columns(6) = "Vessel"
            Columns(7) = "ETA"
            Columns(8) = "Type of Consignment"
            Columns(9) = "Date Entry Lodged"
            Columns(10) = "Date Entry Passed"
            Columns(11) = "Duty Paid"
            Columns(12) = "BIF Value"
            Columns(13) = "T812"
            Columns(14) = "Date Out of Port"
            Columns(15) = "Accounts Department"
            Columns(16) = "Receiving"
            Columns(17) = "Invoicing"
            Columns(18) = "BIF Cancellation"
            Columns(19) = "Remarks"

            Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "General Register", "General Register",
                                                   LabelReportCaption.Text, False, Nothing, 0, "", tmpfields, Columns, tmptable, False)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub




    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call RefreshData()
    End Sub

    Protected Sub LinkProgressStatus_Click(sender As Object, e As EventArgs)
        Call FileClosingSummary(sender)
    End Sub

    Private Sub FileClosingSummary(Sender As Object)
        Dim link As LinkButton = CType(Sender, LinkButton)
        Dim JobID As String = link.CommandArgument.ToString
        Call LoadDialog("fileclosing.aspx?jobid=" & JobID, "File Closing Summary", 650, 850)
    End Sub

End Class

