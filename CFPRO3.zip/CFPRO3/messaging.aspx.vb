﻿
Imports System.Drawing
Public Class messaging
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CSDID As String = ""
            Dim CFPROID As String = ""

            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)
            LabelCSDID.Text = CSDID
            LabelCFPROID.Text = CFPROID

            Call LoadMessageSubjects()
            Call LoadMessages()

            Dim UserType As String = ""
            If Not Request.Cookies("UserType") Is Nothing Then
                UserType = Request.Cookies("UserType").Value
            End If



            If UserType = "cfagent" Then
                PanelTopMenu.Visible = True
                PanelImpoterMenu.Visible = False
            Else
                PanelTopMenu.Visible = False
                PanelImpoterMenu.Visible = True
            End If

            LabelFromPageURL.Text = Page.Request.UrlReferrer.ToString

        End If
    End Sub

    Private Sub LoadMessages()
        Try

            Dim CFPROID As String = LabelCFPROID.Text

            Dim sqlstr As String = _
             "SELECT HeaderID," & _
             "JobDate,ReferenceNo,HeaderType, " & _
             "BL,ShippingVessel, LastMessageDAte " & _
             "FROM MessageHeaders, Jobs " & _
             "Where MessageHeaders.CFPROID = '" & CFPROID & "' " & _
             "And MessageHeaders.HeaderID = Jobs.JobID  " & _
             "Order By LastMessageDate Desc "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)





            Dim HeaderID As String = ""


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                HeaderID = drow("HeaderID")
            End If


            Dim col0 As New DataColumn("MessageDate", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Subject", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Sender", Type.GetType("System.String"))
            Dim col3 As New DataColumn("MessageCount", Type.GetType("System.String"))
            Dim col4 As New DataColumn("AttachmentImageURL", Type.GetType("System.String"))
            Dim col5 As New DataColumn("Count", Type.GetType("System.String"))
            Dim col6 As New DataColumn("JobDate1", Type.GetType("System.String"))

            tmptable.Columns.Add(col0)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)

            GridMessages.DataSource = tmptable
            GridMessages.DataBind()



            Dim sqlstr1 As String = _
              "SELECT MessageID,HeaderID,MessageDate,  " & _
              "Subject, Message, HasAttachment  " & _
              "FROM Messages,  MessageSubjects " & _
              "Where MessageSubjects.SubjectID = Messages.SubjectID " & _
              "And CFPROID = '" & CFPROID & "' " & _
              "Order By Messages.ID Desc "


            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)



            Dim a As Integer

            Dim sqlstr2 As String = _
             "SELECT MessageID, CFPROUserID,  " & _
             "IsRead, Direction, HeaderID  " & _
             "FROM  MessageCFPROUserIDs " & _
             "Where HeaderID ='" & HeaderID & "' " & _
             "And CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim dv As New DataView(tmptable1)

            Dim c As Integer = tmptable.Rows.Count - 1

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                dv.RowFilter = "HeaderID = '" & drow("HeaderID") & "' "
                If dv.Count > 0 Then
                    '  drow("Subject") = c - a + 1 & ". " & dv(0)("Subject")
                    drow("Subject") = dv(0)("Subject")
                End If

                drow("MessageCount") = dv.Count & " Messages"

                dv.RowFilter = "HeaderID = '" & drow("HeaderID") & "' " & _
                    "And HasAttachment = 1 "
                If dv.Count > 0 Then
                    drow("AttachmentImageURL") = "attachment.png"
                Else
                    drow("AttachmentImageURL") = "blank.png"
                End If

                drow("ReferenceNo") = "Ref: " & drow("ReferenceNo")
                drow("BL") = "BL: " & drow("BL")
                drow("JobDate1") = "Job Date: " & Format(drow("JobDate"), "dd MMM yyyy")
                a = a + 1

            Next

            If tmptable.Rows.Count < 10 Then
                GridMessages.Height = 20 + (24 * tmptable.Rows.Count)
            End If

            GridMessages.DataSource = tmptable
            GridMessages.DataBind()


            If GridMessages.Rows.Count > 0 Then
                Dim rowindex As Integer = GridMessages.SelectedIndex
                GridMessages.SelectedIndex = 0


                Call LoadMessageDetails(GridMessages.SelectedValue)


                Dim row As GridViewRow = GridMessages.Rows(0)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If

            LabelMessages.Text = "Messages - " & tmptable.Rows.Count
        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub


    Private Sub LoadMessageDetails(HeaderID As String)

        Dim CFPROUserID As String = LabelCSDID.Text
        Dim sqlstr As String = _
        "SELECT MessageDate, MessageID," & _
        "Message,HasAttachment, " & _
        "Subject,  Messages.ID " & _
        "FROM Messages,MessageSubjects " & _
        "Where HeaderID = '" & HeaderID & "' " & _
        "And MessageSubjects.SubjectID = Messages.SubjectID " & _
        "Order By Messages.ID Desc;"


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        Dim sqlstr1 As String = _
        "SELECT HeaderID, MessageID " & _
        "CFPROUserID,Direction, IsRead,ID " & _
        "FROM MessageCFPROUserIDs," & _
        "Where HeaderID = '" & HeaderID & "' "


        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


        Dim col0 As New DataColumn("Attachments", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Count", Type.GetType("System.String"))
        Dim col2 As New DataColumn("Sender", Type.GetType("System.String"))
        Dim col3 As New DataColumn("BackColor", Type.GetType("System.String"))

        tmptable.Columns.Add(col0)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)

        Dim a, b As Integer
        Dim c As Integer = tmptable.Rows.Count - 1

        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            If drow("HasAttachment") Then
                drow("Attachments") = "Open Attachments"
            End If
            b = 0
            For Each drow1 In tmptable1.Rows
                clsData.NullChecker(tmptable1, b)
                If drow1("MessageID") = drow("MessageID") Then
                    If drow1("CFPROUserID") = CFPROUserID Then
                        If drow1("Direction") = "In" Then
                            If drow1("IsRead") Then
                                drow("BackColor") = "#FCFCFC"
                            Else
                                drow("BackColor") = "#EEEEEE"
                            End If
                        End If

                    End If
                End If

                b = b + 1
            Next

            drow("Count") = c - a + 1 & "."
            a = a + 1

        Next


        DataList1.DataSource = tmptable
        DataList1.DataBind()



    End Sub




    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridMessages, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridMessages.SelectedIndexChanged
        Dim row As GridViewRow = GridMessages.Rows(GridMessages.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        Call LoadMessageDetails(GridMessages.SelectedValue.ToString)

        For a As Integer = 0 To GridMessages.Rows.Count - 1
            row = GridMessages.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridMessages.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Protected Sub Button12_Click(sender As Object, e As EventArgs) Handles Button12.Click
        Dim HeaderID As String = ""
        LoadSendMessage("sendmessage.aspx?HeaderID=" & HeaderID, " Send Message")
    End Sub

    Private Sub LoadSendMessage(funcsource As String, cfFunction As String)
        LabTitle.Text = cfFunction
        iframe1.Attributes("src") = funcsource
        ModalPopupExtender1.Show()
    End Sub


    Private Sub LoadMessageSubjects()
        Dim sqlstr As String = _
        "Select Subject, SubjectID " & _
        "From MessageSubjects " & _
        "Order By SubjectID Asc;"

        ComboMessageSubject.Items.Clear()
        ComboMessageSubject.Items.Add("(Select)")
        Call clsData.PopComboWithValue(ComboMessageSubject, sqlstr, clsData.constr, 0, 1)
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub


    Protected Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Call SearchMessages(-1)
    End Sub
    Private Sub SearchMessages(Rowindex As Integer)

        Dim sqlstr As String = _
          "SELECT Message, ID " & _
          "FROM Messages " & _
          "Where Message Like '%" & Trim(TextSearch.Text) & "%' " &
         "Order By LastMessageDate Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next


        If tmptable.Rows.Count < 10 Then
            GridMessages.Height = 20 + (24 * tmptable.Rows.Count)
        End If

        GridMessages.DataSource = tmptable
        GridMessages.DataBind()


        If GridMessages.Rows.Count > 0 Then
            If Rowindex > 0 Then
                GridMessages.SelectedIndex = Rowindex
                Call LoadMessageDetails(GridMessages.SelectedValue.ToString)
                Dim row As GridViewRow = GridMessages.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If
        End If


        LabelMessages.Text = "Messages - " & tmptable.Rows.Count & " found matching  '" & TextSearch.Text & "' "
    End Sub

    Private Sub DataList1_ItemDataBound(sender As Object, e As DataListItemEventArgs) Handles DataList1.ItemDataBound
        For Each control As Control In e.Item.Controls
            Dim drow = e.Item.DataItem

            If e.Item.ItemType = ListItemType.Item Then
                e.Item.BackColor = ColorTranslator.FromHtml(drow("BackColor").ToString)
            End If

        Next
    End Sub
End Class