﻿Imports System.IO
Imports System.Drawing

Public Class jobentry
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Call clsSubs.isMobileBrowser()

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin(LabelUserCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= 0 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If


            Dim JobID As String = ""
            If Not IsNothing(Request.QueryString("jobid")) Then
                JobID = Request.QueryString("jobid")
            End If



            ButtonDeleteJob.Visible = clsAuth.UserAllowed(CFPROID, CFPROUserID, "00009")

            Dim ReadOnlyUser As Boolean = Not clsAuth.ReadOnlyUser(CFPROID, CFPROUserID)

            Dim TransitUpdateUser As Boolean = Not clsAuth.TransitUpdateUser(CFPROID, CFPROUserID)

            If TransitUpdateUser Then
                If Not ReadOnlyUser Then
                    ReadOnlyUser = TransitUpdateUser
                End If
            End If


            If Not clsAuth.UserRole(CFPROID, CFPROUserID) = "Super Administrator" Then
                    ButtonSetUserName.Visible = False
                End If

                ButtonSaveJob.Enabled = ReadOnlyUser
                ButtonGetBroker.Enabled = ReadOnlyUser
                ButtonGetClient.Enabled = ReadOnlyUser
                ButtonSetReferenceNo.Enabled = ReadOnlyUser
                ButtonGetConsignee.Enabled = ReadOnlyUser
                ButtonGetShipper.Enabled = ReadOnlyUser

            ButtonDeleteCargo.Enabled = ReadOnlyUser
                ButtonNewFile.Enabled = ReadOnlyUser
            'ButtonSendMessage.Enabled = ReadOnlyUser
            ButtonInsurer.Enabled = ReadOnlyUser
            ButtonSaveJob.Enabled = ReadOnlyUser
            CheckKeepVisible.Enabled = ReadOnlyUser
            CheckSOC.Enabled = ReadOnlyUser
            ButtonAddCargo.Enabled = ReadOnlyUser
            ButtonEditCargo.Enabled = ReadOnlyUser



            ButtonGetBroker.Enabled = TransitUpdateUser
            ButtonGetClient.Enabled = TransitUpdateUser
            ButtonSetReferenceNo.Enabled = TransitUpdateUser
            ButtonGetConsignee.Enabled = TransitUpdateUser
            ButtonGetShipper.Enabled = TransitUpdateUser

            ButtonDeleteCargo.Enabled = TransitUpdateUser
            ButtonNewFile.Enabled = TransitUpdateUser
            ButtonInsurer.Enabled = TransitUpdateUser
            ButtonSaveJob.Enabled = TransitUpdateUser
            CheckKeepVisible.Enabled = TransitUpdateUser
            CheckSOC.Enabled = TransitUpdateUser
            ButtonAddCargo.Enabled = TransitUpdateUser






            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

            Call LoadDestinations(CFPROID)
            Call SetSearchItem()

            Call LoadJobIDS(JobID, CFPROID, CFPROUserID)


        End If

    End Sub


    Private Sub LoadJobIDS(JobID As String, CFPROID As String, CFPROUserID As String)

        Try

            Dim tmpstr As String = ""

            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr = "And UserID = '" & CFPROUserID & "' "
            End If

            Dim sqlstr As String =
            "Select JobID From Jobs " &
            "Where CFPROID = '" & CFPROID & "' " &
            tmpstr &
            "Order by ID Desc; "

            ComboJobID.Items.Clear()
            Call clsData.PopCombo(ComboJobID, sqlstr, clsData.constr, 0)

            If ComboJobID.Items.Count > 0 Then
                If JobID = "" Then
                    ComboJobID.SelectedIndex = 0
                Else
                    If Not JobID = "-1" Then
                        ComboJobID.Text = JobID
                    End If

                End If

                Call LoadJob(CFPROID, ComboJobID.Text, CFPROUserID)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & " " & exp.StackTrace
        End Try

    End Sub


    Private Sub LoadJob(CFPROID As String, JobID As String, CFPROUserID As String)

        Dim drow As DataRow


        Try
            Dim sqlstr As String =
                    "Select JobID,ReferenceNo,ReferenceNo1," &
                    "JobDate,ClientID,ImporterID," &
                    "ShipperID, AgentID," &
                    "BL,HouseBL,BLCountry," &
                    "InvoiceNo,InvoiceAmount,Goods," &
                    "JobStatus,CustomJobStatus,JobTypeID," &
                    "Destination,ModeofTransport," &
                    "ShippingLineID, VesselID, DispatchDate," &
                    "ExpiryDate,CustomsSystem,UserID," &
                    "TBL,SOC,KeepVisible,WeightUnit," &
                    "Application,ID " &
                    "From Jobs " &
                    "Where JobID ='" & JobID & "' " &
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then



                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                    If drow("UserID") <> CFPROUserID Then
                        Exit Sub
                    End If
                End If


                TextReferenceNo.Text = drow("ReferenceNo")
                TextReferenceNo1.Text = drow("ReferenceNo1")
                TextJobDate.Text = Format(drow("JobDate"), "dd MMM yyyy")
                TextMBL.Text = drow("BL")
                TextHBL.Text = drow("HouseBL")
                TextCountry.Text = drow("BLCountry")

                TextGoods.Text = drow("Goods")

                Try
                    ComboCustomsSystem.Text = drow("CustomsSystem")
                    ComboDestination.Text = drow("Destination")
                    ComboTransportMode.Text = drow("ModeofTransport")
                Catch ex As Exception

                End Try

                TextDispatchDate.Text = Format(drow("DispatchDate"), "dd MMM yyyy")
                TextExpiryDate.Text = Format(drow("ExpiryDate"), "dd MMM yyyy")
                TextJobStatus.Text = drow("JobStatus")



                CheckTBL.Checked = drow("TBL")
                CheckSOC.Checked = drow("SOC")
                CheckKeepVisible.Checked = drow("KeepVisible")

                If Not drow("WeightUnit") = "" Then
                    ComboWeightUnit.Text = drow("WeightUnit")
                End If



                TextInsuranceCode.Text = JobID & "-" & LabelCFPROID.Text
                TextInvoiceAmount.Text = Format(drow("InvoiceAmount"), "#,##0.00")
                TextInsured.Text = "Not Insured"


                Call SetClient(CFPROID, JobID, drow("ClientID"), False)
                Call SetBroker(CFPROID, JobID, drow("AgentID"), False)
                Call SetImporter(CFPROID, JobID, drow("ImporterID"), False)
                Call SetShipper(CFPROID, JobID, drow("ShipperID"), False)
                Call SetJobType(CFPROID, JobID, drow("JobTypeID"), False)
                Call CurrentKPIandJobStatus(LabelCFPROID.Text, JobID)


                If drow("JobTypeID") = "" Then
                    TextJobType.ForeColor = Color.Red
                    TextJobType.Text = "NOT SET"
                Else
                    TextJobType.ForeColor = Color.Black
                End If



                Dim tmpstr() As String = clsShippingStorage.GetVessel(CFPROID, drow("VesselID"), LabelMessage1.Text)
                ReDim Preserve tmpstr(5)

                TextDaysTaken.Text = clsShippingStorage.DaysTaken(tmpstr(5), drow("DispatchDate")).ToString
                Call clsGetIdentities.SetCFPROuser(CFPROID, drow("UserID"), drow("JobID"), LabelDoneBy.Text, False)

                If drow("Application") = "" Then
                    If drow("JobID").ToString.Length < 6 Then
                        LabelApplication.Text = "On C&F PRO Desktop 1.0"
                    Else
                        LabelApplication.Text = "On C&F PRO Online"
                    End If
                Else
                    LabelApplication.Text = "On " & drow("Application")
                End If

                If drow("ReferenceNo1") = "" Then
                    Call SetReferenceNo2(TextJobType.Text)
                End If

                LabelJobsCount.Text = ComboJobID.Items.Count - ComboJobID.SelectedIndex & " Jobs  of " & ComboJobID.Items.Count
                ButtonJobDocuments.Text = "Job Documents - " & clsDocuments.DocumentCount(CFPROID, JobID, "", "", "", "jobdocuments", LabelMessage1.Text)


                Session("JobCardTable") = tmptable

                Session("ResetCaches") = "1"

                Call clsActionCenter.ReceivedJobDocuments(CFPROID, drow("JobID"), drow("JobTypeID"), ButtonReceivedDocs.Text, LinkDocuments.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkDocuments)

                Call clsActionCenter.ProgressUpdateStatus(CFPROID, drow("JobID"), LinkProgressStatus.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkProgressStatus)


                Call clsActionCenter.MissingShippingInformation(CFPROID, drow("JobID"), LinkShippingStatus.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkShippingStatus)

                Call clsActionCenter.StorageandDemurrage(CFPROID, drow("JobID"), LinkStorageStatus.Text, LinkDemurrageStatus.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkStorageStatus)
                Call StatusColour(LinkDemurrageStatus)

                Call clsActionCenter.InvoiceAlerts(CFPROID, drow("JobID"), LinkInvoicing.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkInvoicing)

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        Finally
            Call LoadJobCargo(CFPROID, JobID, -1)
        End Try

    End Sub

    Private Sub StatusColour(ByRef Link As LinkButton)
        If Link.Text.Contains("Incurred") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("Inc") Then
            Link.CssClass = "amberstatus"

        ElseIf Link.Text.Contains("All") Then

            Link.CssClass = "greenstatus"
        ElseIf Link.Text.Contains("Ok") Then
            Link.CssClass = "greenstatus"

        ElseIf Link.Text.Contains("7+") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("3+") Then
            Link.CssClass = "amberstatus"

        ElseIf Link.Text.Contains("Up to date") Then
            Link.CssClass = "greenstatus"

        ElseIf Link.Text.Contains("Not Berthed") Then
            Link.CssClass = "greenstatus"

        ElseIf Link.Text.Contains("No ETA") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("No Berthing Date") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("No Last Sling") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("No Shipping Line") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("Not Updated") Then
            Link.CssClass = "redstatus"


        ElseIf Link.Text.Contains("Not Invoiced") Then
            Link.CssClass = "redstatus"

        ElseIf Link.Text.Contains("Invoiced 0") Then
            Link.CssClass = "amberstatus"

        ElseIf Link.Text.Contains("In") Then
            Link.CssClass = "greenstatus"

        ElseIf Link.Text.Contains("Than") Then
            Link.CssClass = "amberstatus"

        ElseIf Link.Text.Contains("Begins") Then
            Link.CssClass = "amberstatus"
        Else
            Link.CssClass = "nostatus"
        End If
    End Sub


    Private Sub LoadJobCargo(CFPROID As String, ByVal JobID As String, Optional ByRef RowIndex As Integer = -1)


        Dim sqlstr As String =
           "Select JobID,ContainerNo,Payload," &
           "TEU,Weight,CBM," &
           "VehicleNo,TransporterID," &
           "PortExitDate,CrossBorderDate," &
           "ReturnDate,InterchangeNo," &
           "ContainerStatus,ID " &
           "From JobCargo " &
           "Where JobID = '" & JobID & "' " &
           "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim sqlstr1 As String =
                   "Select Transporter,TransporterID " &
                   "From Transporters " &
                   "Where CFPROID = '" & CFPROID & "' "


        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

        Dim dv1 As New DataView(tmptable1)

        Dim col As New DataColumn("EditCargo", Type.GetType("System.String"))
        Dim col1 As New DataColumn("MoreCargoDetails", Type.GetType("System.String"))
        Dim col4 As New DataColumn("Transporter", Type.GetType("System.String"))
        Dim col5 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
        Dim col6 As New DataColumn("StorageDays", Type.GetType("System.Double"))
        Dim col7 As New DataColumn("PortExitDate1", Type.GetType("System.String"))
        Dim col8 As New DataColumn("CrossBorderDate1", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)
        tmptable.Columns.Add(col8)

        Dim a As Integer
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("EditCargo") = "addeditcargo.aspx?jobcargoid=" & drow("ID")
            drow("MoreCargoDetails") = "addeditcargo.aspx?jobcargoid=" & drow("ID")

            If CDate(drow("PortExitDate")) <= CDate("1-Jan-1800") Then
                drow("PortExitDate") = CDate("1-Jan-1800")
            End If


            If CDate(drow("CrossBorderDate")) <= CDate("1-Jan-1800") Then
                drow("CrossBorderDate") = CDate("1-Jan-1800")
            End If

            If CDate(drow("ReturnDate")) <= CDate("1-Jan-1800") Then
                drow("ReturnDate") = CDate("1-Jan-1800")
            End If

            If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
            End If

            If Not CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                drow("CrossBorderDate1") = Format(drow("CrossBorderDate"), "dd MMM yyyy")
            End If

            dv1.RowFilter = "TransporterID ='" & drow("TransporterID") & "' "

            If dv1.Count > 0 Then
                drow("Transporter") = dv1(0)("Transporter")
            End If

            a = a + 1
        Next

        Call clsShippingStorage.SetDemurrageStorageDays(tmptable, JobID, CFPROID, LabelMessage1.Text)


        LabelCargoCaption.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "


        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Payload") = ""
            tmptable.Rows.Add(drow)
        End If

        If tmptable.Rows.Count >= 6 Then
            PanelCargo.Height = 190
        Else
            PanelCargo.Height = Nothing
        End If

        Call CalcWeight(tmptable)

        GridJobCargo.DataSource = tmptable
        GridJobCargo.DataBind()
        LabelRowIndex.Text = RowIndex

        If RowIndex >= 0 Then
            GridJobCargo.SelectedIndex = RowIndex
        End If

        LabelCargoMessage.Text = ""
        LabelCargoMessage.ForeColor = Color.Black

    End Sub


    Private Sub CurrentKPIandJobStatus(CFPROID As String, JobID As String)

        Dim sqlstr As String =
            "SELECT top 1 ItemDescription,KPIProgressUpdates.KPIItemID  " &
            "FROM KPIProgressUpdates,  KPIProgress  " &
             "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
             "And KPIProgress.CFPROID = '" & CFPROID & "' " &
             "And KPIProgressUpdates.JobID = '" & JobID & "' " &
             "And KPIProgressUpdates.KPIItemID = KPIProgress.ItemID " &
             "And KPIProgressUpdates.CFPROID = KPIProgress.CFPROID " &
             "Order by UpdateDate Desc "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            TextKPIStatus.Text = drow("ItemDescription")

            TextJobStatus.Text = clsProgressUpdates.UpdateOverallJobStatus(CFPROID, JobID, drow("KPIItemID"))
        Else

            TextKPIStatus.Text = ""
        End If

    End Sub



    Private Sub LoadDestinations(CFPROID As String)
        Dim sqlstr As String =
         "Select Destination " &
         "From Destinations " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order By Destination Asc;"
        ComboDestination.Items.Clear()

        Call clsData.PopCombo(ComboDestination, sqlstr, clsData.constr, 0)
        ComboDestination.Items.Add("")
    End Sub


    Protected Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Response.Redirect("jobentry.aspx?jobid=" & ComboJobID.Text)
    End Sub
    Private Sub Navigate(ByVal direction As String)
        Dim JobID As String = ""
        Select Case direction


            Case ">>"
                If ComboJobID.Items.Count > 0 Then
                    JobID = ComboJobID.Items(0).Text
                End If

            Case "<<"
                If ComboJobID.Items.Count > 0 Then
                    JobID = ComboJobID.Items(ComboJobID.Items.Count - 1).Text
                End If

            Case "<"
                If ComboJobID.SelectedIndex + 1 <= ComboJobID.Items.Count - 1 Then
                    JobID = ComboJobID.Items(ComboJobID.SelectedIndex + 1).Text
                End If

            Case ">"
                If ComboJobID.SelectedIndex - 1 >= 0 Then
                    JobID = ComboJobID.Items(ComboJobID.SelectedIndex - 1).Text
                End If
        End Select

        If Not JobID = "" Then
            Response.Redirect("jobentry.aspx?jobid=" & JobID)
        End If

    End Sub
    Protected Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Navigate("<<")
    End Sub

    Protected Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Navigate("<")
    End Sub

    Protected Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Navigate(">")
    End Sub

    Protected Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Navigate(">>")
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call ShippingUpdate()
    End Sub
    Private Sub ShippingUpdate()
        Call LoadDialog("shipping.aspx?jobid=" & ComboJobID.Text & "&jobtype=" & TextJobType.Text, "Shipping", 550, 850)
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl


        If pagetitle.Contains("Job Documents") Then
            ModalPopupExtender4.CancelControlID = "LinkCloseDialog"

        ElseIf pagetitle.Contains("Received Documents") Then
            ModalPopupExtender4.CancelControlID = "LinkCloseDialog"

        ElseIf pagetitle.Contains("Cargo") Then
            ModalPopupExtender4.CancelControlID = "LinkCloseDialog"

        Else
            ModalPopupExtender4.CancelControlID = "ButtonCloseDialog"
        End If
        ModalPopupExtender4.Show()
    End Sub


    Private Sub SetSearchItem()

        TextSearch.Text = Session("Searchtext")
        Select Case LCase(Session("Searchitem"))

            Case "job"
                RadioButtonList1.Items(0).Selected = True

            Case "reference"
                RadioButtonList1.Items(1).Selected = True

            Case "client"
                RadioButtonList1.Items(2).Selected = True

            Case "consignee"
                RadioButtonList1.Items(3).Selected = True

            Case "shipper"
                RadioButtonList1.Items(4).Selected = True

            Case "bl"
                RadioButtonList1.Items(5).Selected = True

            Case "idf"
                RadioButtonList1.Items(6).Selected = True

            Case "entryno"
                RadioButtonList1.Items(7).Selected = True

            Case "container"
                RadioButtonList1.Items(8).Selected = True

            Case "vehicle"
                RadioButtonList1.Items(9).Selected = True

            Case "transporter"
                RadioButtonList1.Items(10).Selected = True

            Case "driver"
                RadioButtonList1.Items(11).Selected = True

            Case "telephone"
                RadioButtonList1.Items(12).Selected = True

            Case "email"
                RadioButtonList1.Items(13).Selected = True


            Case "goods"
                RadioButtonList1.Items(14).Selected = True

        End Select
    End Sub


    Private Sub Search(CFPROID As String, UserID As String)
        Try

            LabelSearchMessage.ForeColor = Drawing.Color.Black

            If Trim(TextSearch.Text) = "" Then
                LabelSearchMessage.Text = "Invalid Search String"
                LabelSearchMessage.ForeColor = Drawing.Color.Red
                ModalPopupExtender1.Show()
                Exit Sub

            Else
                Session("Searchtext") = Trim(TextSearch.Text)
            End If

            Dim SearchField As String
            If RadioButtonList1.Items(0).Selected Then
                SearchField = "JobId"
                Session("Searchitem") = "job"

            ElseIf RadioButtonList1.Items(1).Selected Then
                SearchField = "ReferenceNo"
                Session("Searchitem") = "reference"

            ElseIf RadioButtonList1.Items(2).Selected Then
                SearchField = "Client"
                Session("Searchitem") = "client"

            ElseIf RadioButtonList1.Items(3).Selected Then
                SearchField = "Importer"
                Session("Searchitem") = "consignee"

            ElseIf RadioButtonList1.Items(4).Selected Then
                SearchField = "Shipper"
                Session("Searchitem") = "shipper"

            ElseIf RadioButtonList1.Items(5).Selected Then
                SearchField = "BL"
                Session("Searchitem") = "bl"

            ElseIf RadioButtonList1.Items(6).Selected Then
                SearchField = "IDFNo"
                Session("Searchitem") = "idf"

            ElseIf RadioButtonList1.Items(7).Selected Then
                SearchField = "EntryNo"
                Session("Searchitem") = "entryno"

            ElseIf RadioButtonList1.Items(8).Selected Then
                SearchField = "ContainerNo"
                Session("Searchitem") = "container"


            ElseIf RadioButtonList1.Items(9).Selected Then
                SearchField = "VehicleNo"
                Session("Searchitem") = "vehicle"

            ElseIf RadioButtonList1.Items(10).Selected Then
                SearchField = "Transporter"
                Session("Searchitem") = "transporter"

            ElseIf RadioButtonList1.Items(11).Selected Then
                SearchField = "Driver"
                Session("Searchitem") = "driver"

            ElseIf RadioButtonList1.Items(12).Selected Then
                SearchField = "Telephone"
                Session("Searchitem") = "telephone"

            ElseIf RadioButtonList1.Items(13).Selected Then
                SearchField = "Email"
                Session("Searchitem") = "email"

            ElseIf RadioButtonList1.Items(14).Selected Then
                SearchField = "Goods"
                Session("Searchitem") = "goods"

            Else
                LabelSearchMessage.Text = "Please set item to search for"
                LabelSearchMessage.ForeColor = Drawing.Color.Red
                Exit Sub
            End If

            Dim tmpstr As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, UserID) Then
                tmpstr = "And Jobs.UserID = '" & UserID & "' "
            End If

            Dim sqlstr As String = ""



            If SearchField = "Importer" Then
                sqlstr = "Select Top 35 ReferenceNo, Importers.Importer, " &
                           "BL,IDFNo,EntryNo,ReferenceNo1," &
                           "JobId, Jobs.ID " &
                           "From Jobs, Importers " &
                           "Where Jobs.CFPROID = '" & CFPROID & "' " &
                           "And Importers.CFPROID = Jobs.CFPROID " &
                           "And Importers.ImporterID = Jobs.ImporterID  " &
                           tmpstr

            ElseIf SearchField = "Shipper" Then
                sqlstr = "Select Top 35 ReferenceNo, Shippers.Shipper, " &
                           "BL,IDFNo,EntryNo,ReferenceNo1," &
                           "JobId, Jobs.ID " &
                           "From Jobs, Shippers " &
                           "Where Jobs.CFPROID = '" & CFPROID & "' " &
                           "And Shippers.CFPROID = Jobs.CFPROID " &
                           "And Shippers.ShipperID = Jobs.ShipperID   " &
                           tmpstr

            Else
                sqlstr = "Select Top 35 ReferenceNo, Clients.Client, " &
                          "BL,IDFNo,EntryNo,ReferenceNo1," &
                          "JobId, Jobs.ID " &
                          "From Jobs, Clients " &
                          "Where Jobs.CFPROID = '" & CFPROID & "' " &
                          "And Clients.CFPROID = Jobs.CFPROID " &
                          "And Clients.ClientID = Jobs.ClientID  " &
                          tmpstr


            End If
            Dim sqlstr1 As String = ""


            If SearchField = "ReferenceNo" Then
                sqlstr1 = sqlstr &
                "And (Jobs.ReferenceNo " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                 "Or Jobs.ReferenceNo1 Like '%" & Trim(TextSearch.Text) & "%') " &
                 "Order by Jobs.ID DESC;"

            ElseIf SearchField = "BL" Then
                sqlstr1 = sqlstr &
                "And Jobs." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Client" Then
                sqlstr1 = sqlstr &
                "And Clients." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Importer" Then
                sqlstr1 = sqlstr &
                "And Importers." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Shipper" Then
                sqlstr1 = sqlstr &
                "And Shippers." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Telephone" Then
                sqlstr1 = sqlstr &
                "And Clients." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Email" Then
                sqlstr1 = sqlstr &
                "And Clients." & SearchField & " " &
                "Like '%" & Trim(TextSearch.Text) & "%' " &
                "Order by Jobs.ID DESC;"

            ElseIf SearchField = "IDFNo" Then
                sqlstr1 = sqlstr &
               "And Jobs." & SearchField & " " &
               "Like '%" & Trim(TextSearch.Text) & "%' " &
               "Order by Jobs.ID DESC;"

            ElseIf SearchField = "EntryNo" Then
                sqlstr1 = sqlstr &
               "And Jobs." & SearchField & " " &
               "Like '%" & Trim(TextSearch.Text) & "%' " &
               "Order by Jobs.ID DESC;"

            ElseIf SearchField = "Goods" Then
                sqlstr1 = sqlstr &
               "And " & SearchField & " " &
               "Like '%" & Trim(TextSearch.Text) & "%' " &
               "Order by Jobs.ID DESC;"

            End If




            If RadioButtonList1.Items(8).Selected Then
                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Container No."
                LabelBL.Text = "Vehicle No."

                sqlstr =
                    "Select Top 50 Jobs.ReferenceNo, " &
                    "ContainerNo,VehicleNo,"


            ElseIf RadioButtonList1.Items(9).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Vehicle No."
                LabelBL.Text = "Container No."

                sqlstr =
                    "Select Top 50 Jobs.ReferenceNo, " &
                    "VehicleNo,ContainerNo,"


            ElseIf RadioButtonList1.Items(10).Selected Then
                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Transporter"
                LabelBL.Text = "Vehicle No."

                sqlstr =
                     "Select Top 50 Jobs.ReferenceNo, " &
                     "Driver,VehicleNo,ContainerNo," &
                     "Transporters.Transporter, VehicleNo," &
                     "Jobs.JobID,JobCargo.ID " &
                     "From JobCargo, Jobs " &
                     "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                     "And Jobs.CFPROID = '" & CFPROID & "' " &
                     "And Transporters.CFPROID = '" & CFPROID & "' " &
                     "And JobCargo.JobID = Jobs.JobID " &
                     "And Transporters.TransporterID = JobCargo.TransporterID "



            ElseIf RadioButtonList1.Items(11).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Driver"
                LabelBL.Text = "Vehicle No"

                sqlstr =
                   "Select Top 50 Jobs.ReferenceNo, " &
                   "Driver,VehicleNo,ContainerNo,"


            ElseIf RadioButtonList1.Items(6).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Client"
                LabelBL.Text = "IDF No."


            ElseIf RadioButtonList1.Items(2).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Client"
                LabelBL.Text = "BL No."

            ElseIf RadioButtonList1.Items(3).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Consignee"
                LabelBL.Text = "BL No."

            ElseIf RadioButtonList1.Items(4).Selected Then

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Shipper"
                LabelBL.Text = "BL No."

            Else

                LabelReferenceNo.Text = "Reference No"
                LabelClient.Text = "Client"
                LabelBL.Text = "BL No."

            End If



            Dim sqlstr1a As String =
                   "Jobs.JobID,JobCargo.ID " &
                   "From JobCargo, Jobs " &
                   "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                   "And Jobs.CFPROID = '" & CFPROID & "' " &
                   "And JobCargo.JobID = Jobs.JobID "

            If SearchField = "ContainerNo" Then
                sqlstr1 = sqlstr & sqlstr1a &
                  "And JobCargo.ContainerNo " &
                  "Like '%" & Trim(TextSearch.Text) & "%' " &
                  "Order by JobCargo.ID DESC;"

            ElseIf SearchField = "VehicleNo" Then
                sqlstr1 = sqlstr & sqlstr1a &
                  "And JobCargo.VehicleNo " &
                  "Like '%" & Trim(TextSearch.Text) & "%' " &
                  "Order by JobCargo.ID DESC;"

            ElseIf SearchField = "Driver" Then
                sqlstr1 = sqlstr & sqlstr1a &
                  "And JobCargo.Driver " &
                  "Like '%" & Trim(TextSearch.Text) & "%' " &
                  "Order by JobCargo.ID DESC;"

            ElseIf SearchField = "Transporter" Then
                sqlstr1 = sqlstr1a &
                  "And Transporters.Transporter " &
                  "Like '%" & Trim(TextSearch.Text) & "%' " &
                  "Order by JobCargo.ID DESC;"

            End If



            Dim tmptable As New DataTable("Search")
            Call clsData.TableData(sqlstr1, tmptable, clsData.constr)


            Dim col As New DataColumn("ItemURL", Type.GetType("System.String"))

            Dim col1 As New DataColumn("Item1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Item2", Type.GetType("System.String"))
            Dim col3 As New DataColumn("Item3", Type.GetType("System.String"))
            Dim col4 As New DataColumn("ItemID", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)

            Dim Drow As DataRow
            Dim a As Integer



            For Each Drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Drow("ItemURL") = "jobentry.aspx?jobid=" & (Drow("JobId"))
                Drow("Item1") = Drow(0)
                Drow("Item2") = Drow(1)
                Drow("Item3") = Drow(2)
                Drow("ItemID") = Drow("JobId")
                a = a + 1

            Next

            LabelSearchMessage.Text = tmptable.Rows.Count & " results found matching  '" & TextSearch.Text & "' "

            If tmptable.Rows.Count = 0 Then
                Drow = tmptable.NewRow
                Drow("ItemURL") = Nothing
                Drow("Item1") = "-"
                Drow("Item2") = "No results found for '" & TextSearch.Text & "'"
                tmptable.Rows.Add(Drow)
            End If


            DataList1.DataSource = tmptable
            DataList1.DataBind()

            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub



    Protected Sub ButtonDoSearch_Click(sender As Object, e As EventArgs) Handles ButtonDoSearch.Click
        Call Search(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub Button14_Click(sender As Object, e As EventArgs) Handles ButtonAddCargo.Click
        Call AddEditCargo(-1, "Add")
    End Sub

    Protected Sub Button25_Click(sender As Object, e As EventArgs) Handles ButtonEditCargo.Click

        If Val(LabelRowIndex.Text) >= 0 Then
            Call AddEditCargo(GridJobCargo.SelectedValue, "Edit")
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
            LabelCargoMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkPayload_Click(sender As Object, e As EventArgs)
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim ID As Integer = linkbutton.CommandArgument.ToString
        Call AddEditCargo(ID, "Edit")
    End Sub
    Private Sub AddEditCargo(ID As Integer, AddEdit As String)
        LabelCargoMessage.Text = ""
        LabelCargoMessage.ForeColor = Color.Gray

        LoadDialog("addeditcargo.aspx?cargoaddeditdetails=" & LabelCFPROID.Text & "," & ID & "," &
                     GridJobCargo.SelectedIndex & "," & ComboJobID.Text & "," & AddEdit & "," & LabelCFPROUserID.Text, "Add / Edit Cargo", 400, 480)

    End Sub
    Protected Sub Button26_Click(sender As Object, e As EventArgs) Handles ButtonDeleteCargo.Click

        If Val(LabelRowIndex.Text) >= 0 Then
            Dim row As GridViewRow = GridJobCargo.Rows(GridJobCargo.SelectedIndex)
            Call PromptDeleteCargo(GridJobCargo.SelectedValue, row.Cells(1).Text, row.Cells(2).Text, GridJobCargo.SelectedIndex)
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
            LabelCargoMessage.ForeColor = Color.Red
        End If

    End Sub

    Private Sub PromptDeleteCargo(CargoID As String, PayLoad As String, ContainerNo As String, RowIndex As String)

        Dim DelMessage As String = PayLoad & " " & ContainerNo

        LabelDeleteMessage.Text = "Delete - " & DelMessage & " ?"
        ButtonDelete.Visible = True


        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click

        If LabelDeleteMessage.Text.Contains("Job") Then
            Call DeleteJob(ComboJobID.Text, LabelCFPROID.Text)
        Else
            Call DeleteCargoItem(GridJobCargo.SelectedValue)
        End If

    End Sub

    Private Sub DeleteCargoItem(CargoID As Integer)

        Try
            Dim sqlstr As String =
             "Select JobId,ID " &
             "From JobCargo " &
             "Where ID = " & CInt(CargoID) & " "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                drow.Delete()
            End If

            Call clsData.SaveData("JobCargo", tmptable, sqlstr, True, clsData.constr)
            Call LoadJobCargo(LabelCFPROID.Text, ComboJobID.Text, -1)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub Button12_Click(sender As Object, e As EventArgs) Handles ButtonDeleteJob.Click
        Call PromptDeleteJob(ComboJobID.Text, TextReferenceNo.Text)
    End Sub
    Private Sub PromptDeleteJob(JobID As String, ReferenceNo As String)

        Dim DelMessage As String = ""

        If Trim(ReferenceNo) = "" Then
            DelMessage = "JobID: " & JobID
        Else
            DelMessage = "Reference No: " & ReferenceNo
        End If


        LabelDeleteMessage.Text = "Delete Job - " & DelMessage & " ?"
        ButtonDelete.Visible = True


        ModalPopupExtender3.Show()

    End Sub




    Protected Sub ButtonCancelDelete_Click(sender As Object, e As EventArgs) Handles ButtonCancelDelete.Click
        ModalPopupExtender3.Hide()
    End Sub


    Private Sub DeleteJob(JobID As String, CFPROID As String)
        Dim sqlstr As String =
                 "Select ID " &
                 "From Jobs " &
                 "Where JobId = '" & JobID & "' " &
                 "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        drow = tmptable.Rows(0)
        drow.Delete()

        Dim sqlstr1 As String =
                          "Select ID " &
                          "From JobCargo " &
                          "Where JobId = '" & JobID & "' " &
                          "And CFPROID = '" & CFPROID & "' "

        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
        Dim a As Integer
        For a = 0 To tmptable1.Rows.Count - 1
            drow = tmptable1.Rows(a)
            drow.Delete()
        Next

        Dim sqlstr2 As String =
                         "Select ID " &
                         "From JobProgress " &
                         "Where JobId = '" & JobID & "' " &
                         "And CFPROID = '" & CFPROID & "' "

        Dim tmptable2 As New DataTable()
        Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

        For a = 0 To tmptable2.Rows.Count - 1
            drow = tmptable2.Rows(a)
            drow.Delete()
        Next

        Call clsData.SaveData("Jobs", tmptable, sqlstr, True, clsData.constr)
        Call clsData.SaveData("JobCargo", tmptable1, sqlstr1, True, clsData.constr)
        Call clsData.SaveData("JobProgress", tmptable2, sqlstr2, True, clsData.constr)

        a = ComboJobID.SelectedIndex



        If ComboJobID.Items.Count > 0 Then
            If ComboJobID.Items.Count >= a Then
                ComboJobID.SelectedIndex = a - 1
            End If
        End If

        Response.Redirect("jobentry.aspx?jobid=" & ComboJobID.Text)

        ModalPopupExtender3.Hide()
    End Sub
    Private Sub SetBroker(CFPROID As String, JobID As String, ClientID As String, SaveAgentID As Boolean)
        Try
            ModalPopupExtender2.Hide()
            Dim sqlstr As String =
                    "Select ClientID,Client,Box," &
                    "Telephone,Town,Email,Id " &
                    "From Clients " &
                    "Where ClientID = '" & ClientID & "' " &
                    "And IsAgent = 1 " &
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                TextAgent.Text = drow("Client")

                If SaveAgentID Then
                    Dim sqlstr1 As String =
                                "Select AgentID, ID " &
                                "From Jobs " &
                                "Where JobId ='" & JobID & "' " &
                                "And CFPROID = '" & CFPROID & "' "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                    If tmptable1.Rows.Count > 0 Then
                        drow = tmptable1.Rows(0)
                        drow("AgentID") = ClientID
                        LabelAgentID.Text = ClientID
                        Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)

                    End If
                End If
            Else
                TextAgent.Text = ""
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Private Sub SetClient(CFPROID As String, JobID As String, ByRef ClientID As String, SaveClientID As Boolean)
        Try

            ModalPopupExtender2.Hide()

            Dim sqlstr As String =
                    "Select ClientID,Client,Box," &
                    "Telephone,Town,Email,Id " &
                    "From Clients " &
                    "Where ClientID = '" & ClientID & "' " &
                    "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String =
                    Trim(drow("Client")) & "|" &
                    drow("Telephone") & "|" &
                    drow("Town") & "|" &
                    drow("Email")

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2() As String
                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)
                    If a = 1 Then
                        If Not Trim(tmpstr1(1)) = "" Then
                            tmpstr1(1) = "Tel: " & tmpstr1(1)
                        End If
                    End If

                    If a = 3 Then
                        If Not Trim(tmpstr1(3)) = "" Then
                            tmpstr1(3) = "Email: " & tmpstr1(3)
                        End If
                    End If

                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                TextClient.Text = Join(tmpstr2, vbCrLf)
                LabelClientID.Text = ClientID

                If SaveClientID Then
                    Dim sqlstr1 As String =
                                "Select ClientID, ID " &
                                "From Jobs " &
                                "Where JobId ='" & JobID & "' " &
                                "And CFPROID = '" & CFPROID & "' "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                    If tmptable1.Rows.Count > 0 Then
                        drow = tmptable1.Rows(0)
                        drow("ClientID") = ClientID
                        Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)

                    End If
                End If
            Else
                TextClient.Text = ""
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Private Sub SetImporter(CFPROID As String, JobID As String, ImporterID As String, SaveImporterID As Boolean)
        Try

            Dim sqlstr As String =
                    "Select ImporterID,Importer,Box," &
                    "Telephone,Town,Email,Id " &
                    "From Importers " &
                    "Where ImporterID = '" & ImporterID & "' " &
                   "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String =
                    Trim(drow("Importer")) & "|" &
                    drow("Telephone") & "|" &
                    drow("Town") & "|" &
                    drow("Email")

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2(0) As String

                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)

                    If a = 1 Then
                        If Not Trim(tmpstr1(1)) = "" Then
                            tmpstr1(1) = "Tel: " & tmpstr1(1)
                        End If
                    End If

                    If a = 3 Then
                        If Not Trim(tmpstr1(3)) = "" Then
                            tmpstr1(3) = "Email: " & tmpstr1(3)
                        End If
                    End If

                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                TextConsignee.Text = Join(tmpstr2, vbCrLf)
                LabelImporterID.Text = ImporterID

                If SaveImporterID Then
                    Dim sqlstr1 As String =
                                "Select ImporterID, Id " &
                                "From Jobs " &
                                "Where JobId ='" & JobID & "'" &
                                "And CFPROID = '" & CFPROID & "' "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                    If tmptable1.Rows.Count > 0 Then
                        drow = tmptable1.Rows(0)
                        drow("ImporterID") = ImporterID
                        Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)

                    End If
                End If
            Else
                TextConsignee.Text = ""
            End If

            ModalPopupExtender2.Hide()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Private Sub SearchCountry()

        Dim sqlstr As String =
                "Select Code,Country,ID " &
                "From Countries " &
                "Where Country  Like '%" & Trim(TextSearchItem.Text) & "%' " &
                "Order By Country Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("Code")))
            drow("Item") = (Trim(drow("Country")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Countries found matching '" & Trim(TextSearchItem.Text) & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & TextSearchItem.Text & "'"
            tmptable.Rows.Add(drow)
        End If


        LabelItemHeader.Text = "Country"

        DataList2.DataSource = tmptable
        DataList2.DataBind()

        ModalPopupExtender2.Show()
    End Sub
    Private Sub SetCountry(CFPROID As String, JobID As String, Country As String)
        Try


            Dim sqlstr As String =
                                "Select BLCountry, ID " &
                                "From Jobs " &
                                "Where JobId ='" & JobID & "' " &
                                "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("BLCountry") = Country
                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
                TextCountry.Text = Country
            Else
                TextCountry.Text = ""
            End If

            ModalPopupExtender2.Hide()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub SearchJobStatus(CFPROID As String)

        Dim sqlstr As String =
                "Select Status,ID " &
                "From CFAgentJobStatus " &
                "Where CFPROID ='" & CFPROID & "' " &
                "And Status  Like '%" & Trim(TextSearchItem.Text) & "%' " &
                "Order By Status Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("ID")))
            drow("Item") = (Trim(drow("Status")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Job Status found matching '" & Trim(TextSearchItem.Text) & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & TextSearchItem.Text & "'"
            tmptable.Rows.Add(drow)
        End If




        LabelItemHeader.Text = "Status"

        DataList2.DataSource = tmptable
        DataList2.DataBind()

        ModalPopupExtender2.Show()
    End Sub
    Private Sub SetJobStatus(CFPROID As String, JobID As String, JobStatus As String)
        Try
            Dim sqlstr As String =
                    "Select JobStatus," &
                    "CustomJobStatus, ID " &
                    "From Jobs " &
                    "Where JobId ='" & JobID & "' " &
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("JobStatus") = JobStatus
                drow("CustomJobStatus") = 1
                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
                TextJobStatus.Text = JobStatus
            Else
                TextJobStatus.Text = ""
            End If

            ModalPopupExtender2.Hide()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub SearchShipper(CFPROID As String)

        Dim sqlstr As String =
                "Select ShipperID,Shipper,Box," &
                "Telephone,Town,Email,Id " &
                "From Shippers " &
                "Where Shipper  Like '%" & Trim(TextSearchItem.Text) & "%' " &
                "And CFPROID = '" & CFPROID & "' " &
                "Order By Shipper Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        Dim a As Integer

        Dim col As New DataColumn("ItemID", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Item", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)



        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("ItemID") = (Trim(drow("ShipperID")))
            drow("Item") = (Trim(drow("Shipper")))
            a = a + 1
        Next

        LabelItemMessage.Text = tmptable.Rows.Count & " Shippers(s) found matching '" & Trim(TextSearchItem.Text) & "' "

        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("ItemID") = Nothing
            drow("Item") = "No Names found for '" & TextSearchItem.Text & "'"
            tmptable.Rows.Add(drow)
        End If


        LabelItemHeader.Text = "Shipper"

        DataList2.DataSource = tmptable
        DataList2.DataBind()

        ModalPopupExtender2.Show()
    End Sub



    Private Sub SetShipper(CFPROID As String, JobID As String, ShipperID As String, SaveShipperID As Boolean)
        Try

            Dim sqlstr As String =
                    "Select ShipperID,Shipper,Box," &
                    "Telephone,Town,Email,Id " &
                    "From Shippers " &
                    "Where ShipperID = '" & ShipperID & "' " &
                   "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String =
                    Trim(drow("Shipper")) & "|" &
                    drow("Telephone") & "|" &
                    drow("Town") & "|" &
                    drow("Email")

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2() As String
                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)
                    If a = 1 Then
                        If Not Trim(tmpstr1(1)) = "" Then
                            tmpstr1(1) = "Tel: " & tmpstr1(1)
                        End If
                    End If

                    If a = 3 Then
                        If Not Trim(tmpstr1(3)) = "" Then
                            tmpstr1(3) = "Email: " & tmpstr1(3)
                        End If
                    End If

                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                TextShipper.Text = Join(tmpstr2, vbCrLf)

                If SaveShipperID Then
                    Dim sqlstr1 As String =
                                "Select ShipperID, Id " &
                                "From Jobs " &
                                "Where JobId ='" & JobID & "' " &
                                "And CFPROID = '" & CFPROID & "' "

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                    If tmptable1.Rows.Count > 0 Then
                        drow = tmptable1.Rows(0)
                        drow("ShipperID") = ShipperID
                        Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)

                    End If
                End If
            Else
                TextShipper.Text = ""
            End If

            ModalPopupExtender2.Hide()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub





    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Shipper" Then
            Call SearchShipper(LabelCFPROID.Text)

        ElseIf LabelItemType.Text = "Search / Select Country" Then
            Call SearchCountry()

        ElseIf LabelItemType.Text = "Search / Select Job Status" Then
            Call SearchJobStatus(LabelCFPROID.Text)

        ElseIf LabelItemType.Text = "Search / Select Vehicle" Then
            clsGetIdentities.SearchVehicle(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf LabelItemType.Text = "Search / Select Transporter" Then
            clsGetIdentities.SearchTransporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)


        ElseIf LabelItemType.Text = "Search / Select User" Then
            clsGetIdentities.SearchUsers(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)

        End If
        ModalPopupExtender2.Show()
    End Sub

    Protected Sub OnRowDataBound2(sender As Object, e As GridViewRowEventArgs) Handles GridJobCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged2(sender As Object, e As EventArgs) Handles GridJobCargo.SelectedIndexChanged
        Dim row As GridViewRow = GridJobCargo.Rows(GridJobCargo.SelectedIndex)
        LabelRowIndex.Text = GridJobCargo.SelectedIndex

        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        LabelCargoMessage.ForeColor = Color.Black
        LabelCargoMessage.Text = ""

        For a As Integer = 0 To GridJobCargo.Rows.Count - 1
            row = GridJobCargo.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridJobCargo.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next


    End Sub

    Protected Sub ButtonGetConsignee_Click(sender As Object, e As EventArgs) Handles ButtonGetConsignee.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonCountry_Click(sender As Object, e As EventArgs) Handles ButtonCountry.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "country", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub


    Protected Sub ButtonJobStatus_Click(sender As Object, e As EventArgs) Handles ButtonJobStatus.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "jobstatus", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub
    Protected Sub ButtonGetClient_Click(sender As Object, e As EventArgs) Handles ButtonGetClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ModalPopupExtender2.Show()
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub ButtonGetShipper_Click(sender As Object, e As EventArgs) Handles ButtonGetShipper.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "shipper", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub


    Protected Sub Button28_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Response.Redirect("jobentry.aspx?jobid=" & ComboJobID.Text)
    End Sub

    Protected Sub Button9_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
        Call ProgressUpdate()
    End Sub
    Private Sub ProgressUpdate()
        Dim tmplient() As String = TextClient.Text.Split(vbCrLf)
        ReDim Preserve tmplient(0)
        Call LoadDialog("progressupdates.aspx?jobid=" & ComboJobID.Text & "&CFPROID=" &
             LabelCFPROID.Text & "&referenceno=" & TextReferenceNo.Text & "&client=" &
             tmplient(0) & "&jobdate=" &
             TextJobDate.Text, "Progress Updates", 580, 780)

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles ButtonNewFile.Click
        Call NewJob(LabelCFPROID.Text)
    End Sub

    Private Sub NewJob(CFPROID As String)

        Try
            Dim JobID As String = clsSubs.GetLastID(LabelCFPROID.Text, "", "JobID")


            Dim nTodaysDate As String = clsSubs.AbsoluteDateTime(TodaysDate.Value)
            LabelTodaysDate.Text = nTodaysDate

            Dim sqlstr As String =
                   "Select JobId,JobDate," &
                   "UserID,CFPROID," &
                   "CustomsSystem,WeightUnit," &
                   "Application, ID " &
                   "From Jobs " &
                   "Where JobId = '" & JobID & "' " &
                   "And CFPROID = '" & LabelCFPROID.Text & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then

                Dim drow As DataRow
                drow = tmptable.NewRow

                drow("JobId") = JobID

                If IsDate(nTodaysDate) Then
                    drow("JobDate") = Format(CDate(nTodaysDate), "dd MMM yyyy HH:mm")
                Else
                    drow("JobDate") = Format(Now, "dd MMM yyyy HH:mm")
                    nTodaysDate = Format(Now, "dd MMM yyyy HH:mm")
                End If

                drow("CustomsSystem") = ComboCustomsSystem.Items(0)
                drow("UserID") = LabelCFPROUserID.Text
                drow("CFPROID") = LabelCFPROID.Text
                drow("Application") = "C&F PRO Online"


                If IsNothing(Request.Cookies("WeightUnit")) Then
                    drow("WeightUnit") = ComboWeightUnit.Text
                Else
                    drow("WeightUnit") = Request.Cookies("WeightUnit").Value
                End If

                tmptable.Rows.Add(drow)

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)


                Dim KPIProgressID As String = "-1"
                Call clsProgressUpdates.UpdateKPIProgress(LabelCFPROID.Text, JobID, "000000", KPIProgressID,
                                                           "JOB FILE OPENED", nTodaysDate, LabelCFPROUserID.Text, -1, False, False, LabelMessage1.Text)



                Response.Redirect("jobentry.aspx?jobid=" & JobID)
                TextClient.Focus()
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub


    Private Function Stopnew() As Boolean
        If Not IsNothing(Request.Cookies("CFPRODemo")) Then
            Dim sqlstr As String =
                                 "Select Count(*) as RecordCount " &
                                 "From Jobs "
            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            If CInt(drow("RecordCount")) >= 10 Then
                MsgBox("Trial version. Maximum 10 Jobs. Get full version")
                Return True
            Else
                Return False
            End If

        Else
            Return False
        End If

    End Function

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Call LoadDialog("declaration.aspx?jobid=" & ComboJobID.Text, "Declaration", 550, 820)
    End Sub

    'Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click

    '    Call LoadDialog("sendmessage.aspx?jobid=" & ComboJobID.Text & "&filetype=jobdocuments&sendercsdid=" & LabelCFPROUserID.Text &
    '                         "&destinationcfprouserid=" & LabelClientID.Text & "&CFPROID=" & LabelCFPROID.Text &
    '                         "&messagesource=cfagent&messagedestination=importer", "C&F PRO Messaging", 500, 820)

    'End Sub



    Protected Sub Button13_Click(sender As Object, e As EventArgs) Handles ButtonSaveJob.Click
        Call SaveJob(ComboJobID.Text, LabelCFPROID.Text)
    End Sub

    Private Sub SaveJob(JobID As String, CFPROID As String)
        Try

            Dim sqlstr As String =
                    "Select JobID,ReferenceNo,ReferenceNo1," &
                    "JobDate, BL,HouseBL,BLCountry," &
                    "InvoiceNo,InvoiceAmount," &
                    "Goods,JobStatus,JobType," &
                    "OrderNo,Destination," &
                    "ModeofTransport,DispatchDate," &
                    "TBL,SOC,KeepVisible,JobTypeID," &
                    "ExpiryDate,CustomsSystem," &
                    "WeightUnit, ID " &
                    "From Jobs " &
                    "Where JobID ='" & JobID & "' " &
                    "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                drow("ReferenceNo") = Trim(TextReferenceNo.Text)
                drow("ReferenceNo1") = Trim(TextReferenceNo1.Text)


                drow("BL") = Trim(TextMBL.Text)
                drow("HouseBL") = Trim(TextHBL.Text)
                drow("BLCountry") = TextCountry.Text

                drow("Goods") = TextGoods.Text
                drow("Destination") = ComboDestination.Text
                drow("ModeofTransport") = ComboTransportMode.Text
                drow("CustomsSystem") = ComboCustomsSystem.Text

                drow("JobTypeID") = LabelJobTypeID.Text
                drow("JobStatus") = TextJobStatus.Text

                If IsDate(TextJobDate.Text) Then
                    drow("JobDate") = TextJobDate.Text
                End If

                If IsDate(TextDispatchDate.Text) Then
                    drow("DispatchDate") = TextDispatchDate.Text
                End If

                If IsDate(TextExpiryDate.Text) Then
                    drow("ExpiryDate") = TextDispatchDate.Text
                End If

                drow("TBL") = CheckTBL.Checked
                drow("SOC") = CheckSOC.Checked
                drow("KeepVisible") = CheckKeepVisible.Checked
                drow("JobTypeID") = LabelJobTypeID.Text
                drow("WeightUnit") = ComboWeightUnit.Text


                Response.Cookies("WeightUnit").Value = ComboWeightUnit.Text


                Dim InvoiceAmount As String = Trim(TextInvoiceAmount.Text)
                InvoiceAmount = InvoiceAmount.Replace(" ", "")
                InvoiceAmount = InvoiceAmount.Replace(",", "")
                TextInvoiceAmount.Text = Format(CDbl(InvoiceAmount), "#,##0.00")

                drow("InvoiceAmount") = TextInvoiceAmount.Text

                clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
                tmptable.AcceptChanges()


                Dim sqlstr1 As String =
                 "Select KeepVisible,ID " &
                 "From JobCargo " &
                 "Where JobID = '" & JobID & "' " &
                 "And CFPROID = '" & CFPROID & "' "


                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                Dim drow1 As DataRow

                For Each drow1 In tmptable1.Rows
                    drow1("KeepVisible") = CheckKeepVisible.Checked
                Next

                Call clsData.SaveData("JobCargo", tmptable1, sqlstr1, True, clsData.constr)

                TextReferenceNo.Text = clsReferenceNos.ReferenceNoExists(LabelCFPROID.Text, ComboJobID.Text, TextReferenceNo)

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try

    End Sub

    Private Sub CalcWeight(tmptable As DataTable)
        Try

            Dim JobCardTable As New DataTable("JobCardTable")
            JobCardTable = DirectCast(Session("JobCardTable"), DataTable)

            Dim a As Integer
            Dim Weight, CBM As Double

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                Weight = Weight + drow("Weight")
                CBM = CBM + drow("CBM")
                a = a + 1
            Next

            TextWeight.Text = Format(Weight, "#,##0.00")
            TextCBM.Text = Format(CBM, "#,##0.00")

            Dim col As New DataColumn("Weight", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("CBM", Type.GetType("System.Double"))

            If Not IsNothing(JobCardTable) Then
                If Not JobCardTable.Columns.Contains("Weight") Then
                    JobCardTable.Columns.Add(col)
                    JobCardTable.Columns.Add(col1)

                    If JobCardTable.Rows.Count > 0 Then
                        Dim drow As DataRow = JobCardTable.Rows(0)
                        drow("Weight") = Weight
                        drow("CBM") = CBM
                    End If

                End If

                Session("JobCardTable") = JobCardTable
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Call LoadDialog("portcustoms.aspx?jobid=" & ComboJobID.Text, "Port & Customs", 480, 750)
    End Sub

    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Call VerificationUpdate()
    End Sub
    Private Sub VerificationUpdate()
        Call LoadDialog("verification.aspx?jobid=" & ComboJobID.Text, "Verification", 580, 750)
    End Sub

    Protected Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Call LoadDialog("registration.aspx?jobid=" & ComboJobID.Text, "Vehicle Registration", 320, 430)
    End Sub

    Protected Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Call LoadDialog("swdetails.aspx?jobid=" & ComboJobID.Text, "Single Customs Territory Details", 410, 500)
    End Sub

    Protected Sub Button10_Click(sender As Object, e As EventArgs) Handles ButtonJobDocuments.Click
        Call LoadDialog("jobdocuments.aspx?loadedbyimporter=0&jobid=" & ComboJobID.Text, "Job Documents", 480, 820)
    End Sub

    Protected Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click


        Dim host As String = Request.Url.Host

        If Not host.Contains("cfpro") Then
            host = host & ":90"
        End If

        host = "http://" & host

        Response.Redirect(host & "/progressreport.aspx?loadedbyimporter=0&jobid=" & ComboJobID.Text)
    End Sub

    Protected Sub ButtonCancelGetItem_Click(sender As Object, e As EventArgs) Handles ButtonCancelGetItem.Click
        ModalPopupExtender2.Hide()
    End Sub



    Protected Sub ButtonGetBroker_Click(sender As Object, e As EventArgs) Handles ButtonGetBroker.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

    End Sub

    Protected Sub ButtonInsure_Click(sender As Object, e As EventArgs) Handles ButtonInsurer.Click
        If TextInsured.Text = "Not Insured" Then
            LoadDialog("marineinsurancepurchase.aspx?clientid=" & LabelClientID.Text & "&insurablesum=" & TextInvoiceAmount.Text & "&consignmentcode=" & TextInsuranceCode.Text, "Marine Insurance Purchase", 600, 900)
        Else
            ModalPopupExtender7.Show()
        End If

    End Sub
    Protected Sub ButtonJobCard_Click(sender As Object, e As EventArgs) Handles ButtonJobCard.Click

        Call LoadJob(LabelCFPROID.Text, ComboJobID.Text, LabelCFPROUserID.Text)

        Dim JobCardTable As New DataTable("JobCardTable")
        JobCardTable = DirectCast(Session("JobCardTable"), DataTable)

        Dim JobCard As String = clsJobCardPDF.CreateJobCardPDF(LabelCFPROID.Text, JobCardTable, "Job Card " &
                                            Format(Now, "dd MMM yyyy hh:mm:ss tt") & ".pdf", LabelMessage1.Text)

        If File.Exists(Server.MapPath(JobCard)) Then
            LoadDialog(JobCard, "Job Card", 550, 850)
        Else
            ButtonJobCard.Text = "No file."
        End If


    End Sub

    Private Sub LoadBonds(CFPROID As String)
        Dim sqlstr As String =
         "Select BondDescription, BondID  " &
         "From Bonds " &
         "Where CFPROID = '" & CFPROID & "' "

        ComboBonds.Items.Clear()

        Call clsData.PopComboWithValue(ComboBonds, sqlstr, clsData.constr, 0, 1)
        ComboBonds.Items.Add("")
    End Sub


    Private Sub GetBond(CFPROID As String, BondID As String)
        Dim sqlstr As String =
         "Select BondNo, BondAmount, BondExpiry,ID " &
         "From Bonds " &
         "Where CFPROID = '" & CFPROID & "' " &
         "And BondID = '" & BondID & "' "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            LabelBond.Text = drow("BondNo") & " | " & Format(drow("BondAmount"), "#,##0.00") &
                                                    " | Expires:" & Format(drow("BondExpiry"), "dd MMM yyyy")
        Else
            LabelBond.Text = "---"
        End If

    End Sub
    Private Sub LoadBondStatus(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From BondStatus " &
         "Where CFPROID = '" & CFPROID & "' "

        ComboBondStatus.Items.Clear()

        Call clsData.PopCombo(ComboBondStatus, sqlstr, clsData.constr, 0)
        ComboBondStatus.Items.Add("")
    End Sub


    Protected Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        Call BondDetails(LabelCFPROID.Text, ComboJobID.Text)
    End Sub
    Private Sub BondDetails(CFPROID As String, JobID As String)
        Try

            Call LoadBonds(CFPROID)
            Call LoadBondStatus(CFPROID)


            LabelBondCaption.Text = "Bond Details"

            Dim sqlstr As String =
               "SELECT BondID, " &
               "BondAmount, BondStatus," &
               "BondActiveDate, BondCancelDate," &
               "BondRemarks, ID " &
               "FROM Jobs " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And JobID = '" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                ComboBonds.SelectedValue = drow("BondID")

                TextBondAmount.Text = Format(drow("BondAmount"), "#,##0.00")
                TextBondActivationDate.Text = Format(drow("BondActiveDate"), "dd MMM yyyy")
                TextBondCancelDate.Text = Format(drow("BondCancelDate"), "dd MMM yyyy")
                TextBondRemarks.Text = drow("BondRemarks")
                ComboBondStatus.Text = drow("BondStatus")

                Call GetBond(LabelCFPROID.Text, ComboBonds.Text)

            End If


            ModalPopupExtender9.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveBondDetails_Click(sender As Object, e As EventArgs) Handles ButtonSaveBondDetails.Click
        Call SaveBondDetails(LabelCFPROID.Text, ComboBonds.Text, ComboJobID.Text)
    End Sub

    Private Sub SaveBondDetails(CFPROID As String, BondID As String, JobID As String)

        Try

            Dim sqlstr As String =
             "SELECT BondID, " &
             "BondAmount, BondStatus," &
             "BondActiveDate, BondCancelDate," &
             "BondRemarks, ID " &
             "FROM Jobs " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And JobID = '" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim BondAmount As String = Trim(TextBondAmount.Text)
            BondAmount = BondAmount.Replace(" ", "")
            BondAmount = BondAmount.Replace(",", "")

            TextBondAmount.Text = Format(CDbl(BondAmount), "#,##0.00")

            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                drow("BondID") = BondID
                drow("BondAmount") = Trim(TextBondAmount.Text)
                drow("BondRemarks") = Trim(TextBondRemarks.Text)
                drow("BondStatus") = ComboBondStatus.Text

                If IsDate(Trim(TextBondActivationDate.Text)) Then
                    drow("BondActiveDate") = Trim(TextBondActivationDate.Text)
                End If

                If IsDate(Trim(TextBondCancelDate.Text)) Then
                    drow("BondCancelDate") = Trim(TextBondCancelDate.Text)
                End If

            End If


            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            ModalPopupExtender9.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub Button37_Click(sender As Object, e As EventArgs) Handles Button37.Click
        Call LoadGoodsDescriptions(LabelCFPROID.Text, "")
    End Sub
    Private Sub LoadGoodsDescriptions(ByVal CFPROID As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Description Like '%" & Trim(SearchStr) & "'% "
            End If

            Dim sqlstr As String = "SELECT Description, CFPROID, ID " &
                                    "From  GoodsDescriptions " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                       tmpstr &
                                    "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridGoodsDescriptions.DataSource = tmptable
            GridGoodsDescriptions.DataBind()

            If Not Trim(SearchStr) = "" Then
                LabelGoodsCaption.Text = tmptable.Rows.Count & "  Goods Descriptions Found matching '" & SearchStr & "'"
            Else
                LabelGoodsCaption.Text = tmptable.Rows.Count & "  Goods Descriptions"
            End If

            ModalPopupExtender8.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        Call LoadGoodsDescriptions(LabelCFPROID.Text, TextSearchGoods.Text)
    End Sub


    Protected Sub ComboBonds_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBonds.SelectedIndexChanged
        Call GetBond(LabelCFPROID.Text, ComboBonds.SelectedValue)
        ModalPopupExtender9.Show()
    End Sub

    Protected Sub GridShippingGoodsDescriptions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridGoodsDescriptions.SelectedIndexChanged
        Dim row As GridViewRow = GridGoodsDescriptions.Rows(GridGoodsDescriptions.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridGoodsDescriptions.Rows.Count - 1
            row = GridGoodsDescriptions.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridGoodsDescriptions.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingGoodsDescriptions_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridGoodsDescriptions.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridGoodsDescriptions, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonSetReferenceNo_Click(sender As Object, e As EventArgs) Handles ButtonSetReferenceNo.Click
        Call SetReferenceNo(TextJobType.Text)
    End Sub
    Private Sub SetReferenceNo(JobType)
        TextReferenceNo.Text = clsReferenceNos.ReferenceNo(LabelCFPROID.Text, JobType, ComboJobID.Text, TextReferenceNo.Text)
        TextReferenceNo.Text = clsReferenceNos.ReferenceNoExists(LabelCFPROID.Text, ComboJobID.Text, TextReferenceNo)
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetSelectedItem(sender)
    End Sub

    Private Sub SetSelectedItem(sender As Object)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            Call SetClient(LabelCFPROID.Text, ComboJobID.Text, ItemID, True)

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            Call SetBroker(LabelCFPROID.Text, ComboJobID.Text, ItemID, True)

        ElseIf LabelItemType.Text = "Search / Select Shipper" Then
            Call SetShipper(LabelCFPROID.Text, ComboJobID.Text, ItemID, True)

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call SetImporter(LabelCFPROID.Text, ComboJobID.Text, ItemID, True)

        ElseIf LabelItemType.Text = "Search / Select Country" Then
            Call SetCountry(LabelCFPROID.Text, ComboJobID.Text, Item)

        ElseIf LabelItemType.Text = "Search / Select Job Status" Then
            Call SetJobStatus(LabelCFPROID.Text, ComboJobID.Text, Item)

        ElseIf LabelItemType.Text = "Search / Select Job Type" Then
            Call SetJobType(LabelCFPROID.Text, ComboJobID.Text, ItemID, True)

        ElseIf LabelItemType.Text = "Search / Select User" Then
            Call clsGetIdentities.SetCFPROuser(LabelCFPROID.Text, ItemID, ComboJobID.Text, LabelDoneBy.Text, True)

        End If
    End Sub

    Protected Sub LinkGoJob_Click(sender As Object, e As EventArgs)
        GotoJob(sender)
    End Sub
    Private Sub GotoJob(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Response.Redirect("jobentry.aspx?jobid=" & link.CommandArgument.ToString)

        'Dim ItemID As String = link.CommandArgument.ToString
        'Dim Item As String = link.Text
        'ComboJobID.Text = ItemID
        'Call LoadJob(LabelCFPROID.Text, ItemID, LabelCFPROUserID.Text)
        'ModalPopupExtender1.Hide()
    End Sub


    Protected Sub LinkGoods_Click(sender As Object, e As EventArgs)
        SetGoodsDescriptions(sender)

    End Sub

    Private Sub SetGoodsDescriptions(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim Item As String = link.Text

        TextGoods.Text = Item
        ModalPopupExtender8.Hide()

    End Sub

    Protected Sub ButtonMoreCargoDetails_Click(sender As Object, e As EventArgs) Handles ButtonMoreCargoDetails.Click
        If GridJobCargo.SelectedIndex >= 0 Then
            Call LoadDialog("morecargodetails.aspx?jobid=" & ComboJobID.Text & "&jobcargoid=" & GridJobCargo.SelectedValue, "More Cargo Details", 550, 780)
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
        End If

    End Sub

    Protected Sub ButtonRefreshCargo_Click(sender As Object, e As EventArgs) Handles ButtonRefreshCargo.Click
        Call LoadJobCargo(LabelCFPROID.Text, ComboJobID.Text, LabelRowIndex.Text)
    End Sub

    Protected Sub ButtonReceivedDocs_Click(sender As Object, e As EventArgs) Handles ButtonReceivedDocs.Click
        Call ReceivedDocs()
    End Sub

    Private Sub ReceivedDocs()
        If LabelJobTypeID.Text = "" Then
            TextJobType.ForeColor = Color.Red
            TextJobType.Text = "NOT SET"
        Else
            TextJobType.ForeColor = Color.Black
            Call LoadDialog("receiveddocuments.aspx?jobid=" & ComboJobID.Text & "&todaysdate=" & LabelTodaysDate.Text & "&jobtypeid=" & LabelJobTypeID.Text, "Received Documents", 418, 585)
        End If

    End Sub

    Protected Sub ButtonCloseDialog_Click(sender As Object, e As EventArgs) Handles ButtonCloseDialog.Click
        ModalPopupExtender4.Hide()
        If ComboJobID.SelectedIndex >= 0 Then
            If LabelDialogTitle.Text.Contains("Job Documents") Then
                ButtonJobDocuments.Text = "Job Documents - " & clsDocuments.DocumentCount(LabelCFPROID.Text, ComboJobID.Text, "", "", "", "jobdocuments", "")

            ElseIf LabelDialogTitle.Text.Contains("Received Documents") Then
                Call clsActionCenter.ReceivedJobDocuments(LabelCFPROID.Text, ComboJobID.Text, LabelJobTypeID.Text, ButtonReceivedDocs.Text, LinkDocuments.Text, False, LabelMessage1.Text)
                Call StatusColour(LinkDocuments)

            ElseIf LabelDialogTitle.Text.Contains("Cargo") Then
                Call LoadJobCargo(LabelCFPROID.Text, ComboJobID.Text, GridJobCargo.SelectedIndex)

            End If
        End If
    End Sub

    Protected Sub ButtonTextMessage_Click(sender As Object, e As EventArgs) Handles ButtonTextMessage.Click
        Dim JobID As String = ComboJobID.Text
        Call LoadDialog("sendtextmessage.aspx?jobid=" & JobID & "&clientid=" & LabelClientID.Text & "&importerid=" & LabelImporterID.Text &
                        "&userid=" & LabelCFPROUserID.Text, "Send Text Message to Client / Consignee", 420, 620)
    End Sub

    Protected Sub ButtonSmartUpdates_Click(sender As Object, e As EventArgs) Handles ButtonSmartUpdates.Click
        Response.Redirect("actioncenter.aspx")
    End Sub


    Protected Sub ButtonJobType_Click(sender As Object, e As EventArgs) Handles ButtonJobType.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "jobtype", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Private Sub SetJobType(CFPROID As String, JobID As String, JobTypeID As String, SaveJobTypeID As Boolean)

        Try

            Dim sqlstr As String = _
                    "Select JobTypeID, JobType " & _
                    "From JobTypes " & _
                    "Where JobTypeID = '" & JobTypeID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                TextJobType.Text = drow("JobType")
                LabelJobTypeID.Text = JobTypeID
                TextJobType.ForeColor = Color.Black

                Call SetReferenceNo(drow("JobType"))
                Call SetReferenceNo2(drow("JobType"))


            Else
                TextJobType.Text = "NOT SET"
                LabelJobTypeID.Text = ""
            End If


            If SaveJobTypeID Then

                Dim sqlstr1 As String = _
                                "Select JobTypeID, ID " & _
                                "From Jobs " & _
                                "Where JobID ='" & JobID & "' " & _
                                "And CFPROID = '" & CFPROID & "' "

                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                If tmptable1.Rows.Count > 0 Then
                    Dim drow1 As DataRow = tmptable1.Rows(0)
                    drow1("JobTypeID") = JobTypeID

                    Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)
                End If
            End If


            Call clsActionCenter.ReceivedJobDocuments(LabelCFPROID.Text, ComboJobID.Text, LabelJobTypeID.Text, ButtonReceivedDocs.Text, LinkDocuments.Text, False, LabelMessage1.Text)
            Call StatusColour(LinkDocuments)

            ModalPopupExtender2.Hide()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try


    End Sub


    Protected Sub ButtonSetReferenceNo2_Click(sender As Object, e As EventArgs) Handles ButtonSetReferenceNo2.Click
        Call SetReferenceNo2(TextJobType.Text)
    End Sub

    Private Sub SetReferenceNo2(JobType)
        TextReferenceNo1.Text = clsReferenceNos.ReferenceNo2(LabelCFPROID.Text, JobType, ComboJobID.Text, TextReferenceNo1.Text)
        TextReferenceNo1.Text = clsReferenceNos.ReferenceNo2Exists(LabelCFPROID.Text, ComboJobID.Text, TextReferenceNo1)
    End Sub

    Protected Sub LinkDocuments_Click(sender As Object, e As EventArgs) Handles LinkDocuments.Click
        Call ReceivedDocs()
    End Sub

    Protected Sub LinkProgress_Click(sender As Object, e As EventArgs) Handles LinkProgressStatus.Click
        Call ProgressUpdate()
    End Sub

    Protected Sub LinkShipping_Click(sender As Object, e As EventArgs) Handles LinkShippingStatus.Click
        Call ShippingUpdate()
    End Sub
    Protected Sub ButtonJobInvoice_Click(sender As Object, e As EventArgs) Handles ButtonJobInvoice.Click
        Call Invoicing()
    End Sub
    Protected Sub LinkVerification_Click(sender As Object, e As EventArgs) Handles LinkInvoicing.Click
        Call Invoicing()
    End Sub
    Private Sub Invoicing()
        Call LoadDialog("invoice.aspx?jobid=" & ComboJobID.Text, "Job Invoice", 665, 980)
    End Sub

    Protected Sub ButtonSetUserName_Click(sender As Object, e As EventArgs) Handles ButtonSetUserName.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "user", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

    End Sub

    Protected Sub ButtonExpandedCargoView_Click(sender As Object, e As EventArgs) Handles ButtonExpandedCargoView.Click
        LoadDialog("jobcargo.aspx?jobid=" & ComboJobID.Text, "Expanded Job Cargo View", 676, 1150)
    End Sub

    Protected Sub LinkStorageStatus_Click(sender As Object, e As EventArgs) Handles LinkStorageStatus.Click
        Call VerificationUpdate()
    End Sub

    Protected Sub LinkDemurrageStatus_Click(sender As Object, e As EventArgs) Handles LinkDemurrageStatus.Click
        Call ShippingUpdate()
    End Sub

    'Protected Sub ButtonAlerts_Click(sender As Object, e As EventArgs) Handles ButtonAlerts.Click
    '    ModalPopupExtender10.Show()
    'End Sub

    Protected Sub ButtonFileClosingForm_Click(sender As Object, e As EventArgs) Handles ButtonFileClosingForm.Click
        Call LoadDialog("fileclosing.aspx?jobid=" & ComboJobID.Text, "File Closing Summary", 650, 850)
    End Sub
End Class
