﻿

Imports System.IO
Imports System.Drawing


Public Class jobcostsheet
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim Usertype As String = Request.QueryString("usertype")
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUserNames.Text, CFAgentName, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID

            Dim JobID As String = Request.QueryString("jobid")
            LabelJobID.Text = JobID


            Dim InvoiceID As String = Request.QueryString("invoiceid")
            LabelInvoiceID.Text = InvoiceID

            Call clsAccounts.LoadActiveCurrencies(CFPROID, ComboCurrency)
            Call LoadSalesmen(CFPROID)
            Call LoadCFAgentUsers(CFPROID)
            Call LoadJobCost(CFPROID, InvoiceID, JobID)

        End If
    End Sub


    Private Sub LoadJobCost(CFPROID As String, InvoiceID As String, JobID As String)
        Try
            Dim sqlstr As String =
                "Select JobInvoiceHeader.JobID, CompanyID," &
                "InvoiceID,ClientID," &
                "JobDate, JobInvoiceHeader.InvoiceNo,  " &
                "JobInvoiceHeader.InvoiceDate, CostSheetDate,Cost, Total, " &
                "Paid, Balance, SubTotal, VAT," &
                "InvoiceParticulars, ApplyVAT," &
                "VATinclusive, UserID," &
                "CurrencyID, InvoiceHeader," &
                "InvoiceDueDate, VATAmount," &
                "CurrencyRate,ReferenceNo," &
                "PreparedByID,ReviewedByID,SalesmanID," &
                "PreparedByDate,ReviewedByDate," &
                "InvoicetypeID, JobInvoiceHeader.ID " &
                "FROM JobInvoiceHeader,Jobs " &
                "Where InvoiceID ='" & InvoiceID & "' " &
                "And JobInvoiceHeader.JobID ='" & JobID & "'" &
                "And Jobs.JobID ='" & JobID & "'" &
                "And JobInvoiceHeader.CFPROID ='" & CFPROID & "' " &
                "And Jobs.CFPROID ='" & CFPROID & "' "



            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)

                LabelJobID.Text = drow("JobID")
                TextReferenceNo.Text = drow("ReferenceNo")
                TextInvoiceNo.Text = drow("InvoiceNo")


                TextTotalCost.Text = Format(drow("SubTotal"), "#,##0.00")
                TextProfitLossPercent.Text = Format(drow("Paid"), "#,##0.00")
                TextProfitLoss.Text = Format(drow("Total"), "#,##0.00")
                TextTaxAmount.Text = Format(drow("VATAmount"), "#,##0.00")
                TextInvoiceDate.Text = Format(drow("InvoiceDate"), "dd-MMM-yyyy")


                ComboSalesman.Text = drow("SalesmanID")
                ComboReviewedBy.Text = drow("ReviewedByID")
                ComboPreparedBy.Text = drow("PreparedByID")
                ComboCurrency.Text = drow("CurrencyID")
                LabelInvoiceCurrencyID.Text = drow("CurrencyID")

                Dim tmpstr() As String = clsAccounts.CurrencyRateandCode(LabelCFPROID.Text, drow("CurrencyID"))
                TextInvoiceCurrency.Text = tmpstr(2)

                If CDate(drow("CostSheetDate")) = CDate("1-Jan 1800") Then
                    drow("CostSheetDate") = Now
                End If

                If CDate(drow("ReviewedByDate")) = CDate("1-Jan 1800") Then
                    drow("ReviewedByDate") = Now
                End If

                If CDate(drow("PreparedByDate")) = CDate("1-Jan 1800") Then
                    drow("PreparedByDate") = Now
                End If


                TextCostSheetDate.Text = Format(drow("CostSheetDate"), "dd-MMM-yyyy")
                TextReviewedByDate.Text = Format(drow("ReviewedByDate"), "dd-MMM-yyyy")
                TextPreparedByDate.Text = Format(drow("PreparedByDate"), "dd-MMM-yyyy")
                LabelCompanyID.Text = drow("CompanyID")

                TextClient.Text = clsSubs.GetClient(CFPROID, drow("ClientID"))
                TextCompany.Text = clsSubs.GetCompany(CFPROID, drow("CompanyID"))


                Call LoadJobCostItems(CFPROID, InvoiceID, JobID, drow("CurrencyID"))
                Call CargoTotals(CFPROID, JobID)

            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub CargoTotals(CFPROID As String, JobID As String)
        Dim sqlstr As String = "SELECT Weight,CBM,ID " &
                                "From  JobCargo " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim a As Integer
        Dim Weight, CBM As Double

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            Weight = Weight + drow("Weight")
            CBM = CBM + drow("CBM")
            a = a + 1
        Next

        TextWeight.Text = Format(Weight, "#,##0.00")
        TextCBM.Text = Format(CBM, "#,##0.00")
        TextCargoCount.Text = Format(a, "#,##0")

    End Sub
    Private Sub LoadJobCostItems(CFPROID As String, InvoiceID As String, JobID As String, CurrencyID As String)

        Try

            Dim sqlstr As String =
                "SELECT JobInvoiceItems.ItemID," &
                "Item,UOC, Cost," &
                "CostRate, CurrencyID,ExchangeRate," &
                "SaleRate,Quantity, JobInvoiceItems.Amount," &
                "JobInvoiceItems.ApplyTax," &
                "JobInvoiceItems.TaxPercent,ProfitPercent," &
                "TaxAmount,VendorInvoiceNo, JobInvoiceItems.TaxType," &
                "Total, InvoiceID, " &
                "VendorID,VendorType,JobInvoiceItems.ID  " &
                "FROM  InvoiceItems, JobInvoiceItems " &
                "Where InvoiceID = '" & InvoiceID & "' " &
                "And JobInvoiceItems.JobID = '" & JobID & "' " &
                "And JobInvoiceItems.CFPROID = '" & CFPROID & "' " &
                "And InvoiceItems.CFPROID ='" & CFPROID & "' " &
                "And JobInvoiceItems.ItemID = InvoiceItems.ItemID " &
                "And JobInvoiceItems.CFPROID = InvoiceItems.CFPROID " &
                "Order By JobInvoiceItems.ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("Vendor", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Currency", Type.GetType("System.String"))
            Dim col2 As New DataColumn("TaxAmount1", Type.GetType("System.Double"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)

            Dim a As Integer
            Dim drow As DataRow
            Dim tmpstr() As String


            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    If Not drow("VendorID") = "" Then
                        drow("Vendor") = clsSubs.GetVendor(CFPROID, drow("VendorID"), drow("VendorType"))
                    Else
                        drow("Vendor") = "Vendor not set"
                    End If

                    If Not drow("VendorInvoiceNo") = "" Then
                        drow("VendorInvoiceNo") = "Inv No. " & drow("VendorInvoiceNo")
                    End If


                    If Not drow("CurrencyID") = "" Then
                        tmpstr = clsAccounts.CurrencyRateandCode(CFPROID, drow("CurrencyID"))
                        drow("Currency") = tmpstr(1) & " @ " & tmpstr(0)
                    End If

                    drow("Cost") = drow("CostRate") * drow("Quantity")
                    drow("Amount") = drow("SaleRate") * drow("Quantity")

                    If drow("CurrencyID") <> CurrencyID Then
                        drow("Cost") = drow("Cost") * drow("ExchangeRate")
                    End If


                    If drow("Cost") = 0 Then
                        drow("Cost") = 0.001
                    End If


                    If drow("ApplyTax") Then
                        drow("TaxAmount") = drow("Amount") * (drow("TaxPercent") / 100)
                        drow("TaxAmount1") = drow("Cost") * (drow("TaxPercent") / 100)
                    Else
                        drow("TaxAmount") = 0
                        drow("TaxAmount1") = 0
                    End If

                    drow("ProfitPercent") = (drow("Amount") - drow("Cost"))
                    drow("ProfitPercent") = drow("ProfitPercent") / drow("Cost")
                    drow("ProfitPercent") = drow("ProfitPercent") * 100
                    a = a + 1

                Next
            End If

            LabelInvoiceCaption.Text = tmptable.Rows.Count & "  Invoice Items"

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Item") = "Invoice Items Not Set"
                tmptable.Rows.Add(drow)
            End If

            GridJobCost.DataSource = tmptable
            GridJobCost.DataBind()

            Call CalcTotals(tmptable)


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub CalcTotals(tmptable As DataTable)
        Try
            Dim a As Integer
            Dim Cost, Amount, ProfitLoss, TaxAmount1, TaxAmount As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Cost = Cost + drow("Cost")
                Amount = Amount + drow("Amount")

                TaxAmount1 = TaxAmount1 + drow("TaxAmount1")
                TaxAmount = TaxAmount + drow("TaxAmount")

                a = a + 1

            Next
            ProfitLoss = Amount - Cost


            TextTotalCost.Text = Format(Cost, "#,##0.00")
            TextTaxAmount.Text = Format(Amount, "#,##0.00")
            TextProfitLoss.Text = Format(ProfitLoss, "#,##0.00")
            TextCostVAT.Text = Format(TaxAmount1, "#,##0.00")
            TextSalesVAT.Text = Format(TaxAmount, "#,##0.00")


            If Cost = 0 Then
                Cost = 0.001
            End If

            ProfitLoss = (ProfitLoss / Cost) * 100
            TextProfitLossPercent.Text = Format(ProfitLoss, "#,#0.00") & " %"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr1 As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboPreparedBy, sqlstr1, clsData.constr, 0, 1)
        Call clsData.PopComboWithValue(ComboReviewedBy, sqlstr1, clsData.constr, 0, 1)

        ComboPreparedBy.Items.Insert(0, "")
        ComboReviewedBy.Items.Insert(0, "")
    End Sub


    Private Sub LoadSalesmen(CFPROID As String)
        Dim sqlstr As String =
            "Select Salesman,SalesmanID, ID " &
            "From Salesmen " &
            "Where CFPROID = '" & CFPROID & "' "
        Call clsData.PopComboWithValue(ComboSalesman, sqlstr, clsData.constr, 0, 1)
        ComboSalesman.Items.Insert(0, "")
    End Sub
    Protected Sub LinkInvoiceItem_Click(sender As Object, e As EventArgs)

        LabelMessage.Text = ""
        LabelMessage.ForeColor = Color.Gray
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim ID As Integer = linkbutton.CommandArgument.ToString
        Call EditCostItem(LabelCFPROID.Text, ID)
    End Sub

    Private Sub EditCostItem(CFPROID As String, ID As Integer)
        Try
            If NAVInvoicePosted() Then
                Exit Sub
            End If

            LabelCostItemID.Text = ID

            Dim sqlstr As String = "SELECT CostRate," &
                                    "CurrencyID,ExchangeRate," &
                                    "VendorID,VendorType," &
                                    "VendorInvoiceNo,UOC,ID " &
                                    "From  JobInvoiceItems " &
                                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            TextCostRate.Text = "0.00"
            TextUnitofCharge.Text = ""
            TextExchangeRate.Text = "0.00"

            TextVendorInvoiceNo.Text = ""
            LabelVendorID.Text = ""
            TextVendor.Text = ""

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)


                If drow("UOC") = "" Then
                    drow("UOC") = "Per Document"
                End If

                TextCostRate.Text = drow("CostRate")
                TextUnitofCharge.Text = drow("UOC")
                TextExchangeRate.Text = drow("ExchangeRate")


                TextVendorInvoiceNo.Text = drow("VendorInvoiceNo")

                LabelVendorID.Text = drow("VendorID")
                TextVendor.Text = ""

                If Not drow("VendorID") = "" Then
                    TextVendor.Text = clsSubs.GetVendor(CFPROID, drow("VendorID"), drow("VendorType"))
                    ComboVendorType.Text = drow("VendorType")
                    LabelVendorID.Text = drow("VendorID")
                Else
                    TextVendor.Text = ""
                End If

                If Not drow("CurrencyID") = "" Then
                    ComboCurrency.Text = drow("CurrencyID")
                Else
                    ComboCurrency.Text = LabelInvoiceCurrencyID.Text
                End If

                If drow("ExchangeRate") = 0 Then
                    Dim tmpstr() As String = clsAccounts.CurrencyRateandCode(LabelCFPROID.Text, ComboCurrency.Text)
                    TextExchangeRate.Text = CDbl(tmpstr(0))
                End If

                TextCostRate.Focus()

            End If
            ModalPopupExtender7.Show()



        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveItem_Click(sender As Object, e As EventArgs) Handles ButtonSaveItem.Click
        Call SaveCostItem(LabelCostItemID.Text)
    End Sub

    Private Sub SaveCostItem(ID As String)


        Try
            Dim sqlstr As String = "SELECT CostRate,Quantity," &
                                   "CurrencyID,ExchangeRate," &
                                   "VendorID,VendorType," &
                                   "VendorInvoiceNo,UOC, ID " &
                                   "From  JobInvoiceItems " &
                                   "Where ID = " & ID & " "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)

                drow("CostRate") = TextCostRate.Text
                drow("CurrencyID") = ComboCurrency.Text
                drow("ExchangeRate") = TextExchangeRate.Text
                drow("VendorType") = ComboVendorType.Text
                drow("VendorID") = LabelVendorID.Text
                drow("VendorInvoiceNo") = TextVendorInvoiceNo.Text
                drow("UOC") = TextUnitofCharge.Text

                Call clsData.SaveData("JobInvoiceItems", tmptable, sqlstr, False, clsData.constr)

                Call LoadJobCostItems(LabelCFPROID.Text, LabelInvoiceID.Text, LabelJobID.Text, LabelInvoiceCurrencyID.Text)
            End If

            ModalPopupExtender7.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Private Function NAVInvoicePosted(Optional Reply As String = Nothing) As Boolean
        If clsMSDynamicsNAVint.NAVInvoiceisPosted(LabelCFPROID.Text, LabelInvoiceID.Text, LabelJobID.Text, ComboSalesman.Text, Reply) Then
            LabelPromptTitle.Text = "Invoice Alert"
            LabelPromptMessage.Text = "Invoice ID:" & LabelInvoiceID.Text & " is  Already Posted in MS Dynamics NAV. Cannot be Modified "
            ButtonOKPrompt.Visible = False
            ModalPopupExtender3.Show()
            Return True
        Else
            Return False
        End If

    End Function




    Protected Sub GridInvoice_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobCost.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobCost, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub GridInvoice_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridJobCost.SelectedIndexChanged
        Dim row As GridViewRow = GridJobCost.Rows(GridJobCost.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridJobCost.Rows.Count - 1
            row = GridJobCost.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridJobCost.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub



    Protected Sub ButtonSaveJobInvoice_Click(sender As Object, e As EventArgs) Handles ButtonSaveJobInvoice.Click
        Call SaveJobCost(LabelCFPROID.Text, LabelInvoiceID.Text, LabelJobID.Text)
    End Sub

    Private Sub SaveJobCost(CFPROID As String, InvoiceID As String, JobID As String)

        Try
            If NAVInvoicePosted(LabelMessage1.Text) Then
                Exit Sub
            End If


            Dim sqlstr As String =
                "Select JobID,InvoiceID,InvoiceNo,  " &
                "CostSheetDate, Cost, Total, " &
                "Paid, Balance, SubTotal, VAT," &
                "InvoiceParticulars, ApplyVAT," &
                "VATinclusive,CurrencyID, InvoiceHeader," &
                "InvoiceDueDate, VATAmount," &
                "InvoiceTypeID, SalesmanID," &
                "PreparedByID,ReviewedByID," &
                "CompanyID,PreparedByDate,ReviewedByDate,ID " &
                "FROM JobInvoiceHeader " &
                "Where InvoiceID='" & InvoiceID & "' " &
                "And JobID ='" & JobID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)

                If Trim(TextInvoiceNo.Text) = "" Then
                    TextInvoiceNo.Text = InvoiceID
                End If

                drow("Total") = TextProfitLoss.Text
                drow("VATAmount") = TextTaxAmount.Text
                drow("Cost") = TextTotalCost.Text
                drow("CostSheetDate") = TextCostSheetDate.Text

                drow("SalesmanID") = ComboSalesman.Text
                drow("ReviewedByID") = ComboReviewedBy.Text
                drow("PreparedByID") = ComboPreparedBy.Text
                drow("ReviewedByDate") = TextReviewedByDate.Text
                drow("PreparedByDate") = TextPreparedByDate.Text

                Call clsData.SaveData("JobInvoiceHeader", tmptable, sqlstr, False, clsData.constr)

                Call clsMSDynamicsNAVint.UpdateNAVInvoiceHeader(CFPROID, InvoiceID, JobID, LabelCompanyID.Text, LabelMessage1.Text)

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub



    Protected Sub ButtonToInvoice_Click(sender As Object, e As EventArgs) Handles ButtonToInvoice.Click
        Call BacktoInvoice()
    End Sub

    Protected Sub ButtonToInvoice1_Click(sender As Object, e As EventArgs) Handles ButtonToInvoice1.Click
        Call BacktoInvoice()
    End Sub



    Private Sub BacktoInvoice()
        Response.Redirect("invoice.aspx?jobid=" & LabelJobID.Text & "&invoiceid=" & LabelInvoiceID.Text & "&companyid=" & LabelCompanyID.Text)
    End Sub
    Protected Sub ButtonJobCostSheet_Click(sender As Object, e As EventArgs) Handles ButtonJobCostSheet.Click

        Dim JobCostSheet As String =
            clsJobCostSheetPDF.CreateJobCostSheet(LabelCFPROID.Text, LabelInvoiceID.Text,
                                                  LabelJobID.Text, LabelCompanyID.Text, LabelUserNames.Text, LabelMessage1.Text)

        If File.Exists(Server.MapPath(JobCostSheet)) Then
            Call LoadDialog(JobCostSheet, "Job Cost Sheet", 825, 495)
        End If



    End Sub

    Private Sub LoadDialog(sourcepage As String, dialogtitle As String, width As Integer, height As Integer)

        Dim iframebg As String = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit;" &
                "background-position-y: center; background-position-x: center;"

        PanelDialog.Attributes("style") = "width:" & width + 10 & "px; height:" & height + 72 & "px;"
        PanelDrag.Attributes("style") = "width:100%;"
        iframe1.Attributes("style") = "width:" & width & "px ; height:" & height & "px;" & iframebg

        LabelDialogTitle.Text = dialogtitle
        iframe1.Attributes("src") = sourcepage

        ModalPopupExtender5.Show()
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        TextVendor.Text = Item

        If ComboVendorType.Text = "supplier" Then
            LabelVendorID.Text = ItemID

        ElseIf ComboVendorType.Text = "transporter" Then
            LabelVendorID.Text = ItemID

        ElseIf ComboVendorType.Text = "cfs" Then
            LabelVendorID.Text = ItemID

        ElseIf ComboVendorType.Text = "shippingline" Then
            LabelVendorID.Text = ItemID
        End If


        ModalPopupExtender2.Hide()
        ModalPopupExtender7.Show()

    End Sub
    Protected Sub ComboVendorType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVendorType.SelectedIndexChanged
        Call LoadVendors(ComboVendorType.Text)
    End Sub

    Protected Sub ButtonGetVendor_Click(sender As Object, e As EventArgs) Handles ButtonGetVendor.Click
        Call LoadVendors(ComboVendorType.Text)
    End Sub

    Private Sub LoadVendors(VendorType As String)
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, VendorType, DataList2, LabelItemType, LabelVendorMessage, LabelVendorHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ModalPopupExtender2.Show()
    End Sub


    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If ComboVendorType.Text = "shippingline" Then
            clsGetIdentities.SearchShippingLine(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelVendorMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf ComboVendorType.Text = "transporter" Then
            clsGetIdentities.SearchTransporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelVendorMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf ComboVendorType.Text = "cfs" Then
            clsGetIdentities.SearchCFS(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelVendorMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf ComboVendorType.Text = "supplier" Then
            clsGetIdentities.SearchSupplier(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelVendorMessage, LabelItemHeader, ModalPopupExtender2)
        End If

        ModalPopupExtender2.Show()
    End Sub


    Protected Sub ComboCurrency_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCurrency.SelectedIndexChanged
        Dim tmpstr() As String = clsAccounts.CurrencyRateandCode(LabelCFPROID.Text, ComboCurrency.Text)
        TextExchangeRate.Text = tmpstr(0)
    End Sub

    Protected Sub ButtonLiveRate_Click(sender As Object, e As EventArgs) Handles ButtonLiveRate.Click
        Dim ICCode As String() = clsAccounts.GetCUrrencyNameandCode(LabelInvoiceCurrencyID.Text)
        Dim FCCode As String() = clsAccounts.GetCUrrencyNameandCode(ComboCurrency.Text)

        TextExchangeRate.Text = clsAccounts.convertCurrency(FCCode(0), ICCode(0))

        ModalPopupExtender7.Show()
    End Sub


End Class

