﻿Imports System.Drawing

Public Class invoiceitems
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""

            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadInvoiceItems(CFPROID, "", 0)

        End If

    End Sub

    Private Sub LoadInvoiceItems(CFPROID As String, SearchStr As String, Rowindex As Integer)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "Where Item Like '%" & Trim(SearchStr) & "'% " &
                         "And CFPROID = '" & CFPROID & "' "
            Else
                tmpstr = "Where  CFPROID = '" & CFPROID & "' "
            End If

            Dim sqlstr As String =
              "SELECT  ItemID, Item," &
              "Amount, ApplyTax," &
              "TaxType, TaxPercent," &
              "CFPROID,ID " &
              "FROM  InvoiceItems " &
              tmpstr &
              "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then
                Call clsSubs.CreateAccountInvoiceItems(CFPROID, tmptable, True)
            End If

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridInvoiceItems.DataSource = tmptable
            GridInvoiceItems.DataBind()

            Session("InvoiceItemsTable") = tmptable


            If GridInvoiceItems.Rows.Count > 0 Then
                If Rowindex < 0 Then
                    Rowindex = 0
                End If

                If Rowindex > GridInvoiceItems.Rows.Count - 1 Then
                    Rowindex = GridInvoiceItems.Rows.Count - 1
                End If

                GridInvoiceItems.SelectedIndex = Rowindex
                Dim row As GridViewRow = GridInvoiceItems.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If


            If Not Trim(SearchStr) = "" Then
                LabelCaption.Text = tmptable.Rows.Count & "  Invoice Items Found matching '" & SearchStr & "'"
            Else
                LabelCaption.Text = tmptable.Rows.Count & "  Invoice Items"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub GridInvoiceItems_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridInvoiceItems.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridInvoiceItems, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub GridInvoiceItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridInvoiceItems.SelectedIndexChanged
        Dim row As GridViewRow = GridInvoiceItems.Rows(GridInvoiceItems.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridInvoiceItems.Rows.Count - 1
            row = GridInvoiceItems.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridInvoiceItems.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub




    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditInvoiceItem(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditInvoiceItem(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridInvoiceItems.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please SELECT Invoice Item."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Invoice Item"
                Dim ID As Integer = GridInvoiceItems.SelectedValue
                Dim sqlstr As String = "SELECT Item,Amount," &
                                        "ApplyTax,TaxType," &
                                        "TaxPercent,ID " &
                                        "From  InvoiceItems " &
                                        "Where ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextItem.Text = drow("Item")
                    TextAmount.Text = drow("Amount")
                    CheckApplyTax.Checked = drow("ApplyTax")
                    ComboTaxType.Text = drow("TaxType")
                    TextTaxPercent.Text = drow("TaxPercent")
                End If

            Else
                LabelAddEdit.Text = "Add  Invoice Item"
                TextItem.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditInvoiceItem(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveInvoiceItem(Edit)
    End Sub

    Private Sub SaveInvoiceItem(Edit As Boolean)

        Dim ID As Integer = -1
        Dim CFPROID As String = LabelCFPROID.Text

        If Not Edit Then
            If InvoiceItemExists(TextItem.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridInvoiceItems.SelectedIndex >= 0 Then
                    ID = GridInvoiceItems.SelectedDataKey(0)
                End If
            End If

            Dim sqlstr As String =
                    "SELECT  ItemID, Item," &
                    "Amount, ApplyTax," &
                    "TaxType, TaxPercent," &
                    "CFPROID,ID " &
                    "FROM  InvoiceItems " &
                    "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("ItemID") = clsSubs.GetInvoiceItemID()
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Item") = Trim(UCase(TextItem.Text))
            drow("Amount") = Trim(TextAmount.Text)
            drow("ApplyTax") = CheckApplyTax.Checked
            drow("TaxType") = ComboTaxType.Text
            drow("TaxPercent") = Trim(TextTaxPercent.Text)


            Call clsData.SaveData("InvoiceItems", tmptable, sqlstr, False, clsData.constr)

            Call LoadInvoiceItems(CFPROID, TextSearch.Text, GridInvoiceItems.SelectedIndex)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub



    Private Function InvoiceItemExists(InvoiceItem As String) As Boolean


        Dim sqlstr As String = "SELECT InvoiceItem, InvoiceItemID " &
                                "From  InvoiceItems " &
                                "Where InvoiceItem = '" & Trim(InvoiceItem) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridInvoiceItems.SelectedIndex >= 0 Then
            Call PromptDeleteInvoiceItem(GridInvoiceItems.SelectedValue)
        Else
            LabelMessage.Text = "Please SELECT Invoice Item to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteInvoiceItem(ID As Integer)


        Dim row As GridViewRow = GridInvoiceItems.Rows(GridInvoiceItems.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteInvoiceItem(GridInvoiceItems.SelectedDataKey(0))
    End Sub
    Private Sub DeleteInvoiceItem(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From InvoiceItems  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("InvoiceItems", tmptable, sqlstr, True, clsData.constr)

            Call LoadInvoiceItems(LabelCFPROID.Text, TextSearch.Text, GridInvoiceItems.SelectedIndex - 1)

        End If
        ModalPopupExtender3.Hide()

    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadInvoiceItems(LabelCFPROID.Text, TextSearch.Text, 0)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadInvoiceItems(LabelCFPROID.Text, "", GridInvoiceItems.SelectedIndex)
    End Sub

    Private Function GetInvoiceItemID() As String
        Try

            Dim tmpInvoiceItemID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From InvoiceItems " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpInvoiceItemID = drow("ID")
                tmpInvoiceItemID = tmpInvoiceItemID + 1
                tmpstr = Format(tmpInvoiceItemID, "0000#")
            Else
                tmpstr = Format(tmpInvoiceItemID, "0000#")
            End If

            Return tmpstr

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetInvoiceItemID")
        End Try
    End Function

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click

        Dim Fields(5) As String
        Fields(0) = "ItemID"
        Fields(1) = "Item"
        Fields(2) = "Amount"
        Fields(3) = "ApplyTax"
        Fields(4) = "TaxType"
        Fields(5) = "TaxPercent"


        Dim tmptable As DataTable = Session("InvoiceItemsTable")
        Call clsExportToExcel.ExportToExcel("", "", "", "Invoice Items", "Invoice Items",
                                            LabelCaption.Text, False, Nothing, 0, "", Fields, Nothing, tmptable, False)


    End Sub
End Class