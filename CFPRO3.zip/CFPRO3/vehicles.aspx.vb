﻿Imports System.Drawing
Public Class vehicles
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadTransporters(CFPROID)
            Call LoadVehicles(CFPROID, 0, "")


        End If
    End Sub


    Private Sub LoadVehicles(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim sqlstr As String = _
                "Select VehicleID,VehicleNo," &
                "TransporterID, VehicleDescription, " &
                "Tonnage, ID " & _
                "From Vehicles " & _
                "Where CFPROID ='" & CFPROID & "' " &
                "Order By VehicleID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col As New DataColumn("Transporter", Type.GetType("System.String"))
        tmptable.Columns.Add(col)


        Dim sqlstr1 As String = _
                  "Select TransporterID,Transporter " & _
                  "From Transporters " & _
                  "Where CFPROID ='" & CFPROID & "' "

        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
        Dim dv1 As New DataView(tmptable1)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            dv1.RowFilter = "TransporterID = '" & drow("TransporterID") & "' "
            If dv1.Count > 0 Then
                clsData.NullChecker1(dv1, 0)
                drow("Transporter") = dv1(0)("Transporter")
            End If
            a = a + 1
        Next

        Session("VehiclesTable") = tmptable

        Dim dv As New DataView(tmptable)

        If Not Trim(SearchStr) = "" Then
            Dim FilterStr As String = "VehicleNo  Like '%" & Trim(TextSearchVehicleTransporter.Text) & "'% " &
                          "Or Transporter  Like '%" & Trim(TextSearchVehicleTransporter.Text) & "'% "
            dv.RowFilter = FilterStr

            LabelFilterStr.Text = FilterStr
        Else
            LabelFilterStr.Text = ""
        End If

        GridVehicles.DataSource = dv
        GridVehicles.DataBind()

        If GridVehicles.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridVehicles.Rows.Count - 1 Then
                Rowindex = GridVehicles.Rows.Count - 1
            End If

            GridVehicles.SelectedIndex = Rowindex
            Call ShowVehicle(CFPROID, GridVehicles.SelectedValue.ToString)
            Dim row As GridViewRow = GridVehicles.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = dv.Count & " Vehicles or Transporters found matching  '" & TextSearchVehicleTransporter.Text & "' "
        Else
            LabelItemsMessage.Text = dv.Count & " Vehicles"
        End If


    End Sub



    Private Sub ShowVehicle(CFPROID As String, VehicleID As String)
        Try
            Dim sqlstr As String = _
                     "Select VehicleID,VehicleNo," & _
                     "VehicleDescription," & _
                     "Tonnage,Capacity," & _
                     "TransporterID, ID " & _
                     "From Vehicles " & _
                     "Where CFPROID ='" & CFPROID & "' " &
                     "And VehicleID = '" & VehicleID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                TextVehicleNo.Text = drow("VehicleNo")
                TextVehicleDescription.Text = drow("VehicleDescription")
                TextTonnage.Text = drow("Tonnage")

                ComboTransporter.SelectedValue = drow("TransporterID")
                LabelTransporterID.Text = drow("TransporterID")
            End If

        Catch exp As Exception
            ' LabelMessage1.Text = exp.Message
        End Try
    End Sub



    Private Sub NewVehicle(CFPROID As String)
        Try

            Dim sqlstr As String = _
                  "Select VehicleID, VehicleNo," &
                   "CFPROID,ID " & _
                   "From  Vehicles " &
                   "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim Drow As DataRow
            Drow = tmptable.NewRow
            Drow("CFPROID") = CFPROID
            Drow("VehicleID") = GetVehicleID()
            Drow("VehicleNo") = "New Vehicle " & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Vehicles", tmptable, sqlstr, False, clsData.constr)
            Call LoadVehicles(CFPROID, 0, "")

            TextVehicleNo.Focus()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Private Function GetVehicleID() As String
        Try

            Dim tmpVehicleID As Integer

            Dim sqlstr As String = _
             "Select top 1 Id " & _
             "From Vehicles " & _
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpVehicleID = drow("ID")
                tmpVehicleID = tmpVehicleID + 1
                tmpstr = Format(tmpVehicleID, "000000#")
            Else
                tmpstr = Format(tmpVehicleID, "000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridVehicles, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridVehicles.SelectedIndexChanged
        Dim row As GridViewRow = GridVehicles.Rows(GridVehicles.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowVehicle(LabelCFPROID.Text, GridVehicles.SelectedValue.ToString)

        For a As Integer = 0 To GridVehicles.Rows.Count - 1
            row = GridVehicles.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridVehicles.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub





    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewVehicle(LabelCFPROID.Text)
    End Sub


    Private Sub SaveVehicle(CFPROID As String, VehicleID As String)
        Try

            Dim sqlstr As String = _
                 "Select VehicleID,VehicleNo," & _
                 "VehicleDescription," & _
                 "Tonnage,Capacity," & _
                 "TransporterID, Driver, ID " & _
                 "From Vehicles " & _
                 "Where CFPROID ='" & CFPROID & "' " &
                 "And VehicleID = '" & VehicleID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("VehicleNo") = UCase(Trim(TextVehicleNo.Text))
                drow("VehicleDescription") = Trim(TextVehicleDescription.Text)
                drow("Tonnage") = Trim(TextTonnage.Text)
                drow("TransporterID") = LabelTransporterID.Text
            End If

            Call clsData.SaveData("Vehicles", tmptable, sqlstr, False, clsData.constr)

            Call LoadVehicles(CFPROID, GridVehicles.SelectedIndex, TextSearchVehicleTransporter.Text)


        Catch exp As Exception
            MsgBox(exp.Message, , "SaveVehicle")
        End Try
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveVehicle(LabelCFPROID.Text, GridVehicles.SelectedValue.ToString)
    End Sub

    Private Sub DeleteVehicle(CFPROID As String, VehicleID As String)


        Dim sqlstr As String = _
        "Select ID " & _
        "From  Vehicles " & _
        "Where CFPROID ='" & CFPROID & "' " &
        "And VehicleID = '" & VehicleID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Vehicles", tmptable, sqlstr, True, clsData.constr)
        Call LoadVehicles(CFPROID, GridVehicles.SelectedIndex - 1, TextSearchVehicleTransporter.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteVehicle(LabelCFPROID.Text, GridVehicles.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadVehicles(LabelCFPROID.Text, -1, TextSearchVehicleTransporter.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        TextSearchVehicleTransporter.Text = ""
        Call LoadVehicles(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ComboTransporter_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboTransporter.SelectedIndexChanged
        LabelTransporterID.Text = ComboTransporter.SelectedValue
    End Sub

    Private Sub LoadTransporters(CFPROID As String)

        If ComboTransporter.Items.Count = 0 Then
            Dim sqlstr As String = _
                "Select Transporter,TransporterID " & _
                "From Transporters " & _
                "Where CFPROID = '" & CFPROID & "' " &
                "Order By Id Desc; "

            ComboTransporter.Items.Add("")
            Call clsData.PopComboWithValue(ComboTransporter, sqlstr, clsData.constr, 0, 1)
        End If
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click

        Dim Fields(3) As String
        Fields(0) = "VehicleID"
        Fields(1) = "VehicleNo"
        Fields(2) = "VehicleDescription"
        Fields(3) = "Transporter"

        Dim tmptable As DataTable = Session("VehiclesTable")
        Call clsExportToExcel.ExportToExcel(LabelCFPROID.Text, LabelFilterStr.Text, "", "Vehicles", "Vehicles",
                                            LabelItemsMessage.Text, False, Nothing, 0, LabelMessage1.Text, Fields, Nothing, tmptable, False)

    End Sub


End Class