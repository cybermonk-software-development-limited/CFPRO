﻿Public Class marineproductdesc
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Call LoadProductDesc(Request.QueryString("insurerid"))

        End If





    End Sub

    Private Sub LoadProductDesc(InsurerID As String)

        Dim sqlstr As String =
       "SELECT InsurerID, Insurer, " & _
       "ProductName, " & _
       "Description, URL," & _
       "EmailAddress,Telephone " & _
       "FROM MarineCargoInsurer " & _
       "Where InsurerID ='" & InsurerID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim imageURL As String


        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            If IO.File.Exists(Server.MapPath(".") & "\insurerimages\" & drow("InsurerID") & ".jpg") Then
                imageURL = "~/insurerimages/" & drow("InsurerID") & ".jpg"
            ElseIf IO.File.Exists(Server.MapPath(".") & "\insurerimages\" & drow("InsurerID") & ".png") Then
                imageURL = "~/insurerimages/" & drow("InsurerID") & ".png"
            Else
                imageURL = "~/insurerimages/000000000.png"
            End If
            Image1.ImageUrl = imageURL

            LabelInsurer.Text = drow("Insurer")
            LabelProductName.Text = drow("ProductName")
            LabelContacts.Text = "You can contact us on - Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")
            Literal1.Text = clsTextToHtml.ToHtml(drow("Description"))

            HyperLink1.NavigateUrl = drow("URL")

        End If

    End Sub

End Class