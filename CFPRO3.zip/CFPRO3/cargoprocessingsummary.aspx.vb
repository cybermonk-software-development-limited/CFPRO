﻿Imports System.Drawing

Public Class cargoprocessingsummary
    Inherits System.Web.UI.Page

    Friend JobId As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If

            Try

                Call LoadJobTypes(CFPROID)
                Call LoadTransporters(CFPROID)
                Call LoadReleaseOrderStatus(CFPROID)
                Call LoadContainerStatuses(CFPROID)
                Call LoadCFS(CFPROID)
                Call LoadVessels(CFPROID)
                Call LoadPayLoads(CFPROID)
                Call LoadDestinations(CFPROID)

            Catch ex As Exception
                LabelMessage1.Text = ex.Message & ex.StackTrace
            End Try


            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"


            Call LoadCargoProcessing("", LabelCFPROID.Text)

        End If

    End Sub

    Private Sub LoadCargoProcessing(CFPROID As String, ByVal UserID As String)


        Dim sqlstr As String =
            "Select TOP 50 JobCargo.JobId," &
            "ContainerNo,Payload,JobCargo.Weight,VehicleNo," &
            "Transporter,JobCargo.PortExitDate," &
            "JobCargo.CrossBorderDate,DestinationArrivalDate," &
            "Jobs.JobDate,ReferenceNo," &
            "Jobs.Importer,EntryStatus,T812No," &
            "EntryRegistrationDate,EntryPassDate, " &
            "DeliveryOrderStatus,DeliveryOrderCharges," &
            "DeliveryOrderDate,Jobs.ReleaseOrderStatus," &
            "ReleaseOrderDate,PortCharges," &
            "Jobs.ShippingVessel,Jobs.VoyageNo," &
            "PortChargesStatus,PortChargesPaidDate, " &
            "Jobs.Client,Jobs.JobStatus,Jobs.VesselETA," &
            "Jobs.BerthingDate,CFS," &
            "Shipper,Agent, " &
            "Jobs.JobType,Jobs.KeepVisible,JobCargo.ID " &
            "From JobCargo, Jobs " &
            "Where JobCargo.JobId  = Jobs.JobId " & _
            "And Jobs.CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col1 As New DataColumn("T810", Type.GetType("System.String"))
        Dim col2 As New DataColumn("T812", Type.GetType("System.String"))
        Dim col3 As New DataColumn("DO", Type.GetType("System.String"))
        Dim col4 As New DataColumn("RO", Type.GetType("System.String"))
        Dim col5 As New DataColumn("Port", Type.GetType("System.String"))
        Dim col6 As New DataColumn("Trans", Type.GetType("System.String"))
        Dim col7 As New DataColumn("Consignee", Type.GetType("System.String"))
        Dim col8 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
        Dim col9 As New DataColumn("Arrived", Type.GetType("System.Boolean"))
        Dim col10 As New DataColumn("Status", Type.GetType("System.String"))

        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)
        tmptable.Columns.Add(col8)
        tmptable.Columns.Add(col9)
        tmptable.Columns.Add(col10)

        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)

            Dim tmpstr5() As String = drow("Importer").ToString.Split(vbCrLf)
            ReDim Preserve tmpstr5(0)
            drow("Importer") = tmpstr5(0)
            drow("Consignee") = Mid(tmpstr5(0), 1, 20)

            If CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                drow("CrossedBorder") = CBool(1)
            End If

            If CDate(drow("DestinationArrivalDate")) = CDate("1-Jan-1800") Then
                drow("Arrived") = CBool(1)
            End If

            drow("T810") = "-"

            If Trim(LCase(drow("EntryStatus"))) = "lodged" Then
                drow("T810") = "OK"
            End If

            If Trim(LCase(drow("EntryStatus"))) = "passed" Then
                drow("T810") = "OK"
            End If


            If Not CDate(Trim(drow("EntryRegistrationDate"))) = CDate("1-Jan-1800") Then
                drow("T810") = "OK"
            End If

            If Not CDate(Trim(drow("EntryRegistrationDate"))) = CDate("1-Jan-1800") Then
                drow("T810") = "OK"
            End If

            '----------
            drow("T812") = "-"

            If Not Trim(LCase(drow("T812No"))) = "" Then
                drow("T812") = "OK"
            End If

            '----------

            drow("DO") = "-"

            If Trim(LCase(drow("DeliveryOrderStatus"))) = "secured" Then
                drow("DO") = "OK"
            End If

            If Not CDate(Trim(drow("DeliveryOrderDate"))) = CDate("1-Jan-1800") Then
                drow("DO") = "OK"
            End If

            If Val(drow("DeliveryOrderCharges")) > 0 Then
                drow("DO") = "OK"
            End If

            '----------

            drow("RO") = "-"

            If Trim(LCase(drow("ReleaseOrderStatus"))) = "secured" Then
                drow("RO") = "OK"
            End If

            If Not CDate(Trim(drow("ReleaseOrderDate"))) = CDate("1-Jan-1800") Then
                drow("RO") = "OK"
            End If


            '----------

            drow("PORT") = "-"

            If Trim(LCase(drow("PortChargesStatus"))) = "paid" Then
                drow("PORT") = "OK"
            End If

            If Not CDate(Trim(drow("PortChargesPaidDate"))) = CDate("1-Jan-1800") Then
                drow("PORT") = "OK"
            End If


            If Val(drow("PortCharges")) > 0 Then
                drow("Port") = "OK"
            End If


            drow("Trans") = "-"

            If Not Trim(LCase(drow("VehicleNo"))) = "" Then
                drow("Trans") = "OK"
            End If

            If Not Trim(LCase(drow("Transporter"))) = "" Then
                drow("Trans") = "OK"
            End If

            a = a + 1
        Next

        If tmptable.Rows.Count > 10 Then
            Panel1.Height = 300
        Else
            GridCargo.Height = 20 + (tmptable.Rows.Count * 20)
            Panel1.Height = Nothing
        End If

        GridCargo.DataSource = tmptable
        GridCargo.DataBind()

        LabelReportCaption.Text = "CARGO PROCESSING SUMMARY: " & tmptable.Rows.Count & " Cargo Items  " & TextFromDate.Text & " - " & TextToDate.Text
    End Sub

    Private Sub LoadDestinations(CFPROID As String)
        Dim sqlstr As String =
        "Select Destination From Destinations " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Destination Asc;"

        ComboDestination.Items.Clear()
        Call clsData.PopCombo(ComboDestination, sqlstr, clsData.constr, 0)
        ComboDestination.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadTransporters(CFPROID As String)
        Dim sqlstr As String =
        "Select Transporter,TransporterID From Transporters " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Transporter Asc;"

        ComboTransporter.Items.Clear()
        Call clsData.PopComboWithValue(ComboTransporter, sqlstr, clsData.constr, 0, 1)
        ComboTransporter.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadPayLoads(CFPROID As String)
        Dim sqlstr As String =
        "Select Payload From Payloads " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Payload Asc;"

        ComboPayload.Items.Clear()
        Call clsData.PopCombo(ComboPayload, sqlstr, clsData.constr, 0)
        ComboPayload.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadReleaseOrderStatus(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ReleaseOrderStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboReleaseOrderStatus.Items.Clear()
        Call clsData.PopCombo(ComboReleaseOrderStatus, sqlstr, clsData.constr, 0)
        ComboReleaseOrderStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadContainerStatuses(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ContainerStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboContainerStatus.Items.Clear()
        Call clsData.PopCombo(ComboContainerStatus, sqlstr, clsData.constr, 0)
        ComboContainerStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadVessels(CFPROID As String)
        Dim sqlstr As String =
        "Select Vessel, VesselID " &
        "From ShippingVessels " &
        "Where CFPROID = '" & CFPROID & "' " &
        "And Active =1 " &
        "Order By Vessel Asc;"

        Call clsData.PopComboWithValue(ComboVessel, sqlstr, clsData.constr, 0, 1)
        ComboVessel.Items.Insert(0, "(All)")

    End Sub
    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub

    Private Sub CompoundFilter(agent As Boolean, client As Boolean, containerStatus As Boolean, consignee As Boolean,
                               jobType As Boolean, ROstatus As Boolean, payLoad As Boolean, transporter As Boolean,
                               cfs As Boolean, vessel As Boolean, destination As Boolean, remainingDays As Boolean,
                               ByVal OmitCrossedBorder As Boolean, Optional ByRef ErrMsg As String = "")
        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer


            If IsNothing(Session("JobCargo")) Then
                Call LoadCargoProcessing(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobCargo As DataTable = Session("JobCargo")

            Dim dv As New DataView(JobCargo)
            'dv.Sort = Nothing
            'dv.RowFilter = Nothing

            If agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID Like " & "'%" & Trim(LabelAgentID.Text) & "'% "
                tmpstr1(a) = "Agent: " & LabelAgentID.Text
                b = b + 1
                tmpstr1(a) = "Agent : " & TextAgent.Text
            End If


            If client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & Trim(LabelClientID.Text) & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & Trim(LabelClientID.Text) & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If containerStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ContainerStatus Like " & "'%" & Trim(ComboContainerStatus.Text) & "'% "
                Else
                    tmpstr(a) = " And ContainerStatus Like " & "'%" & ComboContainerStatus.Text & "'% "
                End If

                tmpstr1(a) = "ContainerStatus: " & ComboContainerStatus.Text
                b = b + 1
            End If

            If consignee Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & Trim(LabelImporterID.Text) & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If jobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                b = b + 1
            End If

            If vessel Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "VesselID = " & "'" & Trim(ComboVessel.Text) & "' "
                Else
                    tmpstr(a) = " And VesselID = " & "'" & ComboVessel.Text & "%=' "
                End If

                tmpstr1(a) = "Vessel: " & ComboVessel.SelectedItem.Text
                b = b + 1
            End If


            If payLoad Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "PayLoad Like " & "'%" & Trim(ComboPayload.Text) & "'% "
                Else
                    tmpstr(a) = " And PayLoad Like " & "'%" & ComboPayload.Text & "'% "
                End If

                tmpstr1(a) = "PayLoad: " & ComboPayload.Text
                b = b + 1
            End If


            If transporter Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "TransporterID Like " & "'%" & Trim(ComboTransporter.Text) & "'% "
                Else
                    tmpstr(a) = " And TransporterID Like " & "'%" & ComboTransporter.Text & "'% "
                End If

                tmpstr1(a) = "Transporter: " & ComboTransporter.SelectedItem.ToString
                b = b + 1
            End If

            If ROstatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ReleaseOrderStatus Like " & "'%" & Trim(ComboReleaseOrderStatus.Text) & "'% "
                Else
                    tmpstr(a) = " And ReleaseOrderStatus Like " & "'%" & ComboReleaseOrderStatus.Text & "'% "
                End If

                tmpstr1(a) = "Release Order Status: " & ComboReleaseOrderStatus.Text
                b = b + 1
            End If

            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If


            If destination Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "Destination Like " & "'%" & Trim(ComboDestination.Text) & "'% "
                Else
                    tmpstr(a) = " And Destination Like " & "'%" & ComboDestination.Text & "'% "
                End If

                tmpstr1(a) = "Destination: " & ComboTransporter.Text
                b = b + 1
            End If

            If cfs Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If

            If remainingDays Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)

                If ComboRemainingDays.SelectedIndex > 0 Then
                    If ComboRemainingDays.SelectedValue >= 0 Then
                        If b = 0 Then
                            tmpstr(a) = "RemainingDays <= " & "" & Trim(ComboRemainingDays.SelectedValue) & " " &
                                "And RemainingDays >= 0"
                        Else
                            tmpstr(a) = "And RemainingDays <= " & "'" & ComboRemainingDays.SelectedValue & "' " &
                                "And RemainingDays >= 0"
                        End If
                    Else
                        If b = 0 Then
                            tmpstr(a) = "RemainingDays <= " & "" & Trim(ComboRemainingDays.SelectedValue) & " " &
                                "And RemainingDays <= 0"
                        Else
                            tmpstr(a) = "And RemainingDays <= " & "'" & ComboRemainingDays.SelectedValue & "' " &
                                "And RemainingDays <= 0"
                        End If
                    End If
                End If

                tmpstr1(a) = "Demurrage Days: " & ComboRemainingDays.SelectedItem.Text
                b = b + 1
            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2

            GridCargo.DataSource = dv
            GridCargo.DataBind()


            LabelFilterStr.Text = tmpstr2
            LabelReportCaption.Text = dv.Count & " Containers"


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim TEU, Weight, CBM As Double
            Dim TWFT, FTFT As Double

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + Val(dv(a)("TEU"))

                If InStr(dv(a)("PayLoad"), "20", CompareMethod.Text) > 0 Then
                    TWFT = TWFT + 1
                End If

                If InStr(dv(a)("PayLoad"), "40", CompareMethod.Text) > 0 Then
                    FTFT = FTFT + 1
                End If

            Next

            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTEU.Text = Format(TEU, "#,##0")

            TextTotal20ft.Text = Format(TWFT, "#,##0")
            TextTotal40ft.Text = Format(FTFT, "#,##0")
            TextTotalContainers.Text = Format((TWFT + FTFT), "#,##0")

            TextTotalQty.Text = Format(dv.Count, "#,##0")

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " | " & tmpstr
            Else
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " " & tmpcaption1 & " | " & tmpstr
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadCargoProcessing(CFPROID, CFPROUserID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2



                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadCargoProcessing(CFPROID, CFPROUserID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelFilters.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub



    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridCargo.SelectedIndexChanged
        Dim row As GridViewRow = GridCargo.Rows(GridCargo.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridCargo.Rows.Count - 1
            row = GridCargo.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridCargo.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub ButtonApplyDates0_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        GotoJob(GridCargo.SelectedValue)
    End Sub

    Private Sub GotoJob(JobID As String)
        Response.Redirect("jobentry.aspx?jobid=" & JobID)
    End Sub
End Class