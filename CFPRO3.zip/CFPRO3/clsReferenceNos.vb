﻿Imports System.Drawing
Public Class clsReferenceNos

    Shared Function ReferenceNo(CFPROID As String, JobType As String, JobID As String, nReferenceNo As String) As String

        If CFPROID = "CFPR000000043-30" Then

            Dim nJobType As String = ""
            Dim nYear As String = Format(Now, "yy")
            Dim nJobID As String = Format(CInt(JobID), "0000")
            If InStr(LCase(JobType), "local") > 0 Then
                If InStr(LCase(JobType), "ex") > 0 Then
                    nJobType = "LX"
                Else
                    nJobType = "L"
                End If
            ElseIf InStr(LCase(JobType), "trans") > 0 Then
                If InStr(LCase(JobType), "exp") > 0 Then
                    nJobType = "EX"
                Else
                    nJobType = "TR"
                End If
            End If

            Return "L365/" & nJobID & nJobType & "/" & nYear

        Else
            Return nReferenceNo
        End If


    End Function

    Shared Function ReferenceNoExists(CFPROID As String, JobID As String, ByRef TextReferenceNo As TextBox) As String

        Dim nReferenceNo As String = TextReferenceNo.Text

        If InStr(nReferenceNo, "Already Exists.", CompareMethod.Text) > 0 Then
            nReferenceNo = Trim(nReferenceNo.Replace("Already Exists.", ""))
        End If

        If InStr(nReferenceNo, "Exists more than once.", CompareMethod.Text) > 0 Then
            nReferenceNo = Trim(nReferenceNo.Replace("Exists more than once.", ""))
        End If

        If Not nReferenceNo = "" Then
            Dim sqlstr As String =
                      "Select JobID,ReferenceNo " &
                      "From Jobs " &
                      "Where ReferenceNo = '" & nReferenceNo & "' " &
                      "And CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim a As Integer
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    a = a + 1
                Next

                If tmptable.Rows.Count = 1 Then
                    drow = tmptable.Rows(0)
                    If drow("JobID") = JobID Then
                        TextReferenceNo.ForeColor = Color.Black
                        Return nReferenceNo
                    Else
                        TextReferenceNo.ForeColor = Color.Red
                        Return nReferenceNo & " Already Exists."
                    End If
                ElseIf tmptable.Rows.Count > 1 Then
                    TextReferenceNo.ForeColor = Color.Red
                    Return nReferenceNo & " Exists more than once."
                End If
            Else
                TextReferenceNo.ForeColor = Color.Black
                Return nReferenceNo
            End If
        End If
    End Function

    Shared Function ReferenceNo2(CFPROID As String, JobType As String, JobID As String, nReferenceNo2 As String) As String

        If CFPROID = "CFPR000000272-80" Then

            Dim nJobType As String = ""
            Dim nYear As String = Format(Now, "yyyy-")

            If InStr(LCase(JobType), "local") > 0 Then
                If InStr(LCase(JobType), "ex") > 0 Then
                    nJobType = "LX-"
                Else
                    nJobType = "LC-"
                End If
            ElseIf InStr(LCase(JobType), "trans") > 0 Then
                If InStr(LCase(JobType), "exp") > 0 Then
                    nJobType = "EX-"
                Else
                    nJobType = "TR-"
                End If
            End If

            Return "AGL-" & nYear & nJobType & JobID

        Else
            Return nReferenceNo2
        End If


    End Function

    Shared Function ReferenceNo2Exists(CFPROID As String, JobID As String, ByRef TextReferenceNo2 As TextBox) As String

        Dim nReferenceNo2 As String = TextReferenceNo2.Text

        If InStr(nReferenceNo2, "Already Exists.", CompareMethod.Text) > 0 Then
            nReferenceNo2 = Trim(nReferenceNo2.Replace("Already Exists.", ""))
        End If

        If InStr(nReferenceNo2, "Exists more than once.", CompareMethod.Text) > 0 Then
            nReferenceNo2 = Trim(nReferenceNo2.Replace("Exists more than once.", ""))
        End If

        If Not nReferenceNo2 = "" Then
            Dim sqlstr As String =
                      "Select JobID,ReferenceNo " &
                      "From Jobs " &
                      "Where ReferenceNo1 = '" & nReferenceNo2 & "' " &
                      "And CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim a As Integer
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    a = a + 1
                Next

                If tmptable.Rows.Count = 1 Then
                    drow = tmptable.Rows(0)
                    If drow("JobID") = JobID Then
                        TextReferenceNo2.ForeColor = Color.Black
                        Return nReferenceNo2
                    Else
                        TextReferenceNo2.ForeColor = Color.Red
                        Return nReferenceNo2 & " Already Exists."
                    End If
                ElseIf tmptable.Rows.Count > 1 Then
                    TextReferenceNo2.ForeColor = Color.Red
                    Return nReferenceNo2 & " Exists more than once."
                End If
            Else
                TextReferenceNo2.ForeColor = Color.Black
                Return nReferenceNo2
            End If
        End If
    End Function

End Class
