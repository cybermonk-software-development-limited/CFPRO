﻿Public Class cfproaccount
    Inherits System.Web.UI.Page

    Friend JobId As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



        If Not IsPostBack Then

            'Dim imgurl As String = ""
            Dim CSDID As String = ""
            Dim CFPROID As String = ""
            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Dim UserType As String = ""
            If Not Request.Cookies("UserType") Is Nothing Then
                UserType = Request.Cookies("UserType").Value
            End If



            If UserType = "cfagent" Then
                PanelTopMenu.Visible = True
                PanelImpoterMenu.Visible = False
            Else
                PanelTopMenu.Visible = False
                PanelImpoterMenu.Visible = True
            End If




            Dim host As String = HttpContext.Current.Request.Url.Host

            If InStr(host, ".com", CompareMethod.Text) > 0 Then
                host = "http://www.cybermonksd.com/"
            Else
                host = "http://" & host & ":84/"
            End If

            host = host & "productaccount.aspx?productaccountid=" & HttpUtility.UrlEncode(clsEncr.EncryptString(CFPROID)) & _
                   "&csdid=" & HttpUtility.UrlEncode(clsEncr.EncryptString(CSDID))


            iFrame1.Attributes("src") = host
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If

    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub
End Class