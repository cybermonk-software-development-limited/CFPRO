﻿Public Class cfprousers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            Dim CSDID As String = ""
            Dim CFPROID As String = ""

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Call clsAuth.UserLogin(CSDID, CFPROID, "", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, "", False)
            Call LoadCFPROAccounts()

            LabelUserCSDID.Text = CSDID
            LabelCFPROID.Text = CFPROID

            Dim tmpdest As String = ""


            If Not IsNothing(Request.Cookies("CSDAdmin")) Then
                Try
                    If Request.Cookies("CSDAdmin").Value = 1 Then
                        tmpdest = "/adminproducts.aspx"
                    End If
                Catch ex As Exception

                End Try
            End If


            If InStr(HttpContext.Current.Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://localhost:84" & tmpdest
            ElseIf InStr(HttpContext.Current.Request.Url.ToString, "172.16.254", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://172.16.254.105:84" & tmpdest

            ElseIf InStr(HttpContext.Current.Request.Url.ToString, "cfproonline.com", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://cybermonksd.com" & tmpdest
            End If

            LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadCFPROAccounts()
        Try

            'load impoter and transpoter accounts from cfproaccount connect
            'get names and other details from csd prodcut accounts using web service


            Dim sqlstr As String = _
                "SELECT   CFPROID, CFAgentName," &
                "CFAgentAddress, NextPaymentDate," &
                "CurrentUseCount, MaxUseCount," &
                "ProductStatus, AboutAccount," &
                "AccountURL, AccountStatus," &
                "LogoURL, CreatedOn, ID " &
                "FROM  CFPROAccounts"

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
              "SELECT CFPROID," &
               "RatingAvarage,RatingID, ID " &
               "FROM  CFAgentRating "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim col As New DataColumn("CSDAdmin", Type.GetType("System.Boolean"))
            Dim col1 As New DataColumn("ImageURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Added", Type.GetType("System.String"))
            Dim col3 As New DataColumn("AccountURLText", Type.GetType("System.String"))

            Dim col4 As New DataColumn("Image0", Type.GetType("System.String"))
            Dim col5 As New DataColumn("Image1", Type.GetType("System.String"))
            Dim col6 As New DataColumn("Image2", Type.GetType("System.String"))
            Dim col7 As New DataColumn("Image3", Type.GetType("System.String"))
            Dim col8 As New DataColumn("Image4", Type.GetType("System.String"))

            Dim col9 As New DataColumn("RatingAvarageText", Type.GetType("System.String"))


            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)


            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)


            Dim a As Integer
            Dim CSDAdmin As Boolean
            If Not IsNothing(Request.QueryString("csdadmin")) Then
                CSDAdmin = Request.QueryString("csdadmin")
            End If

            Dim tmpstr(0) As String
            Dim RatingImageURL(4) As String
            Dim RatingAvarage As Double = 0
            Dim RatingUsers As Double = 0
            Dim b As Integer

            Dim dv1 As New DataView(tmptable1)

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                drow("CSDAdmin") = CSDAdmin

                drow("AboutAccount") = Mid(drow("AboutAccount"), 1, 100)

                If drow("AccountURL") = "" Then
                    drow("AccountURLText") = ""
                Else
                    drow("AccountURL") = drow("AccountURL").ToString.Replace("http://", "")
                    drow("AccountURLText") = drow("AccountURL")
                    drow("AccountURL") = "http://" & drow("AccountURL")

                End If

                drow("Added") = "Joined: " & Format(drow("CreatedOn"), "dd MMMM yyyy")

                dv1.RowFilter = "CFPROID ='" & drow("CFPROID") & "' "
                If dv1.Count > 0 Then
                    For b = 0 To dv1.Count - 1
                        clsData.NullChecker1(dv1, b)
                        RatingAvarage = RatingAvarage + dv1(b)("RatingAvarage")
                    Next

                    RatingAvarage = RatingAvarage / dv1.Count

                    If RatingAvarage < 1 Then
                        RatingAvarage = 1.5
                    End If

                    RatingUsers = dv1.Count
                Else
                    RatingAvarage = 1.5

                    RatingUsers = 1

                End If

                drow("RatingAvarageText") = "Rated: " & Format(RatingAvarage, "0.0") & " - " & Format(RatingUsers, "#,#") & " Votes"




                RatingImageURL = clsCFPROAccount.SetAvarageRating(RatingAvarage)

                drow("Image0") = RatingImageURL(0)
                drow("Image1") = RatingImageURL(1)
                drow("Image2") = RatingImageURL(2)
                drow("Image3") = RatingImageURL(3)
                drow("Image4") = RatingImageURL(4)


                tmpstr = drow("LogoURL").ToString.Split(".")
                b = tmpstr.GetUpperBound(0)
                If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFPROID") & "." & tmpstr(b)) Then
                    drow("ImageURL") = "~/cfagentimages/" & drow("CFPROID") & "." & tmpstr(b)
                Else
                    drow("ImageURL") = "~/cfagentimages/000000000.png"
                End If

                Call ClearDashes(tmptable, drow)

                a = a + 1

            Next

            LabelCaption.Text = "Users on C&F PRO - " & tmptable.Rows.Count

            DataList1.DataSource = tmptable
            DataList1.DataBind()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

    Private Sub ClearDashes(tmptable As DataTable, drow As DataRow)
        For Each col As DataColumn In tmptable.Columns
            If Not IsNumeric(drow(col.ColumnName)) Then
                If Not IsDate(drow(col.ColumnName)) Then
                    If drow(col.ColumnName) = "--" Then
                        drow(col.ColumnName) = ""
                    End If
                End If
            End If
        Next
    End Sub
    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub


    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Call ShowCFPROAccount(sender)
    End Sub

    Private Sub ShowCFPROAccount(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim tmpstr As String = link.CommandArgument

            PanelDialog.Attributes("style") = "height:580px; width:750px;"
            iframe1.Attributes("style") = "height:510px; width:740px;" & LabeliFrameBgStyle.Text
            iframe1.Attributes("src") = "cfproaccountdetails.aspx?CFPROID=" & tmpstr & "&allowrating=0&usercsdid=" & LabelUserCSDID.Text
            LableDialogTitle.Text = "C&F PRO User Account"

            ModalPopupExtender1.Show()
        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub LinkRating_Click(sender As Object, e As EventArgs)
        Call ShowRating(sender)
    End Sub

    Private Sub ShowRating(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim tmpstr As String = link.CommandArgument

            PanelDialog.Attributes("style") = "height:555px; width:710px;"
            iframe1.Attributes("style") = "height:480px; width:700px;" & LabeliFrameBgStyle.Text
            iframe1.Attributes("src") = "cfagentrating.aspx?CFPROID=" & tmpstr & "&allowrating=0&usercsdid = " & LabelUserCSDID.Text
            LableDialogTitle.Text = "Rating Breakdown"

            ModalPopupExtender1.Show()
        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs)
        Call DeleteCFPROAccount(sender)
    End Sub


    Private Sub DeleteCFPROAccount(sender As Object)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim tmpstr As String = link.CommandArgument


        Dim sqlstr As String = _
             "SELECT   ID " &
             "FROM  CFPROAccounts " &
             "Where ID = " & CInt(tmpstr) & " "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, True, clsData.constr)

            Call LoadCFPROAccounts()
        End If

    End Sub



End Class