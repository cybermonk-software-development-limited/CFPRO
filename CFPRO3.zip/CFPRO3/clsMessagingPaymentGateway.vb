﻿
Imports System.IO
Imports System.Net
Imports System.Net.Http
Imports System.Web.Script.Serialization
Imports Newtonsoft.Json




Public Class ATSendText
    Shared Sub SendText(Recipients As String, Message As String, CFPROID As String, ByRef Result As String)


        Dim username As String
        Dim apiKey As String
        Dim sender As String


        If CFPROID = "CFPR000000272-80" Then
            username = "aglkenya"
            apiKey = "34188289535822d3350639d06c3321c90038ad7b8a3f92b8111b463f101dbe22"
            sender = "AGL-KENYA"
        Else
            username = "cfpro"
            apiKey = "46bcb4fd894efde2bfea29a5b6eb202b4a16ade3702e0238a46ea270d4a71e72"
            sender = "CFPRO"
        End If



        Try

            Dim Gateway As New AfricasTalkingGateway(username, apiKey)
            Call Gateway.sendMessage(Recipients, Message, sender)

            'Dim response As Object() = Gateway.sendMessage(recipients, Message, sender)
            'Dim result As Object
            'For Each result In response
            '    System.Console.WriteLine("Status: " + result("status"))
            '    System.Console.WriteLine("StatusCode: " + result("statusCode"))
            '    System.Console.WriteLine("MessageID: " + result("messageId"))
            '    System.Console.WriteLine("phoneNumber: " + result("number"))
            '    System.Console.WriteLine("Cost: " + result("cost"))
            'Next

            Result = "Success!"

        Catch e As AfricasTalkingGatewayException
            Result = e.Message
        End Try
    End Sub
End Class




Public Class AfricasTalkingGateway
    Private _username As String
    Private _apiKey As String
    Private _environment As String
    Private responseCode As Integer
    Private serializer As JavaScriptSerializer

    'Change the debug flag to true to view the full response
    Private DEBUG As Boolean = False

    Public Sub New(ByVal username_ As String, ByVal apiKey_ As String)
        _username = username_
        _apiKey = apiKey_
        _environment = "production"
    End Sub

    Public Sub New(ByVal username_ As String, ByVal apiKey_ As String, ByVal environment_ As String)
        _username = username_
        _apiKey = apiKey_
        _environment = environment_
        serializer = New JavaScriptSerializer()
    End Sub

    Public Function sendMessage(ByVal to_ As String, ByVal message_ As String, Optional ByVal from_ As String = Nothing,
                                Optional ByVal bulkSMSMode_ As Integer = 1, Optional ByVal options_ As Hashtable = Nothing) As Object
        Dim data As New Hashtable()
        data("username") = _username
        data("to") = to_
        data("message") = message_

        If from_ IsNot Nothing Then
            data("from") = from_
            data("bulkSMSMode") = Convert.ToString(bulkSMSMode_)

            If options_ IsNot Nothing Then
                If options_.Contains("keyword") Then
                    data("keyword") = options_("keyword")
                End If

                If options_.Contains("linkId") Then
                    data("linkId") = options_("linkId")
                End If

                If options_.Contains("enqueue") Then
                    data("enqueue") = options_("enqueue")
                End If

                If options_.Contains("retryDurationInHours") Then
                    data("retryDurationInHours") = options_("retryDurationInHours")
                End If
            End If
        End If

        Try
            Dim response As String = sendPostRequest(data, SMS_URLString)

            If responseCode = CInt(HttpStatusCode.Created) Then

                Dim json = serializer.Deserialize(Of Object)(response)
                Dim recipients As Object = json("SMSMessageData")("Recipients")
                If recipients.Length > 0 Then
                    Return recipients
                End If
                Throw New AfricasTalkingGatewayException(CType(json("SMSMessageData")("Message"), String))
            End If

            Throw New AfricasTalkingGatewayException(response)

        Catch ex As Exception
            Return ex.Message & ex.StackTrace
        End Try


    End Function

    Shared Sub nFetchMessages(ByVal args As String())
        Console.WriteLine("Hello World!")
        Dim username As String = "cfpro"
        Dim apiKey As String = "46bcb4fd894efde2bfea29a5b6eb202b4a16ade3702e0238a46ea270d4a71e72"


        Dim gateway = New AfricasTalkingGateway(username, apiKey)
        Dim msgId As Integer = 0

        Try
            Dim res = gateway.fetchMessages(msgId)
            Console.WriteLine(res)
        Catch e As AfricasTalkingGatewayException
            Console.WriteLine("We had an Error: " & e.Message)
        End Try

        Console.ReadLine()
    End Sub
    Public Function fetchMessages(ByVal lastReceivedId_ As Integer) As Object
        Dim url As String = SMS_URLString & "?username=" & _username & "&lastReceivedId=" & Convert.ToString(lastReceivedId_)

        Dim response As String = sendGetRequest(url)
        If responseCode = CInt(HttpStatusCode.OK) Then
            Dim json As Object = serializer.DeserializeObject(response)
            Return json("SMSMessageData")("Messages")
        End If
        Throw New AfricasTalkingGatewayException(response)
    End Function


    Public Function createSubscription(ByVal phoneNumber_ As String, ByVal shortCode_ As String, ByVal keyword_ As String) As Object
        If phoneNumber_.Length = 0 OrElse shortCode_.Length = 0 OrElse keyword_.Length = 0 Then
            Throw New AfricasTalkingGatewayException("Please supply phone number, short code and keyword")
        End If
        Dim data_ As New Hashtable()
        data_("username") = _username
        data_("phoneNumber") = phoneNumber_
        data_("shortCode") = shortCode_
        data_("keyword") = keyword_
        Dim urlString As String = SUBSCRIPTION_URLString & "/create"
        Dim response As String = sendPostRequest(data_, urlString)
        If responseCode = CInt(HttpStatusCode.Created) Then
            Dim json As Object = serializer.Deserialize(Of Object)(response)
            Return json
        End If
        Throw New AfricasTalkingGatewayException(response)
    End Function

    Public Function deleteSubscription(ByVal phoneNumber_ As String, ByVal shortCode_ As String, ByVal keyword_ As String) As Object
        If phoneNumber_.Length = 0 OrElse shortCode_.Length = 0 OrElse keyword_.Length = 0 Then
            Throw New AfricasTalkingGatewayException("Please supply phone number, short code and keyword")
        End If
        Dim data_ As New Hashtable()
        data_("username") = _username
        data_("phoneNumber") = phoneNumber_
        data_("shortCode") = shortCode_
        data_("keyword") = keyword_
        Dim urlString As String = SUBSCRIPTION_URLString & "/delete"
        Dim response As String = sendPostRequest(data_, urlString)
        If responseCode = CInt(HttpStatusCode.Created) Then

            Dim json As Object = serializer.Deserialize(Of Object)(response)
            Return json
        End If
        Throw New AfricasTalkingGatewayException(response)
    End Function

    Public Function [call](ByVal from_ As String, ByVal to_ As String) As Object
        Dim data As New Hashtable()
        data("username") = _username
        data("from") = from_
        data("to") = to_

        Dim urlString As String = VOICE_URLString & "/call"
        Dim response As String = sendPostRequest(data, urlString)

        Dim json As Object = serializer.Deserialize(Of Object)(response)
        If CStr(json("errorMessage")) = "None" Then
            Return json("entries")
        End If
        Throw New AfricasTalkingGatewayException(json("errorMessage"))
    End Function

    Public Function getNumQueuedCalls(ByVal phoneNumber_ As String, Optional ByVal queueName_ As String = Nothing) As Integer
        Dim data As New Hashtable()
        data("username") = _username
        data("phoneNumbers") = phoneNumber_
        If queueName_ IsNot Nothing Then
            data("queueName") = queueName_
        End If

        Dim urlString As String = VOICE_URLString & "/queueStatus"
        Dim response As String = sendPostRequest(data, urlString)
        Dim json As Object = serializer.Deserialize(Of Object)(response)
        If CStr(json("errorMessage")) = "None" Then
            Return json("entries")
        End If
        Throw New AfricasTalkingGatewayException(json("errorMessage"))
    End Function

    Public Sub uploadMediaFile(ByVal url_ As String, ByVal phoneNumber_ As String)
        Dim data As New Hashtable()
        data("username") = _username
        data("url") = url_
        data("phoneNumber") = phoneNumber_

        Dim urlString As String = VOICE_URLString & "/mediaUpload"
        sendPostRequest(data, urlString)
    End Sub

    Public Function sendAirtime(ByVal recipients_ As ArrayList) As Object
        Dim urlString As String = AIRTIME_URLString & "/send"
        Dim recipients As String = (New JavaScriptSerializer()).Serialize(recipients_)
        Dim data As New Hashtable()
        data("username") = _username
        data("recipients") = recipients
        Dim response As String = sendPostRequest(data, urlString)
        If responseCode = CInt(HttpStatusCode.Created) Then
            Dim json As Object = serializer.Deserialize(Of Object)(response)
            If json("responses").Count > 0 Then
                Return json("responses")
            End If
            Throw New AfricasTalkingGatewayException(json("errorMessage"))
        End If
        Throw New AfricasTalkingGatewayException(response)
    End Function

    Public Function getUserData() As Object
        Dim urlString As String = USERDATA_URLString & "?username=" & _username
        Dim response As String = sendGetRequest(urlString)
        If responseCode = CInt(HttpStatusCode.OK) Then
            Dim json As Object = serializer.Deserialize(Of Object)(response)
            Return json("UserData")
        End If
        Throw New AfricasTalkingGatewayException(response)
    End Function





    Private Function sendPostRequest(ByVal dataMap_ As Hashtable, ByVal urlString_ As String) As String
        Try
            Dim dataStr As String = ""
            For Each key As String In dataMap_.Keys
                If dataStr.Length > 0 Then
                    dataStr &= "&"
                End If
                Dim value As String = DirectCast(dataMap_(key), String)
                dataStr &= HttpUtility.UrlEncode(key, Encoding.UTF8)
                dataStr &= "=" & HttpUtility.UrlEncode(value, Encoding.UTF8)
            Next key

            Dim byteArray() As Byte = Encoding.UTF8.GetBytes(dataStr)

            System.Net.ServicePointManager.ServerCertificateValidationCallback = AddressOf RemoteCertificateValidationCallback
            Dim webRequest As HttpWebRequest = CType(System.Net.WebRequest.Create(urlString_), HttpWebRequest)

            webRequest.Method = "POST"
            webRequest.ContentType = "application/x-www-form-urlencoded"
            webRequest.ContentLength = byteArray.Length
            webRequest.Accept = "application/json"

            webRequest.Headers.Add("apiKey", _apiKey)

            Dim webpageStream As Stream = webRequest.GetRequestStream()
            webpageStream.Write(byteArray, 0, byteArray.Length)
            webpageStream.Close()

            Dim httpResponse As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
            responseCode = CInt(httpResponse.StatusCode)
            Dim webpageReader As New StreamReader(httpResponse.GetResponseStream())
            Dim response As String = webpageReader.ReadToEnd()

            If DEBUG Then
                Console.WriteLine("Full response: " & response)
            End If

            Return response

        Catch ex As WebException
            If ex.Response Is Nothing Then
                Throw New AfricasTalkingGatewayException(ex.Message)
            End If
            Using stream = ex.Response.GetResponseStream()
                Using reader = New StreamReader(stream)
                    Dim response As String = reader.ReadToEnd()

                    If DEBUG Then
                        Console.WriteLine("Full response: " & response)
                    End If

                    Return response
                End Using
            End Using

        Catch ex As AfricasTalkingGatewayException
            Throw ex
        End Try
    End Function

    Private Function sendGetRequest(ByVal urlString_ As String) As String
        Try
            System.Net.ServicePointManager.ServerCertificateValidationCallback = AddressOf RemoteCertificateValidationCallback

            Dim webRequest As HttpWebRequest = CType(System.Net.WebRequest.Create(urlString_), HttpWebRequest)
            webRequest.Method = "GET"
            webRequest.Accept = "application/json"
            webRequest.Headers.Add("apiKey", _apiKey)

            Dim httpResponse As HttpWebResponse = CType(webRequest.GetResponse(), HttpWebResponse)
            responseCode = CInt(httpResponse.StatusCode)
            Dim webpageReader As New StreamReader(httpResponse.GetResponseStream())

            Dim response As String = webpageReader.ReadToEnd()

            If DEBUG Then
                Console.WriteLine("Full response: " & response)
            End If

            Return response


        Catch ex As WebException
            If ex.Response Is Nothing Then
                Throw New AfricasTalkingGatewayException(ex.Message)
            End If

            Using stream = ex.Response.GetResponseStream()
                Using reader = New StreamReader(stream)
                    Dim response As String = reader.ReadToEnd()

                    If DEBUG Then
                        Console.WriteLine("Full response: " & response)
                    End If

                    Return response
                End Using
            End Using

        Catch ex As AfricasTalkingGatewayException
            Throw ex
        End Try
    End Function

    Private Function RemoteCertificateValidationCallback(ByVal sender_ As Object, ByVal certificate As System.Security.Cryptography.X509Certificates.X509Certificate, ByVal chain_ As System.Security.Cryptography.X509Certificates.X509Chain, ByVal errors_ As System.Net.Security.SslPolicyErrors) As Boolean
        Return True
    End Function

    Private ReadOnly Property ApiHost() As String
        Get
            Return If(String.ReferenceEquals(_environment, "sandbox"), "https://api.sandbox.africastalking.com", "https://api.africastalking.com")
        End Get
    End Property

    Private ReadOnly Property PaymentHost() As String
        Get
            Return If(String.ReferenceEquals(_environment, "sandbox"), "https://payments.sandbox.africastalking.com", "https://payments.africastalking.com")
        End Get
    End Property



    Private ReadOnly Property SMS_URLString() As String
        Get
            Return ApiHost & "/version1/messaging"
        End Get
    End Property
    Private ReadOnly Property VOICE_URLString() As String
        Get
            Return If(String.ReferenceEquals(_environment, "sandbox"), "https://voice.sandbox.africastalking.com", "https://voice.africastalking.com")
        End Get
    End Property

    Private ReadOnly Property SUBSCRIPTION_URLString() As String
        Get
            Return ApiHost & "/version1/subscription"
        End Get
    End Property

    Private ReadOnly Property USERDATA_URLString() As String
        Get
            Return ApiHost & "/version1/user"
        End Get
    End Property

    Private ReadOnly Property AIRTIME_URLString() As String
        Get
            Return ApiHost & "/version1/airtime"
        End Get
    End Property

    Private ReadOnly Property MobilePaymePAYMENTS_URLStringntCheckoutUrl() As String
        Get
            Return PaymentHost & "/mobile/checkout/request"
        End Get
    End Property

    Private ReadOnly Property PAYMENTS_B2B_URLString() As String
        Get
            Return PaymentHost & "/mobile/b2b/request"
        End Get
    End Property
    Private ReadOnly Property PaymentsUrl As String
        Get
            Return Me.PaymentHost & "/mobile/checkout/request"
        End Get
    End Property

    Private ReadOnly Property B2BPaymentsUrl As String
        Get
            Return Me.PaymentHost & "/mobile/b2b/request"
        End Get
    End Property

    Private ReadOnly Property B2CPaymentsUrl As String
        Get
            Return Me.PaymentHost & "/mobile/b2c/request"
        End Get
    End Property


    Private Shared Function IsValidTransactionId(ByVal transactionId As String) As Boolean
        Return Regex.Match(transactionId, "^ATPid_.*$").Success AndAlso transactionId.Length > 7
    End Function

    Private Shared Function IsValidToken(ByVal token As String) As Boolean
        Return Regex.Match(token, "^CkTkn_.*$").Success AndAlso token.Length > 7
    End Function


    Private Function Post(ByVal requestBody As RequestBody, ByVal url As String) As DataResult
        Dim nhttpClient As New Http.HttpClient
        nhttpClient.DefaultRequestHeaders.Add("apikey", Me._apiKey)
        Dim res = nhttpClient.PostAsJsonAsync(url, requestBody).Result
        res.EnsureSuccessStatusCode()
        Dim result = res.Content.ReadAsAsync(Of DataResult)()
        Return result.Result
    End Function





    Shared Sub C2BPAyment(Product As String, Price As Double, customerNumber As String)


        Dim username As String = "cfpro"
        Dim apiKey As String = "46bcb4fd894efde2bfea29a5b6eb202b4a16ade3702e0238a46ea270d4a71e72"
        Dim sender As String = "CFPRO"


        Dim productName = Product
        Dim phoneNumber = customerNumber
        Dim amount As Integer = Price
        Dim currency = "KES"


        Dim channel = "mychannel"
        Dim metadata = New Dictionary(Of String, String) From {
            {"reason", "stuff"}
        }
        Dim Gateway = New AfricasTalkingGateway(username, apiKey)

        Try
            Dim checkout As C2BDataResults = Gateway.Checkout(productName, phoneNumber, currency, amount, channel, metadata)
            Console.WriteLine(checkout.Status)
        Catch e As AfricasTalkingGatewayException
            Console.WriteLine("We ran into problems: " & e.Message)
        End Try
    End Sub

    Shared Sub B2CPAyment()
        Dim username As String = "cfpro"
        Dim apiKey As String = "46bcb4fd894efde2bfea29a5b6eb202b4a16ade3702e0238a46ea270d4a71e72"
        Dim sender As String = "CFPRO"

        Dim productName As String = "coolproduct"
        Dim currencyCode As String = "KES"
        Dim hero1PhoneNum As String = "+254xxxxxxx"
        Dim hero2PhoneNum As String = "+254xxxxxxx"
        Dim hero1Name As String = "Batman"
        Dim hero2Name As String = "Superman"
        Dim hero1amount As Decimal = 15000D
        Dim hero2amount As Decimal = 54000D

        Dim gateway = New AfricasTalkingGateway(username, apiKey)
        Dim hero1 = New MobileB2CRecepient(hero1Name, hero1PhoneNum, currencyCode, hero1amount)
        hero1.AddMetadata("reason", "Torn Suit")

        Dim hero2 = New MobileB2CRecepient(hero2Name, hero2PhoneNum, currencyCode, hero2amount)
        hero2.AddMetadata("reason", "Itchy Suit")

        Dim heroes As IList(Of MobileB2CRecepient) = New List(Of MobileB2CRecepient) From {
            hero1,
            hero2
        }

        Try
            Dim response = gateway.MobileB2C(productName, heroes)
            Console.WriteLine(heroes)
            Console.WriteLine(response)
        Catch e As AfricasTalkingGatewayException
            Console.WriteLine("We ran into problems: " & e.StackTrace + e.Message)
        End Try

        Console.ReadLine()
    End Sub


    Public Function MobileB2C(ByVal productName As String, ByVal recipients As IEnumerable(Of MobileB2CRecepient)) As System.Object
        If productName.Length = 0 Then
            Throw New AfricasTalkingGatewayException("Malformed product name")
        End If

        Dim requestBody = New RequestBody With {
        .productName = productName,
        .username = Me._username,
        .recepients = recipients.ToList()
    }
        Dim response = Me.Post(requestBody, Me.B2CPaymentsUrl)
        Return response
    End Function

    Private Shared Function IsValidSIPAddress(ByVal address As String()) As Boolean
        Dim isValidSIP As Boolean = True

        For Each _address As String In address
            isValidSIP = Regex.Match(_address, "^(?P<agent>[\w\.]+\@[a-z]\w\.sip\.africastalking\.com)$").Success
        Next

        Return isValidSIP
    End Function

    Private Function PostAsJson(ByVal dataMap As CheckOutData, ByVal url As String) As C2BDataResults
        Dim client As New Http.HttpClient
        client.DefaultRequestHeaders.Add("apiKey", Me._apiKey)
        Dim result = client.PostAsJsonAsync(url, dataMap).Result
        result.EnsureSuccessStatusCode()
        Dim stringResult = result.Content.ReadAsAsync(Of C2BDataResults)()
        Return stringResult.Result
    End Function


    Public Function Checkout(ByVal productName As String, ByVal phoneNumber As String, ByVal currencyCode As String, ByVal amount As Decimal, ByVal providerChannel As String, ByVal Optional metadata As Dictionary(Of String, String) = Nothing) As System.Object
        Dim symbol As String = "KES"
        Dim numbers As String() = phoneNumber.Split(separator:={","c}, options:=StringSplitOptions.RemoveEmptyEntries)

        If productName.Length = 0 OrElse providerChannel.Length = 0 Then
            Throw New AfricasTalkingGatewayException("Missing or malformed arguments, or invalid currency symbol or phonenumber")
        End If

        Dim nCheckout = New CheckOutData With {
        .username = Me._username,
        .productName = productName,
        .phoneNumber = phoneNumber,
        .currencyCode = currencyCode,
        .amount = amount,
        .providerChannel = providerChannel
    }

        If metadata IsNot Nothing Then
            nCheckout.metadata = metadata
        End If

        Try
            Dim checkoutResponse = Me.PostAsJson(nCheckout, Me.PaymentsUrl)
            Return checkoutResponse
        Catch e As Exception
            Throw New AfricasTalkingGatewayException(e.StackTrace + e.Message + e.Source)
        End Try
    End Function



End Class


Public Class MobileB2CRecepient
    <JsonProperty("name")>
    Public Property Name As String
    <JsonProperty("phoneNumber")>
    Public Property PhoneNumber As String
    <JsonProperty("currencyCode")>
    Public Property CurrencyCode As String
    <JsonProperty("amount")>
    Public Property Amount As Decimal
    <JsonProperty("metadata")>
    Public Property Metadata As Dictionary(Of String, String)

    Public Sub New(ByVal name As String, ByVal phoneNumber As String, ByVal currencyCode As String, ByVal amount As Decimal)
        name = name
        phoneNumber = phoneNumber
        currencyCode = currencyCode
        amount = amount
        Metadata = New Dictionary(Of String, String)()
    End Sub

    Public Sub AddMetadata(ByVal key As String, ByVal value As String)
        Me.Metadata.Add(key, value)
    End Sub

    Public Function ToJson() As String
        Dim json = JsonConvert.SerializeObject(Me)
        Return json
    End Function
End Class

Public Class AfricasTalkingGatewayException
    Inherits Exception

    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
End Class

Public Class CheckOutData
    Public Property username As String
    Public Property productName As String
    Public Property phoneNumber As String
    Public Property currencyCode As String
    Public Property amount As Decimal
    Public Property providerChannel As String
    Public Property metadata As Dictionary(Of String, String)
End Class
Public Class C2BDataResults
    <JsonProperty("providerChannel")>
    Public Property ProviderChannel As String
    <JsonProperty("description")>
    Public Property Description As String
    <JsonProperty("transactionId")>
    Public Property TransactionId As String
    <JsonProperty("status")>
    Public Property Status As String

    Public Overrides Function ToString() As String
        Dim result = JsonConvert.SerializeObject(Me)
        Return result
    End Function
End Class

Public Class DataResult
    <JsonProperty("numQueued")>
    Public Property NumQueued As Integer
    <JsonProperty("entries")>
    Public Property Entries As IList()
    <JsonProperty("totalValue")>
    Public Property TotalValue As String
    <JsonProperty("totalTransactionFee")>
    Public Property TotalTransactionFee As String

    Public Overrides Function ToString() As String
        Dim result = JsonConvert.SerializeObject(Me)
        Return result
    End Function
End Class


Friend Class RequestBody
    Public Sub New()
        recepients = New List(Of MobileB2CRecepient)()
    End Sub

    <JsonProperty("username")>
    Public Property username As String
    <JsonProperty("productName")>
    Public Property productName As String
    <JsonProperty("recipients")>
    Public Property recepients As List(Of MobileB2CRecepient)

    Public Overrides Function ToString() As String
        Dim json = JsonConvert.SerializeObject(Me)
        Return json
    End Function
End Class
