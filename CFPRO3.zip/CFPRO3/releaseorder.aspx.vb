﻿Imports System.Drawing
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports System.IO

Public Class releaseorder
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Call clsAuth.UserLogin(LabelCSDID.Text, LabelCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True)

            Call LoadCFSs()
            Call LoadSignatories()
            Call LoadRecordIDs()
            ComboRecordID.SelectedIndex = ComboRecordID.Items.Count - 1
            Call LoadReleaseOrder(ComboRecordID.SelectedItem.Text)

            If Request.QueryString("releaseOrderId") IsNot Nothing Then
                ComboRecordID.SelectedValue = Request.QueryString("releaseOrderId")
                Call LoadReleaseOrder(ComboRecordID.SelectedItem.Text)
            End If

            HyperLinkStart.NavigateUrl = "cfagentdashboard.aspx"
            HyperLinkStart1.NavigateUrl = "impoterdashboard.aspx"

            If Request.Cookies("UserType").Value = "cfagent" Then
                PanelTopMenu.Visible = True
                PanelImpoterMenu.Visible = False
            Else
                PanelTopMenu.Visible = False
                PanelImpoterMenu.Visible = True
            End If

        End If
    End Sub

    Private Sub LoadCFSs()
        Try
            Dim sqlstr As String =
            "Select CFS " &
            "From CFS " &
            "Order By ID Asc; "

            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow
            Dim a As Integer
            Dim b As Integer = -1


            ComboCFS.Items.Clear()

            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    ComboCFS.Items.Add(drow("CFS"))
                Next
            End If
            ComboCFS.Items.Add("")
        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try
    End Sub

    'Private Sub LoadROProgress(ReleaseOrderId As String)
    '    Try

    '        Dim sqlstr As String =
    '        "Select ReleaseOrderID,Status," &
    '        "ReleaseOrderProgress.UserID,StaffName," &
    '        "StatusDate,ReleaseOrderStatusID, ReleaseOrderProgress.ID " &
    '        "From ReleaseOrderProgress,Staff " &
    '        "Where ReleaseOrderId = '" & ReleaseOrderId & "' " &
    '        "And Staff.UserID = ReleaseOrderProgress.UserID " &
    '        "Order By StatusDate Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim sqlstr1 As String =
    '          "Select StatusID,Status " &
    '          "From ReleaseOrderStatuses "

    '        Dim tmptable1 As New DataTable()
    '        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

    '        Dim dv As New DataView(tmptable1)

    '        Dim sqlstr2 As String =
    '         "Select UserCSDID,CFPROuserID " &
    '         "FROM CFPROAccountConnect " &
    '         "Where  CFPROID = '" & LabelCFPROID.Text & "' "


    '        Dim tmptable2 As New DataTable
    '        Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

    '        Dim dv1 As New DataView(tmptable2)


    '        Dim a As Integer
    '        Dim col1 As New DataColumn("Date1", Type.GetType("System.String"))
    '        Dim col2 As New DataColumn("UpdateCount", Type.GetType("System.String"))
    '        Dim col3 As New DataColumn("UserImageURL", Type.GetType("System.String"))
    '        Dim col4 As New DataColumn("ReleaseOrderStatus", Type.GetType("System.String"))
    '        Dim col5 As New DataColumn("ShowReleaseOrderStatus", Type.GetType("System.Boolean"))
    '        Dim col6 As New DataColumn("UserIDImageURL", Type.GetType("System.String"))

    '        tmptable.Columns.Add(col1)
    '        tmptable.Columns.Add(col2)
    '        tmptable.Columns.Add(col3)
    '        tmptable.Columns.Add(col4)
    '        tmptable.Columns.Add(col5)
    '        tmptable.Columns.Add(col6)

    '        If tmptable.Rows.Count = 0 Then
    '            Dim drow As DataRow
    '            drow = tmptable.NewRow
    '            drow("Status") = ""
    '            tmptable.Rows.Add(drow)
    '        End If


    '        Dim UserImageURL As String = ""
    '        For Each drow In tmptable.Rows
    '            Call clsData.NullChecker(tmptable, a)
    '            drow("Date1") = Format(drow("Date"), "dd MMM yyyy hh:mm tt")


    '            dv1.RowFilter = "CFPROuserID = '" & drow("UserID") & "' "

    '            If dv1.Count > 0 Then
    '                If File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".png")) Then
    '                    UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".png"
    '                ElseIf File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".jpg")) Then
    '                    UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".jpg"
    '                Else
    '                    UserImageURL = "imageplaceholder.png"
    '                End If
    '            Else
    '                UserImageURL = "imageplaceholder.png"
    '            End If


    '            drow("UserImageURL") = UserImageURL
    '            drow("UserIDImageURL") = drow("UserID") & "|" & drow("UserImageURL")

    '            dv.RowFilter = "StatusID = '" & drow("ReleaseOrderStatusID") & "' "

    '            If dv.Count > 0 Then
    '                drow("ReleaseOrderStatus") = "- R. O. Status: " & dv(0)("Status")
    '            End If

    '            a = a + 1

    '            drow("UpdateCount") = a & "."
    '        Next

    '        If tmptable.Rows.Count < 9 Then
    '            PanelUpdates.Height = Nothing
    '        Else
    '            PanelUpdates.Height = 600
    '        End If

    '        DataList1.DataSource = tmptable
    '        DataList1.DataBind()

    '        LabelUpdateCount.Text = "R.O Status Updates - " & tmptable.Rows.Count

    '        LabelMessage1.Text = ""
    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try


    'End Sub

    Private Sub LoadSignatories()
        Try
            Dim sqlstr As String =
            "Select Agent " &
            "From Agents " &
            "Order By ID Asc; "

            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow
            Dim a As Integer
            Dim b As Integer = -1


            ComboSignatory.Items.Clear()

            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    ComboSignatory.Items.Add(drow("Agent"))
                Next
            End If
            ComboSignatory.Items.Add("")
        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try
    End Sub

    Private Sub LoadRecordIDs()
        Try

            Dim UserID As String = ""

            If Not Request.Cookies("UserID") Is Nothing Then
                UserID = Server.HtmlEncode(Request.Cookies("UserID").Value)
            End If

            Dim sqlstr As String =
            "Select ReleaseOrderId " &
            "From ReleaseOrders " &
            "Order By ID Asc; "

            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow
            Dim a As Integer
            Dim b As Integer = -1


            ComboRecordID.Items.Clear()

            Dim RecordID As String = Request.QueryString("recordid")

            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    ComboRecordID.Items.Add(drow("ReleaseOrderId"))
                    If Len(RecordID) > 0 Then
                        b = a
                    End If
                    a = a + 1
                Next

                If Len(RecordID) = 0 Then
                    RecordID = drow("ReleaseOrderId")
                End If

                Call LoadReleaseOrder(RecordID)
            End If

            If b > 0 Then
                LabelEntryCount.Text = "Release Order: " & b & " of " & tmptable.Rows.Count
            Else
                LabelEntryCount.Text = "Release Order: " & a & " of " & tmptable.Rows.Count
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try

    End Sub
    Private Sub LoadReleaseOrder(ByVal RecordId As String)
        Try
            Dim sqlstr As String =
             "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFS,CFSID,ReleaseOrderStatus, ID " &
             "From ReleaseOrders " &
             "Where ReleaseOrderId= '" & RecordId & "'"

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim Drow As DataRow
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Drow = tmptable.Rows(0)
                TextImporter.Text = Drow("Importer")
                TextBillofLadingNo.Text = Drow("BillOfLadingNo")
                TextCustomsAssignNo.Text = Drow("CustomsAssignNo")
                TextImportLicenceNo.Text = Drow("ImportLicenceNo")
                TextManifestPage.Text = Drow("ManifestPage")
                TextManifestDate.Text = Format(Drow("ManifestDate"), "dd MMM yyyy")
                TextShippingLine.Text = Drow("ShippingLine")
                TextCountryofOrigin.Text = Drow("CountryOfOrigin")
                TextCountryofDestination.Text = Drow("CountryOfDestination")
                TextAcceptedValue.Text = Drow("AcceptedValue")
                TextValueinKES.Text = Drow("ValueinKES")
                TextValueinWords.Text = Drow("ValueInWords")
                TextSupplier.Text = Drow("SupplierName")
                TextBuyer.Text = Drow("Buyer")
                ComboDisposalCode.Text = Drow("DisposalCode")
                TextRotationNo.Text = Drow("RotationNo")
                TextDateofReport.Text = Format(Drow("DateOfReport"), "dd MMM yyyy")
                TextVesselName.Text = Drow("VesselName")
                TextReferenceNo.Text = Drow("ReferenceNo")
                TextPortofLoading.Text = Drow("PortOfLoading")
                TextPortofDischarge.Text = Drow("PortofDischarge")
                TextPortAccountNo.Text = Drow("PortAccountNo")
                TextTotalNoPackageinWords.Text = Drow("KindofPackage")
                If ComboSignatory.Items.FindByText(ComboSignatory.Text = Drow("Signatory")) Is Nothing Then
                    ComboSignatory.Items.Add(Drow("Signatory"))
                End If
                ComboSignatory.Text = Drow("Signatory")
                TextReleaseOrderDate.Text = Format(Drow("ReleaseOrderDate"), "dd MMM yyyy")
                ComboCFS.Text = Drow("CFS")
                TextSerialNo.Text = Drow("SerialNo")
                LabelEntryCount.Text = "Release Order " & ComboRecordID.SelectedIndex + 1 & " of " & ComboRecordID.Items.Count
                'LinkStatus.Text = Drow("ReleaseOrderStatus")

                Call LoadReleaseOrderGoods(RecordId)
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try
    End Sub

    Private Sub LoadReleaseOrderGoods(RecordId As String)
        Try
            Dim sqlstr As String =
            "Select	UserID,RecordId," &
            "RecordID1, MarksNos,RecordDate, " &
            "DescriptionofGoods,[Weight]," &
            "CubicMeters,SeaFreightCharges,Id " &
            "From ReleaseOrderGoods " &
            "Where RecordId ='" & RecordId & "'"

            Dim tmptable As New DataTable


            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("NavCol", Type.GetType("System.String"))
            Dim col1 As New DataColumn("RecordDate1", Type.GetType("System.String"))
            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)

            Dim a As Integer
            Dim drow As DataRow
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("RecordDate1") = Format(drow("RecordDate"), "dd MMM yyyy")
                drow("NavCol") = "releaseordergoodsaddedit.aspx?recordid=" & drow("RecordID")
                a = a + 1
            Next

            LabelEntryCount.Text = "RO Goods  - " & tmptable.Rows.Count

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                tmptable.Rows.Add(drow)
                Call clsData.NullChecker(tmptable, 0)
                drow("NavCol") = "#"
            End If

            'GridReleaseOrderGoods.DataSource = tmptable
            'GridReleaseOrderGoods.DataBind()

            'GridReleaseOrderGoods.Height = 25 + tmptable.Rows.Count * 23

            If tmptable.Rows.Count >= 15 Then
                'LabelROGoodsCount.Visible = True
                LabelEntryCount.Text = "Release Order Goods - " & tmptable.Rows.Count
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            'MsgBox(exp.Message, , "LoadROGoods")
        End Try
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles ButtonNewReleaseOrder.Click
        Call NewReleaseOrder()
    End Sub

    Private Sub NewReleaseOrder()

        Try
            Call SaveReleaseOrder()

            Dim UserID As String = ""
            If Not Request.Cookies("UserID") Is Nothing Then
                UserID = Server.HtmlEncode(Request.Cookies("UserID").Value)
            End If


            Dim sqlstr As String =
            "Select Top 1 Id " &
            "From ReleaseOrders " &
            "Order By Id Desc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                a = Val(drow("Id")) + 1
            End If

            Dim RecordId As String = Format(a, "000000000#")

            Dim sqlstr1 As String =
                       "Select CSDID,ReleaseOrderId," &
                       "ReleaseOrderDate,RecordDate, ID " &
                       "From ReleaseOrders " &
                       "Where ReleaseOrderId = '" & RecordId & "'"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim drow1 As DataRow = tmptable1.NewRow
            drow1("CSDID") = UserID
            drow1("ReleaseOrderId") = RecordId
            drow1("ReleaseOrderDate") = Format(Now, "dd MMM yyyy HH:mm")
            drow1("RecordDate") = Format(Now, "dd MMM yyyy HH:mm")
            tmptable1.Rows.Add(drow1)


            Call clsData.SaveData("ReleaseOrders", tmptable1, sqlstr1, False, clsData.constr)
            tmptable1.AcceptChanges()

            Call LoadRecordIDs()
            ComboRecordID.SelectedItem.Text = RecordId
            Call LoadReleaseOrder(RecordId)

            LabelMessage.Text = "New Record Added, Proceed."
            Panel1.BackColor = Drawing.Color.FromArgb(213, 255, 191)
        Catch exp As Exception
            LabelMessage.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try






        'Try
        '    Call SaveReleaseOrder()

        '    Dim UserID As String = ""
        '    If Not Request.Cookies("UserID") Is Nothing Then
        '        UserID = Server.HtmlEncode(Request.Cookies("UserID").Value)
        '    End If

        '    Dim RecordID As String = Format(clsSubs.GetRecordID("ReleaseOrders", "ReleaseOrderID", UserID), "00000#")

        '    Dim sqlstr As String =
        '           "Select UserID,RecordID," &
        '           "ReleaseOrders,RecordDate, ID " &
        '           "From ReleaseOrders " &
        '           "Where RecordID = '" & RecordID & "'"

        '    Dim tmptable1 As New DataTable()
        '    Call clsData.TableData(sqlstr, tmptable1, clsData.constr)

        '    Dim drow As DataRow = tmptable1.NewRow
        '    drow("UserID") = UserID
        '    drow("RecordID") = RecordID
        '    drow("ReleaseOrderDate") = Format(Now, "dd MMM yyyy HH:mm")
        '    drow("RecordDate") = Format(Now, "dd MMM yyyy HH:mm")
        '    tmptable1.Rows.Add(drow)


        '    Call clsData.SaveData("ReleaseOrders", tmptable1, sqlstr, False, clsData.constr)
        '    tmptable1.AcceptChanges()

        '    Call LoadReleaseOrder(RecordID)

        '    LabelMessage.Text = "New Record Added, Proceed."
        '    Panel1.BackColor = Drawing.Color.FromArgb(213, 255, 191)

        'Catch exp As Exception
        '    LabelMessage1.Text = exp.Message
        '    Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        'End Try

    End Sub

    Protected Sub Button13_Click(sender As Object, e As EventArgs) Handles ButtonCopyToNew.Click
        Call CopyToNew()
    End Sub

    Private Sub CopyToNew()
        Try
            Call SaveReleaseOrder()

            Dim UserID As String = ""
            If Not Request.Cookies("UserID") Is Nothing Then
                UserID = Server.HtmlEncode(Request.Cookies("UserID").Value)
            End If

            Dim RecordID As String = Format(clsSubs.GetRecordID("ReleaseOrders", "ReleaseOrderRecordIDCounter", UserID), "00000#")

            Dim sqlstr As String =
                   "Select UserID,RecordID," &
                   "ReleaseOrders,RecordDate, ID " &
                   "From ReleaseOrders " &
                   "Where RecordID = '" & RecordID & "'"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr, tmptable1, clsData.constr)

            Dim drow As DataRow = tmptable1.NewRow
            drow("UserID") = UserID
            drow("RecordID") = RecordID
            drow("ReleaseOrderDate") = Format(Now, "dd MMM yyyy HH:mm")
            drow("RecordDate") = Format(Now, "dd MMM yyyy HH:mm")
            tmptable1.Rows.Add(drow)


            Call clsData.SaveData("ReleaseOrders", tmptable1, sqlstr, False, clsData.constr)
            tmptable1.AcceptChanges()

            Call LoadReleaseOrder(RecordID)

            LabelMessage.Text = "New Record Added, Proceed."
            Panel1.BackColor = Drawing.Color.FromArgb(213, 255, 191)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try
    End Sub


    Private Sub RoundOff()
        Try
            TextValueinKES.Text = Math.Round(Val(TextAcceptedValue.Text + 0.5))
            TextValueinWords.Text = clsSubs.AmountInWords(TextValueinKES.Text)
        Catch exp As Exception
            MsgBox(exp.Message, , "RoundOff")
        End Try
    End Sub

    Private Sub SaveReleaseOrder()
        Try
            Dim sqlstr As String =
             "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFS,CFSID, ID " &
             "From ReleaseOrders " &
             "Where ReleaseOrderId= '" & ComboRecordID.Text & "'"

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                drow = tmptable.Rows(0)
                drow("SerialNo") = TextSerialNo.Text
                drow("Importer") = TextImporter.Text
                drow("BillOfLadingNo") = TextBillofLadingNo.Text
                drow("CustomsAssignNo") = TextCustomsAssignNo.Text
                drow("ImportLicenceNo") = TextImportLicenceNo.Text
                drow("ManifestPage") = TextManifestPage.Text
                drow("ManifestDate") = TextManifestDate.Text
                drow("ShippingLine") = TextShippingLine.Text
                drow("CountryOfOrigin") = TextCountryofOrigin.Text
                drow("CountryOfDestination") = TextCountryofDestination.Text
                drow("AcceptedValue") = TextAcceptedValue.Text
                drow("ValueInWords") = TextValueinWords.Text
                drow("ValueinKES") = TextValueinKES.Text
                drow("SupplierName") = TextSupplier.Text
                drow("Buyer") = TextBuyer.Text
                drow("DisposalCode") = ComboDisposalCode.Text
                drow("RotationNo") = TextRotationNo.Text
                drow("DateOfReport") = TextDateofReport.Text
                drow("VesselName") = TextVesselName.Text
                drow("ReferenceNo") = TextReferenceNo.Text
                drow("PortOfLoading") = TextPortofLoading.Text
                drow("PortofDischarge") = TextPortofDischarge.Text
                drow("PortAccountNo") = TextPortAccountNo.Text
                drow("KindofPackage") = TextTotalNoPackageinWords.Text
                drow("Signatory") = ComboSignatory.Text
                drow("ReleaseOrderDate") = TextReleaseOrderDate.Text
                drow("CFS") = ComboCFS.Text

                clsData.SaveData("ReleaseOrders", tmptable, sqlstr, False, clsData.constr)

                LabelMessage.Text = "Release Order Informations Saved Successfully."
                Panel1.BackColor = Drawing.Color.FromArgb(213, 255, 191)
            End If


        Catch exp As Exception
            LabelMessage.Text = exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try
    End Sub


    Private Function ExtractFromPDFEntry(PdfFileName As String) As String
        Dim oReader As New iTextSharp.text.pdf.PdfReader(PdfFileName)

        Dim sOut = ""

        For i = 1 To oReader.NumberOfPages
            Dim its As New iTextSharp.text.pdf.parser.SimpleTextExtractionStrategy
            sOut &= iTextSharp.text.pdf.parser.PdfTextExtractor.GetTextFromPage(oReader, i, its)
        Next

        Return sOut
    End Function
    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Protected Sub ButtonSaveReleaseOrder_Click(sender As Object, e As EventArgs) Handles ButtonSaveReleaseOrder.Click
        Call SaveReleaseOrder()
    End Sub

    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call LoadReleaseOrder(ComboRecordID.SelectedItem.Text)
    End Sub

    Protected Sub ButtonDownloadPDF_Click(sender As Object, e As EventArgs) Handles ButtonDownloadPDF.Click
        Call DownloadReleaseOrderPDF("Release Order " & Format(Now, "dd MMM yyyy hh:mm:ss tt") & ".pdf")
    End Sub

    Private Sub DownloadReleaseOrderPDF(fileName As String)
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"
        Response.AddHeader("Content-Disposition", "attachment; filename=" & fileName)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Buffer = True
        Response.BinaryWrite(clsReleaseOrderPDF.ReleaseOrderDoc(fileName, ComboRecordID.Text, LabelUser.Text))
        Response.End()
        Response.Flush()
        Response.Clear()
        Response.Close()

    End Sub
    Private Sub EmailReleaseOrderPDF(fileName As String)
        Try
            Dim msgAttachment As Byte() = clsReleaseOrderPDF.ReleaseOrderEmail(fileName, ComboRecordID.Text, LabelUser.Text)
            Dim msgSender As String = "wssilverpg@gmail.com"
            Dim msgReceiver As String = "wssilverpg@gmail.com"
            Dim msgSubject As String = "RELEASE ORDER"
            Dim msgBody As String = "Attached please a copy of the release order you requested for."

            Response.Redirect("mail1.aspx?msgSender=" & msgSender & "&msgReceiver=" & msgReceiver & "&msgSubject=" & msgSubject & "&msgBody=" & msgBody &
                              "&itemId=" & ComboRecordID.Text & "&userName=" & LabelUser.Text & "&attachmentName=" & fileName)
            'LabelMessage.BackColor = Color.Aqua
            'LabelMessage.Text = "Email sent successfully!"
        Catch ex As Exception
            LabelMessage.Text = "failure" & ex.Message
        End Try
    End Sub

    Private Sub DownloadPDF1()

        Try
            ''//The file that we are creating
            Dim documentPath As String = Server.MapPath(".") & "\reportsdocs\RO_" & Format(Now, "dd_MMM_yyyy_hh_mm_tt") & ".pdf"

            Dim fontpath As String = Server.MapPath(".")
            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath & Convert.ToString("\docfonts\arial.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim font As New iTextSharp.text.Font(customfont, 12)
            customfont = BaseFont.CreateFont(fontpath & Convert.ToString("\docfonts\arial.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim font1 As New iTextSharp.text.Font(customfont, 12)
            customfont = BaseFont.CreateFont(fontpath & Convert.ToString("\docfonts\cour.ttf"), BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim font2 As New iTextSharp.text.Font(customfont, 10)

            ''//Create our file with an exclusive writer lock
            Using FS As New FileStream(documentPath, FileMode.Create, FileAccess.Write, FileShare.None)
                ''//Create our PDF document
                Using Doc As New Document(PageSize.LETTER)
                    ''//Bind our PDF object to the physical file using a PdfWriter
                    Using Writer = PdfWriter.GetInstance(Doc, FS)
                        ''//Open our document for writing
                        Doc.Open()

                        ''//Insert a blank page
                        Doc.NewPage()

                        ''//Add a simple paragraph with text
                        Dim head = New Paragraph(TextImporter.Text, font)
                        head.Alignment = Element.ALIGN_CENTER
                        Doc.Add(head)
                        head = New Paragraph("RELEASE ORDER", font)
                        head.Alignment = Element.ALIGN_CENTER
                        Doc.Add(head)

                        'TABLES

                        Dim table1 = New PdfPTable(1)
                        'table1
                        table1.HorizontalAlignment = Element.ALIGN_LEFT
                        table1.SpacingBefore = 50
                        table1.DefaultCell.Border = 1
                        table1.WidthPercentage = 40
                        Dim cell As New PdfPCell(New Phrase("1. Importers Name Address", font1))
                        ' cell.Border = 1;
                        ' cell.HorizontalAlignment = 1; //0=Left, 1=Centre, 2=Right
                        cell.HorizontalAlignment = Element.ALIGN_CENTER
                        table1.AddCell(cell)
                        Doc.Add(table1)


                        'Doc.Add(New Paragraph("New Paragraph String Here", font1))
                        ''//Close our document
                        Doc.Close()
                    End Using
                End Using
            End Using

            LabelMessage.Text = "Document Saved --> " & documentPath
            Panel1.BackColor = Drawing.Color.FromArgb(213, 255, 191)
        Catch exp As Exception
            LabelMessage.Text = "Error: " & exp.Message
            Panel1.BackColor = Drawing.Color.FromArgb(255, 204, 204)
        End Try

    End Sub

    Protected Sub ButtonROGoods_Click(sender As Object, e As EventArgs) Handles ButtonROGoods.Click
        Call LoadROFunction("releaseorders.aspx?ReleaseOrderId=" & ComboRecordID.Text, "Release Order Goods")
    End Sub
    Private Sub LoadROFunction(funcsource As String, cfFunction As String)
        LabelROFunction.Text = cfFunction
        iframe1.Attributes("src") = funcsource
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonEmailPDF_Click(sender As Object, e As EventArgs) Handles ButtonEmailPDF.Click
        EmailReleaseOrderPDF("Release Order " & Format(Now, "dd MMM yyyy hh:mm:ss tt") & ".pdf")
    End Sub

    Protected Sub ButtonGo0_Click(sender As Object, e As EventArgs) Handles ButtonGo0.Click
        Call LoadAgents()
        ModalPopupExtender2.Show()
    End Sub
    Private Sub LoadAgents()
        Try

            Dim sqlstr As String

            sqlstr = "Select AgentID,Agent From Agents " &
                        "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            GridItems.DataSource = tmptable
            GridItems.DataBind()
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub OnRowDataBound1(sender As Object, e As GridViewRowEventArgs) Handles GridItems.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridItems, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged1(sender As Object, e As EventArgs) Handles GridItems.SelectedIndexChanged
        Dim row As GridViewRow = GridItems.Rows(GridItems.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridItems.Rows.Count - 1
            row = GridItems.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridItems.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        If GridItems.SelectedIndex < 0 Then
            LabelgetItemMessage0.Text = "Please select an agent from the list."
        Else
            TextClearingAgent.Text = GridItems.SelectedRow.Cells(1).Text
        End If
        ModalPopupExtender2.Hide()
    End Sub


    Protected Sub LinkStatus_Click(sender As Object, e As EventArgs) Handles LinkStatus.Click

    End Sub

    Protected Sub ButtonDeleteReleaseOrder0_Click(sender As Object, e As EventArgs) Handles ButtonDeleteReleaseOrder0.Click
        Call LoadROFunction1("releaseorderstatus.aspx?ReleaseOrderId=" & ComboRecordID.Text, "Release Order Status")
    End Sub
    Private Sub LoadROFunction1(funcsource As String, cfFunction As String)
        LabelROFunction.Text = cfFunction
        iframe2.Attributes("src") = funcsource
        ModalPopupExtender5.Show()
    End Sub

    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs)

    End Sub
End Class