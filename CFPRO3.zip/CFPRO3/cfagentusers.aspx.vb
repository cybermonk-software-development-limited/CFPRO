﻿Imports System.Drawing
Public Class cfagentusers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, "", LabelCFAgent.Text, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID

            Call LoadCFAgentUsers(0, CFPROID, "")

            LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

        End If
    End Sub




    Private Sub LoadCFAgentUsers(Rowindex As Integer, CFPROID As String, SearchStr As String)
        Try


            Dim tmpstr As String = ""

            If Not SearchStr = "" Then
                TextUserNames.Text = ""
                TextJobDescription.Text = ""
                TextDepartment.Text = ""
                TextTelephone.Text = ""
                TextEmailAddress.Text = ""


                tmpstr = "And UserNames  Like '%" & Trim(TextSearch.Text) & "'% "
            End If

            Dim sqlstr As String = _
              "Select UserID, UserNames,ID " & _
               "From CFAgentUsers " & _
               "Where CFPROID ='" & CFPROID & "' " &
               tmpstr &
               "Order By ID Desc;"

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                a = a + 1
            Next




            GridCFAgentUsers.DataSource = tmptable
            GridCFAgentUsers.DataBind()

            If GridCFAgentUsers.Rows.Count > 0 Then
                If Rowindex < 0 Then
                    Rowindex = 0
                End If

                If Rowindex > GridCFAgentUsers.Rows.Count - 1 Then
                    Rowindex = GridCFAgentUsers.Rows.Count - 1
                End If
                GridCFAgentUsers.SelectedIndex = Rowindex

                Call ShowUser(GridCFAgentUsers.SelectedValue.ToString, CFPROID)
                Dim row As GridViewRow = GridCFAgentUsers.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If

            If SearchStr = "" Then
                LabelItemsCount.Text = tmptable.Rows.Count & " Users / Staff"
            Else
                LabelItemsCount.Text = tmptable.Rows.Count & "Users / Staff found matching  '" & TextSearch.Text & "' "
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub



    Private Sub ShowUser(UserID As String, CFPROID As String)
        Try
            Dim sqlstr As String = _
               "Select CFPROID,UserID, " &
                "UserNames,JobDescription," &
                "Department,Telephone," &
                "Email, Role," & _
                "ReadOnlyUser,NoAlerts," &
                "OwnRecordsOnly,TransitUpdateUser,ID " &
                "From CFAgentUsers " &
                "Where CFPROID ='" & CFPROID & "' " &
                "And UserID = '" & UserID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)

                TextUserNames.Text = drow("UserNames")
                TextJobDescription.Text = drow("JobDescription")
                TextDepartment.Text = drow("Department")
                TextTelephone.Text = drow("Telephone")
                TextEmailAddress.Text = drow("Email")
                CheckReadOnlyUser.Checked = drow("ReadOnlyUser")
                CheckTransitUpdateUser.Checked = drow("TransitUpdateUser")
                ComboUserRole.Text = drow("Role")
                CheckNoAlerts.Checked = drow("NoAlerts")
                CheckOwnRecordsOnly.Checked = drow("OwnRecordsOnly")
                TextUserAccessCode.Text = clsEncr.EncryptString(CFPROID & "|" & UserID & "|" & "cfagent")
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub NewUser(CFPROID As String)
        Try
            Dim sqlstr As String = _
                  "Select UserID, UserNames," &
                  "CFPROID, ID " & _
                  "From  CFAgentUsers " &
                  "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("UserID") = GetCFPROUserID()
            Drow("CFPROID") = LabelCFPROID.Text
            Drow("UserNames") = "New User" & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("CFAgentUsers", tmptable, sqlstr, False, clsData.constr)
            Call LoadCFAgentUsers(0, CFPROID, "")


            TextUserNames.Focus()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Shared Function GetCFPROUserID() As String


        Dim tmpUserID As Integer

        Dim sqlstr As String = _
         "Select top 1 ID " & _
         "From CFAgentUsers " & _
         "Order By Id Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr As String
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            tmpUserID = drow("ID")
            tmpUserID = tmpUserID + 1
            tmpstr = Format(tmpUserID, "000000000#")
        Else
            tmpstr = Format(tmpUserID, "000000000#")
        End If

        Return tmpstr & "-" & clsSubs.GetRandomNo


    End Function

    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCFAgentUsers, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridCFAgentUsers.SelectedIndexChanged
        Dim row As GridViewRow = GridCFAgentUsers.Rows(GridCFAgentUsers.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowUser(GridCFAgentUsers.SelectedValue.ToString, LabelCFPROID.Text)

        For a As Integer = 0 To GridCFAgentUsers.Rows.Count - 1
            row = GridCFAgentUsers.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridCFAgentUsers.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub




    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewUser(LabelCFPROID.Text)
    End Sub


    Private Sub SaveUser(UserID As String, CFPROID As String)
        Try

            Dim sqlstr As String = _
            "Select UserID, UserNames, " & _
             "JobDescription," & _
             "Department,Telephone," & _
             "Email, Role," & _
             "ReadOnlyUser,TransitUpdateUser," &
             "NoAlerts, OwnRecordsOnly,ID " & _
             "From CFAgentUsers " & _
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserID = '" & UserID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("UserNames") = Trim(TextUserNames.Text)
                drow("JobDescription") = Trim(TextJobDescription.Text)
                drow("Department") = Trim(TextDepartment.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Role") = ComboUserRole.Text
                drow("ReadOnlyUser") = CheckReadOnlyUser.Checked
                drow("TransitUpdateUser") = CheckTransitUpdateUser.Checked
                drow("NoAlerts") = CheckNoAlerts.Checked
                drow("OwnRecordsOnly") = CheckOwnRecordsOnly.Checked
            End If

            Call clsData.SaveData("CFAgentUsers", tmptable, sqlstr, False, clsData.constr)


            Call LoadCFAgentUsers(GridCFAgentUsers.SelectedIndex, LabelCFPROID.Text, Trim(TextSearch.Text))

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveUser(GridCFAgentUsers.SelectedValue.ToString, LabelCFPROID.Text)
    End Sub

    Private Sub DeleteStaff(UserID As String, CFPROID As String)


        Dim sqlstr As String = _
        "Select ID " & _
        "From  CFAgentUsers " & _
        "Where CFPROID ='" & CFPROID & "' " &
        "And UserID = '" & UserID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("CFAgentUsers", tmptable, sqlstr, True, clsData.constr)
        Call LoadCFAgentUsers(GridCFAgentUsers.SelectedIndex - 1, LabelCFPROID.Text, Trim(TextSearch.Text))
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteStaff(GridCFAgentUsers.SelectedValue.ToString, LabelCFPROID.Text)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadCFAgentUsers(-1, LabelCFPROID.Text, Trim(TextSearch.Text))
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        TextSearch.Text = ""
        Call LoadCFAgentUsers(0, LabelCFPROID.Text, "")
    End Sub

    Protected Sub ButtonUserCode_Click(sender As Object, e As EventArgs) Handles ButtonUserCode.Click
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonUserPermissions_Click(sender As Object, e As EventArgs) Handles ButtonUserPermissions.Click
        If GridCFAgentUsers.SelectedIndex >= 0 Then

            Dim sqlstr As String = "SELECT IPAddress,LockIP " &
                                  "FROM CFPROAccounts " &
                                  "Where CFPROID ='" & LabelCFPROID.Text & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim AccountIPAddress As String = ""
            Dim AccountIPLock As String = ""


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                AccountIPAddress = drow("IPAddress")
                AccountIPLock = drow("LockIP").ToString
            End If

            Dim row As GridViewRow = GridCFAgentUsers.SelectedRow
            iframe1.Attributes("style") = "height:455px; width:654px;" & LabeliFrameBgStyle.Text
            iframe1.Src = "userpermissions.aspx?userid=" & row.Cells(0).Text & "&cfagentuser=" & row.Cells(1).Text & "&userrole=" & ComboUserRole.Text &
                           "&accountipaddress=" & AccountIPAddress & "&iplock=" & AccountIPLock
            ModalPopupExtender2.Show()

        End If
    End Sub


    Private Sub AccountIplockSettings(CFPROID As String)

    End Sub
End Class