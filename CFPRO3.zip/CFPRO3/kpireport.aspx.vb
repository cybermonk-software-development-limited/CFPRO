﻿Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing


Public Class kpireport
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If

            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If


            Call LoadShippers(CFPROID)
            Call LoadCFAgentUsers(CFPROID)
            Call LoadVesselStatus(CFPROID)
            Call LoadJobStatus(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadCFS(CFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadKPIReport(Scope As String, CFPROID As String, ResetCacheTable As Boolean)
        Try


            Dim tmpstr As String

            If Not LCase(Scope) = "(all)" Then
                tmpstr = "And Jobs.JobDate  >= '" & TextFromDate.Text & "' " &
                          "And Jobs.JobDate <= '" & TextToDate.Text & "' "

            Else
                tmpstr = "And ID > 0 "

            End If


            Dim tmpstrClientsAgents As String = ""


            Dim sqlstr As String =
                    "Select Top " & ComboSelectTop.Text & " " &
                    "JobID, ReferenceNo," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "ShipperID,CustomsSystem,BL," &
                    "DeclarationPersonnel," &
                    "EntryRegistrationDate,EntryPassDate," &
                    "ShippingPersonnel,ShipStatus," &
                    "CFSEntryDate,VerificationStart," &
                    "CFSChargesPaidDate,DateClearedOut," &
                    "JobTypeID,JobStatus,Goods,ManifestNo," &
                    "ManifestAdviseDate,UserID, ID " &
                    "From Jobs " &
                    "Where CFPROID = '" & CFPROID & "' " &
                    tmpstr &
                    "Order by Jobs.JobDate Desc;"


            Dim tmptable As New DataTable("JobsData")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,Payload,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "JobCargo.PortExitDate,JobCargo.ReturnDate, " &
                   "JobCargo.CrossBorderDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID " &
                  tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                        "Select CFS,CFSID " &
                        "From CFS " &
                        "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)



            Dim sqlstr4 As String =
                       "Select  JobProgress.JobID," &
                       "JobProgress.Status, JobProgress.Date," &
                       "JobProgress.KPIProgressID,KPIItemID " &
                       "From JobProgress,Jobs,KPIProgressUpdates " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                       "And KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                       "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID " &
                       "And JobProgress.KPIProgressID = KPIProgressUpdates.KPIProgressID " &
                       "And KPIProgressUpdates.JobID = Jobs.JobID " &
                        tmpstr & " " &
                       "Order by JobProgress.Date Desc;"


            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)


            Dim sqlstr5 As String =
                    "Select ClientID, Client, AgreedKPIDays " &
                    "From Clients " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "

            Dim drow As DataRow
            Dim a, b, c, d As Integer



            Dim tmpstr3(0) As String

            Dim tmptableKpi As New DataTable("KPITable")


            Dim col0 As New DataColumn("JobID", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ReferenceNo", Type.GetType("System.String"))
            Dim col2 As New DataColumn("JobDate", Type.GetType("System.String"))
            Dim col2a As New DataColumn("JobDate1", Type.GetType("System.DateTime"))
            Dim col3 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col4 As New DataColumn("ClientID", Type.GetType("System.String"))
            Dim col5 As New DataColumn("ImporterID", Type.GetType("System.String"))
            Dim col6 As New DataColumn("AgentID", Type.GetType("System.String"))
            Dim col7 As New DataColumn("CFSID", Type.GetType("System.String"))
            Dim col8 As New DataColumn("VesselID", Type.GetType("System.String"))
            Dim col9 As New DataColumn("ShippingLineID", Type.GetType("System.String"))
            Dim col10 As New DataColumn("CustomsSystem", Type.GetType("System.String"))
            Dim col11 As New DataColumn("BL", Type.GetType("System.String"))
            Dim col12 As New DataColumn("Goods", Type.GetType("System.String"))
            Dim col13 As New DataColumn("ShipperID", Type.GetType("System.String"))

            Dim col15 As New DataColumn("DeclarationPersonnel", Type.GetType("System.String"))
            Dim col16 As New DataColumn("EntryRegistrationDate", Type.GetType("System.String"))
            Dim col17 As New DataColumn("ShippingPersonnel", Type.GetType("System.String"))
            Dim col18 As New DataColumn("ShipStatus", Type.GetType("System.String"))

            Dim col19 As New DataColumn("CFSEntryDate", Type.GetType("System.String"))
            Dim col20 As New DataColumn("VerificationStart", Type.GetType("System.String"))
            Dim col21 As New DataColumn("CFSChargesPaidDate", Type.GetType("System.String"))

            Dim col22 As New DataColumn("DispatchDate", Type.GetType("System.String"))
            Dim col23 As New DataColumn("ManifestNo", Type.GetType("System.String"))
            Dim col24 As New DataColumn("ManifestAdviseDate", Type.GetType("System.String"))
            Dim col25 As New DataColumn("UserID", Type.GetType("System.String"))

            Dim col26 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col27 As New DataColumn("VesselETA", Type.GetType("System.String"))
            Dim col28 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col29 As New DataColumn("ContainerNos", Type.GetType("System.String"))
            Dim col30 As New DataColumn("Quantity", Type.GetType("System.Double"))

            Dim col31 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col32 As New DataColumn("DocReceivedDate", Type.GetType("System.String"))
            Dim col33 As New DataColumn("TaxEstimatesDate", Type.GetType("System.String"))
            Dim col34 As New DataColumn("EntryPassDate", Type.GetType("System.String"))
            Dim col35 As New DataColumn("TaxesPaidDate", Type.GetType("System.String"))
            Dim col36 As New DataColumn("TreoApprovedDate", Type.GetType("System.String"))
            Dim col37 As New DataColumn("PreVerification", Type.GetType("System.String"))
            Dim col38 As New DataColumn("LastSlingDate", Type.GetType("System.String"))
            Dim col39 As New DataColumn("DateClearedOut", Type.GetType("System.String"))

            Dim col42 As New DataColumn("DownPaymentDate", Type.GetType("System.String"))
            Dim col44 As New DataColumn("DaysAtCFS", Type.GetType("System.Double"))
            Dim col45 As New DataColumn("ClearanceDays", Type.GetType("System.Double"))
            Dim col46 As New DataColumn("TransitDays", Type.GetType("System.Double"))
            Dim col47 As New DataColumn("TotalDays", Type.GetType("System.Double"))
            Dim col48 As New DataColumn("CFS", Type.GetType("System.String"))

            Dim col49 As New DataColumn("AgreedKPIDays", Type.GetType("System.Double"))
            Dim col50 As New DataColumn("Variance", Type.GetType("System.Double"))
            Dim col51 As New DataColumn("Result", Type.GetType("System.String"))
            Dim col52 As New DataColumn("PortExitDate", Type.GetType("System.String"))
            Dim col53 As New DataColumn("PreVerificationDate", Type.GetType("System.String"))
            Dim col55 As New DataColumn("DeliveryDate", Type.GetType("System.String"))
            Dim col56 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col57 As New DataColumn("VesselETA1", Type.GetType("System.DateTime"))
            Dim col58 As New DataColumn("ReleasePersonnel", Type.GetType("System.String"))

            Dim col40 As New DataColumn("ClearanceRemarks", Type.GetType("System.String"))
            Dim col41 As New DataColumn("DeliveryRemarks", Type.GetType("System.String"))

            Dim col59 As New DataColumn("1x20", Type.GetType("System.Double"))
            Dim col60 As New DataColumn("1x40", Type.GetType("System.Double"))
            Dim col61 As New DataColumn("LCL", Type.GetType("System.Double"))
            Dim col62 As New DataColumn("JobTypeID", Type.GetType("System.String"))
            Dim col63 As New DataColumn("JobStatus", Type.GetType("System.String"))
            Dim col64 As New DataColumn("ID", Type.GetType("System.Double"))

            tmptableKpi.Columns.Add(col0)
            tmptableKpi.Columns.Add(col1)
            tmptableKpi.Columns.Add(col2)
            tmptableKpi.Columns.Add(col2a)
            tmptableKpi.Columns.Add(col3)
            tmptableKpi.Columns.Add(col4)
            tmptableKpi.Columns.Add(col5)
            tmptableKpi.Columns.Add(col6)
            tmptableKpi.Columns.Add(col7)
            tmptableKpi.Columns.Add(col8)
            tmptableKpi.Columns.Add(col9)
            tmptableKpi.Columns.Add(col10)
            tmptableKpi.Columns.Add(col11)
            tmptableKpi.Columns.Add(col12)
            tmptableKpi.Columns.Add(col13)

            tmptableKpi.Columns.Add(col15)
            tmptableKpi.Columns.Add(col16)
            tmptableKpi.Columns.Add(col17)
            tmptableKpi.Columns.Add(col18)
            tmptableKpi.Columns.Add(col19)
            tmptableKpi.Columns.Add(col20)
            tmptableKpi.Columns.Add(col21)
            tmptableKpi.Columns.Add(col22)
            tmptableKpi.Columns.Add(col23)
            tmptableKpi.Columns.Add(col24)
            tmptableKpi.Columns.Add(col25)
            tmptableKpi.Columns.Add(col26)
            tmptableKpi.Columns.Add(col27)

            tmptableKpi.Columns.Add(col28)
            tmptableKpi.Columns.Add(col29)
            tmptableKpi.Columns.Add(col30)

            tmptableKpi.Columns.Add(col31)
            tmptableKpi.Columns.Add(col32)
            tmptableKpi.Columns.Add(col33)
            tmptableKpi.Columns.Add(col34)
            tmptableKpi.Columns.Add(col35)
            tmptableKpi.Columns.Add(col36)
            tmptableKpi.Columns.Add(col37)
            tmptableKpi.Columns.Add(col38)
            tmptableKpi.Columns.Add(col39)
            tmptableKpi.Columns.Add(col40)
            tmptableKpi.Columns.Add(col41)
            tmptableKpi.Columns.Add(col42)

            tmptableKpi.Columns.Add(col44)
            tmptableKpi.Columns.Add(col45)
            tmptableKpi.Columns.Add(col46)
            tmptableKpi.Columns.Add(col47)
            tmptableKpi.Columns.Add(col48)
            tmptableKpi.Columns.Add(col49)
            tmptableKpi.Columns.Add(col50)
            tmptableKpi.Columns.Add(col51)
            tmptableKpi.Columns.Add(col52)
            tmptableKpi.Columns.Add(col53)

            tmptableKpi.Columns.Add(col55)
            tmptableKpi.Columns.Add(col56)
            tmptableKpi.Columns.Add(col57)
            tmptableKpi.Columns.Add(col58)
            tmptableKpi.Columns.Add(col59)

            tmptableKpi.Columns.Add(col60)
            tmptableKpi.Columns.Add(col61)
            tmptableKpi.Columns.Add(col62)
            tmptableKpi.Columns.Add(col63)
            tmptableKpi.Columns.Add(col64)

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now


            Dim CrossedBorder As Boolean

            Dim drow1 As DataRow
            Dim col, colkpi As DataColumn
            Dim ts As TimeSpan

            Dim qty1x20, qty1x40, qtyLCL As Double

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)


                drow1 = tmptableKpi.NewRow
                tmptableKpi.Rows.Add(drow1)
                Call clsData.NullChecker(tmptableKpi, a)

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                drow1("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")
                drow1("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                drow1("JobDate1") = Format(drow("JobDate"), "dd MMM yyyy")


                For Each col In tmptable.Columns
                    For Each colkpi In tmptableKpi.Columns
                        If LCase(col.ColumnName.ToString) = LCase(colkpi.ColumnName.ToString) Then
                            If col.DataType Is Type.GetType("System.DateTime") Then
                                If CDate(drow(col.ColumnName.ToString)) = CDate("1-Jan-1800") Then
                                    drow1(colkpi.ColumnName.ToString) = ""
                                Else
                                    drow1(colkpi.ColumnName.ToString) = Format(drow(col.ColumnName.ToString), "dd MMM yyyy")
                                End If
                            Else
                                drow1(colkpi.ColumnName.ToString) = drow(col.ColumnName.ToString)
                            End If
                            Exit For
                        End If
                    Next
                Next

                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"

                CrossedBorder = True
                qty1x20 = 0
                qty1x40 = 0
                qtyLCL = 0



                If dv1.Count > 0 Then


                    For b = 0 To dv1.Count - 1
                        Call clsData.NullChecker1(dv1, b)
                        c = c + 1
                        CBM = CBM + dv1(b)("CBM")
                        Weight = Weight + dv1(b)("Weight")
                        TEU = TEU + Val(dv1(b)("TEU"))

                        If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                            CrossedBorder = False
                        End If

                        If InStr(dv1(b)("Payload"), "20", CompareMethod.Text) Then
                            qty1x20 = qty1x20 + 1
                        End If

                        If InStr(dv1(b)("Payload"), "40", CompareMethod.Text) Then
                            qty1x40 = qty1x40 + 1
                        End If

                        If InStr(dv1(b)("Payload"), "LCL", CompareMethod.Text) Then
                            qtyLCL = qtyLCL + 1
                        End If

                        If InStr(dv1(b)("Payload"), "20", CompareMethod.Text) = 0 Then
                            If InStr(dv1(b)("Payload"), "40", CompareMethod.Text) = 0 Then
                                If InStr(dv1(b)("Payload"), "LCL", CompareMethod.Text) = 0 Then
                                    qtyLCL = qtyLCL + 1
                                End If
                            End If

                        End If

                        ReDim Preserve tmpstr3(b)
                        tmpstr3(b) = dv1(b)("ContainerNo")
                    Next

                    dv1.Sort = "PortExitDate DESC"

                    If Not CDate(dv1(0)("PortExitDate")) = CDate("1-Jan-1800") Then
                        drow1("PortExitDate") = Format(dv1(0)("PortExitDate"), "dd MMM yyyy")
                    Else
                        drow1("PortExitDate") = ""
                    End If

                End If


                    drow1("CrossedBorder") = CrossedBorder

                drow1("ContainerNos") = Join(tmpstr3, " ")
                drow1("Quantity") = dv1.Count
                drow1("1x20") = qty1x20
                drow1("1x40") = qty1x40
                drow1("LCL") = qtyLCL

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow1("CFS") = dv2(0)("CFS")
                End If

                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)
                    drow1("Vessel") = dv3(0)("Vessel")
                    drow1("VesselETA1") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow1("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")

                    If Not CDate(dv3(0)("ETA")) = CDate("1-Jan-1800") Then
                        drow1("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    Else
                        drow1("VesselETA") = ""
                    End If


                End If



                Dim tmpcol(15), tmpkpitemid(15) As String

                tmpcol(0) = "DocReceivedDate"
                tmpkpitemid(0) = "000003"

                tmpcol(1) = "DownPaymentDate"
                tmpkpitemid(1) = "000004"

                tmpcol(2) = "PreVerificationDate"
                tmpkpitemid(2) = "000007"

                tmpcol(3) = "TaxEstimatesDate"
                tmpkpitemid(3) = "000010"

                tmpcol(4) = "EntryRegistrationDate"
                tmpkpitemid(4) = "000011"

                tmpcol(5) = "EntryPassDate"
                tmpkpitemid(5) = "000012"


                tmpcol(6) = "TreoApprovedDate"
                tmpkpitemid(6) = "000013"

                tmpcol(7) = "TaxesPaidDate"
                tmpkpitemid(7) = "000015"

                tmpcol(8) = "CFSChargesPaidDate"
                tmpkpitemid(8) = "000008"

                tmpcol(9) = "PortExitDate"
                tmpkpitemid(9) = "000016"

                tmpcol(10) = "DateClearedOut"
                tmpkpitemid(10) = "000018"

                tmpcol(11) = "DispatchDate"
                tmpkpitemid(11) = "000018"


                tmpcol(12) = "DeliveryDate"
                tmpkpitemid(12) = "000020"

                tmpcol(13) = "CFSEntryDate"
                tmpkpitemid(13) = "000006"


                tmpcol(14) = "VerificationStart"
                tmpkpitemid(14) = "000014"


                tmpcol(15) = "ManifestAdviseDate"
                tmpkpitemid(15) = "000005"



                For d = 0 To tmpkpitemid.GetUpperBound(0)
                    dv4.RowFilter = "JobID = '" & drow1("JobID") & "' " &
                               "And KPIItemID = '" & tmpkpitemid(d) & "' "

                    If dv4.Count > 0 Then
                        Call clsData.NullChecker1(dv4, 0)


                        If tmpcol(d) = "EntryRegistrationDate" Then
                            If IsDate(drow1("EntryRegistrationDate")) Then
                                If CDate(drow1("EntryRegistrationDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("EntryRegistrationDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("EntryRegistrationDate") = ""
                                    End If
                                End If
                            Else
                                drow1("EntryRegistrationDate") = ""
                            End If

                        ElseIf tmpcol(d) = "EntryPassDate" Then
                            If IsDate(drow1("EntryPassDate")) Then
                                If CDate(drow1("EntryPassDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("EntryPassDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("EntryPassDate") = ""
                                    End If
                                End If
                            Else
                                drow1("EntryPassDate") = ""
                            End If


                        ElseIf tmpcol(d) = "CFSEntryDate" Then
                            If IsDate(drow1("CFSEntryDate")) Then
                                If CDate(drow1("CFSEntryDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("CFSEntryDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("CFSEntryDate") = ""
                                    End If
                                End If
                            Else
                                drow1("CFSEntryDate") = ""
                            End If

                        ElseIf tmpcol(d) = "VerificationStart" Then
                            If IsDate(drow1("VerificationStart")) Then
                                If CDate(drow1("VerificationStart")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("VerificationStart") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("VerificationStart") = ""
                                    End If
                                End If

                            Else
                                drow1("VerificationStart") = ""
                            End If


                        ElseIf tmpcol(d) = "CFSChargesPaidDate" Then
                            If IsDate(drow1("CFSChargesPaidDate")) Then
                                If CDate(drow1("CFSChargesPaidDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("CFSChargesPaidDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("CFSChargesPaidDate") = ""
                                    End If
                                End If
                            Else
                                drow1("CFSChargesPaidDate") = ""
                            End If

                        ElseIf tmpcol(d) = "PortExitDate" Then
                            If IsDate(drow1("PortExitDate")) Then
                                If CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("PortExitDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("PortExitDate") = ""
                                    End If
                                End If
                            Else
                                drow1("PortExitDate") = ""
                            End If


                        ElseIf tmpcol(d) = "DateClearedOut" Then
                            If IsDate(drow1("DateClearedOut")) Then
                                If CDate(drow1("DateClearedOut")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("DateClearedOut") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("DateClearedOut") = ""
                                    End If
                                End If
                            Else
                                drow1("DateClearedOut") = ""
                            End If


                        ElseIf tmpcol(d) = "ManifestAdviseDate" Then
                            If IsDate(drow1("ManifestAdviseDate")) Then
                                If CDate(drow1("ManifestAdviseDate")) = CDate("1-Jan-1800") Then
                                    If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                        drow1("ManifestAdviseDate") = Format(dv4(0)("Date"), "dd MMM yyyy")
                                    Else
                                        drow1("ManifestAdviseDate") = ""
                                    End If
                                End If
                            Else
                                drow1("ManifestAdviseDate") = ""
                            End If

                        Else
                            If Not CDate(dv4(0)("Date")) = CDate("1-Jan-1800") Then
                                drow1(tmpcol(d)) = Format(dv4(0)("Date"), "dd MMM yyyy")
                            Else
                                drow1(tmpcol(d)) = ""
                            End If
                        End If


                        If tmpkpitemid(d) = "000016" Then
                            drow1("ClearanceRemarks") = dv4(0)("Status")
                        End If

                        If tmpkpitemid(d) = "000020" Then
                            drow1("DeliveryRemarks") = dv4(0)("Status")
                        End If

                        If tmpkpitemid(d) = "000007" Then
                            drow1("PreVerification") = dv4(0)("Status")
                        End If
                    End If

                Next




                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow1("Client") = dv5(0)("Client")
                    If drow1("AgreedKPIDays") = 0 Then
                        drow1("AgreedKPIDays") = dv5(0)("AgreedKPIDays")
                    End If
                End If

                If IsDate(drow1("DispatchDate")) Then
                    If IsDate(drow1("DispatchDate")) And IsDate(drow1("DocReceivedDate")) Then
                        If Not CDate(drow1("DispatchDate")) = CDate("1-Jan-1800") And Not CDate(drow1("DocReceivedDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("DispatchDate")).Subtract(drow1("DocReceivedDate"))
                            drow1("ClearanceDays") = ts.Days
                        Else
                            drow1("ClearanceDays") = -1
                        End If

                    Else
                        drow1("ClearanceDays") = -1
                    End If

                Else
                    If IsDate(drow1("PortExitDate")) And IsDate(drow1("DocReceivedDate")) Then
                        If Not CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") And Not CDate(drow1("DocReceivedDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("PortExitDate")).Subtract(drow1("DocReceivedDate"))
                            drow1("ClearanceDays") = ts.Days
                        Else
                            drow1("ClearanceDays") = -1
                        End If
                    Else
                        drow1("ClearanceDays") = -1
                    End If

                End If


                If IsDate(drow1("DateClearedOut")) Then

                    If IsDate(drow1("DateClearedOut")) And IsDate(drow1("CFSEntryDate")) Then
                        If Not CDate(drow1("DateClearedOut")) = CDate("1-Jan-1800") And Not CDate(drow1("CFSEntryDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("DateClearedOut")).Subtract(drow1("CFSEntryDate"))
                            drow1("DaysAtCFS") = ts.Days
                        Else
                            drow1("DaysAtCFS") = -1
                        End If

                    Else
                        drow1("DaysAtCFS") = -1
                    End If

                Else
                    If IsDate(drow1("PortExitDate")) And IsDate(drow1("CFSEntryDate")) Then
                        If Not CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") And Not CDate(drow1("CFSEntryDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("PortExitDate")).Subtract(drow1("CFSEntryDate"))
                            drow1("DaysAtCFS") = ts.Days
                        Else
                            drow1("DaysAtCFS") = -1
                        End If
                    Else
                        drow1("DaysAtCFS") = -1
                    End If
                End If

                If drow1("DaysAtCFS") < 0 Then
                    If IsDate(drow1("PortExitDate")) And IsDate(drow1("LastSlingDate")) Then
                        If Not CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") And Not CDate(drow1("LastSlingDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("PortExitDate")).Subtract(drow1("LastSlingDate"))
                            drow1("DaysAtCFS") = ts.Days
                        Else
                            drow1("DaysAtCFS") = -1
                        End If
                    Else
                        drow1("DaysAtCFS") = -1
                    End If
                End If

                If IsDate(drow1("DispatchDate")) Then
                    If IsDate(drow1("DispatchDate")) And IsDate(drow1("DeliveryDate")) Then
                        If Not CDate(drow1("DispatchDate")) = CDate("1-Jan-1800") And Not CDate(drow1("DeliveryDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("DeliveryDate")).Subtract(drow1("DispatchDate"))
                            drow1("TransitDays") = ts.Days
                        Else
                            drow1("TransitDays") = -1
                        End If

                    Else
                        drow1("TransitDays") = -1
                    End If

                Else
                    If IsDate(drow1("PortExitDate")) And IsDate(drow1("DeliveryDate")) Then
                        If Not CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") And Not CDate(drow1("DeliveryDate")) = CDate("1-Jan-1800") Then
                            ts = CDate(drow1("DeliveryDate")).Subtract(drow1("PortExitDate"))
                            drow1("TransitDays") = ts.Days
                        Else
                            drow1("TransitDays") = -1
                        End If

                    Else
                        drow1("TransitDays") = -1
                    End If
                End If


                If IsDate(drow1("DeliveryDate")) And IsDate(drow1("DocReceivedDate")) Then
                    If Not CDate(drow1("DeliveryDate")) = CDate("1-Jan-1800") And Not CDate(drow1("DocReceivedDate")) = CDate("1-Jan-1800") Then
                        ts = CDate(drow1("DeliveryDate")).Subtract(drow1("DocReceivedDate"))
                        drow1("TotalDays") = ts.Days
                    Else
                        drow1("TotalDays") = -1
                    End If

                Else
                    drow1("TotalDays") = -1

                End If

                If drow1("TotalDays") > 0 And drow1("AgreedKPIdays") > 0 Then

                    drow1("Variance") = drow1("AgreedKPIdays") - drow1("TotalDays")

                    If drow1("Variance") < 0 Then
                        drow1("Result") = "FAIL"
                    Else
                        drow1("Result") = "SUCCESS"
                    End If
                Else
                    drow1("Result") = "N/A"
                End If


                a = a + 1

            Next

            If tmptableKpi.Rows.Count = 0 Then
                drow1 = tmptableKpi.NewRow
                drow1("ReferenceNo") = "No Jobs"
                tmptableKpi.Rows.Add(drow1)
            End If


            If tmptableKpi.Rows.Count > 10 Then
                PanelJobs.Height = 350
            Else
                PanelJobs.Height = Nothing
            End If




            Dim dv As New DataView(tmptableKpi)

            Call Calctotal(dv, "")

            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate1 " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobID" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA1 " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort


            Session("KPIReportTable") = tmptableKpi


            If ResetCacheTable Then
                Exit Sub
            End If


            GridKPIReport.DataSource = dv
            GridKPIReport.DataBind()



            LabelMessage1.Text = ""


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Private Sub LoadShippers(CFPROID As String)
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Shipper Asc;"


        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
        ComboShippers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames, UserID From CFAgentUsers " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By UserNames Asc;"


        Call clsData.PopComboWithValue(ComboCFAgentUsers, sqlstr, clsData.constr, 0, 1)
        ComboCFAgentUsers.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadVesselStatus(CFPROID As String)
        Dim sqlstr As String =
        "Select Status From VesselStatus " &
        "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopCombo(ComboVesselStatus, sqlstr, clsData.constr, 0)
        ComboVesselStatus.Items.Insert(0, "(All)")


    End Sub

    Private Sub LoadJobStatus(CFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus " &
       "Where CFPROID = '" & CFPROID & "' "

        ComboJobStatus.Items.Clear()
        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select ItemDescription,ItemID " &
         "From KPIProgress "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr1, clsData.constr, 0, 1)

        ComboJobStatus.Items.Insert(0, "(All)")
        ComboJobStatus.Items(ComboJobStatus.Items.Count - 1).Value = "0"
    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridKPIReport.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridKPIReport.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridKPIReport.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()


        Call ClearFilters()
        Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, False)


    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckFilterAgent" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterClient" Then
                    Continue For
                End If

                If cont.ID = "CheckJobStatus" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterConsignee" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterJobType" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterShipper" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCFS" Then
                    Continue For
                End If

                If cont.ID = "CheckCFAgentUser" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCustomsSystem" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitCrossedBorder" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitDispatched" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day


            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, False)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetCurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, False)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, False)
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim Qty, qty1x20, qty1x40, qtyLCL As Double



            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Quantity")
                qty1x20 = qty1x20 + dv(a)("1x20")
                qty1x40 = qty1x40 + dv(a)("1x40")
                qtyLCL = qtyLCL + dv(a)("LCL")

            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextTotal1x20.Text = Format(qty1x20, "#,##0.00")
            TextTotal1x40.Text = Format(qty1x40, "#,##0.00")
            TextTotalLCLOther.Text = Format(qtyLCL, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text
            Else
                tmpstr = "All Jobs In System"
            End If

            If tmpcaption1 = "" Then
                LabelReportCaption.Text = dv.Count & " Jobs: " & tmpstr

            Else
                LabelReportCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean, ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer

            Dim CFPROID As String = LabelCFPROID.Text


            Dim tmptable As DataTable = Session("KPIReportTable")

            If IsNothing(Session("KPIReportTable")) Then
                Call LoadKPIReport(ComboPredefine.Text, CFPROID, True)
            End If

            Dim dv As New DataView(tmptable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                b = b + 1
                tmpstr1(a) = "Agent : " & TextAgent.Text
            End If


            If Client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If Shipper Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                Else
                    tmpstr(a) = " And ShipperID = " & "'" & ComboShippers.SelectedValue & "' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.SelectedItem.ToString
                b = b + 1
            End If

            If ShipStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like '%" & ComboVesselStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboVesselStatus.SelectedItem.ToString
                b = b + 1
            End If

            If JobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobTypeID Like '" & ComboJobType.Text & "%' "
                Else
                    tmpstr(a) = " And JobTypeID Like '" & ComboJobType.Text & "%' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                b = b + 1
            End If

            If JobStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                a = a + 1
            End If


            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If



            If OmitDispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Dispatched" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Dispatched" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                b = b + 1
            End If


            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If

            If CustomsSystem Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                b = b + 1
            End If



            If CFAgentUser Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                Dim UserNames As String = Trim(ComboCFAgentUsers.SelectedItem.ToString)

                If b = 0 Then

                    tmpstr(a) = "UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                Else
                    tmpstr(a) = " And UserID = " & "'" & ComboCFAgentUsers.SelectedValue & "' " &
                                "Or ShippingPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & UserNames & "%' " &
                                "Or PortStaff Like " & "'%" & UserNames & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & UserNames & "%'"

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                b = b + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridKPIReport.DataSource = dv
            GridKPIReport.DataBind()


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridKPIReport.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridKPIReport.SelectedValue.ToString)
        End If

    End Sub


    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobId"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "VesselETA"
        Else
            Return "JobDate"
        End If
    End Function

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00015") Then
            Call ExportToExcel()
        Else
            LabelJobMessage.Text = "User Not Allowed"
            LabelJobMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridKPIReport.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridKPIReport, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckFilterAgent.Checked, CheckFilterClient.Checked, CheckFilterConsignee.Checked, CheckFilterShipper.Checked,
                            CheckShipStatus.Checked, CheckFilterJobType.Checked, CheckJobStatus.Checked, CheckFilterCFS.Checked,
                            CheckOmitDispatched.Checked, CheckOmitCrossedBorder.Checked, CheckFilterCustomsSystem.Checked, CheckCFAgentUser.Checked)
    End Sub

    Protected Sub ButtonProgressReports_Click(sender As Object, e As EventArgs) Handles ButtonProgressReports.Click
        If GridKPIReport.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            If Not IsNothing(GridKPIReport.SelectedValue.ToString) Then
                Response.Redirect("progressreport.aspx?loadedbyimporter=0&jobid=" & GridKPIReport.SelectedValue.ToString())
            End If
        End If

    End Sub
    Private Sub LoadPage(page As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = page
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonProgressUpdates_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
        Try
            If GridKPIReport.SelectedValue Is Nothing Then
                LabelJobMessage.Text = "Please select an item"
            Else
                If GridKPIReport.SelectedIndex >= 0 Then

                End If

                Dim row As GridViewRow = GridKPIReport.SelectedRow

                Call LoadPage("progressupdates.aspx?jobid=" & GridKPIReport.SelectedValue.ToString & "&CFPROID=" &
                              LabelCFPROID.Text & "&referenceno=" & row.Cells(0).Text & "&jobdate=" &
                               row.Cells(1).Text & "&client=" &
                               row.Cells(2).Text, "Progress Update", 545, 780)
            End If
        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try
    End Sub




    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub


    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call ClearFilters()
        Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, False)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("KPITable")) Then
            Call LoadKPIReport(ComboPredefine.Text, LabelCFPROID.Text, True)
        End If

        Dim KPITable As DataTable = Session("KPITable")
        Dim dv As DataView = New DataView(KPITable)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or ContainerNos Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "

        GridKPIReport.DataSource = dv
        GridKPIReport.DataBind()

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub




    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)

        Dim CFPROID As String = LabelCFPROID.Text


        If dv Is Nothing Then

            If IsNothing(Session("KPIReportTable")) Then
                Call LoadKPIReport(ComboPredefine.Text, CFPROID, True)
            End If

            Dim tmptable As DataTable = Session("KPIReportTable")
            dv = New DataView(tmptable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate1 " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA1 " & tmpstrSort
        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridKPIReport.DataSource = dv
            GridKPIReport.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub



    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckFilterJobType.Checked = True
    End Sub


    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckFilterCFS.Checked = True
    End Sub

    Protected Sub ComboCustomsSystem_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCustomsSystem.SelectedIndexChanged
        CheckFilterCustomsSystem.Checked = True
    End Sub

    Protected Sub ComboShippers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboShippers.SelectedIndexChanged
        CheckFilterShipper.Checked = True
    End Sub


    Protected Sub ComboCFAgentUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgentUsers.SelectedIndexChanged
        CheckCFAgentUser.Checked = True
    End Sub

    Protected Sub ComboVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVesselStatus.SelectedIndexChanged
        CheckShipStatus.Checked = True
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckFilterClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckFilterAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub

    Private Sub ExportToExcel()
        Try



            Dim tmptable As DataTable = Session("KPIReportTable")
            Dim dv As New DataView(tmptable)

            Dim tmpfields(35) As String
            tmpfields(0) = "ReferenceNo"
            tmpfields(1) = "JobDate"
            tmpfields(2) = "Client"
            tmpfields(3) = "JobType"
            tmpfields(4) = "Goods"
            tmpfields(5) = "Quantity"
            tmpfields(6) = "1x20"
            tmpfields(7) = "1x40"
            tmpfields(8) = "LCL"
            tmpfields(9) = "Vessel"
            tmpfields(10) = "VesselETA"
            tmpfields(11) = "DocReceivedDate"
            tmpfields(12) = "DownPaymentDate"
            tmpfields(13) = "ManifestAdviseDate"
            tmpfields(14) = "PortExitDate"
            tmpfields(15) = "CFSEntryDate"
            tmpfields(16) = "PreVerificationDate"
            tmpfields(17) = "CFSChargesPaidDate"
            tmpfields(18) = "TaxEstimatesDate"
            tmpfields(19) = "EntryRegistrationDate"
            tmpfields(20) = "EntryPassDate"
            tmpfields(21) = "TreoApprovedDate"
            tmpfields(22) = "VerificationStart"
            tmpfields(23) = "TaxesPaidDate"
            tmpfields(24) = "DateClearedOut"
            tmpfields(25) = "DaysAtCFS"
            tmpfields(26) = "ClearanceDays"
            tmpfields(27) = "ClearanceRemarks"
            tmpfields(28) = "DispatchDate"
            tmpfields(29) = "DeliveryDate"
            tmpfields(30) = "TransitDays"
            tmpfields(31) = "DeliveryRemarks"
            tmpfields(32) = "TotalDays"
            tmpfields(33) = "AgreedKPIDays"
            tmpfields(34) = "Variance"
            tmpfields(35) = "Result"


            Dim tmpcols(35) As String
            tmpcols(0) = "Ref No"
            tmpcols(1) = "Job Date"
            tmpcols(2) = "Client"
            tmpcols(3) = "Job Type"
            tmpcols(4) = "Desc of Goods"
            tmpcols(5) = "No of Pkgs"
            tmpcols(6) = "1x20"
            tmpcols(7) = "1x40"
            tmpcols(8) = "LCL"
            tmpcols(9) = "Vessel"
            tmpcols(10) = "Vessel E.T.A"
            tmpcols(11) = "Docs Received"
            tmpcols(12) = "Down Payment"
            tmpcols(13) = "Manifest Date"
            tmpcols(14) = "Port Exit"
            tmpcols(15) = "Entered CFS"
            tmpcols(16) = "Pre Verification"
            tmpcols(17) = "CFS Charges Paid Date"
            tmpcols(18) = "Tax Est. to Client"
            tmpcols(19) = "Entry Lodged"
            tmpcols(20) = "Entry Passed"
            tmpcols(21) = "Treo Approved"
            tmpcols(22) = "Verification"
            tmpcols(23) = "Taxes Paid"
            tmpcols(24) = "Cleared / Released"
            tmpcols(25) = "Days At CFS"
            tmpcols(26) = "C&F Days"
            tmpcols(27) = "Clearance Remarks"
            tmpcols(28) = "Dispatch On"
            tmpcols(29) = "Delivery Date to Client"
            tmpcols(30) = "Transit Days"
            tmpcols(31) = "Delivery Remarks"
            tmpcols(32) = "Total Days"
            tmpcols(33) = "Agreed Days"
            tmpcols(34) = "Variance"
            tmpcols(35) = "Result"


            Dim Filter As String = LabelFilterStr.Text
            Dim Sort As String = LabelSortStr.Text

            If Not Filter = "" Then
                dv.RowFilter = Filter
            End If

            If Not Sort = "" Then
                dv.Sort = Sort
            End If


            Dim excel As New ExcelPackage()
            Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
            Dim totalCols = tmpfields.GetUpperBound(0) + 1
            Dim totalRows = dv.Count


            Dim lcol As String = GetExcelColumnName(totalCols + 1)

            For col1 As Integer = 2 To totalCols + 1
                workSheet.Cells(5, col1).Value = tmpcols(col1 - 2)
            Next

            workSheet.Cells("B3:" & lcol & "3").Merge = True
            workSheet.Cells("B4:" & lcol & "4").Merge = True

            workSheet.Cells("B3:" & lcol & "3").Style.Font.Size = 14
            workSheet.Cells("B4:" & lcol & "4").Style.Font.Size = 9
            workSheet.Cells("B3:" & lcol & "4").Style.Font.Bold = True

            workSheet.Cells(3, 2).Value = "Key Performance Indicators Report: " & LabelCFAgent.Text
            workSheet.Cells(4, 2).Value = LabelReportCaption.Text


            Dim a, b As Integer


            Dim row As Integer
            For row = 5 To totalRows + 4
                b = row - 5

                For a = 1 To totalCols
                    If tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.DateTime") Then
                        If Not CDate(dv(b)(tmpfields(a - 1))) <= CDate("1-Jan-1800") Then
                            workSheet.Cells(row + 1, a + 1).Value = Format(dv(b)(tmpfields(a - 1)), "dd MMM yyyy")
                        End If
                    ElseIf tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.Double") Then
                        workSheet.Cells(row + 1, a + 1).Value = CDbl(Format(dv(b)(tmpfields(a - 1)), "#,##0.00"))
                        workSheet.Cells(row + 1, a + 1).Style.VerticalAlignment = Style.ExcelHorizontalAlignment.Right


                    ElseIf tmptable.Columns(tmpfields(a - 1)).DataType = Type.GetType("System.Decimal") Then
                        workSheet.Cells(row + 1, a + 1).Value = CDbl(Format(dv(b)(tmpfields(a - 1)), "#,##0.00"))
                        workSheet.Cells(row + 1, a + 1).Style.VerticalAlignment = Style.ExcelHorizontalAlignment.Right
                    Else
                        workSheet.Cells(row + 1, a + 1).Value = dv(b)(tmpfields(a - 1)).ToString
                    End If
                    workSheet.Cells(row + 1, a + 1).Style.VerticalAlignment = Style.ExcelVerticalAlignment.Top


                    If a = 3 Then
                        workSheet.Cells(row + 1, a + 1).Style.WrapText = True
                    End If

                    If a = 5 Then
                        workSheet.Cells(row + 1, a + 1).Style.WrapText = True
                    End If

                    If a = 29 Then
                        workSheet.Cells(row + 1, a + 1).Style.WrapText = True
                    End If

                    If a = 34 Then
                        workSheet.Cells(row + 1, a + 1).Style.WrapText = True
                    End If


                    workSheet.Cells(row + 1, a + 1).Style.VerticalAlignment = Style.ExcelVerticalAlignment.Top
                Next
            Next


            Using rng As ExcelRange = workSheet.Cells("B5:" & lcol & "" & dv.Count + 5)
                rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
                rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
                rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
                rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
                rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                rng.AutoFitColumns()
                rng.Style.Font.Size = 9
            End Using

            Using rng As ExcelRange = workSheet.Cells("B3:" & lcol & "5")
                rng.Style.Font.Bold = True
                rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            End Using

            Using rng As ExcelRange = workSheet.Cells("B3:" & lcol & "5")
                rng.Style.Font.Bold = True
                rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            End Using


            'TOTALS

            row = row + 1


            Using rng As ExcelRange = workSheet.Cells("G" & row & ":J" & row)
                rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
                rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
                rng.Style.Font.Size = 10
                rng.Style.Font.Bold = True
                rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
            End Using



            workSheet.Cells("G" & row).Value = CDbl(TextTotalQty.Text)
            workSheet.Cells("H" & row).Value = CDbl(TextTotal1x20.Text)
            workSheet.Cells("I" & row).Value = CDbl(TextTotal1x40.Text)
            workSheet.Cells("J" & row).Value = CDbl(TextTotalLCLOther.Text)

            workSheet.Column(4).Width = 40
            workSheet.Column(6).Width = 40
            workSheet.Column(30).Width = 30
            workSheet.Column(35).Width = 30

            'END TOTALS

            'FOOTER IMAGE

            Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
            If IO.File.Exists(imagePath) Then
                Using img As System.Drawing.Image = Image.FromFile(imagePath)
                    workSheet.Drawings.AddPicture("picture1", img)
                    workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
                End Using
            End If

            Using memoryStream = New MemoryStream()
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                Response.AddHeader("content-disposition", "attachment;  filename=" & "Key Performance Indicators Report " & Format(Now, "dd MMM yyyy hh mm tt") & ".xlsx")
                excel.SaveAs(memoryStream)
                memoryStream.WriteTo(Response.OutputStream)
                Response.Flush()
                Response.[End]()
            End Using


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Shared Function GetExcelColumnName(columnNumber As Integer) As String
        Dim dividend As Integer = columnNumber
        Dim columnname As String = String.Empty
        Dim modulo As Integer
        While dividend > 0
            modulo = (dividend - 1) Mod 26
            columnname = Convert.ToChar(65 + modulo).ToString() + columnname
            dividend = Convert.ToInt32((dividend - modulo) / 26)
        End While

        Return columnname

    End Function

End Class

