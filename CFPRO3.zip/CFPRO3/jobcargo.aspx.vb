﻿Imports System.Drawing

Public Class jobcargo
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim Usertype As String = Request.QueryString("usertype")

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""


            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", CFAgentName, "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Dim JobID As String = Request.QueryString("jobid")
            LabelJobID.Text = JobID

            Call LoadJobCargo(CFPROID, JobID, "")
        End If
    End Sub


    Private Sub LoadJobCargo(CFPROID As String, ByVal JobID As String, SearchStr As String, Optional ByRef RowIndex As Integer = -1)

        Dim tmpstr As String = ""

        SearchStr = Trim(SearchStr)

        If Not SearchStr = "" Then
            tmpstr = "And ContainerNo like '%" & SearchStr & "%' "
        End If

        Dim sqlstr As String = _
           "Select JobID,ContainerNo,Payload," & _
           "TEU,Weight,CBM," & _
           "VehicleNo,TransporterID," & _
           "PortExitDate,CrossBorderDate," & _
           "ReturnDate,InterchangeNo," & _
           "ContainerStatus,ID " & _
           "From JobCargo " & _
           "Where JobID = '" & JobID & "' " & _
           "And CFPROID = '" & CFPROID & "' " &
           tmpstr

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim sqlstr1 As String = _
                   "Select Transporter,TransporterID " & _
                   "From Transporters " & _
                   "Where CFPROID = '" & CFPROID & "' "


        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

        Dim dv1 As New DataView(tmptable1)

        Dim col As New DataColumn("EditCargo", Type.GetType("System.String"))
        Dim col1 As New DataColumn("MoreCargoDetails", Type.GetType("System.String"))
        Dim col4 As New DataColumn("Transporter", Type.GetType("System.String"))
        Dim col5 As New DataColumn("DemurrageDays", Type.GetType("System.Double"))
        Dim col6 As New DataColumn("StorageDays", Type.GetType("System.Double"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)


        Dim a As Integer
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("EditCargo") = "addeditcargo.aspx?jobcargoid=" & drow("ID")
            drow("MoreCargoDetails") = "addeditcargo.aspx?jobcargoid=" & drow("ID")

            If CDate(drow("PortExitDate")) <= CDate("1-Jan-1800") Then
                drow("PortExitDate") = CDate("1-Jan-1800")
            End If


            If CDate(drow("CrossBorderDate")) <= CDate("1-Jan-1800") Then
                drow("CrossBorderDate") = CDate("1-Jan-1800")
            End If

            If CDate(drow("ReturnDate")) <= CDate("1-Jan-1800") Then
                drow("ReturnDate") = CDate("1-Jan-1800")
            End If


            dv1.RowFilter = "TransporterID ='" & drow("TransporterID") & "' "
            If dv1.Count > 0 Then
                drow("Transporter") = dv1(0)("Transporter")
            End If

            a = a + 1
        Next

        Call clsShippingStorage.SetDemurrageStorageDays(tmptable, JobID, CFPROID, LabelMessage1.Text)

        If SearchStr = "" Then
            LabelCargoCaption.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "
        Else
            LabelCargoCaption.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count &
                                   "Items Found Matching '" & SearchStr & "'"
        End If



        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Payload") = ""
            tmptable.Rows.Add(drow)
        End If

        If tmptable.Rows.Count >= 18 Then
            PanelCargo.Height = 546
        Else
            PanelCargo.Height = Nothing
        End If

        Call CargoTotals(tmptable)

        GridJobCargo.DataSource = tmptable
        GridJobCargo.DataBind()
        LabelRowIndex.Text = RowIndex

        If RowIndex >= 0 Then
            GridJobCargo.SelectedIndex = RowIndex
        End If

        LabelCargoMessage.Text = ""
        LabelCargoMessage.ForeColor = Color.Black

    End Sub


    Private Sub CargoTotals(tmptable As DataTable)

        Dim a As Integer
        Dim Weight, CBM As Double

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            Weight = Weight + drow("Weight")
            CBM = CBM + drow("CBM")
            a = a + 1
        Next

        TextWeight.Text = Format(Weight, "#,##0.00")
        TextCBM.Text = Format(CBM, "#,##0.00")
        TextCargoCount.Text = Format(a, "#,##0")

    End Sub
    Protected Sub Button14_Click(sender As Object, e As EventArgs) Handles ButtonAddCargo.Click
        Call AddEditCargo(-1, "Add")
    End Sub

    Protected Sub Button25_Click(sender As Object, e As EventArgs) Handles ButtonEditCargo.Click

        If Val(LabelRowIndex.Text) >= 0 Then
            Call AddEditCargo(GridJobCargo.SelectedValue, "Edit")
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
            LabelCargoMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkPayload_Click(sender As Object, e As EventArgs)
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim ID As Integer = linkbutton.CommandArgument.ToString
        Call AddEditCargo(ID, "Edit")
    End Sub
    Private Sub AddEditCargo(ID As Integer, AddEdit As String)
        Try

      
        LabelCargoMessage.Text = ""
        LabelCargoMessage.ForeColor = Color.Gray

            LoadDialog("addeditcargo.aspx?cargoaddeditdetails=" & LabelCFPROID.Text & "," & ID & "," &
                          GridJobCargo.SelectedIndex & "," & LabelJobID.Text & "," & AddEdit, "Add / Edit Cargo", 400, 480)


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub
    Protected Sub Button26_Click(sender As Object, e As EventArgs) Handles ButtonDeleteCargo.Click

        If Val(LabelRowIndex.Text) >= 0 Then
            Dim row As GridViewRow = GridJobCargo.Rows(GridJobCargo.SelectedIndex)
            Call PromptDeleteCargo(GridJobCargo.SelectedValue, row.Cells(1).Text, row.Cells(2).Text, GridJobCargo.SelectedIndex)
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
            LabelCargoMessage.ForeColor = Color.Red
        End If

    End Sub


    Private Sub PromptDeleteCargo(CargoID As String, PayLoad As String, ContainerNo As String, RowIndex As String)

        Dim DelMessage As String = PayLoad & " " & ContainerNo

        LabelDeleteMessage.Text = "Delete - " & DelMessage & " ?"
        ButtonDelete.Visible = True


        ModalPopupExtender2.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteCargoItem(GridJobCargo.SelectedValue)
    End Sub

    Private Sub DeleteCargoItem(CargoID As Integer)

        Try
            Dim sqlstr As String = _
             "Select JobID,ID " & _
             "From JobCargo " & _
             "Where ID = " & CInt(CargoID) & " "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                drow.Delete()
            End If

            Dim rowindex As Integer = GridJobCargo.SelectedIndex

            Call clsData.SaveData("JobCargo", tmptable, sqlstr, True, clsData.constr)
            Call LoadJobCargo(LabelCFPROID.Text, LabelJobID.Text, TextSearch.Text, rowindex - 1)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl

     If pagetitle.Contains("Cargo") Then
            ModalPopupExtender1.CancelControlID = "LinkCloseDialog"
        Else
            ModalPopupExtender1.CancelControlID = "ButtonCloseDialog"
        End If
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonMoreCargoDetails_Click(sender As Object, e As EventArgs) Handles ButtonMoreCargoDetails.Click
        If GridJobCargo.SelectedIndex >= 0 Then
            Call LoadDialog("morecargodetails.aspx?jobid=" & LabelJobID.Text & "&jobcargoid=" & GridJobCargo.SelectedValue, "More Cargo Details", 495, 780)
        Else
            LabelCargoMessage.Text = "Select Cargo Item .."
            LabelCargoMessage.ForeColor = Color.Red
        End If
    End Sub


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridJobCargo.SelectedIndexChanged
        Dim row As GridViewRow = GridJobCargo.Rows(GridJobCargo.SelectedIndex)
        LabelRowIndex.Text = GridJobCargo.SelectedIndex

        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        LabelCargoMessage.ForeColor = Color.Gray
        LabelCargoMessage.Text = ""

        For a As Integer = 0 To GridJobCargo.Rows.Count - 1
            row = GridJobCargo.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridJobCargo.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub ButtonRefreshCargo_Click(sender As Object, e As EventArgs) Handles ButtonRefreshCargo.Click
        TextSearch.Text = ""
        Call LoadJobCargo(LabelCFPROID.Text, LabelJobID.Text,
                          "", LabelRowIndex.Text)
    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadJobCargo(LabelCFPROID.Text, LabelJobID.Text,
                        TextSearch.Text, LabelRowIndex.Text)
    End Sub

    Protected Sub ButtonCloseDialog_Click(sender As Object, e As EventArgs) Handles ButtonCloseDialog.Click
        If LabelDialogTitle.Text.Contains("Cargo") Then
            Call LoadJobCargo(LabelCFPROID.Text, LabelJobID.Text, "", GridJobCargo.SelectedIndex)

        End If
    End Sub
End Class