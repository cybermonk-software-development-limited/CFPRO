﻿Public Class swdetails
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
                
            Dim CFPROID As String = ""
            Dim CFAgentUserName As String = ""

            Call clsAuth.UserLogin("", CFPROID, "", CFAgentUserName, "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Dim JobID As String = Request.QueryString("jobid")

            Call LoadSWDetails(CFPROID, JobID, CFAgentUserName)
            Call LoadCFS(CFPROID)


        End If
    End Sub

    Private Sub LoadSWDetails(CFPROID As String, JobID As String, CFAgentUserName As String)
        Dim sqlstr As String =
            "Select CustomsSystem,	AgentAppointStatus," &
            "AgentApointDate,SWCFAgent," &
            "SWDutyPayableStatus,SWDutyPaidDate," &
            "SWDutyAmount,SWCFS,ID " &
            "From Jobs " &
            "Where CFPROID ='" & CFPROID & "' " &
            "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            If drow("AgentAppointStatus") = "" Then
                drow("AgentAppointStatus") = ComboAgentAppointmentStatus.Items(0)
            End If

            If drow("SWDutyPayableStatus") = "" Then
                drow("SWDutyPayableStatus") = ComboDutyStatus.Items(1)
            End If

            TextCustomSystems.Text = drow("CustomsSystem")
            ComboAgentAppointmentStatus.Text = drow("AgentAppointStatus")
            TextAgentAppointDate.Text = Format(drow("AgentApointDate"), "dd MMM yyyy")
            TextCfAgent.Text = drow("SWCFAgent")
            ComboDutyStatus.Text = drow("SWDutyPayableStatus")
            TextDutyPaidDate.Text = Format(drow("SWDutyPaidDate"), "dd MMM yyyy")
            TextDutyAmount.Text = Format(drow("SWDutyAmount"), "#,##0.00")
            ComboCFS.Text = drow("SWCFS")
            
        End If

    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Dim JobID As String = Request.QueryString("jobid")
        Call SaveSWDetails(LabelCFPROID.Text, JobID)
    End Sub

    Private Sub SaveSWDetails(CFPROID As String, JobID As String)

        Dim sqlstr As String =
           "Select CustomsSystem,	AgentAppointStatus," &
           "AgentApointDate,SWCFAgent," &
           "SWDutyPayableStatus,SWDutyPaidDate," &
           "SWDutyAmount,SWCFS,ID " &
           "From Jobs Where JobID = '" & JobID & "' "
        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            drow("AgentAppointStatus") = ComboAgentAppointmentStatus.Text
            drow("SWDutyPayableStatus") = ComboDutyStatus.Text
            drow("CustomsSystem") = TextCustomSystems.Text
            drow("AgentAppointStatus") = ComboAgentAppointmentStatus.Text
            drow("AgentApointDate") = TextAgentAppointDate.Text
            drow("SWCFAgent") = TextCfAgent.Text
            drow("SWDutyPayableStatus") = ComboDutyStatus.Text
            drow("SWDutyPaidDate") = TextDutyPaidDate.Text
            drow("SWDutyAmount") = TextDutyAmount.Text
            drow("SWCFS") = ComboCFS.SelectedItem.ToString

            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

        End If
    End Sub


    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr1 As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboCFS, sqlstr1, clsData.constr, 0)
        ComboCFS.Items.Insert(0, "")
    End Sub

 
End Class