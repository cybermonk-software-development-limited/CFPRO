﻿Public Class registration
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            Dim CFPROID As String = ""
            Dim CFAgentUserName As String = ""

            Call clsAuth.UserLogin("", CFPROID, "", CFAgentUserName, "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID

            Dim JobID As String = Request.QueryString("jobid")

            Call LoadCFAgentUsers(CFPROID)
            Call LoadRegistration(CFPROID, JobID, CFAgentUserName)
        End If
    End Sub

    Private Sub LoadRegistration(CFPROID As String, JobID As String, CFAgentUserName As String)
        Try
            Dim sqlstr As String =
                  "Select  JobId, RegistrationNo," &
                  "RegistrationType,	RegistrationCharges," &
                  "RegistrationReceiptNo, RegistrationPersonnel," &
                  "RegistrationStart,RegistrationEnd," &
                  "RegistrationExpenses, ID " &
                  "From Jobs " &
                  "Where CFPROID ='" & CFPROID & "' " &
                  "And JobId ='" & JobID & "'"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)
                TextRegistrationNoPlate.Text = drow("RegistrationNo")
                ComboTypeOfRegistration.Text = drow("RegistrationType")

                TextCharges.Text = Format(drow("RegistrationCharges"), "#,##0.00")
                TextReceiptNo.Text = drow("RegistrationReceiptNo")

                TextRegistrationExpenses.Text = Format(drow("RegistrationExpenses"), "#,##0.00")

                TextDateStarted.Text = Format(drow("RegistrationStart"), "dd MMM yyyy")
                TextDateCompleted.Text = Format(drow("RegistrationEnd"), "dd MMM yyyy")
                ComboPersonnel.Text = drow("RegistrationPersonnel")

                If CDate(TextDateStarted.Text) = CDate("1-Jan-1800") Then
                    TextDateStarted.Text = Format(Now, "dd MMM yyyy")
                    ComboPersonnel.Text = CFAgentUserName
                End If

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub


    Private Sub SaveRegistration(CFPROID As String, JobID As String)
        Try

            Dim sqlstr As String =
                "Select  JobId, RegistrationNo," &
                "RegistrationType,	RegistrationCharges," &
                "RegistrationReceiptNo, RegistrationPersonnel," &
                "RegistrationStart,RegistrationEnd," &
                "RegistrationExpenses, ID " &
                "From Jobs " &
                "Where CFPROID ='" & CFPROID & "' " &
                "And JobId ='" & JobID & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

                drow("RegistrationNo") = Trim(TextRegistrationNoPlate.Text)
                drow("RegistrationType") = Trim(ComboTypeOfRegistration.Text)

                drow("RegistrationCharges") = Trim(TextCharges.Text)
                drow("RegistrationReceiptNo") = Trim(TextReceiptNo.Text)

                drow("RegistrationStart") = Trim(TextDateStarted.Text)
                drow("RegistrationEnd") = Trim(TextDateCompleted.Text)

                drow("RegistrationPersonnel") = ComboPersonnel.Text
                drow("RegistrationExpenses") = Trim(TextRegistrationExpenses.Text)

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try


    End Sub

    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr1 As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPersonnel, sqlstr1, clsData.constr, 0)
        ComboPersonnel.Items.Insert(0, "")
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Dim JobID As String = Request.QueryString("jobid")
        Call SaveRegistration(LabelCFPROID.Text, JobID)
    End Sub
End Class