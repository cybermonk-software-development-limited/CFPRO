﻿
Imports AjaxControlToolkit
Imports System.ComponentModel

Public Class clsExtendRating
    Inherits Rating
    <Category("Behavior")> _
    Public Property CommandName() As String
        Get
            Return If(DirectCast(ViewState("CommandName"), String), String.Empty)
        End Get
        Set(value As String)
            ViewState("CommandName") = value
        End Set
    End Property

    <Category("Behavior")> _
    Public Property CommandArgument() As String
        Get
            Return If(DirectCast(ViewState("CommandArgument"), String), String.Empty)
        End Get
        Set(value As String)
            ViewState("CommandArgument") = value
        End Set
    End Property

    Protected Overrides Sub OnChanged(e As AjaxControlToolkit.RatingEventArgs)
        MyBase.OnChanged(e)
        RaiseBubbleEvent(Me, New CommandEventArgs(CommandName, CommandArgument))
    End Sub
End Class