﻿


Imports System.Net

Public Class clsCurrencyConvert


    Shared Function CurrencyConvert(Amount As Double, FromCurrency As String, ToCurrency As String, ByRef ErrMsg As String) As Double()

        Dim response As String = ""
        Dim url As String = ""


        Try

            Dim ConvertResult(1) As Double

            'If FromCurrency = "USD" Then
            '    ConvertResult(0) = Amount * 103.5
            '    ConvertResult(1) = 103.5
            '    Return ConvertResult
            'End If

            If FromCurrency = ToCurrency Then
                ConvertResult(0) = Amount
                ConvertResult(1) = 1
                Return ConvertResult
            End If

            Dim web As New WebClient()
            url = String.Format("https://finance.google.com/finance/converter?a={2}&from={0}&to={1}", FromCurrency, ToCurrency, 1)
            response = web.DownloadString(url)


            Dim regex As New Regex("<span class=bld>(\d*.\d*)")
            Dim rate As String = System.Convert.ToDecimal(regex.Match(response).Groups(1).Value)

            Dim ConvertedAmount As Double = Amount * rate

            ConvertResult(0) = ConvertedAmount
            ConvertResult(1) = rate

            Return ConvertResult
        Catch ex As Exception
            ErrMsg = ex.Message & " " & url
        End Try

    End Function

End Class
