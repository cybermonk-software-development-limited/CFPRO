﻿
Imports System.Drawing
Public Class bonds
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID


            Call LoadBonds(CFPROID)
        End If
    End Sub


   

    Private Sub LoadBonds(ByVal CFPROID As String)

        Try


            Dim sqlstr As String =
                "SELECT BondID, BondDescription," &
                "BondNo, BondAmount," &
                "BondExpiry, CFPROID," &
                "Status, ID " &
                "FROM Bonds " &
                "Where CFPROID ='" & CFPROID & "' " &
                "Order By BondAmount Desc "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            LabelBondsCaption.Text = tmptable.Rows.Count & "  Bonds"

            Dim a As Integer
            Dim drow As DataRow

            LabelCaption.Text = tmptable.Rows.Count & " Bonds"

            If tmptable.Rows.Count = 0 Then

                drow = tmptable.NewRow
                drow("BondDescription") = "No Bonds"
                tmptable.Rows.Add(drow)
            End If

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next



            GridBonds.DataSource = tmptable
            GridBonds.DataBind()




        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditBond(LabelCFPROID.Text, False)
    End Sub
    Protected Sub GridBonds_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridBonds.SelectedIndexChanged
        Dim row As GridViewRow = GridBonds.Rows(GridBonds.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridBonds.Rows.Count - 1
            row = GridBonds.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridBonds.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridBonds_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridBonds.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridBonds, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditBond(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditBond(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridBonds.SelectedIndex < 0 Then
                    LabelMessage3.Text = "Please Select Bond"
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Bond"
                Dim ID As Integer = GridBonds.SelectedValue

                Dim sqlstr As String =
                   "SELECT BondID, BondDescription," &
                   "BondNo, BondAmount," &
                   "BondExpiry, CFPROID," &
                   "Status, ID " &
                   "FROM Bonds " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextBondNo.Text = drow("BondNo")
                    TextBondAmount.Text = Format(drow("BondAmount"), "#,##0.00")
                    TextBondDescription.Text = drow("BondDescription")
                    TextBondExpiry.Text = Format(drow("BondExpiry"), "dd MMM yyyy")
                    ComboBondStatus.Text = drow("Status")
                End If

            Else
                LabelAddEdit.Text = "Add Bond"
                ComboBondStatus.Text = ""
                TextBondNo.Text = ""
                TextBondAmount.Text = "0.00"
                TextBondDescription.Text = ""
                TextBondExpiry.Text = Format(Now, "dd MMM yyyy")
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSave0_Click(sender As Object, e As EventArgs) Handles ButtonSave0.Click
        Call SaveBonds(LabelCFPROID.Text, Trim(TextBondNo.Text))
    End Sub

    Private Sub SaveBonds(CFPROID As String, BondNo As String)

        Try
            Dim sqlstr As String =
                   "SELECT BondID, BondDescription," &
                   "BondNo, BondAmount," &
                   "BondExpiry, CFPROID," &
                   "Status, ID " &
                   "FROM Bonds " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And BondNo ='" & BondNo & "' " 

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim BondAmount As String = Trim(TextBondAmount.Text)
            BondAmount = BondAmount.Replace(" ", "")
            BondAmount = BondAmount.Replace(",", "")

            TextBondAmount.Text = BondAmount

            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("BondID") = GetBondID()
                tmptable.Rows.Add(drow)
            End If

            drow("BondNo") = UCase(Trim(TextBondNo.Text))
            drow("BondAmount") = Trim(TextBondAmount.Text)
            drow("BondDescription") = UCase(Trim(TextBondDescription.Text))


            If IsDate(Trim(TextBondExpiry.Text)) Then
                drow("BondExpiry") = Trim(TextBondExpiry.Text)
            End If

            drow("Status") = ComboBondStatus.Text

            Call clsData.SaveData("Bonds", tmptable, sqlstr, False, clsData.constr)

            Call LoadBonds(CFPROID)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

   
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridBonds.SelectedIndex >= 0 Then
            Call PromptDeleteBonds(GridBonds.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage3.Text = "No Selection"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteBonds(ID As Integer, CFPROID As String)
        Dim row As GridViewRow = GridBonds.Rows(GridBonds.SelectedIndex)

        LabelDeleteMessage.Text = "Delete Bond " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteBonds(GridBonds.SelectedValue)
    End Sub
    Private Sub DeleteBonds(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From Bonds  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("Bonds", tmptable, sqlstr, True, clsData.constr)

            Call LoadBonds(LabelCFPROID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub

   

    Private Function GetBondID() As String
        Try

            Dim tmpBondID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From Bonds " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpBondID = drow("ID")
                tmpBondID = tmpBondID + 1
                tmpstr = Format(tmpBondID, "00000000#")
            Else
                tmpstr = Format(tmpBondID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetBondID")
        End Try
    End Function
  

End Class