﻿Public Class transportercargo
    Inherits System.Web.UI.Page

    Friend JobId As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "transporter", True)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If

            Try

                Call GetTransporterName(CFPROID, CFPROUserID)
                Call LoadJobTypes(CFPROID)
                Call LoadJobTypes(CFPROID)

                Call LoadReleaseOrderStatus(CFPROID)
                Call LoadContainerStatuses(CFPROID)
                Call LoadCFS(CFPROID)
                Call LoadVessels(CFPROID)
                Call LoadPayLoads(CFPROID)
                Call LoadJobTypes(CFPROID)
                Call LoadDestinations(CFPROID)

            Catch ex As Exception
                LabelMessage1.Text = ex.Message & ex.StackTrace
            End Try


            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If

    End Sub

    Private Sub GetTransporterName(CFPROID As String, CFPROUserID As String)
        Dim sqlstr As String = _
                          "Select Transporters.Transporter " & _
                          "FROM CFPROAccountConnect, Transporters " & _
                          "Where  CFPROAccountConnect.CFPROID = '" & CFPROID & "' " &
                          "And  Transporters.CFPROID = '" & CFPROID & "' " &
                          "And  CFPROAccountConnect.CFPROUserID  = '" & CFPROUserID & "' " &
                          "And  CFPROAccountConnect.Usertype = 'transporter' " &
                          "And  CFPROAccountConnect.CFPROUserID =  Transporters.TransporterID "



        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            LabelTransporterHeader.Text = drow("Transporter") & " - Assigned Cargo"
        End If

    End Sub
    Private Sub LoadContainers(CFPROID As String, CFPROUserID As String)

        Dim sqlstr As String = ""

        Try

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = "And Jobs.JobDate >= '" & TextFromDate.Text & "' " &
                  "And Jobs.Jobdate <= '" & TextToDate.Text & "' "
            End If

            Dim tmpstr1 As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr1 = "And Jobs.UserID = '" & CFPROUserID & "' "
            End If


            sqlstr = "Select Top " & ComboSelectTop.Text & " " &
                  "JobCargo.JobID,ContainerNo," &
                  "JobCargo.Weight,JobCargo.CBM,VehicleNo,TrailerNo," &
                  "JobCargo.TransporterID,JobCargo.PortExitDate," &
                  "JobCargo.CrossBorderDate,ContainerStatus," &
                  "BorderDispatchDate,DestinationArrivalDate," &
                  "OffLoadDate,DestinationDispatchDate," &
                  "JobCargo.ReturnDate," &
                  "JobCargo.Payload," &
                  "T812No,CustomsSealNo,TEU,T1No," &
                  "InterchangeNo, JobCargo.Destination, DestinationDepot, " &
                  "SpecialCargoType, ContainerStatusRemarks, " &
                  "ReturnVehicleNo, DeliveryNoteNo, JobCargo.ID, " &
                  "Jobs.AgentID, Jobs.ClientID, Jobs.ClientID, " &
                  "Jobs.ImporterID,ShipperID," &
                  "Jobs.ShippingLineID, VesselID, SOC," &
                  "Jobs.JobStatus,Jobs.KeepVisible,DispatchDate," &
                  "BL,HouseBL,BLCountry,CFSID,Jobs.JobDate," &
                  "ReferenceNo,ReferenceNo1," &
                  "ManifestNo,Jobs.ID as ID1," &
                  "Jobs.ReleaseOrderStatus, Jobs.JobTypeID," &
                  "DocumentsReceivedDate, ContainerDepositDate," &
                  "PortofLoading, CountryofLoading," &
                  "PortChargesPaidDate, LoadingDate " &
                  "From JobCargo, Jobs " &
                  "Where Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.TransporterID = '" & CFPROUserID & "' " &
                  "And Jobs.JobID  = JobCargo.JobID " &
                   tmpstr & tmpstr1

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                       "Select ShippingLine, ShippingLineID, ID " &
                       "From ShippingLines " &
                       "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)

            Dim sqlstr2 As String =
                       "Select CFS,CFSID " &
                       "From CFS " &
                       "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)



            Dim sqlstr3 As String =
                    "Select VesselID,Vessel,VoyageNo, " &
                    "ETA,BerthingDate, ExitDate  " &
                    "From ShippingVessels " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim sqlstr4 As String =
                   "Select Transporter, TransporterID " &
                   "From Transporters " &
                   "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)


            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim col0 As New DataColumn("Transporter", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ShippingLine", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col7 As New DataColumn("StorageFreeDays", Type.GetType("System.Double"))
            Dim col8 As New DataColumn("StorageDays", Type.GetType("System.Double"))
            Dim col9 As New DataColumn("StorageCharges", Type.GetType("System.Double"))
            Dim col10 As New DataColumn("DemurrageFreeDays", Type.GetType("System.Double"))
            Dim col11 As New DataColumn("RemainingDays", Type.GetType("System.Double"))
            Dim col12 As New DataColumn("DemurrageCharges", Type.GetType("System.Double"))
            Dim col13 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col14 As New DataColumn("Importer", Type.GetType("System.String"))
            Dim col15 As New DataColumn("VoyageNo", Type.GetType("System.String"))
            Dim col16 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col17 As New DataColumn("JobUrl", Type.GetType("System.String"))


            tmptable.Columns.Add(col0)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)
            tmptable.Columns.Add(col17)


            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")

                If CDate(drow("CrossBorderDate")) = CDate("1-Jan-1800") Then
                    drow("CrossedBorder") = False
                Else
                    drow("CrossedBorder") = True
                End If

                dv1.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    drow("ShippingLine") = dv1(0)("ShippingLine")
                End If


                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")
                End If

                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VoyageNo") = dv3(0)("VoyageNo")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")

                End If


                dv4.RowFilter = "TransporterID = '" & drow("TransporterID") & "' "

                If dv4.Count > 0 Then
                    Call clsData.NullChecker1(dv4, 0)
                    drow("Transporter") = dv4(0)("Transporter")
                End If


                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Client") = Mid(dv5(0)("Client"), 1, 25)
                End If

                dv6.RowFilter = "ImporterID = '" & drow("ImporterID") & "' "
                If dv6.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Importer") = Mid(dv6(0)("Importer"), 1, 25)
                End If
                a = a + 1
            Next


            Dim dv As New DataView(tmptable)
            Session("JobCargo") = tmptable

            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "BerthingDate" Then
                dv.Sort = "BerthingDate " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort

            GridCargo.DataSource = dv
            GridCargo.DataBind()

            Call Calctotal(dv, "")



            If tmptable.Rows.Count >= 10 Then
                PanelCargo.Height = 250
            Else
                PanelCargo.Height = Nothing
            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace & sqlstr

        End Try
    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobId"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "BerthingDate"
        ElseIf RadioButtonList1.SelectedIndex = 4 Then
            Return "RemainingDays"
        Else
            Return "JobDate"
        End If
    End Function

    Private Sub ApplySort(dv As DataView, Databind As Boolean)



        If dv Is Nothing Then

            If IsNothing(Session("JobCargo")) Then
                Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobCargo As DataTable = Session("JobCargo")
            dv = New DataView(JobCargo)
        End If

        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "BerthingDate" Then
            dv.Sort = "BerthingDate " & tmpstrSort

        ElseIf SortBy = "RemainingDays" Then
            dv.Sort = "RemainingDays " & tmpstrSort
        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridCargo.DataSource = dv
            GridCargo.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub
    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim TEU, Weight, CBM As Double
            Dim TWFT, FTFT As Double

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + Val(dv(a)("TEU"))

                If InStr(dv(a)("PayLoad"), "20", CompareMethod.Text) > 0 Then
                    TWFT = TWFT + 1
                End If

                If InStr(dv(a)("PayLoad"), "40", CompareMethod.Text) > 0 Then
                    FTFT = FTFT + 1
                End If

            Next

            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTEU.Text = Format(TEU, "#,##0")

            TextTotal20ft.Text = Format(TWFT, "#,##0")
            TextTotal40ft.Text = Format(FTFT, "#,##0")
            TextTotalContainers.Text = Format((TWFT + FTFT), "#,##0")

            TextTotalQty.Text = Format(dv.Count, "#,##0")

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption1 = "" Then
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " | " & tmpstr
            Else
                LabelReportCaption.Text = dv.Count & " Cargo Items: " & " " & tmpcaption1 & " | " & tmpstr
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub LoadDestinations(CFPROID As String)
        Dim sqlstr As String =
        "Select Destination From Destinations " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Destination Asc;"

        ComboDestination.Items.Clear()
        Call clsData.PopCombo(ComboDestination, sqlstr, clsData.constr, 0)
        ComboDestination.Items.Insert(0, "(All)")

    End Sub

    Private Sub LoadPayLoads(CFPROID As String)
        Dim sqlstr As String =
        "Select Payload From Payloads " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By Payload Asc;"

        ComboPayload.Items.Clear()
        Call clsData.PopCombo(ComboPayload, sqlstr, clsData.constr, 0)
        ComboPayload.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadReleaseOrderStatus(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ReleaseOrderStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboReleaseOrderStatus.Items.Clear()
        Call clsData.PopCombo(ComboReleaseOrderStatus, sqlstr, clsData.constr, 0)
        ComboReleaseOrderStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadContainerStatuses(CFPROID As String)
        Dim sqlstr As String =
         "Select Status " &
         "From ContainerStatus " &
         "Where CFPROID = '" & CFPROID & "' " &
         "Order by Status Asc;"

        ComboContainerStatus.Items.Clear()
        Call clsData.PopCombo(ComboContainerStatus, sqlstr, clsData.constr, 0)
        ComboContainerStatus.Items.Insert(0, "(All)")
    End Sub

    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadVessels(CFPROID As String)
        Dim sqlstr As String =
        "Select Vessel, VesselID " &
        "From ShippingVessels " &
        "Where CFPROID = '" & CFPROID & "' " &
        "And Active =1 " &
        "Order By Vessel Asc;"

        Call clsData.PopComboWithValue(ComboVessel, sqlstr, clsData.constr, 0, 1)
        ComboVessel.Items.Insert(0, "(All)")

    End Sub
    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub CompoundFilter(containerStatus As Boolean, consignee As Boolean,
                               jobType As Boolean, ROstatus As Boolean, payLoad As Boolean,
                               cfs As Boolean, vessel As Boolean, destination As Boolean, remainingDays As Boolean,
                               ByVal OmitCrossedBorder As Boolean, Optional ByRef ErrMsg As String = "")
        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer


            If IsNothing(Session("JobCargo")) Then
                Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobCargo As DataTable = Session("JobCargo")

            Dim dv As New DataView(JobCargo)
            'dv.Sort = Nothing
            'dv.RowFilter = Nothing


            If containerStatus Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "ContainerStatus Like " & "'%" & Trim(ComboContainerStatus.Text) & "'% "


                tmpstr1(a) = "ContainerStatus: " & ComboContainerStatus.Text
                b = b + 1
            End If

            If consignee Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & Trim(LabelImporterID.Text) & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If jobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                b = b + 1
            End If

            If vessel Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "VesselID = " & "'" & Trim(ComboVessel.Text) & "' "
                Else
                    tmpstr(a) = " And VesselID = " & "'" & ComboVessel.Text & "%=' "
                End If

                tmpstr1(a) = "Vessel: " & ComboVessel.SelectedItem.Text
                b = b + 1
            End If


            If payLoad Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "PayLoad Like " & "'%" & Trim(ComboPayload.Text) & "'% "
                Else
                    tmpstr(a) = " And PayLoad Like " & "'%" & ComboPayload.Text & "'% "
                End If

                tmpstr1(a) = "PayLoad: " & ComboPayload.Text
                b = b + 1
            End If


            'If transporter Then
            '    a = a + 1
            '    ReDim Preserve tmpstr(a), tmpstr1(a)
            '    If b = 0 Then
            '        tmpstr(a) = "TransporterID Like " & "'%" & Trim(ComboTransporter.Text) & "'% "
            '    Else
            '        tmpstr(a) = " And TransporterID Like " & "'%" & ComboTransporter.Text & "'% "
            '    End If

            '    tmpstr1(a) = "Transporter: " & ComboTransporter.Text
            '    b = b + 1
            'End If

            If ROstatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ReleaseOrderStatus Like " & "'%" & Trim(ComboReleaseOrderStatus.Text) & "'% "
                Else
                    tmpstr(a) = " And ReleaseOrderStatus Like " & "'%" & ComboReleaseOrderStatus.Text & "'% "
                End If

                tmpstr1(a) = "Release Order Status: " & ComboReleaseOrderStatus.Text
                b = b + 1
            End If

            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If


            If destination Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "Destination Like " & "'%" & Trim(ComboDestination.Text) & "'% "
                Else
                    tmpstr(a) = " And Destination Like " & "'%" & ComboDestination.Text & "'% "
                End If

                tmpstr1(a) = "Destination: " & ComboDestination.Text
                b = b + 1
            End If

            If cfs Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                b = b + 1
            End If

            If remainingDays Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)

                If ComboRemainingDays.SelectedIndex > 0 Then
                    If ComboRemainingDays.SelectedValue >= 0 Then
                        If b = 0 Then
                            tmpstr(a) = "RemainingDays <= " & "" & Trim(ComboRemainingDays.SelectedValue) & " " &
                                "And RemainingDays >= 0"
                        Else
                            tmpstr(a) = "And RemainingDays <= " & "'" & ComboRemainingDays.SelectedValue & "' " &
                                "And RemainingDays >= 0"
                        End If
                    Else
                        If b = 0 Then
                            tmpstr(a) = "RemainingDays <= " & "" & Trim(ComboRemainingDays.SelectedValue) & " " &
                                "And RemainingDays <= 0"
                        Else
                            tmpstr(a) = "And RemainingDays <= " & "'" & ComboRemainingDays.SelectedValue & "' " &
                                "And RemainingDays <= 0"
                        End If
                    End If
                End If

                tmpstr1(a) = "Demurrage Days: " & ComboRemainingDays.SelectedItem.Text
                b = b + 1
            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2

            GridCargo.DataSource = dv
            GridCargo.DataBind()


            LabelFilterStr.Text = tmpstr2
            LabelReportCaption.Text = dv.Count & " Containers"


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadContainers(CFPROID, CFPROUserID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2



                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadContainers(CFPROID, CFPROUserID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelFilters.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub
    Protected Sub GridCargo_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ClearFilters()
        Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExportToExcel()
    End Sub
    Protected Sub ExportToExcel()

        Dim totals(5) As String

        totals(0) = "Total Weight: " & TextWeight.Text & " (Kgs)"
        totals(1) = "Total CBM: " & TextTotalCbm.Text & " Cb.M"
        totals(2) = "Total TEU: " & TextTotalTEU.Text
        totals(3) = "Total 1x20: " & TextTotal20ft.Text
        totals(4) = "Total 1x40: " & TextTotal40ft.Text
        totals(5) = "Total Containers: " & TextTotalContainers.Text

        Dim tmpfields(0) As String
        If Not CheckMoreColumns.Checked Then
            ReDim tmpfields(13)
            tmpfields(0) = "ReferenceNo"
            tmpfields(1) = "ContainerNo"
            tmpfields(2) = "Payload"
            tmpfields(3) = "Vessel"
            tmpfields(4) = "BerthingDate"
            tmpfields(5) = "CFS"
            tmpfields(6) = "PortExitDate"
            tmpfields(7) = "VehicleNo"
            tmpfields(8) = "Transporter"
            tmpfields(9) = "CrossBorderDate"
            tmpfields(10) = "ReturnDate"
            tmpfields(11) = "ContainerStatus"
            tmpfields(12) = "RemainingDays"
            tmpfields(13) = "DemurrageCharges"

        ElseIf CheckMoreColumns.Checked Then

            ReDim tmpfields(31)
            tmpfields(0) = "ReferenceNo"
            tmpfields(1) = "JobDate"
            tmpfields(2) = "JobType"
            tmpfields(3) = "Client"
            tmpfields(4) = "Importer"
            tmpfields(5) = "Payload"
            tmpfields(6) = "ContainerNo"
            tmpfields(7) = "Weight"
            tmpfields(8) = "CBM"
            tmpfields(9) = "TEU"
            tmpfields(10) = "Vessel"
            tmpfields(11) = "BerthingDate"
            tmpfields(12) = "VoyageNo"
            tmpfields(13) = "ManifestNo"
            tmpfields(14) = "VesselETA"
            tmpfields(15) = "LastSlingDate"
            tmpfields(16) = "PortExitDate"
            tmpfields(17) = "VehicleNo"
            tmpfields(18) = "Transporter"
            tmpfields(19) = "Destination"
            tmpfields(20) = "CrossBorderDate"
            tmpfields(21) = "DestinationArrivalDate"
            tmpfields(22) = "ShippingLine"
            tmpfields(23) = "BL"
            tmpfields(24) = "CFS"
            tmpfields(25) = "StorageDays"
            tmpfields(26) = "StorageCharges"
            tmpfields(27) = "RemainingDays"
            tmpfields(28) = "DemurrageCharges"
            tmpfields(29) = "ReturnDate"
            tmpfields(30) = "InterChangeNo"
            tmpfields(31) = "ContainerStatus"
        End If


        Dim tmptable As DataTable = Session("JobCargo")

        Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Transporter Cargo", "Transporter Cargo",
                                                LabelReportCaption.Text, True, totals, 0, LabelMessage1.Text, tmpfields, Nothing, tmptable, False)



    End Sub


    Protected Sub ButtonEditCargo_Click(sender As Object, e As EventArgs) Handles ButtonEditCargo.Click
        If GridCargo.SelectedIndex >= 0 Then
            Call LoadPage("morecargodetails.aspx?jobcargoid=" & GridCargo.SelectedValue, "More Cargo Details", 550, 780)
        Else
            LabelCargoMessage.Text = "Please Select Cargo Item .."
        End If
    End Sub

    Private Sub LoadPage(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Protected Sub ButtonApplySort0_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilter.Click
        Call CompoundFilter(CheckContainerStatus.Checked, CheckFilterConsignee.Checked,
                                  CheckJobType.Checked, CheckRO.Checked, CheckPayload.Checked,
                                   CheckCFS.Checked, CheckVessel.Checked, CheckDestination.Checked, CheckRemainingDays.Checked,
                                   CheckOmitCrossedBorder.Checked, LabelMessage1.Text)
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub



    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckFilterConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call SearchContainer(Trim(TextSearch.Text))
    End Sub

    Private Sub SearchContainer(SearchStr As String)


        If IsNothing(Session("JobCargo")) Then
            Call LoadContainers(LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If

        Dim JobCargo As New DataTable
        JobCargo = Session("JobCargo")

        Dim dv As New DataView(JobCargo)



        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "'% " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "'% " &
                        "Or ContainerNo Like '%" & Trim(SearchStr) & "'% " &
                        "Or Client Like '%" & Trim(SearchStr) & "'% " &
                        "Or BL Like '%" & Trim(SearchStr) & "'% "






        GridCargo.DataSource = dv
        GridCargo.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching " & " " & Trim(SearchStr)

        Call Calctotal(dv, tmpstr)
    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub


    Protected Sub ComboContainerStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboContainerStatus.SelectedIndexChanged
        CheckContainerStatus.Checked = True
    End Sub

    Protected Sub ComboPayload_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPayload.SelectedIndexChanged
        CheckPayload.Checked = True
    End Sub

    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub

    Protected Sub ComboVessel_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboVessel.SelectedIndexChanged
        CheckVessel.Checked = True
    End Sub


    Protected Sub ComboDestination_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDestination.SelectedIndexChanged
        CheckDestination.Checked = True
    End Sub

    Protected Sub ComboReleaseOrderStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboReleaseOrderStatus.SelectedIndexChanged
        CheckRO.Checked = True
    End Sub


    Protected Sub ComboRemainingDays_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboRemainingDays.SelectedIndexChanged
        CheckRemainingDays.Checked = True
    End Sub
End Class