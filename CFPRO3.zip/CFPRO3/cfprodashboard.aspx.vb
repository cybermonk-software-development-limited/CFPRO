﻿Imports System.Drawing
Public Class cfprodashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            'Call clsSubs.isMobileBrowser()

            'Dim csname1 As String = "dateToday"
            'Dim cstype As Type = Me.GetType()

            Dim CSDID As String = ""
            Dim CFAgentName As String = ""
            Dim CFAgentAddress As String = ""
            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""


            Call clsAuth.UserLogin(CSDID, CFPROID, CFPROUserID, LabelUser.Text, "", LinkSignIn.Text, ImageUser.ImageUrl, "", False, "", True,,,,,, LabelMessage1.Text)

            LabelCSDID.Text = CSDID
            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            LabelAlertCount.Text = "0"
            LabelAlertCount1.Text = "0"
            LabelMessageCount.Text = "0"
            LabelMessageCount1.Text = "0"


            If CFAgentName = "" Then
                LinkCFAgentName.Text = "No C&F Agent Selected"
                LabelCFAgentAddress.Text = ""

                LinkCFAgentName1.Text = "No C&F Agent Selected"
                LabelCFAgentAddress1.Text = ""

                LinkCFAgentName2.Text = "No C&F Agent Selected"
                LabelCFAgentAddress2.Text = ""

                LinkCFAgentName3.Text = "No C&F Agent Selected"
                LabelCFAgentAddress3.Text = " "

                Image0.ImageUrl = "companyplaceholder.png"
                Image1.ImageUrl = "companyplaceholder.png"
                Image2.ImageUrl = "companyplaceholder.png"
                Image3.ImageUrl = "companyplaceholder.png"
            End If

            Dim host As String = HttpContext.Current.Request.Url.Host
            If InStr(host, ".com", CompareMethod.Text) > 0 Then
                host = "http://www.cybermonksd.com/"
            ElseIf InStr(HttpContext.Current.Request.Url.Port.ToString, "95", CompareMethod.Text) > 0 Then
                host = "http://www.cybermonksd.com/"
            Else
                host = "http://" & host & ":84/"
            End If

            HyperLinkPayment.NavigateUrl = host & "productstart.aspx?productid=00004"
            HyperLinkContactUs.NavigateUrl = host & "contactus.aspx"

            Dim UserType As String = ""
            If Not Request.Cookies("UserType") Is Nothing Then
                UserType = Request.Cookies("UserType").Value
            End If

            LabelUserType.Text = UserType

            If UserType = "cfagent" Then
                LabelUserTypeDesc.Text = "C&F Agent Dashboard"

                PanelImporterDashboard.Visible = False
                PanelInsurerDashboard.Visible = False
                PanelInsurerMenu.Visible = False
                PanelTransporterDashBoard.Visible = False
                PanelCFAgentDashboard.Visible = True

                If Not CFPROID = "" Or Not CFPROUserID = "" Then
                    If Not clsAuth.AllowIPAccess(CFPROID, CFPROUserID, "") Then
                        LabelDashboardMessage.Text = "C&F Agent's security settings deny user access to system from current location."
                        LabelDashboardMessage.ForeColor = Color.Red
                    End If
                End If


            ElseIf UserType = "importer" Then
                LabelUserTypeDesc.Text = "Importer Dashboard"
                PanelCFAgentDashboard.Visible = False
                PanelImporterDashboard.Visible = True
                PanelInsurerDashboard.Visible = False
                PanelTransporterDashBoard.Visible = False
                PanelInsurerMenu.Visible = False
                PanelWarning.Visible = False


            ElseIf UserType = "transporter" Then
                LabelUserTypeDesc.Text = "Transporter Dashboard"
                PanelCFAgentDashboard.Visible = False
                PanelImporterDashboard.Visible = False
                PanelInsurerDashboard.Visible = False
                PanelInsurerMenu.Visible = False
                PanelTransporterDashBoard.Visible = True
                PanelWarning.Visible = False

            ElseIf UserType = "insurer" Then
                LabelUserTypeDesc.Text = "Insurer Dashboard"
                PanelCFAgentDashboard.Visible = False
                PanelImporterDashboard.Visible = False
                PanelTransporterDashBoard.Visible = False
                PanelInsurerDashboard.Visible = True
                PanelInsurerMenu.Visible = True
                PanelWarning.Visible = False

            Else
                'PanelCFAgentDashboard.Visible = False
                'PanelImporterDashboard.Visible = False
                'PanelTransporterDashBoard.Visible = False
                'LabelUserTypeDesc.Text = "-"
                Response.Redirect("index.aspx")
                Exit Sub
            End If


            If Not UserType = "insurer" Then
                Call LoadAccounts(LabelCSDID.Text, UserType, "")
            End If



            Call ShowStories()

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If
    End Sub



    Private Sub LoadAccounts(UserCSDID As String, UserType As String, SearchStr As String)
        Try

            Dim tmpstr As String
            If Not SearchStr = "" Then
                tmpstr = "And CFAgentName Like '%" & Trim(SearchStr) & "%'"
            End If

            Dim sqlstr As String = _
                "Select CFPROAccountConnect.CFPROID, CFAgentName," & _
                "CFAgentAddress,CFPROUserID,UserCSDID, " & _
                "UserType, DateAdded, CFPROAccountConnect.ID " & _
                "FROM CFPROAccountConnect, CFPROAccounts  " & _
                "Where  CFPROAccountConnect.CFPROID = CFPROAccounts.CFPROID " & _
                "And  CFPROAccountConnect.UserCSDID = '" & UserCSDID & "' " & _
                "And CFPROAccountConnect.Usertype = '" & UserType & "' " &
                tmpstr

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("Destination", Type.GetType("System.String"))
            Dim col1 As New DataColumn("ImageURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Added", Type.GetType("System.String"))
            Dim col3 As New DataColumn("AuthDet", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)

            Dim a As Integer


            Dim drow As DataRow
            Dim imageurl As String = ""
            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)

                If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFPROID") & ".jpg") Then
                    imageurl = "~/cfagentimages/" & drow("CFPROID") & ".jpg"
                ElseIf IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFPROID") & ".png") Then
                    imageurl = "~/cfagentimages/" & drow("CFPROID") & ".png"
                Else
                    imageurl = "~/cfagentimages/000000000.png"
                End If

                drow("ImageURL") = imageurl


                drow("AuthDet") = drow("CFPROID") & "|" & Trim(drow("CFAgentName")) & "|" & drow("CFPROUserID") & "|" & UserType & "|" & Trim(drow("CFAgentAddress"))
                drow("Added") = "Added: " & Format(drow("DateAdded"), "dd MMMM yyyy")

                a = a + 1
            Next

            Dim nUserType As String = ""
            If LCase(UserType) = "cfagent" Then
                nUserType = "User"
            End If

            LabelAddCFAgent.Text = "Request your '" & clsSubs.Capitalise(nUserType) & " Access Code' from your C&F Agent"

            DataList1.DataSource = tmptable
            DataList1.DataBind()


            If tmptable.Rows.Count > 0 Then
                Dim dv As New DataView(tmptable)
                If dv.Count = 1 Then
                    Call SetCurrentAgent(dv(0)("AuthDet"))
                Else
                    If Not IsNothing(HttpContext.Current.Request.Cookies("CFAgent")) Then
                        Dim nAuthCFAgent As String = HttpContext.Current.Request.Cookies("CFAgent").Value

                        If Not nAuthCFAgent = "" Then

                            Dim tmpstr1() As String = nAuthCFAgent.Split("|")
                            ReDim Preserve tmpstr1(4)

                            dv.RowFilter = "CFPROID = '" & tmpstr1(0) & "' "
                            If dv.Count > 0 Then
                                Call SetCurrentAgent(dv(0)("AuthDet"))
                            Else
                                ModalPopupExtender1.Show()
                            End If
                        Else
                            ModalPopupExtender1.Show()
                        End If
                    Else
                        ModalPopupExtender1.Show()
                    End If
                End If

            Else
                ModalPopupExtender1.Show()
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub


    Protected Sub LinkCFAgentName_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Call SetCurrentAgent(link.CommandArgument.ToString)
    End Sub

    Private Sub SetCurrentAgent(AuthDet As String)

        Dim CFAgentName As String = ""
        Dim CFAgentAddress As String = ""
        Dim CFAgentImageURL As String = ""


        Dim CFPROID As String = ""
        Dim CFPROUserID As String = ""

        Dim AlertCount As String = ""
        Dim MessageCount As String = ""


        Call clsAuth.AuthCFAgent(CFPROID, CFAgentName, CFAgentAddress, CFPROUserID, CFAgentImageURL, AuthDet, False, LabelCSDID.Text, AlertCount, MessageCount)
        LabelCFPROID.Text = CFPROID
        LabelCFPROUserID.Text = CFPROUserID

        LabelAlertCount.Text = AlertCount
        LabelAlertCount1.Text = AlertCount

        LabelMessageCount.Text = MessageCount
        LabelMessageCount1.Text = MessageCount

        If Not AuthDet = "" Then
            Response.Cookies("CFAgent").Value = AuthDet
            Response.Cookies("CFAgent").Expires = Now.AddHours(94)
        End If

        Image0.ImageUrl = CFAgentImageURL
        Image1.ImageUrl = CFAgentImageURL
        Image2.ImageUrl = CFAgentImageURL
        Image3.ImageUrl = CFAgentImageURL

        ModalPopupExtender1.Hide()

        If CFAgentName = "" Then
            LinkCFAgentName.Text = "No C&F Agent Selected"
            LabelCFAgentAddress.Text = ""

            LinkCFAgentName1.Text = "No C&F Agent Selected"
            LabelCFAgentAddress1.Text = ""

            LinkCFAgentName2.Text = "No C&F Agent Selected"
            LabelCFAgentAddress2.Text = ""

            LinkCFAgentName3.Text = "No C&F Agent Selected"
            LabelCFAgentAddress3.Text = " "

        Else


            LinkCFAgentName.Text = CFAgentName
            LabelCFAgentAddress.Text = CFAgentAddress

            LinkCFAgentName1.Text = CFAgentName
            LabelCFAgentAddress1.Text = CFAgentAddress

            LinkCFAgentName2.Text = CFAgentName
            LabelCFAgentAddress2.Text = CFAgentAddress

            LinkCFAgentName3.Text = CFAgentName
            LabelCFAgentAddress3.Text = CFAgentAddress


            If Not CFPROID = "" Or Not CFPROUserID = "" Then
                If Not clsAuth.AllowIPAccess(CFPROID, CFPROUserID, "") Then
                    LabelDashboardMessage.Text = "C&F Agent's security settings deny user access to system from current location."
                    LabelDashboardMessage.ForeColor = Color.Red
                End If
            End If


            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft > 0 Then
                    ImageWarning.ImageUrl = "warning.png"
                    LabelContinueMsg.Text = Daysleft & " Days left. Click 'continue' to proceed ..  "
                    LinkContinue.Enabled = True
                Else
                    ImageWarning.ImageUrl = "noentry.png"
                    LabelContinueMsg.Text = "0 Days left"
                    LinkContinue.ForeColor = Color.Silver
                    LinkContinue.Enabled = False
                End If

                PanelWarning.Visible = True
                PanelCFAgentDashboard.Visible = False
                PanelReason.Visible = False

            Else
                PanelWarning.Visible = False
                PanelReason.Visible = True
            End If

        End If


    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, ImageUser.ImageUrl, True)
    End Sub


    Private Sub ShowCFAgents()
        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender1.Y = 40
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender1.Y = 100
        Else
            ModalPopupExtender1.Y = -1
        End If

        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonAddUser_Click(sender As Object, e As EventArgs) Handles ButtonAddUser.Click

        LabelAddCFAgent.ForeColor = Drawing.Color.Black

        Call clsCFPROAccount.ConnectAccount(Trim(TextUserAccessCode.Text), LabelCSDID.Text, LabelUserType.Text, LabelAddCFAgent.Text)

        If LabelAddCFAgent.Text = "User Added Sucessfully!" Then
            LabelAddCFAgent.ForeColor = Drawing.Color.Green
            TextUserAccessCode.Text = ""
            Call LoadAccounts(LabelCSDID.Text, LabelUserType.Text, "")
        Else
            LabelAddCFAgent.ForeColor = Drawing.Color.Red
            ModalPopupExtender1.Show()
        End If



    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadAccounts(LabelCSDID.Text, LabelUserType.Text, TextSearch.Text)
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub LinkRemoveAgent_Click(sender As Object, e As EventArgs)
        Call RemoveAgent(sender)
    End Sub
    Private Sub RemoveAgent(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ID As Integer = CInt(link.CommandArgument)


        Dim sqlstr As String = _
            "SELECT  ID " &
            "FROM CFPROAccountConnect " &
            "Where  ID = " & ID & " "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("CFPROAccountConnect", tmptable, sqlstr, True, clsData.constr)
            Call LoadAccounts(LabelCSDID.Text, LabelUserType.Text, TextSearch.Text)
            ModalPopupExtender1.Show()
        End If

    End Sub


    Private Sub ShowStories()

        Dim sqlstr As String = _
          "SELECT Top (3) StoryID, " &
          "StoryHeader, ShortDescription," &
          "ImageURL, LastUpdated,ID " &
          "FROM  Stories " &
          "Order By StoryID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            drow("ImageURL") = "~/stories/" & drow("ImageURL")
            a = a + 1
        Next

        DataListStories.DataSource = tmptable
        DataListStories.DataBind()

    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs)
        Dim ImageButn As ImageButton = CType(sender, ImageButton)
        Call Showstory(ImageButn.CommandArgument.ToString)
    End Sub

    Protected Sub LinkHeader_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Call Showstory(link.CommandArgument.ToString)
    End Sub
    Private Sub Showstory(StoryID As String)
        Dim sourcepage As String = "story.aspx?storyid=" & StoryID
        Call LoadDialog(sourcepage, 730, 520)
    End Sub

    Private Sub LoadDialog(sourcepage As String, width As Integer, height As Integer)


        Dim iframebg As String = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit;" &
                "background-position-y: center; background-position-x: center;"

        PanelDialog.Attributes("style") = "width:" & width + 10 & "px; height:" & height + 40 & "px;"

        iframe2.Attributes("style") = "width:" & width & "px ; height:" & height & "px;" & iframebg

        iframe2.Attributes("src") = sourcepage

        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender5.Y = 40
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender5.Y = 100
        Else
            ModalPopupExtender5.Y = -1
        End If

        ModalPopupExtender5.Show()

    End Sub



    Protected Sub LinkContinue_Click(sender As Object, e As EventArgs) Handles LinkContinue.Click
        PanelWarning.Visible = False
        PanelCFAgentDashboard.Visible = True

    End Sub

    Protected Sub ButtonMyCFAgents_Click(sender As Object, e As EventArgs) Handles ButtonMyCFAgents.Click
        Call ShowCFAgents()
    End Sub

    Protected Sub ButtonMyCFAgents1_Click(sender As Object, e As EventArgs) Handles ButtonMyCFAgents1.Click
        Call ShowCFAgents()
    End Sub


    Protected Sub ButtonMyCFAgents2_Click(sender As Object, e As EventArgs) Handles ButtonMyCFAgents2.Click
        Call ShowCFAgents()
    End Sub
End Class