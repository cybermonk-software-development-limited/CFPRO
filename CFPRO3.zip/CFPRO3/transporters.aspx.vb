﻿Imports System.Drawing

Public Class transporters
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call clsSubs.CountryList(ComboCountry)
            Call LoadTransporters(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadTransporters(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And Transporter  Like '%" & Trim(TextSearch.Text) & "%' "
        End If

        Dim sqlstr As String =
              "Select TransporterID, Transporter," &
              "Box,Telephone,Email," &
              "Town,Country,ID " &
              "From  Transporters " &
              "Where CFPROID ='" & CFPROID & "' " &
               tmpstr &
              "Order By ID Desc; "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next



        Session("TransportersTable") = tmptable

        GridTransporters.DataSource = tmptable
        GridTransporters.DataBind()

        If GridTransporters.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridTransporters.Rows.Count - 1 Then
                Rowindex = GridTransporters.Rows.Count - 1
            End If

            GridTransporters.SelectedIndex = Rowindex
            Call ShowTransporter(GridTransporters.SelectedValue)
            Dim row As GridViewRow = GridTransporters.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Transporters found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Transporters"
        End If


    End Sub



    Private Sub ShowTransporter(ID As Integer)

        Dim sqlstr As String =
             "Select TransporterID, Transporter," &
             "Box,Telephone,Email," &
             "Town,Country " &
             "From  Transporters " &
             "Where ID =" & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)

            TextTransporter.Text = drow("Transporter")
            TextAddress.Text = drow("Box")
            TextTelephone.Text = drow("Telephone")
            TextEmailAddress.Text = drow("Email")
            TextTown.Text = drow("Town")

            If drow("Country").ToString.Length > 0 And drow("Country").ToString.Length <= 2 Then
                ComboCountry.Text = Trim(drow("Country"))
            Else
                ComboCountry.SelectedIndex = 0
            End If

            TextTransporterAcessCode.Text = clsEncr.EncryptString(LabelCFPROID.Text & "|" & drow("TransporterID") & "|" & "transporter")

        End If

        LabelMessage.ForeColor = Color.Black
        LabelMessage.Text = ""
    End Sub



    Private Sub NewTransporter(CFPROID As String)
        Try

            Dim TransporterID As String = GetTransporterID()

            Dim sqlstr As String =
                  "Select TransporterID, Transporter," &
                   "CFPROID,Country, ID " &
                   "From  Transporters " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And TransporterID = '" & TransporterID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("TransporterID") = TransporterID
            Drow("CFPROID") = CFPROID
            Drow("Transporter") = "New Transporter " & tmptable.Rows.Count
            Drow("Country") = "KE"



            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Transporters", tmptable, sqlstr, False, clsData.constr)
            Call LoadTransporters(CFPROID, 0, "")


            TextTransporter.Focus()

        Catch exp As Exception
            MsgBox(exp.Message, , "AddTransporter")
        End Try
    End Sub


    Private Function GetTransporterID() As String
        Try

            Dim tmpTransporterID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From Transporters " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpTransporterID = drow("ID")
                tmpTransporterID = tmpTransporterID + 1
                tmpstr = Format(tmpTransporterID, "0000000#")
            Else
                tmpstr = Format(tmpTransporterID, "0000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetTransporterID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridTransporters, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridTransporters.SelectedIndexChanged
        Dim row As GridViewRow = GridTransporters.Rows(GridTransporters.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowTransporter(GridTransporters.SelectedValue)

        For a As Integer = 0 To GridTransporters.Rows.Count - 1
            row = GridTransporters.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridTransporters.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub



    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewTransporter(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveTransporter(LabelCFPROID.Text, GridTransporters.SelectedValue)
    End Sub

    Private Sub SaveTransporter(CFPROID As String, ID As Integer)
        Try
            LabelMessage.ForeColor = Color.Black
            LabelMessage.Text = ""

            If Not Trim(TextEmailAddress.Text) = "" Then
                If Not Trim(TextEmailAddress.Text).Contains("@") Then
                    LabelMessage.Text = "Invalid Email Address"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If

            Dim sqlstr As String =
            "Select TransporterID, Transporter," &
            "Box,Telephone,Email," &
            "Town,Country,ID " &
            "From  Transporters " &
             "Where ID = " & ID & " "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("Transporter") = UCase(Trim(TextTransporter.Text))
                drow("Box") = Trim(TextAddress.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Town") = Trim(TextTown.Text)
                drow("Country") = ComboCountry.Text

                Call clsData.SaveData("Transporters", tmptable, sqlstr, False, clsData.constr)


                Call clsMSDynamicsNAVint.UpdateNAVVendor(CFPROID, "T-", drow("TransporterID"), drow("Transporter"),
                                                         drow("Box"), drow("Town"), drow("Telephone"), drow("Country"), "", LabelMessage1.Text)

            End If



            Call LoadTransporters(CFPROID, GridTransporters.SelectedIndex, TextSearch.Text)

        Catch exp As Exception
            MsgBox(exp.Message, , "AddTransporter")
        End Try
    End Sub


    Private Sub DeleteTransporter(ID As Integer)


        Dim sqlstr As String =
        "Select ID " &
        "From  Transporters " &
        "Where ID =" & ID & " "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Transporters", tmptable, sqlstr, True, clsData.constr)
        Call LoadTransporters(LabelCFPROID.Text, GridTransporters.SelectedIndex - 1, TextSearch.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteTransporter(GridTransporters.SelectedValue)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadTransporters(LabelCFPROID.Text, -1, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadTransporters(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click


        Dim Fields(5) As String
        Fields(0) = "TransporterID"
        Fields(1) = "Transporter"
        Fields(2) = "Email"
        Fields(3) = "Telephone"
        Fields(4) = "Town"
        Fields(5) = "Country"


        Dim Fields1(5) As String
        Fields1(0) = "Transporter ID"
        Fields1(1) = "Transporter"
        Fields1(2) = "Email"
        Fields1(3) = "Telephone"
        Fields1(4) = "Town"
        Fields1(5) = "Country"



        Dim tmptable As New DataTable("TransportersTable")
        tmptable = DirectCast(Session("TransportersTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Transporters", "Transporters",
                                            LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Fields1, tmptable, False)

    End Sub


    Protected Sub ButtonTransporterAccessCode_Click(sender As Object, e As EventArgs) Handles ButtonTransporterAccessCode.Click
        ModalPopupExtender1.Show()
    End Sub
End Class