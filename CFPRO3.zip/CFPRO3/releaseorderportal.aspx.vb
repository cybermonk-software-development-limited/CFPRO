﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing


Public Class releaseorderportal
    Inherits System.Web.UI.Page
    Implements IPostBackEventHandler
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            'Dim imgurl As String = ""
            'Dim CSDID As String = ""
            'Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True)
            'Image1.ImageUrl = imgurl

            Call LoadAgents()
            Call LoadImporters()
            Call LoadCFS()
            Call LoadReleaseorders()

            ButtonExportToExcel1.Attributes("onclick") = ClientScript.GetPostBackEventReference(Me, "ClickDiv")

        End If

    End Sub



    '<----------------------Load Release Orders First Overload to load all release orders without any criteria---------------->
    Private Sub LoadReleaseorders()
        Try
            Dim sqlstr As String =
                    "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFS, CFSID, ID " &
             "From ReleaseOrders"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 10 Then
                PanelReleaseOrders.Height = 300
            Else
                GridReleaseOrders.Height = 20 + (tmptable.Rows.Count * 20)
                PanelReleaseOrders.Height = Nothing
            End If

            Call Calctotal(tmptable, "")

            If CheckBoxAgents.Checked Then
                ComboAgents.Text = "(Selected Agents)"
            ElseIf ComboAgents.Text = "(Selected Agents)" Then
                ComboAgents.Text = ""
            End If

            Dim col As New DataColumn("NavUrl", Type.GetType("System.String"))
            tmptable.Columns.Add(col)

            Dim a As Integer

            For Each drow In tmptable.Rows
                clsData.NullChecker(tmptable, a)
                drow("NavUrl") = "releaseorder.aspx?releaseorderid=" & drow("ReleaseOrderId")
                a = a + 1
            Next

            GridReleaseOrders.DataSource = tmptable
            GridReleaseOrders.DataBind()
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadReleaseorders(Alljobs As Boolean, ByVal selectClients As Boolean, ByVal selectAgents As Boolean, dispatchdate As Boolean)
        Try
            Dim Opdate As String
            'Dim SortBy As String = nSortOrder()

            If dispatchdate Then
                Opdate = "RecordDate "
            Else

            End If

            Opdate = "ReleaseOrderDate"

            Dim tmpstr0, tmpstr1, tmpstr2 As String
            Dim tmpstrdate1, tmpstrdate2 As String
            Dim tmpid As Integer = -1

            tmpstr0 = ""
            tmpstr1 = ""
            tmpstr2 = ""
            tmpstrdate1 = ""
            tmpstrdate2 = ""

            Dim tmpdatecri, tmpdatecri1 As String


            If Not Alljobs Then
                tmpdatecri = Opdate & " >= " & tmpstrdate1 &
                         " And " & Opdate & " <= " & tmpstrdate2

                tmpdatecri1 = "ReleaseOrderDate >= " & tmpstrdate1 &
                    " And ReleaseOrderDate <= " & tmpstrdate2

            Else
                tmpdatecri = "ID >= " & tmpid
                tmpdatecri1 = "ID >= " & tmpid
            End If

            Dim tmpkeepVisible As String
            tmpkeepVisible = " Or KeepVisible = 1 "


            If selectAgents Or selectClients Then
                tmpkeepVisible = ""
            End If

            'Select Case ComboLoadedJobs.Text
            '    Case "Active Jobs"
            '        tmpstr0 = " JobStatus <> '" & "Closed" & "' " &
            '                               " And " & tmpdatecri

            '        If Not dispatchdate Then
            '            tmpstr1 = " Where JobStatus <> '" & "Closed" & "' " &
            '                               " And " & tmpdatecri &
            '                tmpkeepVisible
            '        Else
            '            tmpstr1 = " Where JobStatus <> '" & "Closed" & "' " &
            '                tmpkeepVisible
            '        End If

            '    Case "Active + Closed Jobs"
            '        tmpstr0 = tmpdatecri

            '        If Not dispatchdate Then
            '            tmpstr1 = " Where " & tmpdatecri1 &
            '                tmpkeepVisible
            '        Else
            '            tmpstr1 = " " &
            '                tmpkeepVisible
            '        End If

            '    Case "Closed Jobs"
            '        tmpstr0 = " JobStatus = '" & "Closed" & "' " &
            '                               " And " & tmpdatecri &
            '                tmpkeepVisible

            '        If Not dispatchdate Then
            '            tmpstr1 = " Where JobStatus = '" & "Closed" & "' " &
            '                               " And " & tmpdatecri1 &
            '                tmpkeepVisible
            '        Else
            '            tmpstr1 = " Where JobStatus = '" & "Closed" & "' " &
            '                tmpkeepVisible
            '        End If

            '    Case "Jobs Kept Visible"

            '        tmpstr0 = "  KeepVisible = 1 "
            '        tmpstr1 = "Where  KeepVisible = 1"

            '        If Not dispatchdate Then
            '            tmpstr1 = " Where " & tmpdatecri1 &
            '                tmpkeepVisible
            '        Else
            '            tmpstr1 = " " &
            '                tmpkeepVisible
            '        End If

            'End Select



            Dim tmpstrClientsAgents As String

            If selectClients Then
                Dim tmpstrSel(), tmpclients() As String
                tmpstrSel = clsSubs.SelectedClients()

                Dim n As Integer
                If Not IsNothing(tmpstrSel) Then
                    ReDim Preserve tmpclients(n)
                    LabelROCaption.Text = "Clients: " & Join(tmpstrSel, ", ")
                    For n = 0 To tmpstrSel.GetUpperBound(0)
                        ReDim Preserve tmpclients(n)
                        If n = 0 Then
                            tmpclients(n) = "Client Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                              " And " & tmpstr0
                        Else
                            tmpclients(n) = "Or Client Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                             " And " & tmpstr0
                        End If
                    Next
                    tmpstrClientsAgents = Join(tmpclients, " ")
                    GoTo skipagent
                Else
                    LabelMessage1.Text = "No Clients Selected."
                    Exit Sub
                End If
            Else
                tmpstrClientsAgents = tmpstr0
            End If



            If selectAgents Then
                Dim tmpstrSel(), tmpAgents() As String
                tmpstrSel = clsSubs.SelectedAgents()
                Dim n As Integer
                If Not IsNothing(tmpstrSel) Then
                    ReDim Preserve tmpAgents(n)
                    LabelROCaption.Text = "Agents: " & Join(tmpstrSel, ", ")

                    For n = 0 To tmpstrSel.GetUpperBound(0)
                        ReDim Preserve tmpAgents(n)
                        If n = 0 Then
                            tmpAgents(n) = "Agent Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                              " And " & tmpstr0
                        Else
                            tmpAgents(n) = "Or Agent Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                            " And " & tmpstr0
                        End If
                    Next
                    tmpstrClientsAgents = Join(tmpAgents, " ")
                Else
                    LabelMessage1.Text = "No Agents Selected."
                    Exit Sub
                End If
            Else
                tmpstrClientsAgents = tmpstr0
            End If

skipagent:
            Dim tmpstrSort As String

            'If SortBy = "JobDate" Then
            '    tmpstr2 = tmpkeepVisible &
            '                "Order By JobDate " & tmpstrSort

            'ElseIf SortBy = "ReferenceNo" Then
            '    tmpstr2 = tmpkeepVisible &
            '             "Order By ReferenceNo " & tmpstrSort

            'ElseIf SortBy = "JobId" Then
            '    tmpstr2 = tmpkeepVisible & " " &
            '                  "Order By Id " & tmpstrSort
            'End If


            Dim tmpstr As String = "Where " & tmpstrClientsAgents &
                  " " & tmpstr2


            Dim sqlstr, sqlstr1, sqlstr1a, sqlstr2, sqlstr3 As String
            sqlstr =
                    "Select JobId, ReferenceNo," &
                    "JobDate,Agent,Client,Importer," &
                    "CustomsSystem, BL,CFS,OrderNo,Goods," &
                    "LastSlingDate,Shipper,JobStatus," &
                    "JobPersonnel,Weight,CBM," &
                    "ReleasePersonnel,ReleasedTo, " &
                    "ReleaseDate,DeclarationPersonnel," &
                    "ShippingPersonnel,ShipStatus," &
                    "ShippingVessel,VesselETA," &
                    "BerthingDate,ReturnDate," &
                    "CrossBorderDate,ContainerReturnDays," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,RemainingDays," &
                    "DaysTaken,JobType,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested,ManifestNo," &
                    "ExtensionEndDate,RemainingExtensionDays," &
                    "Quantity,Status," &
                    "ContainerNos, Id " &
                    "From Jobs " &
                     tmpstr

            sqlstr1 = "Select JobId," &
                    "ContainerStatus,Id " &
                    "From JobCargo " &
                     tmpstr1 & " " &
                    "And ContainerStatus <> '" & "Returned" & "' " &
                    "And ContainerStatus <> '" & "Damaged" & "' "

            sqlstr1a = "Select JobId," &
                        "ContainerNo, TEU, ContainerStatus,Id " &
                        "From JobCargo " &
                        tmpstr1

            sqlstr2 =
                    "Select JobId,Status, ID " &
                    "From JobProgress " &
                    tmpstr1 & " " &
                    "Order By Date Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            'Dim tmptableA As New DataTable()
            'Call clsData.TableData(sqlstr3, tmptableA, clsData.constr)

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim tmptable1a As New DataTable()
            Call clsData.TableData(sqlstr1a, tmptable1a, clsData.constr)
            Dim dv As New DataView(tmptable1a)


            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv1 As New DataView(tmptable2)


            'x.Label1.Text = "Computing Visibility..."
            'x.PBar1.Maximum = tmptable.Rows.Count
            'x.Button1.Visible = True



            Dim drow, drow1 As DataRow
            Dim a, b, c As Integer

            Dim tmpdate As Date = Now
            Dim ts As TimeSpan
            Dim found As Boolean
            Dim tmpdate3 As Date
            Dim tmpstr3() As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            tmptable.Columns.Add(col)

            Dim TEU As Double
            Dim tmpclient() As String
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                tmpclient = drow("Client").ToString.Split(vbCrLf)
                ReDim Preserve tmpclient(0)
                drow("Client") = tmpclient(0)


                If CheckAddJobDatetoRef.Checked Then
                    drow("ReferenceNo") = drow("ReferenceNo") & " : " & Format(drow("JobDate"), "dd.MMM.yyyy")
                End If

                Dim tmpstr4() As String = clsShippingStorage.GetVessel(CFAgentCFPROID, drow("VesselID"), LabelMessage1.Text)
                drow("DaysTaken") = clsShippingStorage.DaysTaken(tmpstr(5), drow("DispatchDate"))
                found = False
                tmpdate = Now

                If CDate(drow("BerthingDate")) = CDate("1/Jan/1800") Then
                    drow("RemainingDays") = 0
                Else
                    For Each drow1 In tmptable1.Rows
                        If drow("JobId") = drow1("JobId") Then
                            found = True
                            Exit For
                        End If
                    Next

                    If found Then
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    Else
                        tmpdate = drow("ReturnDate")
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    End If
                End If



                If Not CDate(drow("ExtensionEndDate")) = CDate("1-Jan-1800") Then
                    tmpdate3 = drow("ExtensionEndDate")
                    drow("RemainingExtensionDays") = CInt((tmpdate3.Subtract(CDate(Now)).TotalDays))
                Else
                    drow("RemainingExtensionDays") = "0"
                End If


                dv.RowFilter = "JobId = " & "'" & drow("JobId") & "'"

                c = 0
                TEU = 0
                ReDim tmpstr3(c)
                For b = 0 To dv.Count - 1
                    Call clsData.NullChecker1(dv, b)

                    ReDim Preserve tmpstr3(c)
                    tmpstr3(c) = dv(b)("ContainerNo")
                    c = c + 1

                    TEU = TEU + Val(dv(b)("TEU"))
                Next

                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Quantity") = dv.Count
                drow("TEU") = TEU



                'dv1.RowFilter = "JobId = '" & drow("JobId") & "' "

                'If dv1.Count > 0 Then
                '    drow("Status") = dv1(0)("Status")
                'End If

                For Each drow1 In tmptable2.Rows
                    If drow("JobId") = drow1("JobId") Then
                        drow("Status") = drow1("Status")
                        Exit For
                    End If
                Next


                a = a + 1
                '  x.PBar1.Value = x.PBar1.Value + 1


            Next

            'If tmptable.Rows.Count = 0 Then
            '    drow = tmptable.NewRow
            '    drow("ReferenceNo") = "No Jobs"
            '    tmptable.Rows.Add(drow)
            'End If


            If tmptable.Rows.Count > 10 Then
                PanelReleaseOrders.Height = 500
            Else
                GridReleaseOrders.Height = 20 + (tmptable.Rows.Count * 20)
                PanelReleaseOrders.Height = 500
            End If



            'If Not dispatchdate Then
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'Else
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " DISPATCHED Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'End If

            Call Calctotal(tmptable, "")

            If CheckBoxAgents.Checked Then
                ComboAgents.Text = "(Selected Agents)"
            ElseIf ComboAgents.Text = "(Selected Agents)" Then
                ComboAgents.Text = ""
            End If

            GridReleaseOrders.DataSource = tmptable
            GridReleaseOrders.DataBind()





        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ExportToExcel()

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = GridReleaseOrders.Columns.Count
        Dim totalRows = GridReleaseOrders.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = GridReleaseOrders.Columns(col1 - 2).HeaderText
        Next

        workSheet.Cells("B3:I3").Merge = True
        workSheet.Cells("B4:I4").Merge = True

        workSheet.Cells("B3:I3").Style.Font.Size = 14
        workSheet.Cells("B4:I4").Style.Font.Size = 9
        workSheet.Cells("B3:I4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = LabelCFAgent.Text & " - Release Orders"
        workSheet.Cells(4, 2).Value = LabelROCaption.Text

        Dim row1 As GridViewRow
        Dim row As Integer
        For row = 5 To totalRows + 4
            row1 = GridReleaseOrders.Rows(row - 5)
            For col1 As Integer = 1 To totalCols
                workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1 - 1).Text
                If row1.Cells(col1 - 1).Text = "&nbsp;" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next


        Next

        Using rng As ExcelRange = workSheet.Cells("B5:I" & GridReleaseOrders.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:I5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":I" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        'workSheet.Cells("C" & row & ":D" & row).Merge = True
        'workSheet.Cells("E" & row & ":F" & row).Merge = True
        'workSheet.Cells("G" & row & ":I" & row).Merge = True
        'workSheet.Cells("J" & row & ":K" & row).Merge = True

        'workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        'workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        'workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        'workSheet.Cells("J" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Release Order Report " & Format(Now, "dd-MMM-yyyy hh:mm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub
    Private Sub LoadAgents()
        Dim sqlstr As String =
        "Select Agent From Agents " &
        "Order By Agent Asc;"
        ComboAgents.Items.Add("(All)")
        Call clsData.PopCombo(ComboAgents, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadImporters()
        Dim sqlstr As String =
        "Select Importer From Importers " &
        "Order By Importer Asc;"
        ComboImporters.Items.Add("(All)")
        Call clsData.PopCombo(ComboImporters, sqlstr, clsData.constr, 0)
    End Sub
    Private Sub LoadCFS()
        Dim sqlstr As String =
        "Select CFS " &
        "From CFS"
        ComboCFS.Items.Add("(All)")
        Call clsData.PopCombo(ComboCFS, sqlstr, clsData.constr, 0)
    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToReleaseOrder.Click
        Call GoToReleaseOrder()
    End Sub
    Private Sub GoToReleaseOrder()
        If GridReleaseOrders.SelectedIndex >= 0 Then
            Response.Redirect("releaseorder.aspx?releaseOrderId=" & GridReleaseOrders.SelectedValue.ToString())
        Else
            Response.Redirect("releaseorder.aspx")
        End If
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()
        'Dim a As Integer = GridJobs.SelectedValue.ToString
        'Dim selected As Boolean
        'If a >= 0 Then
        '    selected = GridJobs.SelectedIndex
        'End If

        Call ClearFilters()
        'Call LoadReleaseorders(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked)


        '  GridJobs.SelectedIndex = a

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelReleaseOrders.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    GoTo skip
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    GoTo skip
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    GoTo skip
                End If

                If cont.ID = "CheckSelectedClients" Then
                    GoTo skip
                End If

                If cont.ID = "CheckShowBL" Then
                    GoTo skip
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    GoTo skip
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    GoTo skip
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If
skip:
        Next
    End Sub



    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try

            Dim dv As DataView = tmptable.DefaultView
            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)
                Qty = 0
                'Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")
            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If LabelROCaption.Text = "" And tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelROCaption.Text = dv.Count & " Jobs: " &
                                     " | " & tmpstr
                Else
                    LabelROCaption.Text = dv.Count & " DISPATCHED JOBS: " &
                                      " | " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelROCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelROCaption.Text = dv.Count & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Importer As Boolean, ByVal CFS As Boolean)

        Try
            Dim sqlstr As String =
                    "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFS, CFSID, ID " &
             "From ReleaseOrders"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer
            Dim dv As New DataView(tmptable)
            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                dv.RowFilter = "Signatory LIKE '%" & Trim(ComboAgents.Text) & "%'"
                If Not CheckBoxAgents.Checked Then
                    ReDim Preserve tmpstr(a), tmpstr1(a)
                    tmpstr(a) = "Agent Like '%" & Trim(ComboAgents.Text) & "%' "
                    tmpstr1(a) = "Agent: " & ComboAgents.Text
                    b = b + 1
                End If

            End If



            If Importer Then
                dv.RowFilter = "Importer LIKE '%" & Trim(ComboImporters.Text) & "%'"
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "Importer Like '%" & Trim(ComboImporters.Text) & "%' "
                Else
                    tmpstr(a) = " And Importer Like '%" & ComboImporters.Text & "%' "
                End If

                tmpstr1(a) = "Consignee: " & ComboImporters.Text
                b = b + 1
            End If

            If CFS Then
                dv.RowFilter = "CFS LIKE '%" & Trim(ComboCFS.Text) & "%'"
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFS Like '%" & Trim(ComboCFS.Text) & "%' "
                Else
                    tmpstr(a) = " And CFS Like '%" & ComboCFS.Text & "%' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.Text
                b = b + 1
            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")

            If Not CheckDispatchDate.Checked Then
                LabelROCaption.Text = dv.Count & " Jobs: " & tmpstr3 & " | "
            Else
                LabelROCaption.Text = dv.Count & " DISPATCHED Jobs: " & tmpstr3 & " | "
            End If

            'Call Calctotal(tm)

            GridReleaseOrders.DataSource = dv
            GridReleaseOrders.DataBind()

            

        Catch exp As Exception
            LabelROCaption.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridReleaseOrders.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridReleaseOrders.SelectedValue.ToString)
        End If

    End Sub

    Private Sub SelectAgents()
        Response.Redirect("selectedclients.aspx")

    End Sub



    Private Sub SelectClients()
        Response.Redirect("selectedclients.aspx")
    End Sub

    Private Sub AppendJobDate(Append As Boolean)
        Dim dv As DataView = GridReleaseOrders.DataSource
        If Not IsNothing(dv) Then
            Dim a As Integer
            Dim tmpstr(1)
            For a = 0 To dv.Count - 1
                tmpstr = dv(a)("ReferenceNo").ToString.Split(":")
                ReDim Preserve tmpstr(1)
                If Append Then
                    dv(a)("ReferenceNo") = Trim(tmpstr(0)) & " : " & Format(dv(a)("JobDate"), "dd.MMM.yyyy")
                Else
                    dv(a)("ReferenceNo") = Trim(tmpstr(0))
                End If
            Next


        End If
    End Sub

    Private Sub SaveSettings()
        Dim tmptable As New DataTable()
        Call clsData.TableData("", tmptable, clsData.constr)
        Dim drow As DataRow = tmptable.Rows(0)
        'drow("SortJobsBy") = ComboSortOrder.Text
        'drow("SortOrder") = nSortOrder()
        drow("AddJobDatetoRef") = CheckAddJobDatetoRef.Checked

        Call clsData.SaveData("Environment", tmptable, "", False, clsData.constr)
    End Sub




    'Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs)
    '    Call ExportToExcel()
    'End Sub
    Protected Sub ButtonExportToExcel_Click()
        Call ExportToExcel()
    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click

        Call CompoundFilter(CheckBoxAgents.Checked, CheckBoxImporters.Checked, CheckBoxCFS.Checked)
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click

        Call CompoundFilter(CheckBoxAgents.Checked, CheckBoxImporters.Checked, CheckBoxCFS.Checked)
    End Sub

    Protected Sub GridReleaseOrders_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridReleaseOrders.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridReleaseOrders, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub GridReleaseOrders_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridReleaseOrders.SelectedIndexChanged
        Dim row As GridViewRow = GridReleaseOrders.Rows(GridReleaseOrders.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridReleaseOrders.Rows.Count - 1
            row = GridReleaseOrders.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridReleaseOrders.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub ButtonDownloadPDF_Click(sender As Object, e As EventArgs) Handles ButtonDownloadPDF.Click
        If GridReleaseOrders.SelectedIndex >= 0 Then
            Call DownloadReleaseOrderPDF("Release Order " & Format(Now, "dd-MMM-yyyy hh:mm:ss tt") & ".pdf")
        Else
            LabelMessage1.Text = "Please Select a Release Order from the List above"
        End If
    End Sub
    Private Sub DownloadReleaseOrderPDF(fileName As String)
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"
        Response.AddHeader("Content-Disposition", "attachment; filename=" & fileName)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Buffer = True
        Response.BinaryWrite(clsReleaseOrderPDF.ReleaseOrderDoc(fileName, GridReleaseOrders.SelectedValue, LabelUser.Text))
        Response.End()
        Response.Flush()
        Response.Clear()
        Response.Close()

    End Sub

    Protected Sub ButtonEmailPDF_Click(sender As Object, e As EventArgs) Handles ButtonEmailPDF.Click
        If GridReleaseOrders.SelectedIndex >= 0 Then
            Call EmailReleaseOrderPDF("Release Order " & Format(Now, "dd-MMM-yyyy hh:mm:ss tt") & ".pdf")
        Else
            LabelMessage3.Text = "Please Select a Release Order from the List above"
        End If
    End Sub
    Private Sub EmailReleaseOrderPDF(fileName As String)
        Dim msgAttachment As Byte() = clsReleaseOrderPDF.ReleaseOrderEmail(fileName, GridReleaseOrders.SelectedValue, LabelUser.Text)
        Dim msgSender As String = "wssilverpg@gmail.com"
        Dim msgReceiver As String = "wssilverpg@gmail.com"
        Dim msgSubject As String = "RELEASE ORDER"

        Dim msgBody As String = "Attached please a copy of the release order you requested for."
        Response.Redirect("mail1.aspx?msgSender=" & msgSender & "&msgReceiver=" & msgReceiver & "&msgSubject=" & msgSubject & "&msgBody=" & msgBody &
                              "&itemId=" & GridReleaseOrders.SelectedValue & "&userName=" & LabelUser.Text & "&attachmentName=" & fileName)
    End Sub

    Public Sub RaisePostBackEvent(eventArgument As String) Implements IPostBackEventHandler.RaisePostBackEvent
        If Not String.IsNullOrEmpty(eventArgument) Then

            If eventArgument = "ClickDiv" Then
                Call ButtonExportToExcel_Click()
            End If
        End If
    End Sub
End Class