﻿Imports System.Drawing

Public Class vesselstatus
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadVesselStatus(CFPROID, "")

        End If

    End Sub

    Private Sub LoadVesselStatus(ByVal CFPROID As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And VesselStatus Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select " &
                              "Status,ID " &
                              "From  VesselStatus " &
                              "Where CFPROID ='" & CFPROID & "' " &
                              tmpstr &
                              "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridVesselStatus.DataSource = tmptable
            GridVesselStatus.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Vessel Status"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingVesselStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridVesselStatus.SelectedIndexChanged
        Dim row As GridViewRow = GridVesselStatus.Rows(GridVesselStatus.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridVesselStatus.Rows.Count - 1
            row = GridVesselStatus.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridVesselStatus.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingVesselStatus_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridVesselStatus.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridVesselStatus, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call FunctionAddEditVesselStatus(LabelCFPROID.Text, True)
    End Sub
    Private Sub FunctionAddEditVesselStatus(CFPROID As String, Edit As Boolean)
        Try
            If Edit Then
                If GridVesselStatus.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select Vessel Status."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit VesselStatus"
                Dim ID As Integer = GridVesselStatus.SelectedValue
                Dim sqlstr As String = "SELECT Status,ID " &
                                        "From  VesselStatus " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)


                    TextAddEdit.Text = drow("Status")


                End If

            Else
                LabelAddEdit.Text = "Add Vessel Status"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call FunctionAddEditVesselStatus(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveVesselStatus(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveVesselStatus(CFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If VesselStatusExists(CFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridVesselStatus.SelectedIndex >= 0 Then
                    ID = GridVesselStatus.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT Status, CFPROID, ID " &
                                    "From  VesselStatus " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Status") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("VesselStatus", tmptable, sqlstr, False, clsData.constr)

            Call LoadVesselStatus(CFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function VesselStatusExists(CFPROID As String, VesselStatus As String) As Boolean


        Dim sqlstr As String = "SELECT Status " &
                                "From  VesselStatus " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And VesselStatus = " & Trim(VesselStatus) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridVesselStatus.SelectedIndex >= 0 Then
            Call PromptDeleteVesselStatus(GridVesselStatus.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Vessel Status to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteVesselStatus(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridVesselStatus.Rows(GridVesselStatus.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteVesselStatus(GridVesselStatus.SelectedValue)
    End Sub
    Private Sub DeleteVesselStatus(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From VesselStatus  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("VesselStatus", tmptable, sqlstr, True, clsData.constr)

            Call LoadVesselStatus(LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetVesselStatusID() As String
    '    Try

    '        Dim tmpVesselStatusID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From VesselStatus " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpVesselStatusID = drow("ID")
    '            tmpVesselStatusID = tmpVesselStatusID + 1
    '            tmpstr = Format(tmpVesselStatusID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpVesselStatusID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadVesselStatus(LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadVesselStatus(LabelCFPROID.Text, "")
    End Sub



End Class