﻿Imports System.Net

Public Class signin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            LabelMessage1.Text = ""


            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            Dim UserType As String = ""
            If Request.Cookies("UserType") Is Nothing Then
                UserType = ""
            Else
                UserType = Request.Cookies("UserType").Value
            End If


            Call clsAuth.UserLoggedIn("", "", LabelCFPROUserID.Text, "", "", "", "", "", False, "", False)



        End If


    End Sub

  
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call SignIn(Trim(TextEmailAddress.Text), Trim(TextPassword.Text))
    End Sub

    Private Sub SignIn(emailaddress As String, password As String)
        Try
            LabelMessage.ForeColor = Drawing.Color.Black

            Dim IsCaptchaValid As Boolean

            If Panel1.Visible Then
                Dim RecaptchaResponse As String = Request.Form("g-Recaptcha-Response")
                IsCaptchaValid = clsReCaptcha.ValidateReCaptcha("6LcrMkwUAAAAAKjEdh9H5eIQL1VZQKEZHgjimDo5", RecaptchaResponse, "")
            Else
                IsCaptchaValid = True
            End If


            If IsCaptchaValid Then

                If Len(emailaddress & password) < 300 Then
                    Dim sqlstr As String = _
                                      "Select CSDID,EmailAddress," & _
                                      "Password,LastSignIn, ID " & _
                                      "From UserAccounts " & _
                                      "Where EmailAddress = '" & emailaddress & "' "

                    Dim tmptable As New DataTable
                    Call clsData.Tabledata(sqlstr, tmptable, clsData.constr)

                    Dim drow As DataRow
                    If tmptable.Rows.Count > 0 Then
                        password = clsEncr.EncryptString(password)
                        drow = tmptable.Rows(0)
                        Call clsData.NullChecker(tmptable, 0)

                        If drow("Password") = password Then
                            drow("LastSignIn") = Format(Now, "dd-MMM-yyyy hh:mm tt")
                            Call clsData.SaveData("UserAccounts", tmptable, sqlstr, False, clsData.constr)

                            Response.Cookies("CSDID").Value = clsEncr.EncryptString(drow("CSDID"))
                            ' Response.Cookies("CSDID").Expires = DateTime.Now.AddDays(100)

                            If LabelFromPageURL.Text = "" Or InStr(LabelFromPageURL.Text, "signin", CompareMethod.Text) > 0 _
                                          Or InStr(LabelFromPageURL.Text, "signup", CompareMethod.Text) > 0 _
                                          Or InStr(LabelFromPageURL.Text, ":84/index", CompareMethod.Text) > 0 _
                                          Or InStr(LabelFromPageURL.Text, "sd.com/index", CompareMethod.Text) > 0 Then
                                Response.Redirect("userprofile.aspx")
                            Else
                                If InStr(LabelFromPageURL.Text, "cfpro", CompareMethod.Text) > 0 _
                                    Or InStr(LabelFromPageURL.Text, "localhost:90", CompareMethod.Text) > 0 _
                                    Or InStr(LabelFromPageURL.Text, "172.16.254.10", CompareMethod.Text) > 0 Then
                                    Response.Redirect(LabelFromPageURL.Text & "?gotooption=" & HttpUtility.UrlEncode(Request.QueryString("gotooption")) & "&logintoken=" & HttpUtility.UrlEncode(clsEncr.EncryptString(clsAuth.Logintoken(drow("CSDID")))))
                                Else
                                    Response.Redirect(LabelFromPageURL.Text)
                                End If
                            End If
                        Else
                            LabelMessage.Visible = True
                            LabelMessage.Text = "Invalid Email Address or password."
                            LabelMessage.ForeColor = Drawing.Color.Red
                            LabelFailCount.Text = Val(LabelFailCount.Text) + 1
                            If Val(LabelFailCount.Text) > 3 Then
                                Panel1.Visible = True
                            End If
                        End If
                    Else
                        LabelMessage.Visible = True
                        LabelMessage.Text = "Invalid Email Address or password."
                        LabelMessage.ForeColor = Drawing.Color.Red
                    End If
                Else
                    LabelMessage.Visible = True
                    LabelMessage.Text = "Invalid Email Address or password!"
                    LabelMessage.ForeColor = Drawing.Color.Red
                End If
            Else
                LabelMessage.Text = "Robot Test FAIL! Try again."
                LabelMessage.ForeColor = Drawing.Color.Red
            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

End Class