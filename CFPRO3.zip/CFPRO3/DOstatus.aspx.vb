﻿Imports System.Drawing

Public Class DOstatus
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then



            Dim CFAgentCFPROID As String = ""
            Call clsAuth.UserLoggedIn("", CFAgentCFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFAgentCFPROID.Text = CFAgentCFPROID

            Call LoadDeliveryOrderStatus(CFAgentCFPROID, "")

        End If

    End Sub

    Private Sub LoadDeliveryOrderStatus(ByVal CFAgentCFPROID As String, SearchStr As String)

        Try




            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Status Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select " &
                              "Status,ID " &
                              "From  DeliveryOrderStatus " &
                              "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' " &
                              tmpstr &
                              "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridDeliveryOrderStatus.DataSource = tmptable
            GridDeliveryOrderStatus.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Delivery Order Status"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingDeliveryOrderStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridDeliveryOrderStatus.SelectedIndexChanged
        Dim row As GridViewRow = GridDeliveryOrderStatus.Rows(GridDeliveryOrderStatus.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridDeliveryOrderStatus.Rows.Count - 1
            row = GridDeliveryOrderStatus.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridDeliveryOrderStatus.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingDeliveryOrderStatus_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridDeliveryOrderStatus.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridDeliveryOrderStatus, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditStatus(LabelCFAgentCFPROID.Text, True)
    End Sub
    Private Sub AddEditStatus(CFAgentCFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridDeliveryOrderStatus.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select Delivery Order Status."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Status"
                Dim ID As Integer = GridDeliveryOrderStatus.SelectedValue
                Dim sqlstr As String = "SELECT Status,ID " &
                                        "From  DeliveryOrderStatus " &
                                        "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("Status")
                End If

            Else
                LabelAddEdit.Text = "Add Delivery Order Status"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditStatus(LabelCFAgentCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveStatus(LabelCFAgentCFPROID.Text, Edit)
    End Sub

    Private Sub SaveStatus(CFAgentCFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If StatusExists(CFAgentCFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridDeliveryOrderStatus.SelectedIndex >= 0 Then
                    ID = GridDeliveryOrderStatus.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT Status, CFAgentCFPROID, ID " &
                                    "From  DeliveryOrderStatus " &
                                    "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFAgentCFPROID") = CFAgentCFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Status") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("DeliveryOrderStatus", tmptable, sqlstr, False, clsData.constr)

            Call LoadDeliveryOrderStatus(CFAgentCFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function StatusExists(CFAgentCFPROID As String, Status As String) As Boolean


        Dim sqlstr As String = "SELECT Status " &
                                "From  DeliveryOrderStatus " &
                                "Where CFAgentCFPROID ='" & CFAgentCFPROID & "' " &
                                "And Status = " & Trim(Status) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridDeliveryOrderStatus.SelectedIndex >= 0 Then
            Call PromptDeleteStatus(GridDeliveryOrderStatus.SelectedValue, LabelCFAgentCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Delivery Order Status to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteStatus(ID As Integer, CFAgentCFPROID As String)


        Dim row As GridViewRow = GridDeliveryOrderStatus.Rows(GridDeliveryOrderStatus.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteStatus(GridDeliveryOrderStatus.SelectedValue)
    End Sub
    Private Sub DeleteStatus(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From DeliveryOrderStatus  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("DeliveryOrderStatus", tmptable, sqlstr, True, clsData.constr)

            Call LoadDeliveryOrderStatus(LabelCFAgentCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetStatusID() As String
    '    Try

    '        Dim tmpStatusID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From DeliveryOrderStatus " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpStatusID = drow("ID")
    '            tmpStatusID = tmpStatusID + 1
    '            tmpstr = Format(tmpStatusID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpStatusID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadDeliveryOrderStatus(LabelCFAgentCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadDeliveryOrderStatus(LabelCFAgentCFPROID.Text, "")
    End Sub



End Class