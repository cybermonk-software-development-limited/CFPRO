﻿
Imports System.Drawing
Public Class verification
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFAgentUserName As String = ""
            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, CFAgentUserName, "", "", "", "", True, "", False)

            LabelCFPROID.Text = CFPROID

            Call LoadCFAgentUsers(CFPROID)
            Call LoadVerification(CFPROID, CFAgentUserName)


            Dim ReadOnlyUser As Boolean = Not clsAuth.ReadOnlyUser(CFPROID, CFPROUserID)

            ButtonGetCFS.Enabled = ReadOnlyUser
            ButtonAdd.Enabled = ReadOnlyUser
            ButtonEdit.Enabled = ReadOnlyUser
            ButtonRemove.Enabled = ReadOnlyUser
            ButtonSave.Enabled = ReadOnlyUser

        End If
    End Sub


    Private Sub LoadVerification(CFPROID As String, CFAgentUserName As String)
        Try
            Dim JobID As String = Request.QueryString("jobid")

            Dim sqlstr As String =
               "Select JobID,JobTypeID," &
               "CFSID,ClientID,VesselID," &
               "CFSChargesPaidDate,VerificationPersonnel," &
               "VerificationStart,VerificationEnd, " &
               "CFSEntryDate,DateClearedOut, ID " &
               "From Jobs " &
               "Where JobId ='" & JobID & "' " &
               "And CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)



                Call clsData.NullChecker(tmptable, 0)
                LabelCFSID.Text = drow("CFSID")
                Dim JobType As String = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

                LabelClientID.Text = drow("ClientID")
                LabelJobType.Text = JobType
                LabelJobID.Text = drow("JobID")
                LabelCFSID.Text = drow("CFSID")


                TextVericationStart.Text = Format(drow("VerificationStart"), "dd MMM yyyy")
                TextVericationEnd.Text = Format(drow("VerificationEnd"), "dd MMM yyyy")
                ComboPersonnel.Text = drow("VerificationPersonnel")
                TextCFSChargesPaidDate.Text = Format(drow("CFSChargesPaidDate"), "dd MMM yyyy")
                TextCFSEntryDate.Text = Format(drow("CFSEntryDate"), "dd MMM yyyy")
                TextDateClearedOut.Text = Format(drow("DateClearedOut"), "dd MMM yyyy")

                Dim ts As TimeSpan
                If IsDate(drow("DateClearedOut")) And IsDate(drow("CFSEntryDate")) Then
                    ts = CDate(drow("DateClearedOut")).Subtract(drow("CFSEntryDate"))
                    TextDaysatCFS.Text = ts.Days
                Else
                    TextDaysatCFS.Text = -1
                End If


                Dim tmpstr() As String = clsShippingStorage.GetVessel(CFPROID, drow("VesselID"), "")

                Call CFS(CFPROID, drow("CFSID"), tmpstr(5), drow("ClientID"), JobType)

                Call LoadVerifiedBy(CFPROID, JobID)

                If CDate(TextVericationStart.Text) = CDate("1-Jan-1800") Then
                    TextVericationStart.Text = Format(Now, "dd MMM yyyy")
                    ComboPersonnel.Text = CFAgentUserName
                End If


            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub
    Private Sub CFS(CFPROID As String, CFSDID As String, LastslingDate As String, ClientID As String, JobType As String)
        Try
            Dim tmpstr() As String = clsShippingStorage.GetCFS(CFPROID, CFSDID, ClientID, JobType)
            ReDim Preserve tmpstr(2)

            LabelCFSID.Text = CFSDID
            LabelLastslingDate.Text = LastslingDate

            TextCFS.Text = tmpstr(1)
            TextFreeStorageDays.Text = tmpstr(2)



            If IsDate(LastslingDate) Then
                If CDate(LastslingDate) = CDate("1 Jan 1800") Then
                    TextStorageStartDate.Text = "1 Jan 1800"
                Else
                    Dim tmpdate As Date = CDate(LastslingDate).AddDays(CInt(tmpstr(2)))
                    TextStorageStartDate.Text = Format(tmpdate, "dd MMM yyyy")
                End If
            Else
                TextStorageStartDate.Text = "1 Jan 1800"
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Private Sub LoadVerifiedBy(ByVal CFPROID As String, JobID As String)

        Try


            Dim sqlstr As String = "SELECT VerifiedBy, VerificationStart," &
                                          "VerificationEnd, Remarks," &
                                          "JobID,CFPROID, ID " &
                                          "From  Verification " &
                                          "Where CFPROID ='" & CFPROID & "' " &
                                          "And JobID = '" & JobID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            LabelVerificationCaption.Text = tmptable.Rows.Count & "  Verifiers"

            Dim a As Integer
            Dim drow As DataRow

            If tmptable.Rows.Count = 0 Then

                drow = tmptable.NewRow
                drow("VerifiedBy") = "No Verification Done"
                tmptable.Rows.Add(drow)
            End If

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next

            GridVerification.DataSource = tmptable
            GridVerification.DataBind()




        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveVerification(LabelCFPROID.Text)
    End Sub

    Private Sub SaveVerification(CFPROID As String)

        Try
            Dim JobId As String = Request.QueryString("Jobid")

            Dim sqlstr As String =
               "Select JobId,CFSID," &
               "CFSChargesPaidDate,VerificationPersonnel," &
               "VerificationStart,VerificationEnd," &
               "CFSEntryDate,DateClearedOut, ID " &
               "From Jobs " &
               "Where JobId ='" & JobId & "' " &
               "And CFPROID ='" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)

                drow("CFSID") = LabelCFSID.Text
                drow("VerificationStart") = TextVericationStart.Text
                drow("VerificationEnd") = TextVericationEnd.Text
                drow("CFSChargesPaidDate") = TextCFSChargesPaidDate.Text
                drow("VerificationPersonnel") = ComboPersonnel.Text

                drow("CFSEntryDate") = TextCFSEntryDate.Text
                drow("DateClearedOut") = TextDateClearedOut.Text

                Dim ts As TimeSpan
                If IsDate(drow("DateClearedOut")) And IsDate(drow("CFSEntryDate")) Then
                    ts = CDate(drow("DateClearedOut")).Subtract(drow("CFSEntryDate"))
                    TextDaysatCFS.Text = ts.Days
                Else
                    TextDaysatCFS.Text = -1
                End If

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)
                tmptable.AcceptChanges()




                'x.Close()
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr1 As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPersonnel, sqlstr1, clsData.constr, 0)

        ComboPersonnel.Items.Insert(0, "")
    End Sub




    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditVerifiedBy(LabelCFPROID.Text, False)
    End Sub
    Protected Sub GridVerification_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridVerification.SelectedIndexChanged
        Dim row As GridViewRow = GridVerification.Rows(GridVerification.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridVerification.Rows.Count - 1
            row = GridVerification.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridVerification.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridVerification_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridVerification.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridVerification, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnRowDataBound1(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCFS, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged1(sender As Object, e As EventArgs) Handles GridCFS.SelectedIndexChanged
        Dim row As GridViewRow = GridCFS.Rows(GridCFS.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridCFS.Rows.Count - 1
            row = GridCFS.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridCFS.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditVerifiedBy(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditVerifiedBy(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridVerification.SelectedIndex < 0 Then
                    LabelMessage3.Text = "Please Select Verification"
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Verification"
                Dim ID As Integer = GridVerification.SelectedValue

                Dim sqlstr As String = "SELECT VerifiedBy, VerificationStart," &
                                        "VerificationEnd, Remarks," &
                                        "JobID,CFPROID, ID " &
                                        "From  Verification " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    ComboVerifiedBy.Text = drow("VerifiedBy")
                    TextVerificationStart.Text = Format(drow("VerificationStart"), "dd MMM yyyy")
                    TextVerificationEnd.Text = Format(drow("VerificationEnd"), "dd MMM yyyy")
                    TextRemarks.Text = drow("Remarks")
                End If

            Else
                LabelAddEdit.Text = "Add Verification"
                ComboVerifiedBy.Text = ""
                TextVerificationStart.Text = Format(Now, "dd MMM yyyy")
                TextVerificationEnd.Text = Format(Now, "dd MMM yyyy")
                TextRemarks.Text = "OK"

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSave0_Click(sender As Object, e As EventArgs) Handles ButtonSave0.Click
        Call SaveVerifiedBy(LabelCFPROID.Text, LabelJobID.Text, ComboVerifiedBy.Text)
    End Sub

    Private Sub SaveVerifiedBy(CFPROID As String, JobID As String, VerifiedBy As String)

        Try
            Dim sqlstr As String = "SELECT VerifiedBy, VerificationStart," &
                                        "VerificationEnd, Remarks," &
                                        "JobID,CFPROID, ID " &
                                        "From  Verification " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And VerifiedBy = '" & VerifiedBy & "' " &
                                        "And JobID = " & JobID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("JobID") = JobID
                drow("VerifiedBy") = VerifiedBy
                tmptable.Rows.Add(drow)
            End If

            If IsDate(Trim(TextVerificationStart.Text)) Then
                drow("VerificationStart") = TextVerificationStart.Text
            End If

            If IsDate(Trim(TextVerificationEnd.Text)) Then
                drow("VerificationEnd") = Trim(TextVerificationEnd.Text)
            End If

            drow("Remarks") = UCase(Trim(TextRemarks.Text))

            Call clsData.SaveData("Verification", tmptable, sqlstr, False, clsData.constr)

            Call LoadVerifiedBy(CFPROID, LabelJobID.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function VerificationExists(CFPROID As String, VerifiedBy As String) As Boolean

        Dim sqlstr As String = "SELECT VerifiedBy " &
                                "From  Verification " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And VerifiedBy = " & Trim(VerifiedBy) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If

    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridVerification.SelectedIndex >= 0 Then
            Call PromptDeleteVerification(GridVerification.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage3.Text = "No Selection"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteVerification(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridVerification.Rows(GridVerification.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True


        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteVerification(GridVerification.SelectedValue)
    End Sub
    Private Sub DeleteVerification(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From Verification  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("Verification", tmptable, sqlstr, True, clsData.constr)

            Call LoadVerifiedBy(LabelCFPROID.Text, LabelJobID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub

    Protected Sub ButtonGetCFS_Click(sender As Object, e As EventArgs) Handles ButtonGetCFS.Click
        Call LoadCFS(LabelCFPROID.Text, "")
    End Sub
    Private Sub LoadCFS(CFPROID As String, SearchStr As String)

        Try


            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And CFS Like '%" & Trim(SearchStr) & "'% "
            End If

            Dim sqlstr As String =
                   "Select CFSID,CFS, ID " &
                   "From CFS " &
                   "Where CFPROID = '" & CFPROID & "' " &
                   tmpstr &
                   "Order By CFS Asc; "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            Dim a As Integer

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next

            GridCFS.DataSource = tmptable
            GridCFS.DataBind()

            ModalPopupExtender4.Show()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub


    Protected Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        Call LoadCFS(LabelCFPROID.Text, TextSearchCFS.Text)
    End Sub

    Protected Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click
        If GridCFS.SelectedIndex >= 0 Then
            Call CFS(LabelCFPROID.Text, GridCFS.SelectedValue, LabelLastslingDate.Text, LabelClientID.Text, LabelJobType.Text)
        End If
        ModalPopupExtender4.Hide()
    End Sub

   
End Class