﻿Imports AjaxControlToolkit


Public Class cfagentrating
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = Request.QueryString("CFPROID")
            Dim UserCSDID As String = Request.QueryString("usercsdid")
            Dim AllowRating As Boolean = Request.QueryString("allowrating")

            Panel1.Visible = AllowRating

            LabelUserCSDID.Text = UserCSDID
            LabelCFPROID.Text = CFPROID

            Call LoadRating(CFPROID, UserCSDID, AllowRating)

        End If
    End Sub

    Private Sub LoadRating(CFPROID As String, UserCSDID As String, AllowRating As Boolean)


        Dim tmpstr As String = ""


        If AllowRating Then
            tmpstr = "And UserCSDID ='" & UserCSDID & "' "
        End If

        Dim sqlstr As String =
            "SELECT CFPROID,RatingID," &
            "UserCSDID, RatingAvarage," &
            "DateRated, Remarks, ID  " &
            "FROM  CFAgentRating " &
            "Where CFPROID ='" & CFPROID & "' " &
            tmpstr

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            If drow("RatingAvarage") < 1.5 Then
                drow("RatingID") = GetRatingID()
                drow("RatingAvarage") = 1.5
            End If
        Else
            drow = tmptable.NewRow
            tmptable.Rows.Add(drow)

        End If
        drow = tmptable.Rows(0)


        drow("CFPROID") = CFPROID
        drow("UserCSDID") = UserCSDID
        drow("DateRated") = Format(Now, "dd MMM yyyy hh:mm tt")

        If AllowRating Then
            Call clsData.SaveData("CFAgentRating", tmptable, sqlstr, False, clsData.constr)
        End If

        Call clsData.NullChecker(tmptable, 0)

        Dim RatingImageURL() As String = clsCFPROAccount.SetAvarageRating(drow("RatingAvarage"))

        LabelRatingAvarage.Text = "Rating: " & Format(drow("RatingAvarage"), "0.00") & " - Your Votes"

        Image0.ImageUrl = RatingImageURL(0)
        Image1.ImageUrl = RatingImageURL(1)
        Image2.ImageUrl = RatingImageURL(2)
        Image3.ImageUrl = RatingImageURL(3)
        Image4.ImageUrl = RatingImageURL(4)

        Call LoadRatingItems(CFPROID, UserCSDID, drow("RatingID"), AllowRating)

    End Sub

    Private Sub LoadRatingItems(CFPROID As String, UserCSDID As String, RatingID As String, AllowRating As Boolean)
        Try


            Dim drow, drow1 As DataRow

            Dim tmpstr As String = ""


            Dim sqlstr As String =
              "SELECT  ItemID, RatingID," &
              "CFPROID,Rating,ID " &
              "FROM  CFAgentRatingItems " &
              "Where CFPROID ='" & CFPROID & "' " &
              "And RatingID ='" & RatingID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
                    "SELECT  ItemID ,Item," &
                    "Description, SortOrder " &
                    "FROM CFPRORatingItems"

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim col As New DataColumn("Item", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Description", Type.GetType("System.String"))
            Dim col2 As New DataColumn("SortOrder", Type.GetType("System.Double"))
            Dim col3 As New DataColumn("RatingText", Type.GetType("System.String"))
            Dim col4 As New DataColumn("AllowRating", Type.GetType("System.Boolean"))
            Dim col5 As New DataColumn("IDs", Type.GetType("System.String"))


            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)


            Dim a, b As Integer

            If tmptable.Rows.Count = 0 Or Not AllowRating Then
                For Each drow1 In tmptable1.Rows
                    drow = tmptable.NewRow
                    drow("CFPROID") = CFPROID
                    drow("Rating") = 1.5
                    drow("RatingID") = RatingID
                    drow("ItemID") = drow1("ItemID")
                    drow("Item") = drow1("Item")
                    drow("Description") = drow1("Description")
                    drow("SortOrder") = drow1("SortOrder")
                    drow("AllowRating") = Not AllowRating
                    tmptable.Rows.Add(drow)
                Next
            End If

            'If AllowRating Then
            '    Call clsData.SaveData("CFAgentRatingItems", tmptable, sqlstr, False, clsData.constr)
            'End If

            If Not AllowRating Then

                Dim sqlstr2 As String =
                  "SELECT  ItemID, RatingID," &
                  "CFPROID,Rating,ID " &
                  "FROM  CFAgentRatingItems " &
                  "Where CFPROID ='" & CFPROID & "' "


                Dim tmptable2 As New DataTable
                Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


                Dim dv2 As New DataView(tmptable2)

                Dim Rating As Double
                Dim Votecount As Double
                For Each drow In tmptable.Rows

                    Call clsData.NullChecker(tmptable, a)

                    dv2.RowFilter = "ItemID = '" & drow("ItemID") & "' "
                    Rating = 1

                    If dv2.Count > 0 Then
                        For a = 0 To dv2.Count
                            Rating = Rating + dv2(a)("Rating")
                        Next
                        Votecount = dv2.Count
                    Else
                        Votecount = 1
                    End If

                    Rating = Rating / Votecount

                    If Rating < 1.5 Then
                        Rating = 1.5
                    End If

                    drow("Rating") = CInt(Rating)

                    drow("RatingText") = "Rating: " & Format(Rating, "0.00") & " - " & Votecount & " Votes"
                    drow("IDs") = drow("ItemID") & "|" & drow("RatingID")

                    a = a + 1
                Next
            Else

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    b = 0
                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, b)
                        If drow("ItemID") = drow1("ItemID") Then
                            drow("Item") = drow1("Item")
                            drow("Description") = drow1("Description")
                            drow("SortOrder") = drow1("SortOrder")
                        End If
                        b = b + 1
                    Next

                    If drow("Rating") < 1.5 Then
                        drow("Rating") = 1.5
                    End If

                    drow("AllowRating") = Not AllowRating
                    drow("RatingText") = "Rating: " & Format(drow("Rating"), "0.00") & " -  Your Vote"
                    drow("IDs") = drow("ItemID") & "|" & drow("RatingID")

                    a = a + 1
                Next

            End If

            a = 0


            Dim dv As New DataView(tmptable)
            dv.Sort = "SortOrder ASC"

            DataList1.DataSource = dv
            DataList1.DataBind()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Protected Sub OnRatingChanged(sender As Object, e As RatingEventArgs)
        Try
            Dim nRating As clsExtendRating = CType(sender, Rating)
            LabelRatingsCaption.Text = nRating.CommandArgument

            Dim tmpstr() As String = nRating.CommandArgument.Split("|")

            Dim ItemID As String = tmpstr(0)
            Dim RatingID As String = tmpstr(1)



            Dim sqlstr As String =
              "SELECT  ItemID,RatingID," &
              "CFPROID,Rating, ID " &
              "FROM  CFAgentRatingItems " &
              "Where RatingID = '" & RatingID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim value As Integer = e.Value
            Dim RatingAvarage As Double
            Dim a As Integer


            Dim drow, drow1 As DataRow
            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    If drow("ItemID") = ItemID Then
                        drow("Rating") = CInt(e.Value)
                    End If

                    RatingAvarage = RatingAvarage + drow("Rating")
                    a = a + 1
                Next


                Dim sqlstr1 As String =
                 "SELECT RatingAvarage," &
                 "DateRated, Remarks, ID  " &
                 "FROM  CFAgentRating " &
                 "Where CFPROID ='" & LabelCFPROID.Text & "' " &
                 "And RatingID ='" & RatingID & "' "

                Dim tmptable1 As New DataTable
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


                If tmptable1.Rows.Count > 0 Then
                    drow1 = tmptable.Rows(0)
                    drow1("RatingAvarage") = RatingAvarage
                    drow1("DateRated") = Format(Now, "dd-MMM yyyy hh:mm tt")
                End If

                Call clsData.SaveData("CFAgentRatingItems", tmptable, sqlstr, False, clsData.constr)
                Call clsData.SaveData("CFAgentRating", tmptable1, sqlstr1, False, clsData.constr)


            End If

            Call LoadRating(LabelCFPROID.Text, LabelUserCSDID.Text, LabelAllowRating.Text)


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    'Protected Sub OnRatingChanged(sender As Object, e As RatingEventArgs)
    '    Dim rowIndex As Integer = TryCast(TryCast(sender, Rating).NamingContainer, GridViewRow).RowIndex
    '    Dim fruitId As Integer = Convert.ToInt32(gvFruits.DataKeys(rowIndex).Value)
    '    Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
    '    Using con As New SqlConnection(constr)
    '        Using cmd As New SqlCommand("INSERT INTO Fruit_Ratings VALUES(@FruitId, @Rating)")
    '            cmd.CommandType = CommandType.Text
    '            cmd.Parameters.AddWithValue("@FruitId", fruitId)
    '            cmd.Parameters.AddWithValue("@Rating", e.Value)
    '            cmd.Connection = con
    '            con.Open()
    '            cmd.ExecuteNonQuery()
    '            con.Close()
    '        End Using
    '    End Using
    '    Response.Redirect(Request.Url.AbsoluteUri)
    'End Sub
    Private Function GetRatingID() As String
        Try

            Dim tmpRatingID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From CFAgentRating " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpRatingID = drow("ID")
                tmpRatingID = tmpRatingID + 1
                tmpstr = Format(tmpRatingID, "0000000000#")
            Else
                tmpstr = Format(tmpRatingID, "0000000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Function
End Class


