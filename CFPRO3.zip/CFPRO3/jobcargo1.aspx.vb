﻿Imports System.IO

Public Class jobcargo1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            If IsNothing(Request.Cookies("CFPROToken")) Then
                Call RegisterToken()
            ElseIf Request.Cookies("CFPROToken").Value = "" Then
                Call RegisterToken()
            End If

            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            'Call clsAuth.UserLoggedIn("", "", "", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, Image1.ImageUrl, True, "", True)

            Dim JobID As String = Request.QueryString("jobid")
            Call LoadJob(JobID)

        End If

    End Sub


    Private Sub RegisterToken()
        Try

            If Not IsNothing(Request.QueryString("logintoken")) Then


                Response.Cookies("CFPROToken").Value = (Request.QueryString("logintoken"))
                Response.Cookies("CFPROToken").Expires = Now.AddHours(6)

                If Not IsNothing(Request.QueryString("gotooption")) Then
                    Response.Redirect(Request.QueryString("gotooption"))
                End If
            End If

        Catch exp As Exception
            'LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadJob(JobID As String)

        Dim CFS As String = ""
        Try
            Dim sqlstr As String =
                    "Select JobId,ReferenceNo," &
                    "JobDate,ClientID,Client," &
                    "CFS,BL,BLCountry," &
                    "Goods,DaysTaken," &
                    "ShipStatus,ManifestNo," &
                    "JobStatus,JobPersonnel," &
                    "JobInvoiceNo,InvoiceParticulars," &
                    "JobType,OrderNo,VesselETA,ShippingVessel," &
                    "LastSlingDate,DispatchDate,ID " &
                    "From Jobs " &
                    "Where Jobid ='" & JobID & "'"

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                Call clsSubs.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                'LabelRefNo.Text = drow("ReferenceNo")
                'LabelJobDate.Text = Format(drow("JobDate"), "dd-MMM-yyyy")
                'LabelVesseETA.Text = Format(drow("VesselETA"), "dd-MMM-yyyy")
                'LabelManifestNo.Text = drow("ManifestNo")

                'LabelVessel.Text = drow("ShippingVessel")
                'LabelVesselStatus.Text = drow("ShipStatus")

                'LabelBL.Text = drow("BL")
                'LabelBLOrigin.Text = drow("BLCountry")
                'LabelGoods.Text = drow("Goods")
                'LabelOrderNo.Text = drow("OrderNo")

                CFS = drow("CFS")
                'SetClient(JobID, drow("ClientID"), False)



                'LabelDaysTaken.Text = drow("DaysTaken")
                'LabelJobCount.Text = "Job " & ComboJobID.SelectedIndex + 1 & " of " & ComboJobID.Items.Count



                For Each col In tmptable.Columns
                    If drow(col.ColumnName.ToString) = "" Then
                        drow(col.ColumnName.ToString) = "-"
                    End If
                Next

            End If

        Catch exp As Exception

        Finally
            Call LoadJobCargo(JobID, CFS)
        End Try

    End Sub

    Private Sub LoadJobCargo(JobID As String, CFS As String)

        Dim sqlstr As String =
           "Select JobId,ContainerNo,Payload," &
           "TEU,Weight,CBM," &
           "VehicleNo,Transporter," &
           "PortExitDate,ContainerStatus," &
           "RemainingDays,ID " &
           "From JobCargo " &
           "Where JobID = '" & JobID & "' "


        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col As New DataColumn("PortExitDate1", Type.GetType("System.String"))
        Dim col1 As New DataColumn("CargoCount", Type.GetType("System.String"))
        Dim col2 As New DataColumn("CFS", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)

        Dim a As Integer
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)

            If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
            Else
                drow("PortExitDate1") = "-"
            End If

            a = a + 1
        Next



        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Payload") = ""
            tmptable.Rows.Add(drow)
        End If

        a = 0
        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)
            drow("CargoCount") = a + 1
            drow("CFS") = CFS
            a = a + 1
        Next

        '  Call clsSubs.SetRemainingDays(tmptable, JobID)
        LabelJobCargoCount.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "
        If tmptable.Rows.Count < 5 Then
            PanelCargo.Height = Nothing
        Else
            PanelCargo.Height = 255
        End If

        DataList2.DataSource = tmptable
        DataList2.DataBind()



    End Sub



    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs)
        '  ModalPopupExtender1.Show()
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=index.aspx")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
            End If
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
        End If
    End Sub

End Class