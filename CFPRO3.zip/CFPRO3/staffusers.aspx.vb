﻿
Imports System.Data
Imports System.Drawing
Imports System.Web.UI.HtmlControls
Public Class staffusers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call LoadStaffs(0)
        End If
    End Sub


    Private Sub LoadStaffs(Rowindex As Integer)


        Dim sqlstr As String = _
          "Select UserID, StaffName, " & _
           "JobDescription," & _
           "Department,Telephone," & _
           "Email, Role," & _
           "ReadOnlyUser,TransitUpdateUser " & _
           "From Staff " & _
           "Order By StaffName Asc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsSubs.NullChecker(tmptable, a)
            a = a + 1
        Next


        If tmptable.Rows.Count < 10 Then
            GridStaff.Height = 20 + (24 * tmptable.Rows.Count)
        End If

        GridStaff.DataSource = tmptable
        GridStaff.DataBind()

        If GridStaff.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If
            GridStaff.SelectedIndex = Rowindex
            Call ShowStaff(GridStaff.SelectedValue.ToString)
            Dim row As GridViewRow = GridStaff.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        LabelItemsCount.Text = tmptable.Rows.Count & " Users / Staff"
    End Sub



    Private Sub ShowStaff(UserID As String)

        Dim sqlstr As String = _
           "Select UserID, StaffName, " & _
            "JobDescription," & _
            "Department,Telephone," & _
            "Email, Role," & _
            "ReadOnlyUser,TransitUpdateUser " & _
            "From Staff " & _
            "Where UserID = '" & UserID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsSubs.NullChecker(tmptable, 0)
            TextStaffName.Text = drow("StaffName")
            TextJobDescription.Text = drow("JobDescription")
            TextDepartment.Text = drow("Department")
            TextTelephone.Text = drow("Telephone")
            TextEmailAddress.Text = drow("Email")
            CheckReadOnlyUser.Checked = drow("ReadOnlyUser")
            CheckTransitUpdateUser.Checked = drow("TransitUpdateUser")
            ComboUserRole.Text = drow("Role")

        End If



    End Sub



    Private Sub NewStaff()
        Try


            Dim sqlstr As String = _
                  "Select UserID, StaffName, Id " & _
                   "From  Staff "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow

            Drow("UserID") = GetUserID()
            Drow("StaffName") = "New User" & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Staff", tmptable, sqlstr, False, clsData.constr)
            Call LoadStaffs(0)


            TextStaffName.Focus()



        Catch exp As Exception
            MsgBox(exp.Message, , "AddStaff")
        End Try
    End Sub


    Private Function GetUserID() As String
        Try

            Dim tmpUserID As Integer

            Dim sqlstr As String = _
             "Select top 1 Id " & _
             "From Staff " & _
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpUserID = drow("ID")
                tmpUserID = tmpUserID + 1
                tmpstr = Format(tmpUserID, "000000#")
            Else
                tmpstr = Format(tmpUserID, "000000#")
            End If

            Return tmpstr

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetUserID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridStaff, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridStaff.SelectedIndexChanged
        Dim row As GridViewRow = GridStaff.Rows(GridStaff.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowStaff(GridStaff.SelectedValue.ToString)

        For a As Integer = 0 To GridStaff.Rows.Count - 1
            row = GridStaff.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridStaff.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub


    Private Sub SearchStaff(Rowindex As Integer)

        TextStaffName.Text = ""
        TextJobDescription.Text = ""
        TextDepartment.Text = ""
        TextTelephone.Text = ""
        TextEmailAddress.Text = ""


        Dim sqlstr As String = _
            "Select UserID, StaffName, " & _
             "JobDescription," & _
             "Department,Telephone," & _
             "Email, Role," & _
             "ReadOnlyUser,TransitUpdateUser " & _
             "From Staff " & _
            "Where StaffName  Like '%" & Trim(TextSearch.Text) & "%' " & _
            "Order By StaffName Asc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsSubs.NullChecker(tmptable, a)
            a = a + 1
        Next


        If tmptable.Rows.Count < 10 Then
            GridStaff.Height = 20 + (24 * tmptable.Rows.Count)
        End If

        GridStaff.DataSource = tmptable
        GridStaff.DataBind()


        If GridStaff.Rows.Count > 0 Then
            If Rowindex > 0 Then
                GridStaff.SelectedIndex = Rowindex
                Call ShowStaff(GridStaff.SelectedValue.ToString)
                Dim row As GridViewRow = GridStaff.Rows(Rowindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If
        End If


        LabelItemsCount.Text = tmptable.Rows.Count & "Users / Staff found matching  '" & TextSearch.Text & "' "
    End Sub



    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewStaff()
    End Sub


    Private Sub SaveStaff(UserID As String)
        Try

            Dim sqlstr As String = _
            "Select UserID, StaffName, " & _
             "JobDescription," & _
             "Department,Telephone," & _
             "Email, Role," & _
             "ReadOnlyUser,TransitUpdateUser,ID " & _
             "From Staff " & _
             "Where UserID = '" & UserID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                drow("StaffName") = Trim(TextStaffName.Text)
                drow("JobDescription") = Trim(TextJobDescription.Text)
                drow("Department") = Trim(TextDepartment.Text)
                drow("Telephone") = Trim(TextTelephone.Text)
                drow("Email") = Trim(TextEmailAddress.Text)
                drow("Role") = ComboUserRole.Text
                drow("ReadOnlyUser") = CheckReadOnlyUser.Checked
                drow("TransitUpdateUser") = CheckTransitUpdateUser.Checked
            End If

            Call clsData.SaveData("Staff", tmptable, sqlstr, False, clsData.constr)

            If Trim(TextSearch.Text) = "" Then
                Call LoadStaffs(GridStaff.SelectedIndex)
            Else
                Call SearchStaff(GridStaff.SelectedIndex)
            End If



        Catch exp As Exception
            MsgBox(exp.Message, , "AddStaff")
        End Try
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveStaff(GridStaff.SelectedValue.ToString)
    End Sub

    Private Sub DeleteStaff(UserID As String)


        Dim sqlstr As String = _
        "Select ID " & _
        "From  Staffs " & _
        "Where UserID = '" & UserID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Staffs", tmptable, sqlstr, True, clsData.constr)
        Call LoadStaffs(GridStaff.SelectedIndex - 1)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteStaff(GridStaff.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call SearchStaff(-1)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        TextSearch.Text = ""
        Call LoadStaffs(0)
    End Sub
End Class