﻿Public Class containerdepositreport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            'Dim imgurl As String = ""
            'Dim CSDID As String = ""
            '' Call clsSubs.CheckAndSetUser(CSDID, LabelUser.Text, "", LinkSignIn.Text, imgurl, False)
            'Image1.ImageUrl = imgurl

            Call LoadJobTypes()

        End If



    End Sub



    Private Sub LoadJobTypes()
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes "
        ComboFilterJobStatus.Items.Clear()
        Call clsData.PopCombo(ComboFilterJobStatus, sqlstr, clsData.constr, 0)
    End Sub




End Class