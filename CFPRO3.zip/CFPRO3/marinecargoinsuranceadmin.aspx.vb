﻿Public Class marinecargoinsuranceadmin
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Call clsAuth.UserLogin(LabelCSDID.Text, LabelCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", False, "", False)
            Call LoadInsurer()
            Call LoadCargoCategories()
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub



    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, Insurer," & _
            "ProductName, Rate," & _
            "Description, URL," & _
            "EmailAddress,Telephone " & _
            "FROM Insurers "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)

        Dim a As Integer

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)
            drow("SendMessage") = "sendmessage.aspx"
            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")


            HyperLinkCompany.Text = drow("Insurer")
            HyperLinkCompany.NavigateUrl = drow("URL")


            LabelContacts.Text = drow("Contacts")

        End If



    End Sub




    Private Sub LoadMoreInformation(Title As String, src As String)
        ModalPopupExtender1.Show()
        LabelInput.Text = Title
        iframe1.Attributes("src") = src

    End Sub



    Private Sub LoadSendMessage(page As String, title As String)
        LabTitle.Text = title
        iframe1.Attributes("src") = page
        ModalPopupExtender3.Show()
    End Sub


    Private Sub LoadCargoCategories()
        Dim sqlstr As String = _
            "SELECT  CategoryID, Category " & _
            "FROM MarineCargoCategories "

        Call clsData.PopCombo1a(ComboCargoCategories, sqlstr, clsData.constr, 0, 1)

    End Sub

    Private Sub CargoType(CategoryID As String)
        Dim sqlstr As String = _
            "SELECT    CargoID, CargoDesc, Conditions,CategoryID  " & _
            "FROM MarineCargo " & _
            "Where CategoryID = '" & CategoryID & "' "

        'ComboCargoType.Items.Clear()

        'Call clsData.PopCombo1a(ComboCargoType, sqlstr, clsData.constr, 0, 1)
    End Sub


    Protected Sub ComboCargoCategories_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCargoCategories.SelectedIndexChanged
        Call CargoType(ComboCargoCategories.SelectedValue)
    End Sub

    Private Sub CalculatePremuim(CargoCategoryID As String, CargoID As String, InsuredAmount As Double, NonContainerised As Boolean, isAirFreight As Boolean)

        Dim sqlstr As String = _
          "SELECT   InsurerID, CargoCategoryID," & _
          "CargoID, PremiumBase," &
          "PolicyHolderFundBase, " &
          "TrainingLevyBase, PremiumContainerised," &
          "PremiumNonContainerised, TrainingLevy," &
          "StampDuty, PolicyHolderFund," &
          "AirFreight, SeaFreight " &
          "FROM MarineCategoryRates " & _
          "Where CargoCategoryID = '" & CargoCategoryID & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim sqlstr1 As String = _
        "SELECT   InsurerID, CargoCategoryID," &
        "CargoID, PremiumContainerised," &
        "PremiumNonContainerised " &
        "FROM  MarineCargoRates " & _
        "Where CargoID = '" & CargoID & "' "




        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


        Dim drow, drow1 As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Dim Premuim As Double = drow("PremiumBase")


            Dim TrainingLevy As Double = drow("TrainingLevyBase")
            Dim StampDuty As Double = drow("StampDuty") * InsuredAmount
            Dim PolicyHolderFund As Double = drow("PolicyHolderFund") * InsuredAmount

            If isAirFreight Then
                Dim AirFreight As Double = drow("AirFreight") * InsuredAmount
            End If


        End If








    End Sub
End Class


