﻿Imports System.Drawing

Public Class shippinglines
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadShippinglines(CFPROID, 0, "")
        End If
    End Sub


    Private Sub LoadShippinglines(CFPROID As String, Rowindex As Integer, SearchStr As String)

        Dim tmpstr As String = ""
        If Not Trim(SearchStr) = "" Then
            tmpstr = "And ShippingLine  Like '%" & Trim(TextSearch.Text) & "'% "
        End If
        Dim sqlstr As String =
              "Select ShippingLineID,ShippingLine," &
              "TransitReturnDays,LocalReturnDays, Id " &
              "From ShippingLines " &
              "Where  CFPROID = '" & CFPROID & "' " & _
              "Order By ID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            a = a + 1
        Next



        Session("ShippinglinesTable") = tmptable

        GridShippinglines.DataSource = tmptable
        GridShippinglines.DataBind()

        If GridShippinglines.Rows.Count > 0 Then
            If Rowindex < 0 Then
                Rowindex = 0
            End If

            If Rowindex > GridShippinglines.Rows.Count - 1 Then
                Rowindex = GridShippinglines.Rows.Count - 1
            End If

            GridShippinglines.SelectedIndex = Rowindex
            Call ShowShippingline(CFPROID, GridShippinglines.SelectedValue.ToString)
            Dim row As GridViewRow = GridShippinglines.Rows(Rowindex)
            row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
        End If

        If Not Trim(SearchStr) = "" Then
            LabelItemsMessage.Text = tmptable.Rows.Count & " Shipping Lines found matching  '" & TextSearch.Text & "' "
        Else
            LabelItemsMessage.Text = tmptable.Rows.Count & " Shipping Lines"
        End If
    End Sub


    Private Sub ShowShippingline(CFPROID As String, ShippinglineID As String)

        Dim sqlstr As String =
            "Select ShippingLineID,ShippingLine," &
            "TransitReturnDays,LocalReturnDays, ID " &
            "From ShippingLines " &
            "Where  CFPROID = '" & CFPROID & "' " & _
            "And ShippinglineID = '" & ShippinglineID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            clsData.NullChecker(tmptable, 0)
            TextShippingline.Text = drow("Shippingline")
            TextLocalFreeDays.Text = drow("LocalReturnDays")
            TextTransitFreeDays.Text = drow("TransitReturnDays")

        End If



    End Sub



    Private Sub NewShippingline(CFPROID As String)
        Try


            Dim sqlstr As String =
                  "Select ShippinglineID, Shippingline," &
                   "CFPROID, ID " &
                   "From  Shippinglines " &
                   "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim Drow As DataRow
            Drow = tmptable.NewRow
            Drow("CFPROID") = CFPROID
            Drow("ShippinglineID") = GetShippinglineID()
            Drow("Shippingline") = "New Shipping Line " & tmptable.Rows.Count

            tmptable.Rows.Add(Drow)

            Call clsData.SaveData("Shippinglines", tmptable, sqlstr, False, clsData.constr)
            Call LoadShippinglines(CFPROID, 0, "")


            TextShippingline.Focus()



        Catch exp As Exception
            MsgBox(exp.Message, , "AddShippingline")
        End Try
    End Sub


    Private Function GetShippinglineID() As String
        Try

            Dim tmpShippinglineID As Integer

            Dim sqlstr As String =
             "Select top 1 Id " &
             "From Shippinglines " &
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpShippinglineID = drow("ID")
                tmpShippinglineID = tmpShippinglineID + 1
                tmpstr = Format(tmpShippinglineID, "00000000#")
            Else
                tmpstr = Format(tmpShippinglineID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetShippinglineID")
        End Try
    End Function


    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridShippinglines, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs) Handles GridShippinglines.SelectedIndexChanged
        Dim row As GridViewRow = GridShippinglines.Rows(GridShippinglines.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")
        Call ShowShippingline(LabelCFPROID.Text, GridShippinglines.SelectedValue.ToString)

        For a As Integer = 0 To GridShippinglines.Rows.Count - 1
            row = GridShippinglines.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Or row.BackColor = ColorTranslator.FromHtml("#FFF4DD") Then
                If Not a = GridShippinglines.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call NewShippingline(LabelCFPROID.Text)
    End Sub
    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveShippingline(LabelCFPROID.Text, GridShippinglines.SelectedValue.ToString)
    End Sub

    Private Sub SaveShippingline(CFPROID As String, ShippinglineID As String)
        Try


            Dim sqlstr As String =
              "Select ShippingLineID,ShippingLine," &
              "TransitReturnDays,LocalReturnDays," &
              "CFPROID, ID " &
              "From ShippingLines " &
              "Where  CFPROID = '" & CFPROID & "' " & _
              "And ShippinglineID = '" & ShippinglineID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                clsData.NullChecker(tmptable, 0)
                drow("CFPROID") = CFPROID
                drow("Shippingline") = Trim(TextShippingline.Text)
                drow("LocalReturnDays") = Trim(TextLocalFreeDays.Text)
                drow("TransitReturnDays") = Trim(TextTransitFreeDays.Text)

                Call clsData.SaveData("Shippinglines", tmptable, sqlstr, False, clsData.constr)
                clsMSDynamicsNAVint.UpdateNAVVendor(CFPROID, "S-", drow("ShippingLineID"), drow("Shippingline"), "-", "-", "-", "KE", "", LabelMessage1.Text)
            End If

            Call LoadShippinglines(CFPROID, GridShippinglines.SelectedIndex, TextSearch.Text)


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub





    Private Sub DeleteShippingline(CFPROID As String, ShippinglineID As String)

        Dim sqlstr As String = _
        "Select ID " & _
        "From  Shippinglines " & _
        "Where  CFPROID = '" & CFPROID & "' " & _
        "And ShippinglineID = '" & ShippinglineID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
        End If

        Call clsData.SaveData("Shippinglines", tmptable, sqlstr, True, clsData.constr)
        Call LoadShippinglines(LabelCFPROID.Text, GridShippinglines.SelectedIndex - 1, TextSearch.Text)
    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteShippingline(LabelCFPROID.Text, GridShippinglines.SelectedValue.ToString)
    End Sub


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadShippinglines(LabelCFPROID.Text, 0, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadShippinglines(LabelCFPROID.Text, 0, "")
    End Sub

    Protected Sub ButtonDownloadExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click


        Dim Fields(3) As String
        Fields(0) = "ShippingLineID"
        Fields(1) = "ShippingLine"
        Fields(2) = "LocalReturnDays"
        Fields(3) = "TransitReturnDays"

        Dim Fields1(3) As String
        Fields1(0) = "ShippingLine ID"
        Fields1(1) = "Shipping Line"
        Fields1(2) = "Local Return Days"
        Fields1(3) = "Transit Return Days"



        Dim tmptable As New DataTable("ShippingLinesTable")
        tmptable = DirectCast(Session("ShippingLinesTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Shipping Lines", "Shipping Lines",
                                            LabelItemsMessage.Text, False, Nothing, 0, "", Fields, Fields1, tmptable, False)

    End Sub

End Class