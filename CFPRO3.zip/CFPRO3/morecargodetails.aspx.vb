﻿Public Class morecargodetails
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            Dim JobID As String = Request.QueryString("jobId")
            Dim JobCargoID As String = Request.QueryString("jobcargoid")

            Dim CFPROID As String = ""
            Dim CFAgentUserName As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, CFAgentUserName, "", "", "", "", True, "", False)
            LabelCFPROID.Text = CFPROID


            LabelJobID.Text = JobId
            LabelJobCargoID.Text = JobCargoID

            Call LoadDestinations(CFPROID)
            Call LoadDestinationDepots(CFPROID)
            Call LoadSpecialCargo(CFPROID)
            Call LoadContainerStatus(CFPROID)

            Call LoadCargoDetails(CFPROID, JobID, JobCargoID, CFPROUserID)

        End If
    End Sub


    Private Sub LoadCargoDetails(CFPROID As String, JobId As String, JobCargoID As String, CFPROUserID As String)
        Try


            Dim TransitUpdateUser As Boolean = Not clsAuth.TransitUpdateUser(CFPROID, CFPROUserID)

            TextContainerNo.Enabled = TransitUpdateUser
            TextVehicleNo.Enabled = TransitUpdateUser
            TextTransporter.Enabled = TransitUpdateUser
            TextPortExitDate.Enabled = TransitUpdateUser

            ButtonSearchVehicle.Enabled = TransitUpdateUser
            ButtonSearchTransporter.Enabled = TransitUpdateUser
            ButtonResetPortExitDate.Enabled = TransitUpdateUser



            Dim sqlstr As String =
                "SELECT ContainerNo,Payload," &
                "VehicleNo,TransporterID," &
                "PortExitDate,BorderArrivalDate,CrossBorderDate," &
                "BorderDispatchDate,DestinationArrivalDate," &
                "OffloadDate,DestinationDispatchDate," &
                "PortArrivalDate,DeliveryNoteNo," &
                "ReturnDate,InterchangeNo," &
                "ReleaseOrderStatus,ContainerStatus," &
                "ContainerStatusRemarks," &
                "T812No,T1No,T1Expiry," &
                "GFValidity, CustomsSealNo," &
                "Destination,SpecialCargoType," &
                "DestinationDepot,TrailerNo,ReturnVehicleNo, " &
                "Driver, DriverContacts,ID " &
                "From JobCargo " &
               "Where ID = " & CInt(JobCargoID) & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                TextContainerNo.Text = drow("ContainerNo")
                TextPayload.Text = drow("Payload")
                TextBorderArrivalDate.Text = Format(drow("BorderArrivalDate"), "dd MMM yyyy")
                TextPortExitDate.Text = Format(drow("PortExitDate"), "dd MMM yyyy")
                TextCrossBorderDate.Text = Format(drow("CrossBorderDate"), "dd MMM yyyy")
                TextBorderDispatchDate.Text = Format(drow("BorderDispatchDate"), "dd MMM yyyy")
                TextDestinationArrivalDate.Text = Format(drow("DestinationArrivalDate"), "dd MMM yyyy")
                TextOffLoadDate.Text = Format(drow("OffLoadDate"), "dd MMM yyyy")
                TextDestinationDispatchDate.Text = Format(drow("DestinationDispatchDate"), "dd MMM yyyy")
                TextDestinationDispatchDate.Text = Format(drow("DestinationDispatchDate"), "dd MMM yyyy")
                TextPortArrivalDate.Text = Format(drow("PortArrivalDate"), "dd MMM yyyy")
                TextDeliveryNoteNo.Text = drow("DeliveryNoteNo")

                TextReturnDate.Text = Format(drow("ReturnDate"), "dd MMM yyyy")
                TextInterchangeNo.Text = drow("InterchangeNo")

                TextT1No.Text = drow("T1No")
                TextT1Expiry.Text = Format(drow("T1Expiry"), "dd MMM yyyy")
                TextGFValidity.Text = Format(drow("GFValidity"), "dd MMM yyyy")

                TextCustomsSealNo.Text = drow("CustomsSealNo")

                TextVehicleNo.Text = drow("VehicleNo")
                LabelTransporterID.Text = drow("TransporterID")

                Call clsGetIdentities.SetTransporter(LabelCFPROID.Text, drow("TransporterID"), "", TextTransporter.Text, LabelTransporterID.Text,
                                           ModalPopupExtender2, Nothing, LabelMessage1.Text)

                TextTrailerNo.Text = drow("TrailerNo")
                TextReturnVehicleNo.Text = drow("ReturnVehicleNo")


                TextT812No.Text = drow("T812No")
                TextDriver.Text = drow("Driver")
                TextDriverContacts.Text = drow("DriverContacts")


                ComboDestinationDepot.Text = drow("DestinationDepot")
                ComboDestination.Text = drow("Destination")

                ComboSpecialCargo.Text = drow("SpecialCargoType")

                ComboContainerStatus.Text = drow("ContainerStatus")
                TextRemarks.Text = drow("ContainerStatusRemarks")

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSave1_Click(sender As Object, e As EventArgs) Handles ButtonSave1.Click
        Call SaveJobCargo(LabelCFPROID.Text, LabelJobID.Text, LabelJobCargoID.Text)
    End Sub

    Private Sub SaveJobCargo(CFPROID As String, JobId As String, JobCargoID As String)

        Try

            Dim ID As Integer = Val(JobCargoID)
            Dim sqlstr As String =
                "SELECT ContainerNo,Payload," &
                "VehicleNo,TransporterID," &
                "PortExitDate,BorderArrivalDate,CrossBorderDate," &
                "BorderDispatchDate,DestinationArrivalDate," &
                "OffloadDate,DestinationDispatchDate," &
                "PortArrivalDate,DeliveryNoteNo," &
                "ReturnDate,InterchangeNo," &
                "ReleaseOrderStatus,ContainerStatus," &
                "ContainerStatusRemarks," &
                "T812No,T1No,T1Expiry," &
                "GFValidity, CustomsSealNo," &
                "Destination,SpecialCargoType," &
                "DestinationDepot,TrailerNo,ReturnVehicleNo, " &
                "Driver, DriverContacts,ID " &
                "From JobCargo " &
                "Where ID = " & ID & ""


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then

                drow = tmptable.Rows(0)
                drow("ContainerNo") = TextContainerNo.Text
                drow("Payload") = TextPayload.Text
                drow("PortExitDate") = TextPortExitDate.Text
                drow("BorderArrivalDate") = TextBorderArrivalDate.Text
                drow("CrossBorderDate") = TextCrossBorderDate.Text
                drow("BorderDispatchDate") = TextBorderDispatchDate.Text
                drow("DestinationArrivalDate") = TextDestinationArrivalDate.Text
                drow("OffLoadDate") = TextOffLoadDate.Text
                drow("DestinationDispatchDate") = TextDestinationDispatchDate.Text
                drow("PortArrivalDate") = TextPortArrivalDate.Text
                drow("DeliveryNoteNo") = TextDeliveryNoteNo.Text
                drow("ReturnDate") = TextReturnDate.Text
                drow("InterchangeNo") = TextInterchangeNo.Text
                drow("CustomsSealNo") = TextCustomsSealNo.Text
                drow("T812No") = TextT812No.Text
                drow("T1No") = TextT1No.Text

                drow("T1Expiry") = TextT1Expiry.Text
                drow("GFValidity") = TextGFValidity.Text

                drow("Driver") = TextDriver.Text
                drow("DriverContacts") = TextDriverContacts.Text

                drow("VehicleNo") = TextVehicleNo.Text
                drow("TrailerNo") = TextTrailerNo.Text
                drow("ReturnVehicleNo") = TextReturnVehicleNo.Text
                drow("TransporterID") = LabelTransporterID.Text

                drow("Destination") = ComboDestination.Text
                drow("DestinationDepot") = ComboDestinationDepot.Text

                drow("ContainerStatusRemarks") = Trim(TextRemarks.Text)
                drow("SpecialCargoType") = ComboSpecialCargo.Text
                drow("ContainerStatus") = ComboContainerStatus.Text

                Call clsData.NullChecker(tmptable, 0)
                If CDate(drow("ReturnDate")) = CDate("1-Jan-1800") Then
                    If drow("ContainerStatus") = "Returned" Then
                        drow("ContainerStatus") = "Not Returned"
                    End If
                Else
                    If Not drow("ContainerStatus") = "Returned" Then
                        drow("ContainerStatus") = "Returned"
                    End If
                End If

                Dim item As New ListItem()
                item.Text = drow("ContainerStatus")

                If ComboContainerStatus.Items.Contains(item) Then
                    ComboContainerStatus.Text = drow("ContainerStatus")
                Else
                    ComboContainerStatus.Text = ""
                End If


                
                Call clsData.SaveData("JobCargo", tmptable, sqlstr, False, clsData.constr, LabelMessage1.Text)

            End If



        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub
    Private Sub LoadDestinations(CFPROID As String)
        Dim sqlstr As String =
        "Select Destination From Destinations " &
        "Where CFPROID ='" & CFPROID & "' " &
        "Order By Destination Asc;"
        Call clsData.PopCombo(ComboDestination, sqlstr, clsData.constr, 0)
        ComboDestination.Items.Insert(0, "")
    End Sub
    Private Sub LoadDestinationDepots(CFPROID As String)
        Dim sqlstr As String =
        "Select Depot From Depots " &
        "Where CFPROID ='" & CFPROID & "' " &
        "Order By Depot Asc;"
        Call clsData.PopCombo(ComboDestinationDepot, sqlstr, clsData.constr, 0)
        ComboDestinationDepot.Items.Insert(0, "")
    End Sub

    Private Sub LoadSpecialCargo(CFPROID As String)
        Dim sqlstr As String =
        "Select  CargoDesc From SpecialCargo " &
        "Where CFPROID ='" & CFPROID & "' " &
        "Order By CargoDesc Asc;"
        Call clsData.PopCombo(ComboSpecialCargo, sqlstr, clsData.constr, 0)
        ComboSpecialCargo.Items.Insert(0, "")
    End Sub


    Private Sub LoadContainerStatus(CFPROID As String)

        Dim sqlstr4 As String = _
            "Select Status " & _
            "From ContainerStatus " & _
            "Where CFPROID = '" & CFPROID & "' " &
            "Order By Id Desc; "

        ComboContainerStatus.Items.Clear()
        ComboContainerStatus.Items.Add("")
        Call clsData.PopCombo(ComboContainerStatus, sqlstr4, clsData.constr, 0)
    End Sub

    Protected Sub ButtonReset4_Click(sender As Object, e As EventArgs) Handles ButtonSearchTransporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "transporter", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonReset3_Click(sender As Object, e As EventArgs) Handles ButtonSearchVehicle.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "vehicleno", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text.Contains("Vehicle") Then
            clsGetIdentities.SearchVehicle(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)

        ElseIf LabelItemType.Text.Contains("Transporter") Then
            clsGetIdentities.SearchTransporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2)
        End If

    End Sub


    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetSelectedItem(sender)
    End Sub

    Private Sub SetSelectedItem(sender As Object)
        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text.Contains("Vehicle") Then

            Call clsGetIdentities.SetVehicleNo(LabelCFPROID.Text, ItemID, TextVehicleNo.Text, TextTransporter.Text, LabelTransporterID.Text,
                                           ModalPopupExtender2, Nothing, LabelMessage1.Text)

        ElseIf LabelItemType.Text.Contains("Transporter") Then

            Call clsGetIdentities.SetTransporter(LabelCFPROID.Text, ItemID, "", TextTransporter.Text, LabelTransporterID.Text,
                                           ModalPopupExtender2, Nothing, LabelMessage1.Text)
        End If
    End Sub
End Class