﻿Public Class collaboration
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            'Dim imgurl As String = ""
            'Dim CSDID As String = ""
            '' Call clsSubs.CheckAndSetUser(CSDID, LabelUser.Text, "", LinkSignIn.Text, imgurl, False)
            'Image1.ImageUrl = imgurl
        End If



    End Sub





 
End Class