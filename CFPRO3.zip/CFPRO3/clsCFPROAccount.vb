﻿Imports System.Net

Public Class clsCFPROAccount


    Shared Sub CreateUpdateCFPROAccount(ByRef ntmpTable As DataTable, ProductAccountID As String, CSDID As String, CreateAccountAdmin As Boolean)

        Dim tmptable As New DataTable("CFPROAccount")
        Dim tmptable1 As New DataTable("CFPROAccountItems")

        Dim CSDWCFService As New CSDWCFService.CSDService1Client("BasicHttpBinding_ICSDService1")

        tmptable = CSDWCFService.ProductAccount(ProductAccountID)
        tmptable1 = CSDWCFService.ProductAccountItems(ProductAccountID)

        CSDWCFService.Close()

        If tmptable1.Rows.Count = 0 Then
            Exit Sub
        End If


        If tmptable.Rows.Count > 0 Then

            Dim CFPROID As String = clsEncr.DecryptString(ProductAccountID)

            Dim sqlstr2 As String = _
                "SELECT   CFPROID, CFAgentName," &
                "CFAgentAddress, EmailAddress, " &
                "Telephone,NextPaymentDate," &
                "CurrentUseCount,ProductStatus," &
                "AboutAccount,AccountURL," &
                "AccountStatus,LogoURL," &
                "CreatedOn,OptionID," &
                "IPAddress,LockIP, ID " &
                "FROM  CFPROAccounts " &
                "Where  CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable("CFPROAccounts")
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            Dim drow, drow2 As DataRow

            drow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            If tmptable2.Rows.Count > 0 Then
                drow2 = tmptable2.Rows(0)
            Else
                drow2 = tmptable2.NewRow
                drow2("CFPROID") = CFPROID
                drow2("CreatedOn") = drow("CreatedOn")
                tmptable2.Rows.Add(drow2)
            End If

            Call clsData.NullChecker(tmptable2, 0)

            drow2("CFAgentName") = drow("AccountName")
            drow2("AboutAccount") = drow("BusinessDescription")
            drow2("EmailAddress") = drow("EmailAddress")
            drow2("Telephone") = drow("Telephone")
            drow2("AccountURL") = drow("BusinessURL")
            drow2("LogoURL") = drow("LogoURL")


            Dim tmpstr As String = drow("Address") & "|" & drow("City") & "|" & drow("Country")
            Dim tmpstr1() As String = tmpstr.Split("|")
            Dim tmpstr2(0) As String

            Dim a, b As Integer
            For a = 0 To tmpstr1.GetUpperBound(0)
                If Not Trim(tmpstr1(a)) = "" Then
                    If Not Trim(tmpstr1(a)) = "--" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = tmpstr1(a)
                        b = b + 1
                    End If
                End If
            Next

            drow2("CFAgentAddress") = Join(tmpstr2, " ")
            drow2("AccountStatus") = drow("AccountStatus")

            If drow2("IPAddress") = "" Then
                drow2("IPAddress") = HttpContext.Current.Request.UserHostAddress
                drow2("LockIP") = CBool(1)
            End If

            Try
                If InStr(drow("LogoURL1"), ".", CompareMethod.Text) > 0 Then
                    Dim tmpstr3() As String = IO.Directory.GetFiles(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\")

                    Dim tmpstr4 As String
                    For Each tmpstr4 In tmpstr3
                        If InStr(tmpstr4, CFPROID, CompareMethod.Text) > 0 Then
                            IO.File.Delete(tmpstr4)
                        End If
                    Next


                    Dim tmpstr5() As String = drow("LogoURL").ToString.Split(".")
                    Dim c As Integer = tmpstr5.GetUpperBound(0)
                    Using nClient As New WebClient
                        nClient.DownloadFile(drow("LogoURL1"), HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & "." & tmpstr5(c))
                    End Using
                End If
            Catch ex As Exception

            End Try


            Dim PaidUseCount As Double
            Dim OptionID As String = ""
            If tmptable1.Rows.Count > 0 Then


                Dim sqlstr3 As String = _
                    "SELECT  CFPROID," &
                    "CFPROUserID, ItemID," &
                    "ItemStatus, NextPaymentDate," &
                    "CurrentUseCount, PaidUseCount," &
                    "UserType, CreditDescription, IsCredit " &
                    "FROM   CFPROAccountItems " &
                    "Where  CFPROID = '" & CFPROID & "' "

                Dim tmptable3 As New DataTable("CFPROAccountItems")
                Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)




                Dim dv1 As New DataView(tmptable1)
                For b = 0 To dv1.Count - 1
                    If dv1(b)("NextPaymentDate") > drow2("NextPaymentDate") Then
                        OptionID = OptionID & " " & dv1(b)("OptionID")
                        PaidUseCount = PaidUseCount + dv1(b)("PaidUseCount")
                    End If
                Next


                drow2("CurrentUseCount") = drow2("CurrentUseCount") + PaidUseCount
                drow2("OptionID") = Trim(OptionID)

                dv1.RowFilter = "OptionID = '" & "00001" & "' "
                dv1.Sort = "NextPaymentDate DESC "
                If dv1.Count > 0 Then
                    If dv1(0)("NextPaymentDate") > drow2("NextPaymentDate") Then
                        drow2("NextPaymentDate") = dv1(0)("NextPaymentDate")
                    End If
                End If

            End If


            Call clsData.SaveData("CFPROAccounts", tmptable2, sqlstr2, False, clsData.constr)
            ntmpTable = tmptable

            If CreateAccountAdmin Then
                Dim dv1 As New DataView(tmptable1)
                dv1.RowFilter = "OptionID = '" & "00001" & "' "
                If dv1.Count > 0 Then
                    Call CreateCFPROAccountAdmin(ProductAccountID, CSDID, "cfagent", "")
                End If

            End If

        End If




    End Sub

    Shared Function AccountAdminConnected(ProductAccountID As String, CSDID As String) As Integer


        Dim CFPROID As String = clsEncr.DecryptString(ProductAccountID)
        Dim UserCSDID As String = clsEncr.DecryptString(CSDID)

        Dim sqlstr As String = _
                   "SELECT UserCSDID, ID " &
                   "FROM CFPROAccountConnect " &
                   "Where  CFPROID = '" & CFPROID & "' " & _
                   "And  UserCSDID = '" & UserCSDID & "' " & _
                   "And Usertype = 'cfagent' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return 1
        Else
            Return 0
        End If

        Return 2

    End Function



    Shared Sub CreateCFPROAccountAdmin(ProductAccountID As String, CSDID As String, UserType As String, UserNames As String)


        Dim tmptable As New DataTable("CFPROAccountAdmin")

        Dim CSDWCFService As New CSDWCFService.CSDService1Client("BasicHttpBinding_ICSDService1")
        tmptable = CSDWCFService.ProductAccountAdmins(ProductAccountID, CSDID)


        Dim CFPROID As String = clsEncr.DecryptString(ProductAccountID)
        Dim UserCSDID As String = clsEncr.DecryptString(CSDID)

        Dim sqlstr1 As String = _
            "Select UserCSDID,CFPROID," &
             "UserID, UserNames, " &
             "JobDescription," & _
             "Department,Telephone," &
             "Email, Role, " & _
             "ReadOnlyUser,TransitUpdateUser," &
             "CFPROAccountAdmin, ID " &
             "From CFAgentUsers " &
             "Where CFPROID ='" & CFPROID & "' " &
             "And UserCSDID = '" & UserCSDID & "' "

        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)



        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim Drow As DataRow = tmptable.Rows(0)

            Dim Drow1 As DataRow
            If tmptable1.Rows.Count = 0 Then
                Drow1 = tmptable1.NewRow
                Drow1("UserCSDID") = UserCSDID
                Drow1("UserID") = GetCFPROUserID()
                Drow1("CFPROID") = CFPROID
                tmptable1.Rows.Add(Drow1)
            Else
                Drow1 = tmptable1.Rows(0)
            End If

            Drow1("UserNames") = Drow("UserNames")
            Drow1("Email") = Drow("EmailAddress")
            Drow1("Telephone") = Drow("Telephone")
            Drow1("Role") = "Super Administrator"
            Drow1("JobDescription") = "C&F PRO Account Administrator"
            Drow1("Department") = "Systems Admins"
            Drow1("CFPROAccountAdmin") = 1
            Drow1("ReadOnlyUser") = 0
            Drow1("TransitUpdateUser") = 0


            Call clsData.SaveData("CFAgentUsers", tmptable1, sqlstr1, False, clsData.constr)


            Call clsData.NullChecker(tmptable1, 0)
            Dim UserAccessCode As String = clsEncr.EncryptString(Drow1("CFPROID") & "|" & Drow1("UserID") & "|" & "cfagent")
            Call ConnectAccount(UserAccessCode, UserCSDID, "cfagent", "")
        End If

        ' CSDWCFService.Close()


    End Sub


    Shared Sub ConnectAccount(ByVal UserAccessCode As String, ByVal UserCSDID As String, ByVal UserType As String, ByRef AddMessage As String)
        Try


            If UserAccessCode = "" Then
                AddMessage = "Invalid User Access Code."
            End If


            Dim tmpstr() As String = clsEncr.DecryptString(UserAccessCode).Split("|")
            ReDim Preserve tmpstr(2)

            If AddingOtherUser(tmpstr(0), UserCSDID, UserType) Then
                AddMessage = "User already has  access for C&F Agent. Cannot Add."
                Exit Sub
            End If

            If tmpstr(2) <> UserType Then
                AddMessage = "Wrong type code for this User."
                Exit Sub
            End If

            If Not tmpstr(0) = "" Then

                Dim sqlstr As String = _
                    "SELECT UserCSDID, CFPROID, CFPROUserID," &
                    "UserType, DateAdded, ID " &
                    "FROM CFPROAccountConnect " &
                    "Where  CFPROID = '" & tmpstr(0) & "' " & _
                    "And  UserCSDID = '" & UserCSDID & "' " & _
                    "And Usertype = '" & UserType & "' "


                Dim tmptable As New DataTable
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                Dim drow As DataRow

                If tmptable.Rows.Count > 0 Then
                    drow = tmptable.Rows(0)
                Else
                    drow = tmptable.NewRow
                    drow("CFPROID") = tmpstr(0)
                    drow("DateAdded") = Format(Now, "dd MMM yyyy")
                    drow("Usertype") = UserType
                    tmptable.Rows.Add(drow)
                End If


                drow("CFPROUserID") = tmpstr(1)
                drow("UserCSDID") = UserCSDID


                Call clsData.SaveData("CFPROAccountConnect", tmptable, sqlstr, False, clsData.constr)
                AddMessage = "User Added Sucessfully!"
            Else
                AddMessage = "Invalid User Access Code."
            End If

        Catch ex As Exception
            AddMessage = "Error. Try again."
        End Try

    End Sub
    Shared Function GetCFPROUserID() As String


        Dim tmpUserID As Integer

        Dim sqlstr As String = _
         "Select top 1 ID " & _
         "From CFAgentUsers " & _
         "Order By Id Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr As String
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            tmpUserID = drow("ID")
            tmpUserID = tmpUserID + 1
            tmpstr = Format(tmpUserID, "000000000#")
        Else
            tmpstr = Format(tmpUserID, "000000000#")
        End If

        Return tmpstr & "-" & clsSubs.GetRandomNo


    End Function
    Shared Function AddingOtherUser(CFPROID As String, UserCSDID As String, UserType As String) As Boolean
        Dim sqlstr As String = _
               "SELECT  ID " &
               "FROM CFPROAccountConnect " &
               "Where  CFPROID = '" & CFPROID & "' " & _
               "And  UserCSDID = '" & UserCSDID & "' " & _
               "And Usertype = '" & UserType & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            If UserType = "cfagent" Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If

    End Function


    Shared Sub UpdateAccountUse(ProductAccountID As String)

    End Sub

    Shared Function SetAvarageRating(nRating As Double) As String()


        Dim mRating As String = Format(nRating, "0.00")

        Dim tmpstr() As String = mRating.Split(".")


        Dim rating As Integer = CInt(tmpstr(0))
        Dim ratingRem As Double = CDbl(tmpstr(1))

        Dim imurl(4) As String
        For a = 0 To 4
            If rating <= a Then
                imurl(a) = "star1.png"
            Else
                imurl(a) = "filledstar1.png"
            End If
        Next


        If ratingRem > 0 And ratingRem <= 25 Then
            imurl(tmpstr(0)) = "filledstar1a.png"

        ElseIf ratingRem > 25 And ratingRem <= 50 Then
            imurl(tmpstr(0)) = "filledstar1b.png"

        ElseIf ratingRem > 50 And ratingRem <= 75 Then
            imurl(tmpstr(0)) = "filledstar1c.png"

        End If



        Return imurl
    End Function



End Class
