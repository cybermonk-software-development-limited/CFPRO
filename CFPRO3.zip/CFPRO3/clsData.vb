﻿Imports System.Data.SqlClient

Public Class clsData

    Shared Function constr(Optional ByRef ErrMsg As String = "") As String
        Try

            Dim constrx As String = ConfigurationManager.ConnectionStrings("CFPRODataConstr").ConnectionString
            Return clsEncr.DecryptString(constrx)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function
    ' Friend Shared JobTable As New DataTable("JobTableStandard")


    Shared Function TableData(ByVal Sqlstr As String, ByVal Table As DataTable, ByVal Connstr As String) As String
        Try
            Dim Connection As New SqlConnection()
            Connection.ConnectionString = Connstr
            Dim DataAdpt As New SqlDataAdapter()
            Dim Command1 As SqlCommand =
            New SqlCommand(Sqlstr, Connection)

            ' DataAdpt.MissingSchemaAction = MissingSchemaAction.AddWithKey

            DataAdpt.SelectCommand = Command1
            DataAdpt.Fill(Table)
            Connection.Close()

            Return "Query Successful"
        Catch exp As Exception
            Return exp.Message & exp.StackTrace
        End Try
    End Function



    Shared Sub PopCombo(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                              ByVal connstr As String, ByVal index As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        While Reader1.Read
            If Not IsDBNull(Reader1(index)) Then
                Combo1.Items.Add(Reader1(index))
            Else
                Combo1.Items.Add("")
            End If
        End While
        connection1.Close()
    End Sub

    Shared Sub PopComboWithValue(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                            ByVal connstr As String, ByVal index As Integer, Index1 As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader


        While Reader1.Read
            If Not IsDBNull(Reader1(index)) And Not IsDBNull(Reader1(Index1)) Then
                If Not Trim(Reader1(index)) = "" Then
                    If Not Trim(Reader1(index)) = "" Then
                        Combo1.Items.Add(Reader1(index))
                        Combo1.Items(Combo1.Items.Count - 1).Value = Reader1(Index1)
                    End If
                End If
            End If

        End While
        connection1.Close()
    End Sub

    Shared Sub PopRadioListWithValue(ByVal RadioList As RadioButtonList, ByVal sqlstr As String, _
                         ByVal connstr As String, ByVal index As Integer, Index1 As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        While Reader1.Read
            If Not IsDBNull(Reader1(index)) Then
                RadioList.Items.Add(Reader1(index))
                RadioList.Items(RadioList.Items.Count - 1).Value = Reader1(Index1)
            End If
        End While
        connection1.Close()
    End Sub
    Shared Sub PopCombo1(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                         ByVal connstr As String, ByVal index As Integer, ByVal index1 As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        Combo1.Items.Add("(select)")
        While Reader1.Read
            Combo1.Items.Add(Reader1(index) & " - " & Reader1(index1))
        End While
        connection1.Close()
    End Sub

    Shared Sub PopCombo1a(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                        ByVal connstr As String, ByVal index As Integer, ByVal index1 As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        Combo1.Items.Add("(select)")
        While Reader1.Read
            a = a + 1
            Combo1.Items.Add(Reader1(index1))
            Combo1.Items(a).Value = Reader1(index)

        End While
        connection1.Close()
    End Sub

    Shared Sub PopCombo2(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                          ByVal connstr As String, ByVal index As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        While Reader1.Read
            Combo1.Items.Add(Reader1(index))
        End While
        connection1.Close()
    End Sub



    Shared Sub PopCombo2x(ByVal Combo1 As DropDownList, ByVal sqlstr As String, _
                         ByVal connstr As String, ByVal index As Integer)

        Dim connection1 As New SqlConnection(connstr)
        Dim Reader1 As SqlDataReader
        Dim Command1 As New SqlCommand(sqlstr, connection1)

        connection1.Open()
        Reader1 = Command1.ExecuteReader
        Dim a As Integer = 0
        While Reader1.Read
            Combo1.Items.Add(clsSubs.Capitalise(Reader1(index)))
        End While
        connection1.Close()
    End Sub


    Shared Sub PopList(ByVal List1 As ListBox, ByVal sqlstr As String, _
                      ByVal connstr As String, ByVal index As Integer)

        Try
            Dim connection1 As New SqlConnection(connstr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, connection1)

            connection1.Open()
            Reader1 = Command1.ExecuteReader
            While Reader1.Read
                If Not IsDBNull(Reader1(index)) Then
                    If Not Trim(Reader1(index)) = "" Then
                        List1.Items.Add(Reader1(index))
                    End If
                End If

            End While
            connection1.Close()
        Catch exp As Exception
        End Try
    End Sub


    Shared Sub SaveData(ByRef SourceTable As String, ByRef TabletoSave As DataTable,
        ByVal SourceSqlstr As String, ByVal Delete As Boolean, ByVal Connstr As String, Optional ByRef ErrMsg As String = "")

        Try

            'delete deleted items first
            Dim a As Integer
            Dim Drow As DataRow
            Dim Drow1 As DataRow

            If Delete Then

                Dim tmpSource As New DataTable()
                Dim sqlstr As String

                If Not SourceSqlstr = "" Then
                    sqlstr = SourceSqlstr
                Else
                    sqlstr = "Select Id From " & SourceTable
                End If

                clsData.TableData(sqlstr, tmpSource, Connstr)

                Dim Connection1 As New SqlConnection(Connstr)
                Connection1.Open()


                Dim DeleteStr As String = "Delete From " & SourceTable & " " &
                                          "Where @Id= ID"

                Dim CmdDelete As New SqlCommand()

                With CmdDelete
                    .Connection = Connection1
                    .CommandType = CommandType.Text
                    .CommandText = DeleteStr

                    .Parameters.AddWithValue("@Id", 1)

                    a = 0
                    For Each Drow In TabletoSave.Rows
                        If Drow.RowState = DataRowState.Deleted Then
                            Drow1 = tmpSource.Rows(a)
                            .Parameters("@Id").Value = Drow1("Id")
                            .ExecuteNonQuery()
                        End If
                        a = a + 1
                    Next
                End With
                Connection1.Close()
            End If


            Dim ColNames() As String
            Dim ColNamesAdded() As String
            Dim ColNamesUpdate() As String

            For a = 0 To TabletoSave.Columns.Count - 2
                ReDim Preserve ColNames(a), ColNamesUpdate(a), ColNamesAdded(a)
                ColNames(a) = TabletoSave.Columns(a).ColumnName
                ColNamesAdded(a) = "@" & TabletoSave.Columns(a).ColumnName
                ColNamesUpdate(a) = TabletoSave.Columns(a).ColumnName & " = " & "@" & TabletoSave.Columns(a).ColumnName
            Next

            'Modified xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

            Dim tmpStr As String = Join(ColNamesUpdate, ", ")
            Dim UpdateStr As String =
            "UPDATE " & SourceTable & " SET " & tmpStr & " Where ID = @ID"

            Dim Connection3 As New SqlConnection(Connstr)
            Dim CmdUpdate As New SqlCommand(UpdateStr, Connection3)


            For a = 0 To TabletoSave.Columns.Count - 2
                With CmdUpdate
                    Dim Col As String = TabletoSave.Columns(a).ColumnName
                    If TabletoSave.Columns(a).DataType Is Type.GetType("System.String") Then
                        .Parameters.Add(New SqlParameter("@" & Col, SqlDbType.NVarChar))
                        .Parameters(a).Direction = ParameterDirection.Input
                        .Parameters(a).Size = 4000
                        .Parameters(a).SourceColumn = TabletoSave.Columns(a).ColumnName
                        .Parameters(a).SourceVersion = DataRowVersion.Current
                        .Parameters(a).Precision = 0
                    End If

                    If TabletoSave.Columns(a).DataType Is Type.GetType("System.Int32") Then
                        .Parameters.Add(New SqlParameter("@" & Col, SqlDbType.Int))
                        .Parameters(a).Direction = ParameterDirection.Input
                        .Parameters(a).Size = 10
                        .Parameters(a).SourceColumn = TabletoSave.Columns(a).ColumnName
                        .Parameters(a).SourceVersion = DataRowVersion.Current
                        .Parameters(a).Precision = 10
                    End If

                    If TabletoSave.Columns(a).DataType Is Type.GetType("System.Decimal") Then
                        .Parameters.Add(New SqlParameter("@" & Col, SqlDbType.Decimal))
                        .Parameters(a).Direction = ParameterDirection.Input
                        .Parameters(a).Size = 9
                        .Parameters(a).SourceColumn = TabletoSave.Columns(a).ColumnName
                        .Parameters(a).SourceVersion = DataRowVersion.Current
                        .Parameters(a).Precision = 18
                    End If

                    If TabletoSave.Columns(a).DataType Is Type.GetType("System.Boolean") Then
                        .Parameters.Add(New SqlParameter("@" & Col, SqlDbType.Bit))
                        .Parameters(a).SourceColumn = TabletoSave.Columns(a).ColumnName
                        .Parameters(a).Direction = ParameterDirection.Input
                        .Parameters(a).Size = 1
                        .Parameters(a).SourceVersion = DataRowVersion.Current
                        .Parameters(a).Precision = 0
                    End If

                    If TabletoSave.Columns(a).DataType Is Type.GetType("System.DateTime") Then
                        .Parameters.Add(New SqlParameter("@" & Col, SqlDbType.DateTime))
                        .Parameters(a).SqlDbType = SqlDbType.DateTime
                        .Parameters(a).SourceColumn = TabletoSave.Columns(a).ColumnName
                        .Parameters(a).Direction = ParameterDirection.Input
                        .Parameters(a).Size = 8
                        .Parameters(a).SourceVersion = DataRowVersion.Current
                        .Parameters(a).Precision = 0
                    End If
                End With
            Next

            With CmdUpdate
                .Parameters.Add(New SqlParameter("@ID", SqlDbType.Int))
                .Parameters(a).SourceColumn = "ID"
                .Parameters(a).Size = 4
                .Parameters(a).SourceVersion = DataRowVersion.Original
                .Parameters(a).Precision = 10
            End With


            Connection3.Open()

            With CmdUpdate
                .CommandType = CommandType.Text

                For Each Drow In TabletoSave.Rows
                    If Drow.RowState = DataRowState.Modified Then
                        .Parameters("@ID").Value = Drow("ID")
                        For a = 0 To TabletoSave.Columns.Count - 2
                            .Parameters(a).Value = Drow(a)
                        Next
                        .ExecuteNonQuery()
                    End If
                Next
            End With
            Connection3.Close()


            'Add xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


            Dim FieldsStr As String = Join(ColNames, ", ")
            Dim AddedfieldsStr As String = Join(ColNamesAdded, ", ")

            Dim InsertStr As String =
                        "Insert Into " & SourceTable & " (" & FieldsStr & ") " &
                        "Values (" & AddedfieldsStr & ")"

            Dim Connection2 As New SqlConnection(Connstr)
            Connection2.Open()

            Dim CmdAdded As New SqlCommand()
            With CmdAdded
                .CommandType = CommandType.Text
                .CommandText = InsertStr
                .Connection = Connection2

                For Each Drow In TabletoSave.Rows
                    .Parameters.Clear()
                    If Drow.RowState = DataRowState.Added Then
                        For a = 0 To ColNamesAdded.GetUpperBound(0)
                            .Parameters.AddWithValue(ColNamesAdded(a), Drow(a))
                        Next
                        .ExecuteNonQuery()
                    End If
                Next
            End With

            Connection2.Close()


            TabletoSave.AcceptChanges()


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub


    Shared Sub NullChecker(ByRef tmptable As DataTable, ByVal RowIndex As Integer)
        Try
            Dim a As Integer
            For a = 0 To tmptable.Columns.Count - 1
                Dim Drow As DataRow

                Drow = tmptable.Rows(RowIndex)
                If Not Drow.RowState = DataRowState.Deleted Then
                    If IsDBNull(Drow(a)) Then
                        If tmptable.Columns(a).DataType Is Type.GetType("System.String") Then
                            Drow(a) = ""
                        End If
                        If tmptable.Columns(a).DataType Is Type.GetType("System.DateTime") Then
                            Drow(a) = "1-Jan-1800"
                            If CDate(Drow(a)) = CDate("31-Dec-1799") Then
                                Drow(a) = "1-Jan-1800"
                            End If
                        End If

                        If tmptable.Columns(a).DataType Is Type.GetType("System.Double") Then
                            Drow(a) = 0
                        End If

                        If tmptable.Columns(a).DataType Is Type.GetType("System.Int32") Then
                            Drow(a) = 0
                        End If

                        If tmptable.Columns(a).DataType Is Type.GetType("System.Decimal") Then
                            Drow(a) = 0
                        End If

                        If tmptable.Columns(a).DataType Is Type.GetType("System.Boolean") Then
                            Drow(a) = CBool(0)
                        End If
                    Else
                        If tmptable.Columns(a).DataType Is Type.GetType("System.DateTime") Then
                            If CDate(Drow(a)) <= CDate("1-Jan-1800") Then
                                Drow(a) = "1-Jan-1800"
                            End If
                        End If
                    End If
                End If
            Next
        Catch exp As Exception

        End Try
    End Sub

    Shared Sub NullChecker1(ByRef dv As DataView, ByVal RowIndex As Integer)
        Try
            Dim a As Integer

            Dim tmptable As DataTable = dv.Table
            Dim Noallowedit As Boolean
            If Not dv.AllowEdit = True Then
                dv.AllowEdit = True
                Noallowedit = True
            End If

            For a = 0 To tmptable.Columns.Count - 1
                If IsDBNull(dv(RowIndex)(a)) Then
                    If tmptable.Columns(a).DataType Is Type.GetType("System.String") Then
                        dv(RowIndex)(a) = ""
                    End If

                    If tmptable.Columns(a).DataType Is Type.GetType("System.DateTime") Then
                        dv(RowIndex)(a) = "1-Jan-1800"
                    End If

                    If tmptable.Columns(a).DataType Is Type.GetType("System.Double") Then
                        dv(RowIndex)(a) = 0
                    End If

                    If tmptable.Columns(a).DataType Is Type.GetType("System.Int32") Then
                        dv(RowIndex)(a) = 0
                    End If

                    If tmptable.Columns(a).DataType Is Type.GetType("System.Decimal") Then
                        dv(RowIndex)(a) = 0
                    End If

                    If tmptable.Columns(a).DataType Is Type.GetType("System.Boolean") Then
                        dv(RowIndex)(a) = CBool(0)
                    End If
                Else
                    If tmptable.Columns(a).DataType Is Type.GetType("System.DateTime") Then
                        If CDate(dv(RowIndex)(a)) <= CDate("1-Jan-1800") Then
                            dv(RowIndex)(a) = "1-Jan-1800"
                        End If
                    End If
                End If
            Next

            If Noallowedit Then
                dv.AllowEdit = False
            End If

        Catch exp As Exception

        End Try
    End Sub

    Shared Function TableCacheOK(CFPROID As String, CachedTable As DataTable)
        Dim drow As DataRow

        Dim a As Integer
        If CachedTable.Columns.Contains("CFPROID") Then
            For Each drow In CachedTable.Rows
                Call clsData.NullChecker(CachedTable, a)
                If a < 6 Then
                    If Not drow("CFPROID") = CFPROID Then
                        Return False
                    End If
                Else
                    Exit For
                End If

                a = a + 1
            Next
        Else
            Return False
        End If

        Return True
    End Function

    Shared Function GetCFAgents(ByVal prefixText As String, ByVal count As Integer) As List(Of String)

        Try

            Dim sqlstr As String =
                      "SELECT  Top 8 CFAgentName,CFPROID " &
                      "FROM CFPROAccounts " &
                      "Where CFAgentName Like + @SearchText + '%'  " &
                      "Order by CFAgentName Asc;"

            Dim conn As SqlConnection = New SqlConnection
            Dim connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim CFAgents As List(Of String) = New List(Of String)

            While Reader1.Read
                If Not IsDBNull(Reader1("CFAgentName")) Then
                    CFAgents.Add(AjaxControlToolkit.AutoCompleteExtender _
               .CreateAutoCompleteItem(Reader1("CFAgentName"), Reader1("CFPROID")))
                End If
            End While
            connection1.Close()

            Return CFAgents
        Catch ex As Exception
            Return Nothing
        End Try

        Return Nothing

    End Function



End Class
