﻿

Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf
Public Class clsJobCardPDF

    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x2, 842 - y2)

        contentByte.SetLineWidth(0.001)
        contentByte.SetRGBColorStroke(100, 100, 100)
        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - (y1 + height))
        contentByte.LineTo(x1, 842 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 842 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Function getCell(ByVal text As String, ByVal alignment As Integer, fnt As Font) As PdfPCell
        Dim cell As PdfPCell = New PdfPCell(New Phrase(text, fnt))
        cell.PaddingTop = 10
        cell.HorizontalAlignment = alignment
        cell.Border = PdfPCell.NO_BORDER
        Return cell
    End Function

    Shared Function setRect(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single) As PdfRectangle
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        y1 = 842 - y1

        width = width * 0.75
        height = height * 0.75
        Dim rect As New PdfRectangle(x1, y1, width, height)
        Return rect
    End Function

    Shared Function JobCardDoc(CFPROID As String, JobID As String, tmptable As DataTable, ByRef ErrMsg As String) As String
        Try
            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)


            Dim font6b As New Font(customfontb, 6)
            Dim font7b As New Font(customfontb, 7.4)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfontb, 8)
            Dim font8r As New Font(customfont, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            ' Dim font11ca As New Font(customfontc, 10.5)
            'Dim font11b As New Font(customfontb, 11)
            Dim font10b As New Font(customfontb, 10)
            Dim font16 As New Font(customfontb, 16)
            Dim font22b As New Font(customfontb, 22)

            'Dim drf As New Drawing.StringFormat()

            Dim brush1 As Drawing.Color = Drawing.Color.Black
            'Dim brush2 As Drawing.Color = Drawing.Color.Gray
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
            'Dim PDFReader As PdfReader = Nothing 'Read File

            ' Document starts here
            'Dim regdocpath As String = HttpContext.Current.Server.MapPath(".") & "\regdocs\" & JobCardPDFName & ".pdf"


            Dim logospath As String = ""

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".jpg") Then
                logospath = HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".jpg"
            ElseIf File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".png") Then
                logospath = HttpContext.Current.Server.MapPath(".") & "\cfagentimages\" & CFPROID & ".png"
            Else
                logospath = HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp"
            End If

            Dim JobCardPDF As New Document(PageSize.A4, 0, 0, 0, 10)
            Dim logo As Image = Image.GetInstance(logospath)

            'New FileStream(regdocpath, FileMode.Create)



            Dim sqlstr1 As String =
                        "Select CFAgentName,CFAgentAddress,ID " &
                        "From CFPROAccounts " &
                        "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Using memoryStream As New System.IO.MemoryStream()


                Dim PDFwriter As PdfWriter = PdfWriter.GetInstance(JobCardPDF, memoryStream)
                JobCardPDF.Open()
                logo.ScaleToFit(695, 60)
                logo.SetAbsolutePosition(25, 755)
                JobCardPDF.Add(logo)

                Dim StringWriter As PdfContentByte = PDFwriter.DirectContent


                If tmptable1.Rows.Count > 0 Then
                    Dim drow9 As DataRow = tmptable1.Rows(0)
                    Call clsData.NullChecker(tmptable1, 0)
                    Dim ct3 As New ColumnText(StringWriter)
                    ct3.SetSimpleColumn(25, 800, 580, 50, 5, Element.ALIGN_RIGHT)
                    ct3.AddText(New Paragraph(drow9("CFAgentName"), font16))
                    ct3.Go()

                    Dim Ct4 As New ColumnText(StringWriter)
                    Ct4.SetSimpleColumn(25, 786, 580, 50, 5, Element.ALIGN_RIGHT)
                    Ct4.AddText(New Paragraph(drow9("CFAgentAddress"), font7))
                    Ct4.Go()


                    Dim Ct5 As New ColumnText(StringWriter)
                    Ct5.SetSimpleColumn(25, 830, 580, 50, 5, Element.ALIGN_LEFT)
                    Ct5.AddText(New Paragraph("QMF 06.24", font8b))
                    Ct5.Go()

                    Dim Ct6 As New ColumnText(StringWriter)
                    Ct6.SetSimpleColumn(25, 830, 580, 50, 5, Element.ALIGN_CENTER)
                    Ct6.AddText(New Paragraph("ISSUE NO. 3", font8b))
                    Ct6.Go()


                    Dim Ct7 As New ColumnText(StringWriter)
                    Ct7.SetSimpleColumn(25, 830, 580, 50, 5, Element.ALIGN_RIGHT)
                    Ct7.AddText(New Paragraph("Issue Date: 18.02.2016", font8b))
                    Ct7.Go()

                End If



                'Create line pens
                Dim pen As PdfContentByte = PDFwriter.DirectContent
                Dim pen1 As PdfContentByte = PDFwriter.DirectContent
                Dim pen2 As PdfContentByte = PDFwriter.DirectContent
                Dim pen3 As PdfContentByte = PDFwriter.DirectContent

                'pen.SetRGBColorStroke(195, 195, 195)
                'pen1.SetRGBColorStroke(195, 195, 195)
                'pen2.SetRGBColorStroke(0, 0, 0)
                'pen3.SetRGBColorStroke(0, 0, 0)

                'pen.SetLineWidth(0)
                'pen1.SetLineWidth(0.5)
                'pen2.SetLineWidth(0.5)

                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                Dim docfooterpath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp"


                DrawString("FILE OPENING FORM", font16, brush1, 32, 130, StringWriter)

                DrawString("FILE REF NO:", font10b, brush1, 32, 165, StringWriter)
                DrawString(drow("FileRefNo"), font10b, brush2, 200, 165, StringWriter)
                DrawString("NATURE OF CARGO:", font10b, brush1, 32, 185, StringWriter)
                DrawString(drow("JobType"), font10b, brush2, 200, 185, StringWriter)

                DrawString("OPENED BY:", font10b, brush1, 450, 165, StringWriter)
                DrawString(drow("OpenedBy"), font10b, brush2, 600, 165, StringWriter)
                DrawString("DATE:", font10b, brush1, 450, 185, StringWriter)
                DrawString(drow("JobDate"), font10b, brush2, 600, 185, StringWriter)

                DrawLine(pen1, 180, 205, 180, 440)

                DrawLine(pen1, 25, 205, 775, 205)

                font10b.Color = BaseColor.BLUE

                DrawString("Client:", font9b, brush1, 32, 210, StringWriter)
                Dim rect1 As Rectangle = New Rectangle(185 * 0.75, 0.75 * 245, 0.75 * 775, 842 - 0.75 * 205)
                Dim ct1 As ColumnText = New ColumnText(StringWriter)
                ct1.SetSimpleColumn(rect1)
                ct1.AddElement(New Paragraph(drow("Client"), font10b))
                ct1.Go()
                DrawLine(pen1, 25, 255, 775, 255)
                DrawString("Consignee:", font9b, brush1, 32, 260, StringWriter)
                Dim rect2 As Rectangle = New Rectangle(185 * 0.75, 0.75 * 295, 0.75 * 775, 842 - 0.75 * 255)
                Dim ct2 As ColumnText = New ColumnText(StringWriter)
                ct2.SetSimpleColumn(rect2)
                ct2.AddElement(New Paragraph(drow("Consignee"), font10b))
                ct2.Go()
                DrawLine(pen1, 25, 305, 775, 305)
                DrawString("Cargo Description:", font9b, brush1, 32, 310, StringWriter)
                Dim rect As Rectangle = New Rectangle(185 * 0.75, 0.75 * 360, 0.75 * 775, 842 - 0.75 * 300)
                Dim ct As ColumnText = New ColumnText(StringWriter)
                ct.SetSimpleColumn(rect)
                ct.AddElement(New Paragraph(drow("CargoDescription"), font10b))
                ct.Go()
                DrawLine(pen1, 25, 370, 775, 370)
                DrawString("Cargo Weight:", font9b, brush1, 32, 375, StringWriter)

                DrawString("MTN:", font8b, brush1, 185, 372, StringWriter)
                DrawString(drow("MTN"), font10b, brush2, 185, 387, StringWriter)
                DrawString("MTG:", font8b, brush1, 383, 372, StringWriter)
                DrawString(drow("MTG"), font10b, brush2, 383, 387, StringWriter)
                DrawString("CBM:", font8b, brush1, 581, 372, StringWriter)
                DrawString(drow("CBM"), font10b, brush2, 581, 387, StringWriter)

                DrawLine(pen1, 25, 410, 775, 410)
                DrawString("Destination:", font9b, brush1, 32, 415, StringWriter)
                DrawString(drow("Destination"), font10b, brush2, 185, 415, StringWriter)
                DrawLine(pen1, 25, 440, 775, 440)

                DrawLine(pen1, 400, 445, 400, 775)

                DrawLine(pen1, 180, 445, 180, 505)
                DrawLine(pen1, 555, 445, 555, 505)

                DrawLine(pen1, 25, 445, 775, 445)
                DrawString("For Imports", font9b, brush1, 70, 455, StringWriter)
                DrawString("For Exports", font9b, brush1, 445, 455, StringWriter)
                DrawLine(pen1, 25, 475, 775, 475)
                DrawString("MBL", font9b, brush1, 32, 480, StringWriter)
                DrawString(drow("MBL"), font10b, brush2, 255, 480, StringWriter)
                DrawString("Shipping Order", font9b, brush1, 405, 480, StringWriter)
                DrawString(drow("ShippingOrder"), font10b, brush2, 600, 480, StringWriter)
                DrawLine(pen1, 25, 505, 775, 505)
                DrawString("MBL No:", font9b, brush1, 32, 510, StringWriter)
                DrawString(drow("MBLNo"), font10b, brush2, 140, 510, StringWriter)
                DrawString("SO No:", font9b, brush1, 405, 510, StringWriter)
                DrawString(drow("SONo"), font10b, brush2, 513, 510, StringWriter)

                DrawLine(pen1, 180, 535, 180, 565)
                DrawString("Original/Copy", font9b, brush1, 230, 455, StringWriter)
                DrawLine(pen1, 555, 535, 555, 775)
                DrawString("Original/Copy", font9b, brush1, 590, 455, StringWriter)

                DrawLine(pen1, 25, 535, 775, 535)
                DrawString("HBL", font9b, brush1, 32, 540, StringWriter)
                DrawString(drow("HBL"), font10b, brush2, 255, 540, StringWriter)
                DrawString("Shipping Instructions", font9b, brush1, 405, 540, StringWriter)
                DrawString(drow("SHippingInstructions"), font10b, brush2, 560, 540, StringWriter)
                DrawLine(pen1, 25, 565, 775, 565)
                DrawString("HBL No:", font9b, brush1, 32, 570, StringWriter)
                DrawString(drow("HBLNo"), font10b, brush2, 140, 570, StringWriter)
                DrawString("Invoice", font9b, brush1, 405, 570, StringWriter)
                DrawString(drow("Invoice"), font10b, brush2, 185, 570, StringWriter)

                DrawLine(pen1, 180, 595, 180, 775)

                DrawLine(pen1, 25, 595, 775, 595)
                DrawString("Invoice", font9b, brush1, 32, 600, StringWriter)
                DrawString(drow("Invoice"), font10b, brush2, 560, 570, StringWriter)
                DrawString("Tally Sheet", font9b, brush1, 405, 600, StringWriter)
                DrawString(drow("TallySheet"), font10b, brush2, 560, 600, StringWriter)
                DrawLine(pen1, 25, 625, 775, 625)
                DrawString("Packing List", font9b, brush1, 32, 630, StringWriter)
                DrawString(drow("ParkingList"), font10b, brush2, 185, 630, StringWriter)
                DrawString("Other Document(s)", font9b, brush1, 405, 630, StringWriter)
                DrawString(drow("OtherDocument"), font10b, brush2, 560, 630, StringWriter)

                DrawLine(pen1, 25, 655, 400, 655)
                DrawString("C.O.C", font9b, brush1, 32, 660, StringWriter)
                DrawString(drow("COC"), font10b, brush2, 185, 660, StringWriter)
                DrawLine(pen1, 25, 685, 400, 685)
                DrawString("Other Document(s)", font9b, brush1, 32, 690, StringWriter)
                DrawString(drow("OtherDocument"), font10b, brush2, 185, 690, StringWriter)

                DrawLine(pen1, 25, 775, 775, 775)

                DrawLine(pen1, 775, 785, 775, 935)

                DrawLine(pen1, 25, 785, 775, 785)
                DrawString("For Accounts", font9b, brush1, 32, 790, StringWriter)
                DrawString("Job Scope:", font8b, brush1, 32, 805, StringWriter)
                DrawString(drow("JobScope"), font10b, brush2, 160, 805, StringWriter)
                DrawString("Agreed Rate:", font8b, brush1, 32, 835, StringWriter)
                DrawString(drow("AgreedRate"), font10b, brush2, 160, 835, StringWriter)
                DrawString("Total Due:", font8b, brush1, 32, 865, StringWriter)
                DrawString(drow("TotalDue"), font10b, brush2, 160, 865, StringWriter)
                DrawString("Agreed Terms:", font8b, brush1, 32, 895, StringWriter)
                DrawString(drow("AgreedTerms"), font10b, brush2, 160, 895, StringWriter)

                DrawString("Checked By:", font8b, brush1, 32, 955, StringWriter)
                DrawString(drow("CheckedBy1"), font10b, brush2, 32, 970, StringWriter)
                DrawLine(pen1, 135, 950, 135, 1030)
                DrawString("Date:", font8b, brush1, 140, 955, StringWriter)
                DrawString(drow("CheckedBy1Date"), font10b, brush2, 140, 970, StringWriter)
                DrawLine(pen1, 213, 950, 213, 1050)
                DrawString("Checked By:", font8b, brush1, 218, 955, StringWriter)
                DrawString(drow("CheckedBy2"), font10b, brush2, 218, 970, StringWriter)
                DrawLine(pen1, 323, 950, 323, 1030)
                DrawString("Date:", font8b, brush1, 328, 955, StringWriter)
                DrawString(drow("CheckedBy2Date"), font10b, brush2, 328, 970, StringWriter)
                DrawLine(pen1, 400, 950, 400, 1050)
                DrawString("Approved By:", font8b, brush1, 405, 955, StringWriter)
                DrawString(drow("ApprovedBy1"), font10b, brush2, 405, 970, StringWriter)
                DrawLine(pen1, 510, 950, 510, 1030)
                DrawString("Date:", font8b, brush1, 515, 955, StringWriter)
                DrawString(drow("ApprovedBy1Date"), font10b, brush2, 515, 970, StringWriter)
                DrawLine(pen1, 588, 950, 588, 1050)
                DrawString("Approved By:", font8b, brush1, 593, 955, StringWriter)
                DrawString(drow("ApprovedBy2"), font10b, brush2, 593, 970, StringWriter)
                DrawLine(pen1, 698, 950, 698, 1030)
                DrawString("Date:", font8b, brush1, 703, 955, StringWriter)
                DrawString(drow("ApprovedBy2Date"), font10b, brush2, 703, 970, StringWriter)
                DrawLine(pen1, 775, 950, 775, 1050)


                DrawLine(pen1, 25, 950, 775, 950)
                DrawLine(pen1, 25, 1030, 775, 1030)
                DrawString("Finance Manager", font8b, brush1, 75, 1033, StringWriter)
                DrawString("General Manager", font8b, brush1, 263, 1033, StringWriter)
                DrawString("Director 1", font8b, brush1, 475, 1033, StringWriter)
                DrawString("Director 2", font8b, brush1, 663, 1033, StringWriter)
                DrawLine(pen1, 25, 1050, 775, 1050)

                JobCardPDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")
                JobCardPDF.Close()

                Dim JobCardsPath As String = HttpContext.Current.Server.MapPath(".") & "\jobcards"
                If Not Directory.Exists(JobCardsPath) Then
                    Directory.CreateDirectory(JobCardsPath)
                End If

                If Not Directory.Exists(JobCardsPath & "\" & CFPROID) Then
                    Directory.CreateDirectory(JobCardsPath & "\" & CFPROID)
                End If

                Dim JobCardPDFName As String = JobCardsPath & "\" & CFPROID & "\" & JobID & ".pdf"


                If File.Exists(JobCardPDFName) Then
                    File.Delete(JobCardPDFName)
                End If


                Dim bytes As Byte() = memoryStream.ToArray()

                ' Write out PDF from memory stream. 
                Using fs As FileStream = File.Create(JobCardPDFName)
                    fs.Write(bytes, 0, CInt(bytes.Length))
                End Using


                memoryStream.Close()
                Return "~\JobCards\" & CFPROID & "\" & JobID & ".pdf"

                'HttpContext.Current.Response.ClearContent()
                'HttpContext.Current.Response.ClearHeaders()
                'HttpContext.Current.Response.End()
                'HttpContext.Current.Response.Flush()
                'HttpContext.Current.Response.Clear()
                'HttpContext.Current.Response.Close()


                'HttpContext.Current.Response.ContentType = "application/pdf"
                'HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" & fileName)
                'HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache)
                'HttpContext.Current.Response.Buffer = True
                'HttpContext.Current.Response.BinaryWrite()




            End Using


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function CreateJobCardPDF(CFPROID As String, tmptable As DataTable, ByRef fileName As String, ByRef ErrMsg As String) As String
        Try

            Dim drow As DataRow

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
            Else
                Return ""
            End If

            '-------------------------------------------------------------------------------'
            'The fields in tmptable1 required by clsJobCardPDF.JobCardDoc() are set here       '
            '-------------------------------------------------------------------------------'
            Dim tmptable1 As New DataTable

            tmptable1.Columns.Add("IssueNo", Type.GetType("System.String"))
            tmptable1.Columns.Add("QMF", Type.GetType("System.String"))
            tmptable1.Columns.Add("FileRefNo", Type.GetType("System.String"))
            tmptable1.Columns.Add("OpenedBy", Type.GetType("System.String"))
            tmptable1.Columns.Add("JobDate", Type.GetType("System.String"))
            tmptable1.Columns.Add("JobType", Type.GetType("System.String"))
            tmptable1.Columns.Add("Client", Type.GetType("System.String"))
            tmptable1.Columns.Add("Consignee", Type.GetType("System.String"))
            tmptable1.Columns.Add("CargoDescription", Type.GetType("System.String"))
            tmptable1.Columns.Add("MTN", Type.GetType("System.String"))
            tmptable1.Columns.Add("MTG", Type.GetType("System.String"))
            tmptable1.Columns.Add("CBM", Type.GetType("System.String"))
            tmptable1.Columns.Add("Destination", Type.GetType("System.String"))
            tmptable1.Columns.Add("MBL", Type.GetType("System.String")) 'value is either COPY or ORIGINAL
            tmptable1.Columns.Add("MBLNo", Type.GetType("System.String"))
            tmptable1.Columns.Add("HBL", Type.GetType("System.String")) 'value is either COPY or ORIGINAL
            tmptable1.Columns.Add("HBLNo", Type.GetType("System.String"))
            tmptable1.Columns.Add("Invoice", Type.GetType("System.String"))
            tmptable1.Columns.Add("ParkingList", Type.GetType("System.String"))
            tmptable1.Columns.Add("COC", Type.GetType("System.String"))
            tmptable1.Columns.Add("OtherDocument", Type.GetType("System.String"))
            tmptable1.Columns.Add("ShippingOrder", Type.GetType("System.String")) 'value is either COPY or ORIGINAL
            tmptable1.Columns.Add("SONo", Type.GetType("System.String"))
            tmptable1.Columns.Add("ShippingInstructions", Type.GetType("System.String"))
            tmptable1.Columns.Add("TallySheet", Type.GetType("System.String"))
            tmptable1.Columns.Add("JobScope", Type.GetType("System.String"))
            tmptable1.Columns.Add("AgreedRate", Type.GetType("System.String"))
            tmptable1.Columns.Add("TotalDue", Type.GetType("System.String"))
            tmptable1.Columns.Add("AgreedTerms", Type.GetType("System.String"))
            tmptable1.Columns.Add("CheckedBy1", Type.GetType("System.String"))
            tmptable1.Columns.Add("CheckedBy2", Type.GetType("System.String"))
            tmptable1.Columns.Add("ApprovedBy1", Type.GetType("System.String"))
            tmptable1.Columns.Add("ApprovedBy2", Type.GetType("System.String"))
            tmptable1.Columns.Add("CheckedBy1Date", Type.GetType("System.String"))
            tmptable1.Columns.Add("CheckedBy2Date", Type.GetType("System.String"))
            tmptable1.Columns.Add("ApprovedBy1Date", Type.GetType("System.String"))
            tmptable1.Columns.Add("ApprovedBy2Date", Type.GetType("System.String"))
            tmptable1.Columns.Add("JobID", Type.GetType("System.String"))




            Dim drow1 As DataRow = tmptable1.NewRow

            drow1("IssueNo") = ""
            drow1("QMF") = ""
            drow1("JobID") = drow("JobID")
            drow1("FileRefNo") = drow("ReferenceNo")
            drow1("JobDate") = Format(drow("JobDate"), "dd MMM yyyy")
            drow1("OpenedBy") = clsGetIdentities.SetCFPROuser(CFPROID, drow("UserID"), drow("JobID"), "", False)
            drow1("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")
            drow1("Client") = clsGetIdentities.SetClient(CFPROID, drow("JobID"), drow("ClientID"), ErrMsg)
            drow1("Consignee") = clsGetIdentities.SetImporter(CFPROID, drow("JobID"), drow("ImporterID"), ErrMsg)
            drow1("CargoDescription") = drow("Goods")
            drow1("MTN") = Format(drow("Weight"), "#,##0.00")
            drow1("MTG") = ""
            drow1("CBM") = Format(drow("CBM"), "#,##0.00")
            drow1("Destination") = drow("Destination")
            drow1("MBL") = ""
            drow1("MBLNo") = drow("BL")
            drow1("HBL") = ""
            drow1("HBLNo") = drow("HouseBL")
            drow1("Invoice") = ""
            drow1("ParkingList") = ""
            drow1("COC") = ""
            drow1("OtherDocument") = ""
            drow1("ShippingOrder") = ""
            drow1("SONo") = ""
            drow1("ShippingInstructions") = ""
            drow1("TallySheet") = ""
            drow1("JobScope") = ""
            drow1("AgreedRate") = ""
            drow1("TotalDue") = ""
            drow1("AgreedTerms") = ""
            drow1("CheckedBy1") = ""
            drow1("CheckedBy2") = ""
            drow1("ApprovedBy1") = ""
            drow1("ApprovedBy2") = ""
            drow1("CheckedBy1Date") = ""
            drow1("CheckedBy2Date") = ""
            drow1("ApprovedBy1Date") = ""
            drow1("ApprovedBy2Date") = ""

            tmptable1.Rows.Add(drow1)


            Return clsJobCardPDF.JobCardDoc(CFPROID, drow("JobID"), tmptable1, ErrMsg)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function





End Class
