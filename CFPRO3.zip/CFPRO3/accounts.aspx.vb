﻿Imports System.Drawing
Public Class accounts
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub

    Protected Sub LinkInvoiceSettings_Click(sender As Object, e As EventArgs) Handles LinkInvoiceSettings.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            Response.Redirect("invoicesettings.aspx")
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub


    Protected Sub LinkInvoiceItems_Click(sender As Object, e As EventArgs) Handles LinkInvoiceItems.Click
        Dim sourcepage As String = "invoiceitems.aspx"
        Call LoadDialog(sourcepage, "Invoice items", 730, 455)
    End Sub

    Private Sub LoadDialog(sourcepage As String, dialogtitle As String, width As Integer, height As Integer)


        Dim iframebg As String = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit;" &
                "background-position-y: center; background-position-x: center;"

        PanelDialog.Attributes("style") = "width:" & width + 10 & "px; height:" & height + 72 & "px;"
        PanelDrag.Attributes("style") = "width:100%;"
        iframe1.Attributes("style") = "width:" & width & "px ; height:" & height & "px;" & iframebg

        LabelDialogTitle.Text = dialogtitle
        iframe1.Attributes("src") = sourcepage

        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender5.Y = 40
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender5.Y = 100
        Else
            ModalPopupExtender5.Y = -1
        End If

        ModalPopupExtender5.Show()
    End Sub


    Protected Sub LinkQuotes_Click(sender As Object, e As EventArgs) Handles LinkQuotes.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            Response.Redirect("quotes.aspx")
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkCompanies_Click(sender As Object, e As EventArgs) Handles LinkCompanies.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadDialog("companies.aspx", "Companies (Internal)", 560, 450)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkDynamicsNAv_Click(sender As Object, e As EventArgs) Handles LinkDynamicsNAv.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadDialog("msdynamicsnavint.aspx", "MS Dynamics NAV Integration", 710, 455)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkCurrencies_Click(sender As Object, e As EventArgs) Handles LinkCurrencies.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadDialog("currencies.aspx", "Currency Settings", 585, 520)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub

    Protected Sub LinkSuppliers_Click(sender As Object, e As EventArgs) Handles LinkSuppliers.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadDialog("suppliers.aspx", "Suppliers / Vendors", 900, 580)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub

    Protected Sub LinkSalesmen_Click(sender As Object, e As EventArgs) Handles LinkSalesmen.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            LoadDialog("salesmen.aspx", "Sales People", 900, 580)
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub


End Class