﻿Public Class clsStorageDemmurage


    Shared Sub ComputeStorageCharges(tmptable As DataTable, tmpstr As String, CFPROID As String)

        Try

            Dim sqlstr As String =
            "Select JobCargo.ContainerNo,JobCargo.Payload," &
            "JobCargo.PortExitDate,JobCargo.CrossBorderDate," &
            "JobCargo.ReturnDate,JobCargo.ContainerStatus," &
            "JobCargo.Weight,JobCargo.CBM,JobCargo.ID," &
            "Jobs.JobDate,ReferenceNo,BL,HouseBL," &
            "Jobs.ClientID,Jobs.ShippingVessel," &
            "VoyageNo,Jobs.JobId,Jobs.JobTypeID, Jobs.Importer," &
            "Jobs.CFS,Jobs.CFSID,StorageFreeDays,StorageStartDate," &
            "ContainerReturnDays,ContainerReturnDate," &
            "Goods,Shipper, Agent,BerthingDate," &
            "DocumentsReceivedDate,VerificationDate, " &
            "Jobs.ShippingLine,Jobs.ShippinglineID, SOC,LastSlingDate,StorageDemurrageRemarks, " &
            "DutyEstimateSentToClientDate, DutyApprovedDate,DutyPaidDate," &
            "AgentStorageDays, AgentDemurrageDays," &
            "ReMarshallingChargesGoTo,HigherTarrifDaysToAgent," &
            "EntryRegistrationDate,EntryPassDate," &
            "StorageTarrifs.Charges1, StorageTarrifs.Days1," &
            "StorageTarrifs.Charges2,StorageTarrifs.Days2, " &
            "StorageTarrifs.Charges3,StorageTarrifs.Days3, " &
            "StorageTarrifs.Charges4,ReMarshallingCharges, " &
            "TransitFreeDays,LocalFreeDays, " &
            "DemurrageTarrifs.Days1 as Days1a,Demurrage1," &
            "DemurrageTarrifs.Days2 as Days2a,Demurrage2,Demurrage3 " &
            "From JobCargo, Jobs, StorageTarrifs,CFS, DemurrageTarrifs " &
            "Where Jobs.JobId  = JobCargo.JobId " &
            "And StorageTarrifs.CFSID = Jobs.CFSID " &
            "And StorageTarrifs.Payload = JobCargo.Payload " &
            "And CFS.CFSID = Jobs.CFSID " &
            "And DemurrageTarrifs.ShippingLineID = Jobs.ShippingLineID " &
            "And DemurrageTarrifs.Payload = JobCargo.Payload " &
             "Where Jobs.CFPROID = '" & CFPROID & "' " &
            "And JobCargo.CFPROID =  '" & CFPROID & "' " &
             "And JobCargo.CFPROID =  Jobs.CFPROID " &
             "And CFS.CFPROID = '" & CFPROID & "' " &
             "And StorageTarrifs.CFPROID = '" & CFPROID & "' " &
             "And DemurrageTarrifs.CFPROID = '" & CFPROID & "' " &
        tmpstr

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim sqlstr2 As String =
                    "Select RentCharge,EntryPassedFreeDays," &
                    "EntryNotPassedFreeDays, ID " &
                    "From CustomsWarehouseRent " &
                    "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable2 As New DataTable
        Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

        Dim nCustomwarehouserent As Double = 0
        Dim drow As DataRow

        If tmptable2.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable2, 0)
            drow = tmptable2.Rows(0)
            nCustomwarehouserent = drow("RentCharge")
        End If

        'x.PBar1.Maximum = tmptable.Rows.Count
        'x.Label1.Text = "Processing ...."
        'x.Button1.Visible = True

        'Application.DoEvents()

        Dim col1 As New DataColumn("DaysTaken", Type.GetType("System.String"))
        Dim col2 As New DataColumn("StorageCharges", Type.GetType("System.Double"))
        Dim col3 As New DataColumn("DaysToDemurrage", Type.GetType("System.Double"))
        Dim col4 As New DataColumn("DemurrageCharges", Type.GetType("System.Double"))
        Dim col5 As New DataColumn("AgentStorageCharges", Type.GetType("System.Double"))
        Dim col6 As New DataColumn("ClientStorageCharges", Type.GetType("System.Double"))
        Dim col7 As New DataColumn("CustomsWarehouseRent", Type.GetType("System.Double"))


        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)

        Dim ts As TimeSpan
        Dim tmpdate3, tmpdate4 As Date

        Dim DaysTaken, DaysTaken1, DaysTaken2 As Double
        Dim StorageCharges, StorageCharges1, ReMarshallingCharges, CBM, Weight As Double
        Dim ClientStorageCharges, ClientStorageCharges1, ClientStorageDays, AgentStorageCharges, AgentStorageCharges1, AgentStorageDays As Double
        Dim customwarehouserent, customwarehouserent1 As Double


        Dim a As Integer

        Dim nClientstoragedays(1) As Integer

        Dim JobType As String
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)


            Dim tmpstr5() As String = drow("Client").ToString.Split(vbCrLf)
            ReDim Preserve tmpstr5(0)
            drow("Client") = tmpstr5(0)

            JobType = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

            If drow("StorageFreeDays") = 0 Then
                    nClientstoragedays = GetClientFreeStorageDays(CFPROID, drow("ClientID"), drow("CFSID"))

                If InStr(JobType, "transit", CompareMethod.Text) > 0 Then
                    If drow("TransitFreeDays") < nClientstoragedays(1) Then
                        drow("StorageFreeDays") = nClientstoragedays(1)
                    Else
                        drow("StorageFreeDays") = drow("TransitFreeDays")
                    End If
                Else
                    If drow("LocalFreeDays") < nClientstoragedays(0) Then
                        drow("StorageFreeDays") = nClientstoragedays(0)
                    Else
                        drow("StorageFreeDays") = drow("LocalFreeDays")
                    End If
                End If
            End If

            If Not CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                Dim tmpdate As Date = CDate(drow("LastSlingDate")).AddDays(drow("StorageFreeDays"))
                drow("StorageStartDate") = Format(tmpdate, "dd MMM yyyy")
            Else
                drow("StorageStartDate") = "1-Jan-1800"
            End If

            If Not CDate(drow("LastSlingDate")) = CDate("1-Jan-1800") Then
                tmpdate3 = drow("LastSlingDate")

                If CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                    tmpdate4 = Format(Now, "dd MMM yyyy")
                Else
                    tmpdate4 = drow("PortExitDate")
                End If

                ts = tmpdate4.Subtract(tmpdate3)

                DaysTaken = ts.Days
                DaysTaken1 = DaysTaken
                DaysTaken2 = DaysTaken2

                drow("DaysTaken") = DaysTaken

                StorageCharges = 0
                StorageCharges1 = 0
                ReMarshallingCharges = 0
                CBM = 0
                Weight = 0
                ClientStorageCharges = 0
                ClientStorageDays = 0
                AgentStorageCharges = 0
                AgentStorageDays = 0

                If DaysTaken > drow("StorageFreeDays") Then
                    DaysTaken = DaysTaken - drow("StorageFreeDays")
                    DaysTaken1 = DaysTaken1 - drow("StorageFreeDays")


                    CBM = Math.Round(drow("CBM"))

                    If CDbl(drow("CBM")) > CBM Then
                        CBM = CBM + 1
                    End If

                    Weight = Math.Round((drow("Weight") / 1000))

                    If CDbl((drow("Weight") / 1000)) > Weight Then
                        Weight = Weight + 1
                    End If

                    If InStr(drow("PayLoad"), "x", CompareMethod.Text) > 0 Then

                        If DaysTaken <= drow("Days1") Then
                            StorageCharges = (drow("Charges1") * DaysTaken)
                            DaysTaken = 0
                        Else
                            StorageCharges = drow("Charges1") * drow("Days1")
                            DaysTaken = DaysTaken - drow("Days1")
                        End If

                        If DaysTaken <= drow("Days2") Then
                            StorageCharges = StorageCharges + (drow("Charges2") * DaysTaken)
                            DaysTaken = 0
                        Else
                            StorageCharges = StorageCharges + (drow("Charges2") * drow("Days2"))
                            DaysTaken = DaysTaken - drow("Days2")
                        End If

                        If DaysTaken <= drow("Days3") Then
                            StorageCharges = StorageCharges + (drow("Charges3") * DaysTaken)
                            DaysTaken = 0
                        Else
                            StorageCharges = StorageCharges + (drow("Charges3") * drow("Days3"))
                            DaysTaken = DaysTaken - drow("Days3")
                            StorageCharges = StorageCharges + (drow("Charges4") * DaysTaken)
                            DaysTaken = 0
                        End If

                        drow("StorageCharges") = StorageCharges + drow("ReMarshallingCharges")
                        drow("ClientStorageCharges") = StorageCharges
                        drow("AgentStorageCharges") = 0

                    Else


                        StorageCharges = (DaysTaken * drow("Charges1") * Weight)
                        StorageCharges1 = (DaysTaken * drow("Charges1") * CBM)

                        If StorageCharges1 > StorageCharges Then
                            ReMarshallingCharges = (CBM * drow("ReMarshallingCharges"))
                            drow("StorageCharges") = StorageCharges1 + ReMarshallingCharges
                            drow("ReMarshallingCharges") = ReMarshallingCharges
                        Else
                            ReMarshallingCharges = (Weight * drow("ReMarshallingCharges"))
                            drow("StorageCharges") = StorageCharges + ReMarshallingCharges
                            drow("ReMarshallingCharges") = ReMarshallingCharges
                        End If

                        drow("ClientStorageCharges") = StorageCharges
                        drow("AgentStorageCharges") = 0
                    End If

                    If drow("AgentStorageDays") > 0 Then
                        'split storage

                        AgentStorageDays = drow("AgentStorageDays")

                        If AgentStorageDays > DaysTaken1 Then
                            AgentStorageDays = DaysTaken1
                        End If

                        ClientStorageDays = DaysTaken1 - AgentStorageDays

                        drow("ClientStorageCharges") = 0
                        drow("AgentStorageCharges") = 0

                        If drow("HigherTarrifDaysToAgent") Then
                            If InStr(drow("PayLoad"), "x", CompareMethod.Text) > 0 Then
                                If ClientStorageDays <= drow("Days1") Then
                                    ClientStorageCharges = (drow("Charges1") * ClientStorageDays)
                                    ClientStorageDays = 0
                                Else
                                    ClientStorageCharges = drow("Charges1") * drow("Days1")
                                    ClientStorageDays = ClientStorageDays - drow("Days1")
                                End If

                                If ClientStorageDays <= drow("Days2") Then
                                    ClientStorageCharges = ClientStorageCharges + (drow("Charges2") * ClientStorageDays)
                                    ClientStorageDays = 0
                                Else
                                    ClientStorageCharges = ClientStorageCharges + (drow("Charges2") * drow("Days2"))
                                    ClientStorageDays = ClientStorageDays - drow("Days2")
                                End If

                                If ClientStorageDays <= drow("Days3") Then
                                    ClientStorageCharges = ClientStorageCharges + (drow("Charges3") * ClientStorageDays)
                                    ClientStorageDays = 0
                                Else
                                    ClientStorageCharges = ClientStorageCharges + (drow("Charges3") * drow("Days3"))
                                    ClientStorageDays = ClientStorageDays - drow("Days3")
                                    ClientStorageCharges = ClientStorageCharges + (drow("Charges4") * ClientStorageDays)
                                    ClientStorageDays = 0
                                End If

                                drow("ClientStorageCharges") = ClientStorageCharges
                                drow("AgentStorageCharges") = StorageCharges - ClientStorageCharges

                            Else

                                ClientStorageCharges = (ClientStorageDays * drow("Charges1") * Weight)
                                ClientStorageCharges1 = (ClientStorageDays * drow("Charges1") * CBM)


                                If ClientStorageCharges1 > ClientStorageCharges Then
                                    drow("ClientStorageCharges") = ClientStorageCharges1
                                    drow("AgentStorageCharges") = StorageCharges1 - ClientStorageCharges1
                                Else
                                    drow("ClientStorageCharges") = ClientStorageCharges
                                    drow("AgentStorageCharges") = StorageCharges - ClientStorageCharges
                                End If

                            End If
                        Else
                            If InStr(drow("PayLoad"), "x", CompareMethod.Text) > 0 Then
                                If AgentStorageDays <= drow("Days1") Then
                                    AgentStorageCharges = (drow("Charges1") * AgentStorageDays)
                                    AgentStorageDays = 0
                                Else
                                    AgentStorageCharges = drow("Charges1") * drow("Days1")
                                    AgentStorageDays = AgentStorageDays - drow("Days1")
                                End If

                                If AgentStorageDays <= drow("Days2") Then
                                    AgentStorageCharges = AgentStorageCharges + (drow("Charges2") * AgentStorageDays)
                                    AgentStorageDays = 0
                                Else
                                    AgentStorageCharges = AgentStorageCharges + (drow("Charges2") * drow("Days2"))
                                    AgentStorageDays = AgentStorageDays - drow("Days2")
                                End If

                                If AgentStorageDays <= drow("Days3") Then
                                    AgentStorageCharges = AgentStorageCharges + (drow("Charges3") * AgentStorageDays)
                                    AgentStorageDays = 0
                                Else
                                    AgentStorageCharges = AgentStorageCharges + (drow("Charges3") * drow("Days3"))
                                    AgentStorageDays = AgentStorageDays - drow("Days3")
                                    AgentStorageCharges = AgentStorageCharges + (drow("Charges4") * AgentStorageDays)
                                    AgentStorageDays = 0
                                End If

                                drow("AgentStorageCharges") = AgentStorageCharges
                                drow("ClientStorageCharges") = StorageCharges - AgentStorageCharges
                            Else

                                    AgentStorageCharges = (AgentStorageDays * drow("Charges1") * Weight)
                                AgentStorageCharges1 = (AgentStorageDays * drow("Charges1") * CBM)

                                If AgentStorageCharges1 > AgentStorageCharges Then
                                    drow("AgentStorageCharges") = AgentStorageCharges1
                                    drow("ClientStorageCharges") = StorageCharges1 - AgentStorageCharges1
                                Else
                                    drow("AgentStorageCharges") = AgentStorageCharges
                                    drow("ClientStorageCharges") = StorageCharges - AgentStorageCharges
                                End If
                            End If
                        End If
                    End If


                    customwarehouserent = (nCustomwarehouserent * Weight) * DaysTaken2
                    customwarehouserent1 = (nCustomwarehouserent * CBM) * DaysTaken2

                    If customwarehouserent1 > customwarehouserent Then
                        drow("CustomsWarehouseRent") = customwarehouserent1
                    Else
                        drow("CustomsWarehouseRent") = customwarehouserent
                    End If

                Else
                    drow("StorageCharges") = 0
                End If
            Else
                drow("DaysTaken") = 0
                drow("StorageCharges") = 0
            End If

            a = a + 1



        Next
        'x.PBar1.Value = x.PBar1.Maximum
        'x.Close()
            Call ComputeDemurrageCharges(tmptable, CFPROID)

        Catch ex As Exception

        End Try
    End Sub


    Shared Sub ComputeDemurrageCharges(tmptable As DataTable, CFPROID As String)


        Dim nClientFreeDemurrageDays(1) As Integer


        Dim a As Integer
        Dim DemurrageDays As Double
        Dim DemurrageCharges As Double
        Dim JobType As String
        Dim drow As DataRow
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            JobType = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")

            If drow("ContainerReturnDays") = 0 Then
                nClientFreeDemurrageDays = GetClientFreeDemurrageDays(CFPROID, drow("ClientID"), drow("ShippinglineID"))

                If InStr(JobType, "transit", CompareMethod.Text) = 0 Then
                    If drow("ContainerReturnDays") < nClientFreeDemurrageDays(0) Then
                        drow("ContainerReturnDays") = nClientFreeDemurrageDays(0)
                    End If
                Else
                    If drow("ContainerReturnDays") < nClientFreeDemurrageDays(1) Then
                        drow("ContainerReturnDays") = nClientFreeDemurrageDays(1)
                    End If
                End If
            End If


            drow("DaysToDemurrage") = clsShippingStorage.GetDemurrageDays(tmptable, drow("JobID"), drow("BerthingDate"), drow("ReturnDate"), _
                                    drow("ContainerReturnDays"), drow("Id"), drow("SOC"), _
                                    JobType, drow("PortExitDate"), drow("CrossBorderDate"), "")

            DemurrageDays = drow("DaysToDemurrage")
            DemurrageCharges = 0


            If DemurrageDays < 0 Then
                DemurrageDays = DemurrageDays * -1

                If DemurrageDays <= drow("Days1a") Then
                    DemurrageCharges = drow("Demurrage1") * DemurrageDays
                    DemurrageDays = 0
                Else
                    DemurrageCharges = drow("Demurrage1") * drow("Days1a")
                    DemurrageDays = DemurrageDays - drow("Days1a")
                End If

                If DemurrageDays <= drow("Days2a") Then
                    DemurrageCharges = DemurrageCharges + (drow("Demurrage2") * DemurrageDays)
                    DemurrageDays = 0
                Else
                    DemurrageCharges = DemurrageCharges + (drow("Demurrage2") * drow("Days2a"))
                    DemurrageDays = DemurrageDays - drow("Days2a")

                    DemurrageCharges = DemurrageCharges + (drow("Demurrage3") * DemurrageDays)
                    DemurrageDays = 0
                End If

                drow("DemurrageCharges") = DemurrageCharges

            Else
                drow("DemurrageCharges") = 0
            End If

            a = a + 1


        Next


    End Sub
    Shared Function GetClientFreeStorageDays(CFPROID As String, ClientID As String, CFSID As String) As Integer()



        Dim nClientFreeStoragedays(1) As Integer
        nClientFreeStoragedays(0) = 0
        nClientFreeStoragedays(1) = 0

        Try
            Dim tmptable As New DataTable("ClientFreeStorageDays")


            If IsNothing(HttpContext.Current.Session("TableClientStorageDays")) Then
                Dim sqlstr As String = "Select ClientID,CFSID," &
                      "LocalFreeDays,TransitFreeDays,ID " &
                      "From ClientStorageFreeDays " &
                      "Where CFPROID = '" & CFPROID & "' "
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)
                HttpContext.Current.Session("TableClientStorageDays") = tmptable
            Else

                tmptable = DirectCast(HttpContext.Current.Session("TableClientStorageDays"), DataTable)
            End If


            Dim dv As New DataView(tmptable)

            dv.RowFilter = "ClientID = '" & ClientID & "' " & _
                "And CFSID = '" & CFSID & "' "

            If dv.Count > 0 Then
                Call clsData.NullChecker1(dv, 0)
                nClientFreeStoragedays(0) = dv(0)("LocalFreeDays")
                nClientFreeStoragedays(1) = dv(0)("TransitFreeDays")
            End If

            Return nClientFreeStoragedays

        Catch ex As Exception
            Return nClientFreeStoragedays
        End Try

    End Function


    Shared Function GetClientFreeDemurrageDays(CFPROID As String, ClientID As String, ShippingLineID As String) As Integer()
        Dim nClientFreeDemmurageDays(1) As Integer
        nClientFreeDemmurageDays(0) = -1
        nClientFreeDemmurageDays(1) = -1

        Try

            Dim tmptable As New DataTable("ClientDemurrageDays")

            If IsNothing(HttpContext.Current.Session("TableClientDemurrageDays")) Or HttpContext.Current.Session("ResetCaches") = "1" Then
                Dim sqlstr As String = _
                       "Select ClientID,ShippingLineID," & _
                       "LocalReturnDays,TransitReturnDays,ID " & _
                       "From ClientFreeDaysToDemurrage " & _
                       "Where CFPROID = '" & CFPROID & "' "


                Call clsData.TableData(sqlstr, tmptable, clsData.constr)
                HttpContext.Current.Session("TableClientDemurrageDays") = tmptable
            Else
                tmptable = DirectCast(HttpContext.Current.Session("TableClientDemurrageDays"), DataTable)
            End If



            Dim dv As New DataView(tmptable)

            dv.RowFilter = "ClientID = '" & ClientID & "' " & _
                "And ShippingLineID = '" & ShippingLineID & "' "

            If dv.Count > 0 Then
                Call clsData.NullChecker1(dv, 0)
                nClientFreeDemmurageDays(0) = dv(0)("LocalReturnDays")
                nClientFreeDemmurageDays(1) = dv(0)("TransitReturnDays")
            End If

            Return nClientFreeDemmurageDays

        Catch ex As Exception
            Return nClientFreeDemmurageDays
        End Try

    End Function


    Friend Function GetSpecialCargoCharge(storagedays As Integer, payload As String, cargotype As String) As Integer

        Dim nSpecialCargoCharge As Double
        Return nSpecialCargoCharge

    End Function

End Class
