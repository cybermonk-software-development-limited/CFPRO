﻿Public Class importerdashboard1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn("", "", "", LabelUser.Text, "", LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True)

            ComboPredefine.SelectedIndex = 5
            Call PreDefine(ComboPredefine.Text)
        End If

    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image2.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Private Sub LoadClientJobs()
        Try
            Dim sqlstr As String =
                    "Select Top 10 JobId, ReferenceNo," &
                    "JobDate,Goods,Status," &
                    "ShippingVessel,Id " &
                    "From Jobs " &
                    "Where JobDate >= '" & TextFromDate.Text & "' " &
                    "And JobDate <= '" & TextToDate.Text & "' " &
                    "Or KeepVisible = 1"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("ClientJob")
            tmptable.Columns.Add(col)

            Dim col1 As New DataColumn("JobDate1")
            tmptable.Columns.Add(col1)

            Dim sqlstr1 As String =
                        "Select JobId,Status, ID " &
                        "From JobProgress " &
                        "Order By Date Desc;"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim a, b As Integer
            For Each drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)
                drow("ClientJob") = "jobentry.aspx?jobid=" & drow("JobID")
                drow("JobDate1") = Format(drow("JobDate"), "dd MMM yyyy")
                drow("Goods") = Mid(drow("Goods"), 1, 80)

                b = 0
                For Each drow1 In tmptable1.Rows
                    Call clsSubs.NullChecker(tmptable1, b)
                    If drow("JobId") = drow1("JobId") Then
                        drow("Status") = Mid(drow1("Status"), 1, 130)
                        Exit For
                    End If
                    b = b + 1
                Next
                a = a + 1
            Next

            DataList1.DataSource = tmptable
            DataList1.DataBind()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub PreDefine(ByVal Selection As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    Call LoadClientJobs()

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 3 months"

                    Dim tmpstr(12) As String
                    tmpstr(1) = "Jan"
                    tmpstr(2) = "Feb"
                    tmpstr(3) = "Mar"
                    tmpstr(4) = "Apr"
                    tmpstr(5) = "May"
                    tmpstr(6) = "Jun"
                    tmpstr(7) = "Jul"
                    tmpstr(8) = "Aug"
                    tmpstr(9) = "Sep"
                    tmpstr(10) = "Oct"
                    tmpstr(11) = "Nov"
                    tmpstr(12) = "Dec"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select

            TextFromDate.Text = Format(tmpdate1, "dd-MMM-yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd-MMM-yyyy hh:mm tt")


            Call LoadClientJobs()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text)
    End Sub
End Class