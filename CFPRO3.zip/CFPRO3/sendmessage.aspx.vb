﻿Public Class sendmessage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            Dim CSDID As String = ""
            Dim CFPROID As String = ""
            Dim JobID As String = Request.QueryString("jobid")
            Dim MessageID As String = clsSubs.GetLastID(CFPROID, CSDID, "MessageID")


            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUserName.Text, "", "", "", "", False, "", False)

            LabelJobID.Text = JobID
            LabelCFPROID.Text = CFPROID


            If Request.QueryString("messagesource") = "public" Then
                If clsMessaging.tmpUserCSDID = "" Then
                    Randomize()
                    Dim RandomNumber As New System.Random
                    clsMessaging.tmpUserCSDID = Format(Now, "ddMMYYYYhhmmss") & "-" & Format(RandomNumber.Next(1, 999999999), "00000000#")
                End If

                CSDID = clsMessaging.tmpUserCSDID
            End If

            LabelCSDID.Text = CSDID
            LabelMessageID.Text = MessageID


            If Not IsNothing(Request.QueryString("sendresult")) Then
                PanelSendMessage.Visible = False
                PanelSendToEmail.Visible = False
                PanelAttachments.Visible = False
                Image2.Visible = True
                If Request.QueryString("sendresult") = "notsent" Then
                    Image2.ImageUrl = "messagenotsent.png"
                Else
                    Image2.ImageUrl = "messagesent.png"
                End If
            Else
                Call clsDocuments.LoadDocumentTypes(ComboDocumentType, 0, "", LabelMessage1.Text)
                Call LoadMessageSubjects()
            End If


            Dim filetype As String = Request.QueryString("filetype")

            If filetype = "jobdocuments" Or filetype = "attachments" Then
                LabelAttachmentMessage.Text = "Browse to File & Click 'Upload' (3MB max .pdf .xls/xlsx .doc/docx .jpeg  & .png format only)"
            End If


            Call AddMessageRecipients()

            Call clsDocuments.LoadDocuments(CFPROID, "", MessageID, "", DataList1, "", LabelDocumentsCaption.Text, "", "attachments", LabelMessage1.Text)
        End If
    End Sub

   

    Private Sub AddMessageRecipients()
        Dim sqlstr As String = ""
        Dim SelectRepients As Boolean


        Dim MessageSource As String = Request.QueryString("messagesource")
        Dim MessageDestination As String = Request.QueryString("messagedestination")
        Dim DestinationUserCSDID As String = Request.QueryString("destinationusercsdid")
        Dim DestinationCFPROUserID As String = Request.QueryString("destinationcfprouserid")

        If MessageSource = "cfagent" Then
            If MessageDestination = "importer" Or MessageDestination = "transporter" Then
                If DestinationUserCSDID = "" Then
                    PanelSendToEmail.Visible = True
                    CheckSendtoEmail.Checked = True
                    CheckSendtoEmail.Enabled = False
                End If
            End If
        End If

        TextEmailAddresses.Text = GetDestinationUserEmail(MessageDestination, DestinationCFPROUserID)

        If MessageSource = "cfagent" Then

            If MessageDestination = "importer" Then
                sqlstr = "SELECT  ClientID, UserCSDID," & _
                          "Client,EmailAddress " & _
                         "From CFAgentUsers " & _
                          "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                          "And ClientID = '" & DestinationUserCSDID & "' "

            ElseIf MessageDestination = "transporter" Then
                sqlstr = "SELECT  TransporterID, Transporter,EmailAddress " & _
                        "From Transporters " & _
                        "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                        "And TransporterID = '" & DestinationUserCSDID & "' "

            ElseIf MessageDestination = "insurer" Then
                sqlstr = "SELECT  InsurerID, Insurer,EmailAddress " & _
                          "From Insurers " & _
                            "Where InsurerCFPROID = '" & LabelCFPROID.Text & "' " & _
                            "And InsurerID = '" & DestinationUserCSDID & "' "
            End If

        Else

            sqlstr = "SELECT  UserID, UserNames,EmailAddress " & _
                      "From CFAgentUsers " & _
                       "Where CFPROID = '" & LabelCFPROID.Text & "' "
            SelectRepients = True

        End If

        If MessageSource = "importer" Or MessageSource = "transporter" Or MessageSource = "insurer" Then
            If MessageDestination = "cfagent" Then
                If DestinationCFPROUserID = "" Then
                    sqlstr = "SELECT  UserID, UserNames,EmailAddress " & _
                                    "From CFAgentUsers " & _
                                    "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                                    "And UserRole Like '%" & "Admin" & "%' "
                Else

                    sqlstr = "SELECT  UserID, UserNames,EmailAddress " & _
                                "From CFAgentUsers " & _
                                "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                                "And UserID ='" & DestinationCFPROUserID & "' "
                End If


                'for insurer to importer reply
            ElseIf MessageDestination = "importer" Then
                If MessageSource = "insurer" Then
                    sqlstr = "SELECT  ClientID, Client,EmailAddress " & _
                    "From Clients " & _
                    "Where UserCSDID = '" & DestinationUserCSDID & "' "
                End If

                'for importer to insurere reply
            ElseIf MessageDestination = "insurer" Then
                sqlstr = "SELECT  InsurerID, Insurer,EmailAddress " & _
                    "From Insurers " & _
                    "Where InsurerCFPROID = '" & LabelCFPROID.Text & "' " & _
                    "And InsurerCSDID = '" & DestinationUserCSDID & "' "

            End If


        ElseIf MessageSource = "public" Then
            PanelSenderEmailAddress.Visible = True

            If MessageDestination = "cfagent" Then
                sqlstr = "SELECT  UserID, UserNames,EmailAddress " & _
                         "From CFAgentUsers " & _
                         "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                         "And UserRole Like '%" & "Admin" & "%' "

            ElseIf MessageDestination = "transporter" Then
                sqlstr = "SELECT  TransporterID, Transporter, EmailAddress " & _
                        "From Transporters " & _
                        "Where CFPROID = '" & LabelCFPROID.Text & "' " & _
                        "And TransporterID = '" & DestinationUserCSDID & "' "

            ElseIf MessageDestination = "insurer" Then
                sqlstr = "SELECT  InsurerID, Insurer,EmailAddress " & _
                       "From Insurers " & _
                       "Where InsurerCFPROID = '" & LabelCFPROID.Text & "' " & _
                       "And InsurerID = '" & DestinationUserCSDID & "' "

            End If
        End If



        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col As New DataColumn("UserType", Type.GetType("System.String"))
        tmptable.Columns.Add(col)

        Dim UserType As String = ""
        If MessageSource = "cfagent" Then
            UserType = MessageSource
        Else
            UserType = MessageDestination
        End If


        For Each drow In tmptable.Rows
            drow("UserType") = UserType
        Next


        Call SaveMessageRecipients(tmptable, MessageDestination)
    End Sub

    Private Function GetDestinationUserEmail(Usertype As String, CFPROUserID As String) As String
        Dim UserCSDIDorEmail As String = ""

        Return UserCSDIDorEmail

    End Function
    Private Sub SaveMessageRecipients(tmptable As DataTable, MessageDestination As String)

        Dim drow, drow1 As DataRow

        Dim UserID As String = "UserID"
        Dim UserNames As String = "UserNames"

       
        If MessageDestination = "importer" Then
            UserID = "ClientID"
            UserNames = "Client"
        ElseIf MessageDestination = "transporter" Then
            UserID = "TransporterID"
            UserNames = "Transporter"
        ElseIf MessageDestination = "insurer" Then
            UserID = "InsurerID"
            UserNames = "Insurer"
        End If
        For Each drow In tmptable.Rows
            drow1 = clsMessaging.TableMessageRecipents.NewRow
            drow1("UserCSDID") = drow("UserCSDID")
            drow1("CFPROUserID") = drow(UserID)
            drow1("UserNames") = drow(UserNames)
            drow1("UserType") = drow("UserType")
            clsMessaging.TableMessageRecipents.Rows.Add(drow1)
        Next


    End Sub

    Private Sub RemoveRecipient(UserIDAndTtype As String)

        Dim tmpstr() As String = UserIDAndTtype.Split("|")
        ReDim Preserve tmpstr(1)
        For a = 0 To clsMessaging.TableMessageRecipents.Rows.Count - 1
            Dim drow As DataRow = clsMessaging.TableMessageRecipents.Rows(a)
            If drow("CFPROUserID") = tmpstr(0) Then
                clsMessaging.TableMessageRecipents.Rows.Remove(drow)
            End If
        Next

    End Sub

    Protected Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Call clsDocuments.FileUpload(LabelCFPROID.Text, LabelJobID.Text, LabelMessageID.Text, "", FileUpload1, TodaysDate.Value, ModalPopupExtender1,
                                            ComboDocumentType, LabelAttachmentMessage, LabelDocumentsCaption.Text,
                                               DataList1, LabelCSDID.Text, LabelCFPROUserID.Text, "", "attachments", LabelMessage1.Text)
    End Sub

    Private Sub LoadMessageSubjects()
        Dim sqlstr As String = _
        "Select Subject, SubjectID " & _
        "From MessageSubjects " & _
        "Order By SubjectID Asc;"

        ComboMessageSubject.Items.Clear()
        ComboMessageSubject.Items.Add("(Select)")
        Call clsData.PopComboWithValue(ComboMessageSubject, sqlstr, clsData.constr, 0, 1)
    End Sub


    Private Sub LoadDocumentTypes(CFPROID As String)
        Dim sqlstr As String = _
                "SELECT  DocumentTypeID, " &
                "DocumentType, " &
                "CFPROID, ID " &
                "FROM  DocumentTypes " &
                "Where  CFPROID = '" & CFPROID & "' " &
                "And Purpose = 'Clearing' " &
                "Order By ID Desc;"

        ComboDocumentType.Items.Clear()
        ComboDocumentType.Items.Add("(Select)")
        Call clsData.PopComboWithValue(ComboDocumentType, sqlstr, clsData.constr, 0, 1)
    End Sub
    Protected Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Call SendMessage()
    End Sub

    Private Sub SendMessage()

        If ComboMessageSubject.SelectedIndex = 0 Then
            LabelMainSubject.Text = "Please Select Main Subject."
            LabelMainSubject.ForeColor = Drawing.Color.Red
            Response.Redirect(Request.RawUrl)
            Exit Sub
        End If

        Dim CFPROID As String = Request.QueryString("CFPROID")
        Dim SenderCSDID As String = Request.QueryString("sendercsdid")
        Dim ReceiverCSDID As String = Request.QueryString("receivercsdid")
        Dim JobID As String = Request.QueryString("jobid")

        Dim sendresult As String = ""
        clsMessaging.NewMessage(JobID, ComboMessageSubject.SelectedValue, LabelMessageID.Text, Trim(TextUserSubject.Text), Trim(TextMessage.Text), CFPROID, SenderCSDID, ReceiverCSDID, True, LabelMessageID.Text, LabelUserType.Text, sendresult)

    End Sub

    Protected Sub ButtonAddDocumentClick(sender As Object, e As EventArgs) Handles ButtonAddDocument.Click
        ModalPopupExtender1.Show()
    End Sub


    Protected Sub CheckSendtoEmail_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSendtoEmail.CheckedChanged
        PanelSendToEmail.Visible = CheckSendtoEmail.Checked
    End Sub


    Private Sub SaveDocument(CFPROID As String, DocumentID As String, DocumentypeID As String, JobID As String, EmailAddress As String)
        Dim Sqlstr As String = _
            "SELECT   CSDID, MessageID," &
            "JobID, DocumentTypeID," &
            "DocumentName, DateUploaded," &
            "EmailAddress, CFPROUserID," &
            "CFPROID, ID " &
            "FROM   Documents " &
            "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(Sqlstr, tmptable, clsData.constr)
    End Sub


    Private Sub DeleteDocument(DocumentID)
        Dim Sqlstr As String = _
                "SELECT  ID " &
                "FROM   Documents " &
                "Where DocumentID = '" & DocumentID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(Sqlstr, tmptable, clsData.constr)
    End Sub

  
    Protected Sub Button13_Click(sender As Object, e As EventArgs)
        Dim Button As Button = CType(sender, Button)
        Dim tmpstr As String = Button.CommandArgument
        Call clsDocuments.DeleteDocuments(LabelCFPROID.Text, tmpstr, LabelMessage1.Text)

    End Sub


    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Call ShowItem(sender)
    End Sub

    Private Sub ShowItem(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim tmpstr As String = link.CommandArgument

            iframe1.Attributes("src") = tmpstr
            ModalPopupExtender3.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub ComboDocumentType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboDocumentType.SelectedIndexChanged
        ModalPopupExtender1.Show()
    End Sub
End Class

