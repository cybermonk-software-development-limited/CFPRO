﻿

Imports System.IO
'Imports System.Drawing
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Public Class clsVRegPDF

    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        contentByte.MoveTo(x1, y1)
        contentByte.LineTo(x2, y2)
        contentByte.Stroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)

        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, y1)
        contentByte.ShowText(nString)
        contentByte.EndText()


    End Sub
    Shared Function VehicleRegPDF(drow1 As DataRow, drow2 As DataRow, RegPDFName As String) As Byte()

        Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
        Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
        Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
        Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
        Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

        Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)






        Dim font6b As New Font(customfontb, 6.4)
        Dim font7b As New Font(customfontb, 7.4)

        Dim font7 As New Font(customfont, 7)

        Dim font8 As New Font(customfontb, 8)
        Dim font8i As New Font(customfonti, 8)
        Dim font8b As New Font(customfontb, 8)
        Dim font9 As New Font(customfont, 9)
        Dim font11c As New Font(customfontc, 10.5)
        Dim font10b As New Font(customfontb, 10)

        Dim FontMark As Font
        Dim Mark As String

        If drow1("Usetick") Then
            FontMark = New Font(customfontm, 14)
            Mark = "P"
        Else
            FontMark = New Font(customfontc, 11)
            Mark = "X"
        End If

        Dim drow As DataRow

        Dim sqlstr1 As String = _
             "Select Caption,Id " & _
             "From VehicleRegistrationPrint " & _
             "Order By Id Asc;"
        Dim tmptable As New DataTable()

        Dim a As Integer

        Call clsData.Tabledata(sqlstr1, tmptable, clsData.constr)
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            a = a + 1
        Next

        Dim brush1 As Drawing.Color = Drawing.Color.Black
        Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
        'Dim PDFReader As PdfReader = Nothing 'Read File

        ' Document starts here

        Dim regdocpath As String = HttpContext.Current.Server.MapPath(".") & "\regdocs\" & RegPDFName & ".pdf"
        Dim doclogospath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\kralogo.bmp"
        Dim VehicleRegistrationPDF As New Document(PageSize.A4, 0, 0, 0, 50)

        'New FileStream(regdocpath, FileMode.Create)

        Using memoryStream As New System.IO.MemoryStream()

            Dim PDFwriter As PdfWriter = PdfWriter.GetInstance(VehicleRegistrationPDF, memoryStream)

            Dim logo As Image = Image.GetInstance(doclogospath)
            VehicleRegistrationPDF.Open()

            logo.ScaleToFit(172, 43.35)
            logo.SetAbsolutePosition(205, 788)
            VehicleRegistrationPDF.Add(logo)

            'logo added

            'Create line pens
            Dim pen As PdfContentByte = PDFwriter.DirectContent
            Dim pen1 As PdfContentByte = PDFwriter.DirectContent
            Dim pen2 As PdfContentByte = PDFwriter.DirectContent
            pen.SetRGBColorStroke(0, 0, 0)
            pen1.SetRGBColorStroke(0, 0, 0)
            pen2.SetRGBColorStroke(0, 0, 0)

            pen.SetLineWidth(0)
            pen1.SetLineWidth(0.5)
            pen2.SetLineWidth(0.5)

            Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

            drow = tmptable.Rows(0)




            DrawString(drow("Caption"), font8b, brush1, 340 * 0.75, 842 - (80 * 0.75), StringWriter)

            drow = tmptable.Rows(1)
            DrawString(drow("Caption"), font8b, brush1, 310 * 0.75, 842 - (95 * 0.75), StringWriter)

            drow = tmptable.Rows(2)
            DrawString(drow("Caption"), font8b, brush1, 170 * 0.75, 842 - (110 * 0.75), StringWriter)
            DrawLine(pen1, 47 * 0.75, 848 - (130 * 0.75), 770 * 0.75, 848 - (130 * 0.75))

            drow = tmptable.Rows(3)
            DrawString("Important:", font6b, brush1, 28 * 0.75, 842 - (134 * 0.75), StringWriter)
            DrawString(drow("Caption"), font6b, brush1, 75 * 0.75, 842 - (134 * 0.75), StringWriter)

            drow = tmptable.Rows(4)
            DrawString(drow("Caption"), font6b, brush1, 75 * 0.75, 842 - (147 * 0.75), StringWriter)
            DrawLine(pen1, 47 * 0.75, 848 - (163 * 0.75), 600 * 0.75, 848 - (163 * 0.75))

            DrawLine(pen1, 600 * 0.75, 848 - (130 * 0.75), 600 * 0.75, 848 - (1115 * 0.75)) '- vertical

            drow = tmptable.Rows(5)
            DrawString("A.", font8b, brush1, 47 * 0.75, 842 - (175 * 0.75), StringWriter)

            DrawString(drow("Caption"), font8b, brush1, 85 * 0.75, 842 - (175 * 0.75), StringWriter)

            drow = tmptable.Rows(6)
            DrawString(drow("Caption"), font6b, brush1, 85 * 0.75, 842 - (189 * 0.75), StringWriter)

            DrawLine(pen1, 170 * 0.75, 848 - (205 * 0.75), 450 * 0.75, 848 - (205 * 0.75))
            DrawLine(pen1, 170 * 0.75, 848 - (225 * 0.75), 450 * 0.75, 848 - (225 * 0.75))

            DrawLine(pen1, 170 * 0.75, 848 - (205 * 0.75), 170 * 0.75, 848 - (225 * 0.75))
            DrawLine(pen1, 450 * 0.75, 848 - (205 * 0.75), 450 * 0.75, 848 - (225 * 0.75))

            DrawLine(pen1, 270 * 0.75, 848 - (205 * 0.75), 270 * 0.75, 848 - (225 * 0.75))
            DrawLine(pen1, 310 * 0.75, 848 - (205 * 0.75), 310 * 0.75, 848 - (225 * 0.75))
            DrawLine(pen1, 410 * 0.75, 848 - (205 * 0.75), 410 * 0.75, 848 - (225 * 0.75))


            DrawString("4 Months", font6b, brush1, 180 * 0.75, 842 - (210 * 0.75), StringWriter)
            DrawString("12 Months", font6b, brush1, 320 * 0.75, 842 - (210 * 0.75), StringWriter)

            If LCase(drow1("Duration")) = "4 months" Then
                DrawString(Mark, FontMark, brush2, 282 * 0.75, 840 - (211 * 0.75), StringWriter)
            Else
                DrawString(Mark, FontMark, brush2, 422 * 0.75, 840 - (211 * 0.75), StringWriter)
            End If

            drow = tmptable.Rows(7)
            DrawString(drow("Caption"), font6b, brush1, 165 * 0.75, 842 - (243 * 0.75), StringWriter)
            DrawString("(Month)", font6b, brush1, 275 * 0.75, 842 - (255 * 0.75), StringWriter)

            DrawString(drow1("CommencingMonth"), font11c, brush2, 260 * 0.75, 842 - (238 * 0.75), StringWriter)
            DrawString(drow1("CommencingYear"), font11c, brush2, 405 * 0.75, 842 - (238 * 0.75), StringWriter)

            DrawLine(pen1, 47 * 0.75, 848 - (273 * 0.75), 600 * 0.75, 848 - (273 * 0.75))

            'xxxxxxxxxxxxxxxxxxxxxxxxxxxx
            drow = tmptable.Rows(8)
            DrawString("B.", font8b, brush1, 47 * 0.75, 842 - (281 * 0.75), StringWriter)
            DrawString(drow("Caption"), font8b, brush1, 85 * 0.75, 842 - (281 * 0.75), StringWriter)

            drow = tmptable.Rows(9)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (297 * 0.75), StringWriter)
            DrawString(drow1("Insurer"), font11c, brush2, 340 * 0.75, 842 - (293 * 0.75), StringWriter)

            drow = tmptable.Rows(10)
            DrawString("C.", font8b, brush1, 47 * 0.75, 842 - (321 * 0.75), StringWriter)
            DrawString(drow("Caption"), font8b, brush1, 85 * 0.75, 842 - (321 * 0.75), StringWriter)

            DrawLine(pen1, 85 * 0.75, 848 - (340 * 0.75), 530 * 0.75, 848 - (340 * 0.75))
            DrawLine(pen1, 85 * 0.75, 848 - (360 * 0.75), 530 * 0.75, 848 - (360 * 0.75))

            DrawLine(pen1, 85 * 0.75, 848 - (340 * 0.75), 85 * 0.75, 848 - (360 * 0.75))
            DrawLine(pen1, 530 * 0.75, 848 - (340 * 0.75), 530 * 0.75, 848 - (360 * 0.75))

            DrawLine(pen1, 200 * 0.75, 848 - (340 * 0.75), 200 * 0.75, 848 - (360 * 0.75))
            DrawLine(pen1, 240 * 0.75, 848 - (340 * 0.75), 240 * 0.75, 848 - (360 * 0.75))

            DrawLine(pen1, 336 * 0.75, 848 - (340 * 0.75), 336 * 0.75, 848 - (360 * 0.75))
            DrawLine(pen1, 376 * 0.75, 848 - (340 * 0.75), 376 * 0.75, 848 - (360 * 0.75))

            DrawLine(pen1, 485 * 0.75, 848 - (340 * 0.75), 485 * 0.75, 848 - (360 * 0.75))

            'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

            DrawString("1.", font6b, brush1, 47 * 0.75, 842 - (345 * 0.75), StringWriter)

            DrawString("Motor Vehicle", font6b, brush1, 125 * 0.75, 842 - (345 * 0.75), StringWriter)
            DrawString("Trailer", font6b, brush1, 274 * 0.75, 842 - (345 * 0.75), StringWriter)
            DrawString("Motor Cycle", font6b, brush1, 416 * 0.75, 842 - (345 * 0.75), StringWriter)

            If LCase(drow1("VehicleType")) = "motor vehicle" Then
                DrawString(Mark, FontMark, brush2, 216 * 0.75, 842 - (348 * 0.75), StringWriter)
            ElseIf LCase(drow1("VehicleType")) = "trailer" Then
                DrawString(Mark, FontMark, brush2, 353 * 0.75, 842 - (348 * 0.75), StringWriter)
            ElseIf LCase(drow1("VehicleType")) = "motor cycle" Then
                DrawString(Mark, FontMark, brush2, 522 * 0.75, 842 - (348 * 0.75), StringWriter)
            End If


            drow = tmptable.Rows(11)
            DrawString("2.", font7b, brush1, 47 * 0.75, 842 - (371 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (371 * 0.75), StringWriter)
            DrawString(drow1("VehicleMake"), font11c, brush2, 160 * 0.75, 842 - (367 * 0.75), StringWriter)


            drow = tmptable.Rows(12)
            DrawString("3.", font7b, brush1, 47 * 0.75, 842 - (390 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (390 * 0.75), StringWriter)
            DrawString(drow1("BodyType"), font11c, brush2, 180 * 0.75, 842 - (386 * 0.75), StringWriter)

            drow = tmptable.Rows(13)
            DrawString("4.", font7b, brush1, 47 * 0.75, 842 - (410 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (410 * 0.75), StringWriter)
            DrawString(drow1("Description"), font11c, brush2, 228 * 0.75, 842 - (405 * 0.75), StringWriter)

            drow = tmptable.Rows(14)
            DrawString("5.", font7b, brush1, 47 * 0.75, 842 - (430 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (430 * 0.75), StringWriter)
            DrawString(drow1("VehicleYear"), font11c, brush2, 218 * 0.75, 842 - (425 * 0.75), StringWriter)

            drow = tmptable.Rows(15)
            DrawString("6.", font7b, brush1, 47 * 0.75, 842 - (450 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (450 * 0.75), StringWriter)
            DrawString(drow1("TareWeight"), font11c, brush2, 185 * 0.75, 842 - (445 * 0.75), StringWriter)

            drow = tmptable.Rows(16)
            DrawString("7.", font7b, brush1, 47 * 0.75, 842 - (470 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (470 * 0.75), StringWriter)


            DrawLine(pen1, 85 * 0.75, 848 - (485 * 0.75), 527 * 0.75, 848 - (485 * 0.75))
            DrawLine(pen1, 85 * 0.75, 848 - (510 * 0.75), 527 * 0.75, 848 - (510 * 0.75))

            DrawLine(pen1, 85 * 0.75, 848 - (491 * 0.75), 85 * 0.75, 848 - (491 * 0.75))
            DrawLine(pen1, 527 * 0.75, 848 - (510 * 0.75), 527 * 0.75, 848 - (510 * 0.75))

            For a = 0 To 17
                DrawLine(pen1, ((a * 26) + 85) * 0.75, 848 - (485 * 0.75), ((a * 26) + 85) * 0.75, 848 - (510 * 0.75))
            Next

            Dim tmpstr() As String = SplitNo(drow1("ChassisNo"))
            For a = 0 To tmpstr.GetUpperBound(0)
                DrawString(tmpstr(a), font11c, brush2, ((a * 26) + 93) * 0.75, 848 - (502 * 0.75), StringWriter)
            Next

            'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

            drow = tmptable.Rows(17)
            DrawString("8.", font7b, brush1, 47 * 0.75, 842 - (523 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (523 * 0.75), StringWriter)
            DrawString(drow1("NoofAxles"), font11c, brush2, 200 * 0.75, 842 - (519 * 0.75), StringWriter)

            drow = tmptable.Rows(18)
            DrawString("9.", font7b, brush1, 47 * 0.75, 842 - (543 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (543 * 0.75), StringWriter)
            DrawString(drow1("VehicleValue"), font11c, brush2, 250, 842 - (539 * 0.75), StringWriter)


            drow = tmptable.Rows(19)
            DrawString("10.", font7b, brush1, 47 * 0.75, 842 - (563 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (563 * 0.75), StringWriter)
            DrawString(drow1("Color"), font11c, brush2, 230 * 0.75, 842 - (558 * 0.75), StringWriter)

            drow = tmptable.Rows(20)
            DrawString("11.", font7b, brush1, 47 * 0.75, 842 - (583 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (583 * 0.75), StringWriter)

            If drow1("IsVehicleNew") = "YES" Then
                DrawString(Mark, FontMark, brush2, 235 * 0.75, 842 - (580 * 0.75), StringWriter)
            Else
                DrawString(Mark, FontMark, brush2, 365 * 0.75, 842 - (580 * 0.75), StringWriter)
            End If

            drow = tmptable.Rows(21)
            DrawString("12.", font7b, brush1, 47 * 0.75, 842 - (603 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (603 * 0.75), StringWriter)

            If drow1("PreviousRegistration") = "YES" Then
                DrawString(Mark, FontMark, brush2, 350 * 0.75, 842 - (601 * 0.75), StringWriter)
            Else
                DrawString(Mark, FontMark, brush2, 460 * 0.75, 842 - (601 * 0.75), StringWriter)
            End If

            drow = tmptable.Rows(22)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (623 * 0.75), StringWriter)
            DrawString(drow1("PreviousRegistrationCountry"), font11c, brush2, 190 * 0.75, 842 - (619 * 0.75), StringWriter)

            drow = tmptable.Rows(23)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (643 * 0.75), StringWriter)
            DrawString(drow1("PreviousRegistrationNo"), font11c, brush2, 240 * 0.75, 842 - (639 * 0.75), StringWriter)


            drow = tmptable.Rows(24)
            DrawString("13.", font7b, brush1, 47 * 0.75, 842 - (663 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (663 * 0.75), StringWriter)


            drow = tmptable.Rows(25)
            DrawString(drow("Caption"), font7b, brush1, 112 * 0.75, 842 - (683 * 0.75), StringWriter)


            drow = tmptable.Rows(26)
            DrawString(drow("Caption"), font7b, brush1, 112 * 0.75, 842 - (703 * 0.75), StringWriter)

            If LCase(drow1("VehicleUse")) = "private" Then
                DrawString(Mark, FontMark, brush2, 220 * 0.75, 842 - (661 * 0.75), StringWriter)
                DrawString(drow1("LoadingCapacity"), font11c, brush2, 420 * 0.75, 842 - (659 * 0.75), StringWriter)

            ElseIf LCase(drow1("VehicleUse")) = "commercial - goods" Then
                DrawString(Mark, FontMark, brush2, 250 * 0.75, 842 - (681 * 0.75), StringWriter)
                DrawString(drow1("LoadingCapacity"), font11c, brush2, 430 * 0.75, 842 - (679 * 0.75), StringWriter)

            ElseIf LCase(drow1("VehicleUse")) = "commercial - psv" Then
                DrawString(Mark, FontMark, brush2, 250 * 0.75, 842 - (701 * 0.75), StringWriter)
                DrawString(drow1("LoadingCapacity"), font11c, brush2, 430 * 0.75, 842 - (699 * 0.75), StringWriter)
            End If

            drow = tmptable.Rows(27)
            DrawString("14.", font7b, brush1, 47 * 0.75, 842 - (723 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (723 * 0.75), StringWriter)

            drow = tmptable.Rows(28)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (743 * 0.75), StringWriter)
            DrawString(drow1("VehicleLocationRoad"), font11c, brush2, 95 * 0.75, 842 - (739 * 0.75), StringWriter)
            DrawString(drow1("VehicleLocationEstate"), font11c, brush2, 420 * 0.75, 842 - (739 * 0.75), StringWriter)

            drow = tmptable.Rows(29)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (763 * 0.75), StringWriter)
            DrawString(drow1("VehicleLocationTown"), font11c, brush2, 130 * 0.75, 842 - (759 * 0.75), StringWriter)
            DrawString(drow1("VehicleLocationCounty"), font11c, brush2, 350 * 0.75, 842 - (759 * 0.75), StringWriter)

            drow = tmptable.Rows(30)
            DrawString("15.", font7b, brush1, 47 * 0.75, 842 - (783 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (783 * 0.75), StringWriter)


            drow = tmptable.Rows(31)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (795 * 0.75), StringWriter)

            DrawLine(pen1, 85 * 0.75, 848 - (810 * 0.75), 550 * 0.75, 848 - (810 * 0.75))
            DrawLine(pen1, 85 * 0.75, 848 - (830 * 0.75), 550 * 0.75, 848 - (830 * 0.75))

            DrawLine(pen1, 85 * 0.75, 848 - (810 * 0.75), 85 * 0.75, 848 - (830 * 0.75))
            DrawLine(pen1, 550 * 0.75, 848 - (810 * 0.75), 550 * 0.75, 848 - (830 * 0.75))


            For a = 0 To 4
                DrawLine(pen1, ((a * 93) + 85) * 0.75, 848 - (810 * 0.75), ((a * 93) + 85) * 0.75, 848 - (830 * 0.75))
                DrawLine(pen1, ((a * 93) + 155) * 0.75, 848 - (810 * 0.75), ((a * 93) + 155) * 0.75, 848 - (830 * 0.75))
            Next

            Dim tmpstr1(4) As String
            tmpstr1(0) = "Petrol"
            tmpstr1(1) = "Diesel"
            tmpstr1(2) = "Other Oil"
            tmpstr1(3) = "Steam"
            tmpstr1(4) = "Electricity"

            For a = 0 To tmpstr1.GetUpperBound(0)
                DrawString(tmpstr1(a), font7b, brush1, ((a * 93) + 98) * 0.75, 842 - (816 * 0.75), StringWriter)
            Next


            If LCase(drow1("EngineType")) = "petrol" Then
                DrawString(Mark, FontMark, brush2, 162 * 0.75, 842 - (819 * 0.75), StringWriter)

            ElseIf LCase(drow1("EngineType")) = "diesel" Then
                DrawString(Mark, FontMark, brush2, 255 * 0.75, 842 - (819 * 0.75), StringWriter)

            ElseIf LCase(drow1("EngineType")) = "other oil" Then
                DrawString(Mark, FontMark, brush2, 347 * 0.75, 842 - (819 * 0.75), StringWriter)

            ElseIf LCase(drow1("EngineType")) = "steam" Then
                DrawString(Mark, FontMark, brush2, 441 * 0.75, 842 - (819 * 0.75), StringWriter)

            ElseIf LCase(drow1("EngineType")) = "electric" Then
                DrawString(Mark, FontMark, brush2, 533 * 0.75, 842 - (819 * 0.75), StringWriter)

            End If

            drow = tmptable.Rows(32)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (842 * 0.75), StringWriter)

            DrawLine(pen1, 85 * 0.75, 848 - (856 * 0.75), 470 * 0.75, 848 - (856 * 0.75))
            DrawLine(pen1, 85 * 0.75, 848 - (880 * 0.75), 470 * 0.75, 848 - (880 * 0.75))

            DrawLine(pen1, 85 * 0.75, 848 - (856 * 0.75), 85 * 0.75, 848 - (880 * 0.75))
            DrawLine(pen1, 470 * 0.75, 848 - (880 * 0.75), 470 * 0.75, 848 - (880 * 0.75))

            For a = 0 To 14
                DrawLine(pen1, ((a * 27.5) + 85) * 0.75, 848 - (856 * 0.75), ((a * 27.5) + 85) * 0.75, 848 - (880 * 0.75))
            Next

            tmpstr = SplitNo(drow1("EngineNo"))
            For a = 0 To tmpstr.GetUpperBound(0)
                DrawString(tmpstr(a), font11c, brush2, ((a * 27.5) + 96) * 0.75, 848 - (873 * 0.75), StringWriter)
            Next

            drow = tmptable.Rows(33)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (893 * 0.75), StringWriter)
            DrawString(drow1("EngineCapacity"), font11c, brush2, 260 * 0.75, 842 - (889 * 0.75), StringWriter)

            DrawLine(pen1, 47 * 0.75, 848 - (908 * 0.75), 600 * 0.75, 848 - (908 * 0.75))
            'declaration

            drow = tmptable.Rows(34)
            DrawString("D.", font8b, brush1, 47 * 0.75, 842 - (914 * 0.75), StringWriter)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (914 * 0.75), StringWriter)

            drow = tmptable.Rows(35)
            DrawString(drow("Caption"), font7b, brush1, 85 * 0.75, 842 - (926 * 0.75), StringWriter)

            drow = tmptable.Rows(36)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (945 * 0.75), StringWriter)

            'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

            drow = tmptable.Rows(37)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (968 * 0.75), StringWriter)
            DrawString(UCase(drow2("Declarant")), font11c, brush2, 190 * 0.75, 842 - (964 * 0.75), StringWriter)

            drow = tmptable.Rows(38)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (993 * 0.75), StringWriter)
            DrawString(UCase(drow2("Occupation")), font11c, brush2, 112 * 0.75, 842 - (989 * 0.75), StringWriter)
            DrawString(Mid(drow2("Company"), 1, 18), font11c, brush2, 440 * 0.75, 842 - (989 * 0.75), StringWriter)

            drow = tmptable.Rows(39)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (1018 * 0.75), StringWriter)
            DrawString(drow2("Box"), font11c, brush2, 140 * 0.75, 842 - (1014 * 0.75), StringWriter)
            DrawString(drow2("PostCode"), font11c, brush2, 280 * 0.75, 842 - (1014 * 0.75), StringWriter)
            DrawString(drow2("Town"), font11c, brush2, 415 * 0.75, 842 - (1014 * 0.75), StringWriter)

            drow = tmptable.Rows(40)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (1043 * 0.75), StringWriter)
            DrawString(drow2("Telephone"), font11c, brush2, 130 * 0.75, 842 - (1039 * 0.75), StringWriter)
            DrawString(drow2("Fax"), font11c, brush2, 298 * 0.75, 842 - (1039 * 0.75), StringWriter)
            DrawString(drow2("Cell"), font11c, brush2, 475 * 0.75, 842 - (1039 * 0.75), StringWriter)


            drow = tmptable.Rows(41)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (1068 * 0.75), StringWriter)
            DrawString(drow2("Building"), font11c, brush2, 100 * 0.75, 842 - (1064 * 0.75), StringWriter)
            DrawString(drow2("Stream"), font11c, brush2, 300 * 0.75, 842 - (1064 * 0.75), StringWriter)
            DrawString(drow2("Estate"), font11c, brush2, 440 * 0.75, 842 - (1064 * 0.75), StringWriter)

            drow = tmptable.Rows(42)
            DrawString(drow("Caption"), font7b, brush1, 47 * 0.75, 842 - (1093 * 0.75), StringWriter)
            DrawString(Format(drow1("RecordDate"), "dd MMM yyyy"), font11c, brush2, 160 * 0.75, 842 - (1089 * 0.75), StringWriter)

            'dealer section

            drow = tmptable.Rows(43)
            DrawString("E. ", font8b, brush1, 607 * 0.75, 842 - (145 * 0.75), StringWriter)
            DrawString(drow("Caption"), font8b, brush1, 621 * 0.75, 842 - (145 * 0.75), StringWriter)

            drow = tmptable.Rows(44)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (170 * 0.75), StringWriter)

            drow = tmptable.Rows(45)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (195 * 0.75), StringWriter)

            drow = tmptable.Rows(46)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (220 * 0.75), StringWriter)


            drow = tmptable.Rows(47)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (245 * 0.75), StringWriter)


            drow = tmptable.Rows(48)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (270 * 0.75), StringWriter)

            drow = tmptable.Rows(49)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (295 * 0.75), StringWriter)

            drow = tmptable.Rows(50)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (320 * 0.75), StringWriter)

            drow = tmptable.Rows(51)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (345 * 0.75), StringWriter)

            drow = tmptable.Rows(52)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (370 * 0.75), StringWriter)

            drow = tmptable.Rows(53)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (395 * 0.75), StringWriter)

            drow = tmptable.Rows(54)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (420 * 0.75), StringWriter)

            DrawLine(pen1, 600 * 0.75, 842 - (460 * 0.75), 800 * 0.75, 842 - (460 * 0.75))

            'for official use only
            drow = tmptable.Rows(55)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (485 * 0.75), StringWriter)

            drow = tmptable.Rows(56)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (520 * 0.75), StringWriter)

            drow = tmptable.Rows(57)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (550 * 0.75), StringWriter)

            drow = tmptable.Rows(58)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (580 * 0.75), StringWriter)

            drow = tmptable.Rows(59)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (640 * 0.75), StringWriter)

            drow = tmptable.Rows(60)
            DrawString(drow("Caption"), font10b, brush1, 607 * 0.75, 842 - (700 * 0.75), StringWriter)

            drow = tmptable.Rows(61)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (750 * 0.75), StringWriter)

            drow = tmptable.Rows(62)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (780 * 0.75), StringWriter)

            drow = tmptable.Rows(63)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (810 * 0.75), StringWriter)

            drow = tmptable.Rows(64)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 842 - (850 * 0.75), StringWriter)

            DrawLine(pen1, 610 * 0.75, 848 - (885 * 0.75), 780 * 0.75, 848 - (885 * 0.75))
            DrawLine(pen1, 610 * 0.75, 848 - (915 * 0.75), 780 * 0.75, 848 - (915 * 0.75))


            For a = 0 To 6
                DrawLine(pen1, ((a * 28.5) + 610) * 0.75, 848 - (885 * 0.75), ((a * 28.5) + 610) * 0.75, 848 - (915 * 0.75))
            Next

            drow = tmptable.Rows(65)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 848 - (960 * 0.75), StringWriter)

            drow = tmptable.Rows(66)
            DrawString(drow("Caption"), font8b, brush1, 607 * 0.75, 848 - (990 * 0.75), StringWriter)

            VehicleRegistrationPDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")
            VehicleRegistrationPDF.Close()

            Dim bytes As Byte() = memoryStream.ToArray()
            Return bytes
            memoryStream.Close()

        End Using
    End Function


    Private Shared Function SplitNo(ByVal StrNo As String) As Array
        Dim a As Integer
        Dim tmpstr(0) As String

        For a = 0 To StrNo.Length
            ReDim Preserve tmpstr(a)
            tmpstr(a) = Mid(StrNo, a + 1, 1)
        Next
        Return tmpstr

    End Function
End Class
