﻿Public Class progresskpisettings
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then




            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If


            Dim CFPROID As String = ""

            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, "", "", "", "", "", True, "", False)

            LabelCFPROID.Text = CFPROID


            Call LoadKPIProgressSettings(CFPROID)

        End If
    End Sub

    Private Sub LoadKPIProgressSettings(CFPROID As String)
        Dim sqlstr As String =
            "SELECT SortOrder, ItemID," &
            "ItemDescription, MaxDays," &
            "PreAlertDays, PostAlertDays," &
            "DayCount, Remarks," &
            "RemarksDesc, CFPROID,ID " &
            "FROM  KPIProgress " &
            "Where CFPROID = '" & CFPROID & "'"

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count = 0 Then
            Call clsProgressUpdates.CreateAccountKpiSettings(CFPROID, tmptable)
        End If

        Dim col1 As New DataColumn("ItemCount", Type.GetType("System.String"))

        tmptable.Columns.Add(col1)

        Dim a As Integer

        If tmptable.Rows.Count > 0 Then
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemCount") = a + 1 & "."
                a = a + 1
            Next
        End If

        LabelCaption.Text = tmptable.Rows.Count & " Items"

        DataList1.DataSource = tmptable
        DataList1.DataBind()

    End Sub
    Protected Sub ButtonSaveSettings_Click(sender As Object, e As EventArgs) Handles ButtonSaveSettings.Click
        ModalPopupExtender1.Hide()
    End Sub

    Protected Sub LinkItemDesc_Click(sender As Object, e As EventArgs)
        ModalPopupExtender1.Show()
    End Sub

    Private Sub LoadKPIProgressItem(CFPROID As String, ItemID As String)
        Dim sqlstr As String =
            "SELECT SortOrder, ItemID," &
            "ItemDescription, MaxDays," &
            "PreAlertDays, PostAlertDays," &
            "DayCount, Remarks, " &
            "RemarksDesc, CFPROID,ID " &
            "FROM  KPIProgress " &
            "Where CFPROID = '" & CFPROID & "' " &
            "And ItemID = '" & ItemID & "'"

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then




        End If

        DataList1.DataSource = tmptable
        DataList1.DataBind()

    End Sub


    Private Sub SaveKPIProgressItem(CFPROID As String, ItemID As String)
        Dim sqlstr As String =
            "SELECT SortOrder, ItemID," &
            "ItemDescription, MaxDays," &
            "PreAlertDays, PostAlertDays," &
            "DayCount, Remarks, " &
            "RemarksDesc, CFPROID,ID " &
            "FROM  KPIProgress " &
            "Where CFPROID = '" & CFPROID & "' " &
            "And ItemID = '" & ItemID & "'"

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then




        End If

        DataList1.DataSource = tmptable
        DataList1.DataBind()

    End Sub



End Class

