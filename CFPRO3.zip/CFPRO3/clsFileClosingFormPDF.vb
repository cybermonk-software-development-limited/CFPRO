﻿


Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf


Public Class clsFileClosingFormPDF


    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.SetLineWidth(0.001)
        contentByte.SetRGBColorStroke(0, 0, 0)
        contentByte.Stroke()
    End Sub

    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - (y1 + height))
        contentByte.LineTo(x1, 595 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 595 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Private Shared Sub DrawParagraph(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single,
                                                                                           ByRef contentByte As PdfContentByte, ByVal align As String)

        x1 = x1 * 0.75
        y1 = y1 * 0.75

        Dim x2 = (x1 * 0.75) + 500
        Dim y2 = (y1 * 0.75) + 200

        Dim fnt As Single = font.Size * 0.75
        Dim ct As New ColumnText(contentByte)


        If align = "right" Then
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_RIGHT)

        ElseIf align = "center" Then
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_CENTER)

        Else
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_LEFT)
        End If


        ct.AddElement(New Paragraph(nString, font))
        ct.Go()
    End Sub



    Shared Function CreateFileClosingFormPDF(CFPROID As String, JobID As String, Optional ErrMSg As String = Nothing) As String
        Try



            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeui.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeuib.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"
            Dim fontpath5 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\calibrib.ttf"
            Dim fontpath6 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\calibri.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb1 As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath5, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontk As BaseFont = BaseFont.CreateFont(fontpath6, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim font6b As New Font(customfontb, 6)
            Dim font4b As New Font(customfontb, 4)
            Dim font7b As New Font(customfontb, 8)
            Dim font7b1 As New Font(customfontb1, 7)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfont, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            Dim font11c As New Font(customfontc, 10.5)
            Dim font10 As New Font(customfontc, 10)
            Dim font11 As New Font(customfontk, 11)
            Dim font7k As New Font(customfontk, 8)
            Dim font10b As New Font(customfontb, 10)
            Dim font16a As New Font(customfont, 16)
            Dim font16b As New Font(customfontb, 16)
            Dim font14b As New Font(customfontb, 20)
            Dim font22b As New Font(customfontb, 24)
            Dim font13b As New Font(customfontb, 13)
            Dim font13 As New Font(customfont, 13)
            Dim font9c As New Font(customfontb, 9)
            Dim font36b As New Font(customfontb, 36)
            Dim font8c As New Font(customfontc, 8)
            Dim font7c As New Font(customfontc, 7)
            Dim font11b As New Font(customfontb, 11)
            Dim font20b As New Font(customfontb, 20)
            Dim font5b As New Font(customfontb, 5)
            Dim font17b As New Font(customfontb, 17)

            Dim drf As New Drawing.StringFormat()

            Dim brush1 As Drawing.Color = Drawing.Color.FromArgb(61, 61, 61)
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
            Dim FontMark As Font
            Dim Mark As String
            FontMark = New Font(customfontm, 14)
            Mark = "P"

            'Dim brush1 As Drawing.Color = Drawing.Color.FromArgb(61, 61, 61)
            'Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)


            Dim pencolor As Drawing.Color = Drawing.Color.FromArgb(200, 200, 200)


            Dim sqlstr As String =
                             "Select CFAgentName,CFAgentAddress,LogoURL,ID " &
                             "From CFPROAccounts " &
                             "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmptable1 As DataTable = LoadFileClosingFormData(CFPROID, JobID)


            Dim drow1 As DataRow
            If tmptable1.Rows.Count > 0 Then
                drow1 = tmptable1.Rows(0)

                Dim FileClosingFormPDF As New Document(PageSize.A4, 0, 0, 0, 10)
                Using memoryStream As New System.IO.MemoryStream()


                    Dim PDFwriter As PdfWriter = PdfWriter.GetInstance(FileClosingFormPDF, memoryStream)
                    FileClosingFormPDF.Open()
                    Dim pen As PdfContentByte = PDFwriter.DirectContent
                    Dim pen1 As PdfContentByte = PDFwriter.DirectContent
                    Dim pen2 As PdfContentByte = PDFwriter.DirectContent
                    Dim StringWriter As PdfContentByte = PDFwriter.DirectContent



                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    Dim logopath As String = ""
                    Dim cfagentlogo As String

                    Dim files() As String = Directory.GetFiles(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\")
                    Dim nfile As String = ""


                    For Each nfile In files
                        cfagentlogo = Path.GetFileName(nfile)
                        If InStr(cfagentlogo, CFPROID, CompareMethod.Text) > 0 Then
                            logopath = nfile
                            Exit For
                        End If
                    Next


                    If logopath = "" Then
                        logopath = HttpContext.Current.Server.MapPath(".") & "\companyplaceholder.png"
                    End If

                    Dim logo As Image = Image.GetInstance(logopath)

                    logo.ScaleToFit(45, 45)
                    logo.SetAbsolutePosition(45, 770)
                    FileClosingFormPDF.Add(logo)



                    DrawString(drow("CFAgentName"), font14b, Drawing.Color.FromArgb(21, 21, 21), 127, -292, StringWriter)


                    Dim ct1 As New ColumnText(StringWriter)
                    ct1.SetSimpleColumn(95, 798, 350, -350)
                    ct1.AddElement(New Paragraph(drow("CFAgentAddress"), font7b))
                    ct1.Go()



                    DrawString("File Closing Summary", font20b, Drawing.Color.FromArgb(31, 31, 31), 60, -212, StringWriter)

                    DrawLine(pen, 60, -178, 735, -178)
                    DrawLine(pen, 60, -158, 735, -158)
                    DrawLine(pen, 60, -138, 735, -138)
                    DrawLine(pen, 60, -118, 735, -118)
                    DrawLine(pen, 60, -98, 735, -98)
                    DrawLine(pen, 60, -78, 735, -78)
                    DrawLine(pen, 60, -58, 735, -58)
                    DrawLine(pen, 60, -38, 735, -38)
                    DrawLine(pen, 60, -18, 735, -18)
                    DrawLine(pen, 60, 2, 735, 2)
                    DrawLine(pen, 60, 22, 735, 22)

                    DrawLine(pen, 60, -178, 60, 22)
                    DrawLine(pen, 200, -178, 200, 22)
                    DrawLine(pen, 735, -178, 735, 22)

                    DrawString("Reference No:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -173, StringWriter)
                    DrawString(drow1("ReferenceNo"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -173, StringWriter)

                    Dim nClient As String = clsGetIdentities.SetClient(CFPROID, JobID, drow1("ClientID"), ErrMSg)
                    DrawString("Client:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -153, StringWriter)
                    DrawString(nClient, font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -153, StringWriter)

                    DrawString("Consignee:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -133, StringWriter)
                    DrawString(clsGetIdentities.SetImporter(CFPROID, JobID, drow1("ImporterID"), ErrMSg),
                                       font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -133, StringWriter)


                    DrawString("Cargo Description:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -113, StringWriter)
                    DrawString(drow1("Goods"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -113, StringWriter)

                    DrawString("Bill of Lading No:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -93, StringWriter)
                    DrawString(drow1("BL"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -93, StringWriter)


                    DrawString("Shipping Line:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -73, StringWriter)
                    DrawString(clsGetIdentities.SetShippingLine(CFPROID, JobID, drow1("ShippingLineID"), ErrMSg),
                                       font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -73, StringWriter)


                    Dim tmpcargo() As String = CargoTotals(CFPROID, JobID)
                    DrawString("Weight:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -53, StringWriter)
                    DrawString(tmpcargo(0), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -53, StringWriter)

                    DrawString("CBM:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -33, StringWriter)
                    DrawString(tmpcargo(1), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -33, StringWriter)

                    Dim drow2 As DataRow = GetVessel(CFPROID, drow1("VesselID"))
                    DrawString("Vessel:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -13, StringWriter)
                    DrawString(drow2("VesselVoyage"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, -13, StringWriter)

                    DrawString("ETA:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 7, StringWriter)
                    DrawString(drow2("ETA1"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 7, StringWriter)



                    DrawString("COSTS:", font8b, Drawing.Color.FromArgb(21, 21, 21), 65, 38, StringWriter)
                    DrawLine(pen, 60, 52, 735, 52)
                    DrawLine(pen, 60, 72, 735, 72)
                    DrawLine(pen, 60, 92, 735, 92)
                    DrawLine(pen, 60, 112, 735, 112)
                    DrawLine(pen, 60, 132, 735, 132)
                    DrawLine(pen, 60, 152, 735, 152)
                    DrawLine(pen, 60, 172, 735, 172)



                    DrawLine(pen, 60, 52, 60, 172)
                    DrawLine(pen, 200, 52, 200, 172)
                    DrawLine(pen, 380, 52, 380, 172)
                    DrawLine(pen, 735, 52, 735, 172)

                    DrawString("DESCRIPTION", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 57, StringWriter)
                    DrawString("AMOUNT", font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 57, StringWriter)
                    DrawString("REMARKS (IF APPLICABLE)", font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 57, StringWriter)
                    DrawString("SHIPPING LINE CHARGES", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 77, StringWriter)

                    DrawString("Delivery Order Fees:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 97, StringWriter)
                    DrawString(Format(drow1("DeliveryOrderCharges"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 97, StringWriter)
                    DrawString(drow1("ContainerDepositRemarks"), font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 97, StringWriter)


                    DrawString("Handing Over Fees:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 117, StringWriter)
                    DrawString(Format(drow1("HandoverFees"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 117, StringWriter)


                    DrawString("Container Deposit:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 137, StringWriter)
                    DrawString(Format(drow1("ContainerDeposit"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 137, StringWriter)

                    DrawString("Other:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 157, StringWriter)
                    DrawString(Format(drow1("ShippingExpenses"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 157, StringWriter)


                    DrawLine(pen, 60, 192, 735, 192)
                    DrawLine(pen, 60, 212, 735, 212)
                    DrawLine(pen, 60, 232, 735, 232)
                    DrawLine(pen, 60, 252, 735, 252)
                    DrawLine(pen, 60, 272, 735, 272)
                    DrawLine(pen, 60, 292, 735, 292)
                    DrawLine(pen, 60, 312, 735, 312)

                    DrawLine(pen, 60, 192, 60, 312)
                    DrawLine(pen, 200, 192, 200, 312)
                    DrawLine(pen, 380, 192, 380, 312)
                    DrawLine(pen, 735, 192, 735, 312)



                    DrawString("KPA / CFS  CHARGES", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 197, StringWriter)

                    DrawString("Normal Charges:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 217, StringWriter)
                    DrawString(Format(drow1("CFSCharges"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 217, StringWriter)
                    DrawString(drow1("VerificationRemarks"), font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 217, StringWriter)

                    DrawString("Remasharling Fees:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 237, StringWriter)
                    DrawString(Format(drow1("RemasharlingFees"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 237, StringWriter)

                    DrawString("Storage Charges:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 257, StringWriter)
                    DrawString(Format(drow1("StorageCharges"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 257, StringWriter)

                    DrawString("Shorehandling Fees:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 277, StringWriter)
                    DrawString(Format(drow1("ShoreHandlingFees"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 277, StringWriter)

                    DrawString("Other:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 297, StringWriter)
                    DrawString(Format(drow1("VerificationExpenses"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 297, StringWriter)


                    DrawLine(pen, 60, 332, 735, 332)
                    DrawLine(pen, 60, 352, 735, 352)
                    DrawLine(pen, 60, 372, 735, 372)
                    DrawLine(pen, 60, 392, 735, 392)
                    DrawLine(pen, 60, 412, 735, 412)
                    DrawLine(pen, 60, 432, 735, 432)


                    DrawLine(pen, 60, 332, 60, 432)
                    DrawLine(pen, 200, 332, 200, 432)
                    DrawLine(pen, 380, 332, 380, 432)
                    DrawLine(pen, 735, 332, 735, 432)

                    DrawString("KRA CHARGES", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 337, StringWriter)

                    DrawString("Truck Alteration Charges:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 357, StringWriter)
                    DrawString(Format(drow1("TruckAlterationFee"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 357, StringWriter)
                    DrawString(drow1("PortCustomsRemarks"), font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 357, StringWriter)

                    DrawString("Road Toll:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 377, StringWriter)
                    DrawString(Format(drow1("RoadToll"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 377, StringWriter)

                    DrawString("Custom Warehouse Rent:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 397, StringWriter)
                    DrawString(Format(drow1("WareHouseRent"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 397, StringWriter)

                    DrawString("Direct Release Charges:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 417, StringWriter)
                    DrawString(Format(drow1("ReleaseCharges"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 417, StringWriter)





                    DrawLine(pen, 60, 452, 735, 452)
                    DrawLine(pen, 60, 472, 735, 472)
                    DrawLine(pen, 60, 492, 735, 492)
                    DrawLine(pen, 60, 512, 735, 512)
                    DrawLine(pen, 60, 532, 735, 532)
                    DrawLine(pen, 60, 552, 735, 552)
                    DrawLine(pen, 60, 572, 735, 572)
                    DrawLine(pen, 60, 592, 735, 592)



                    DrawLine(pen, 60, 452, 60, 592)
                    DrawLine(pen, 200, 452, 200, 592)
                    DrawLine(pen, 380, 452, 380, 592)
                    DrawLine(pen, 545, 552, 545, 592)
                    DrawLine(pen, 735, 452, 735, 592)



                    DrawString("TRANSPORT CHARGES", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 457, StringWriter)

                    DrawString("Transported By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 477, StringWriter)

                    DrawString(clsGetIdentities.GetTransporter(CFPROID, drow1("TransporterID")),
                                                               font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 477, StringWriter)


                    DrawString("Transport Charges:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 497, StringWriter)
                    DrawString(Format(drow1("TransportCharges"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 497, StringWriter)

                    DrawString("Agreed Rate:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 517, StringWriter)
                    DrawString(Format(drow1("AgreedRate"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 517, StringWriter)
                    DrawString(drow1("CleareanceTransportRemarks"), font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 517, StringWriter)

                    DrawString("Quotation Ref:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 537, StringWriter)
                    DrawString(drow1("QuotationNo"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 537, StringWriter)


                    DrawString("Amount to Invoice:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 557, StringWriter)
                    DrawString(Format(drow1("InvoiceAmount"), "#,#0.00"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 557, StringWriter)

                    DrawString("Invoice No:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 577, StringWriter)
                    DrawString(drow1("InvoiceNo"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 577, StringWriter)

                    DrawString("Invoice Date:", font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 557, StringWriter)

                    If Not CDate(drow1("InvoiceDate")) = CDate("1/Jan/1800") Then
                        DrawString(Format(drow1("InvoiceDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 550, 557, StringWriter)
                    End If


                    DrawString("Dispatch Date:", font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 577, StringWriter)

                    If Not CDate(drow1("DispatchDate")) = CDate("1/Jan/1800") Then
                        DrawString(Format(drow1("DispatchDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 550, 577, StringWriter)
                    End If


                    DrawLine(pen, 60, 612, 735, 612)
                    DrawLine(pen, 60, 632, 735, 632)
                    DrawLine(pen, 60, 652, 735, 652)
                    DrawLine(pen, 60, 672, 735, 672)


                    DrawLine(pen, 60, 612, 60, 672)
                    DrawLine(pen, 200, 612, 200, 672)
                    DrawLine(pen, 380, 612, 380, 672)
                    DrawLine(pen, 545, 612, 545, 672)
                    DrawLine(pen, 735, 612, 735, 672)



                    DrawString("Prepared By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 617, StringWriter)
                    DrawString(drow1("FileClosingBy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 617, StringWriter)

                    DrawString("Checked By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 637, StringWriter)
                    DrawString(drow1("FileClosingCheckedBy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 205, 637, StringWriter)
                    DrawString("Accounts:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 657, StringWriter)

                    DrawString("General Manager:", font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 617, StringWriter)
                    DrawString("Director:", font7b, Drawing.Color.FromArgb(21, 21, 21), 385, 637, StringWriter)


                    DrawString("NOTES:", font8b, Drawing.Color.FromArgb(21, 21, 21), 65, 680, StringWriter)
                    DrawString("1. THE FILE NEEDS TO BE COMPLETED (INVOICED) 2 WEEKS FROM VESSEL ARRIVAL.", font7, Drawing.Color.FromArgb(21, 21, 21), 65, 695, StringWriter)
                    DrawString("2. INVOICES NEED TO BE DISPATCHED IMMEDIATELY AFTER BEING RAISED. CLIENT MANAGER TO ENSURE THIS IS DONE.", font7, Drawing.Color.FromArgb(21, 21, 21), 65, 710, StringWriter)
                    DrawString("3. ANY CHANGES THAT ARE NOT CAPTURED IN THE INVOICING SHALL BE TO THE ACCOUNT OF THE CLIENT MANAGER.", font7, Drawing.Color.FromArgb(21, 21, 21), 65, 725, StringWriter)
                    DrawString("4. CLIENT MANAGER TO CONFIRM THAT C&F PRO IS UP TO DATE ON THE FILE STATUS.", font7, Drawing.Color.FromArgb(21, 21, 21), 65, 740, StringWriter)

                    FileClosingFormPDF.AddTitle(drow("CFAgentName") & " | " & nClient)
                    FileClosingFormPDF.AddSubject("File Closing Summary | Job Ref No: " & drow1("ReferenceNo"))
                    FileClosingFormPDF.AddAuthor("Gamonki")
                    FileClosingFormPDF.AddCreator("C&F PRO ® | Cybermonk Software Development Limited")

                    FileClosingFormPDF.Close()

                    Dim bytes As Byte() = memoryStream.ToArray()



                    Dim FileClosingFormPath As String = HttpContext.Current.Server.MapPath(".") & "\fileclosingforms"

                    If Not Directory.Exists(FileClosingFormPath) Then
                        Directory.CreateDirectory(FileClosingFormPath)
                    End If

                    If Not Directory.Exists(FileClosingFormPath & "\" & CFPROID) Then
                        Directory.CreateDirectory(FileClosingFormPath & "\" & CFPROID)
                    End If



                    Dim nFileClosingFormPDF As String = FileClosingFormPath & "\" & CFPROID & "\FileClosingForm-" & JobID & ".pdf"


                    If File.Exists(nFileClosingFormPDF) Then
                        File.Delete(nFileClosingFormPDF)
                    End If


                    ' Write out PDF from memory stream.

                    Using fs As FileStream = File.Create(nFileClosingFormPDF)
                        fs.Write(bytes, 0, CInt(bytes.Length))
                        fs.Close()
                    End Using

                    memoryStream.Close()

                    Return "~/fileclosingforms/" & CFPROID & "/FileClosingForm-" & JobID & ".pdf"
                End Using

            Else
                Return ""
            End If

        Catch ex As Exception
            ErrMSg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function LoadFileClosingFormData(CFPROID As String, JobID As String, Optional ByRef ErrMsg As String = Nothing) As DataTable
        Try
            Dim sqlstr As String =
                     "Select ReferenceNo,ClientID,ImporterID," &
                      "Goods,BL,ShippingLineID,VesselID," &
                      "InvoiceNo,InvoiceDate,InvoiceAmount," &
                      "DeliveryOrderCharges,ContainerDeposit," &
                      "HandoverFees,ShippingExpenses," &
                      "CFSCharges,RemasharlingFees," &
                      "StorageCharges,ShoreHandlingFees," &
                      "VerificationExpenses,TruckAlterationFee," &
                      "RoadToll,WareHouseRent,ReleaseCharges," &
                      "TransportCharges,DispatchDate," &
                      "FileClosingBy,FileClosingCheckedBy," &
                      "TransporterID, AgreedRate,QuotationNo," &
                      "ContainerDepositRemarks,VerificationRemarks," &
                      "PortCustomsRemarks,CleareanceTransportRemarks,ID " &
                      "From Jobs " &
                      "Where CFPROID ='" & CFPROID & "' " &
                      "And JobId ='" & JobID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
            End If

            Return tmptable

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function


    Shared Function GetVessel(CFPROID As String, VesselID As String) As DataRow


        Dim sqlstr As String = "SELECT VesselID,Vessel,VoyageNo," &
                                "ShippingLine,ETA," &
                                "BerthingDate,ExitDate," &
                                "Active, ID " &
                                "From  ShippingVessels " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And VesselID = '" & VesselID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col1 As New DataColumn("VesselVoyage", Type.GetType("System.String"))
        Dim col2 As New DataColumn("ETA1", Type.GetType("System.String"))
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)



        Dim drow As DataRow
        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            tmptable.Rows.Add(drow)
        End If

        Call clsData.NullChecker(tmptable, 0)
        drow = tmptable.Rows(0)

        If Not drow("Vessel") = "" Then
            drow("VesselVoyage") = drow("Vessel") & " Voyage No: " & drow("VoyageNo")
        Else
            drow("VesselVoyage") = "N/A"
        End If

        If CDate(drow("ETA")) = CDate("1/Jan/1800") Then
            drow("ETA1") = "N/A"
        Else
            drow("ETA1") = Format(drow("ETA"), "dd MMM yyyy")
        End If

        Return drow

    End Function



    Shared Function CargoTotals(CFPROID As String, JobID As String) As String()
        Dim sqlstr As String = "SELECT Weight,CBM,ID " &
                                "From  JobCargo " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim a As Integer
        Dim Weight, CBM As Double

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            Weight = Weight + drow("Weight")
            CBM = CBM + drow("CBM")
            a = a + 1
        Next

        Dim tmpstr(2) As String
        tmpstr(0) = Format(Weight, "#,##0.00")
        tmpstr(1) = Format(CBM, "#,##0.00")
        tmpstr(2) = Format(a, "#,##0")

        Return tmpstr

    End Function




End Class





