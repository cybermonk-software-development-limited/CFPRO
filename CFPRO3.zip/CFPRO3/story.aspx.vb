﻿Public Class story
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            Dim CFPROID As String = ""
            Dim StoryID As String = ""
            Dim CSDID As String = ""

            Call clsAuth.UserLogin(CSDID, CFPROID, "", "", "", "", "", "", False, "", True)

            StoryID = Request.QueryString("storyid")

            LabelCSDID.text = CSDID
            LabelCFPROID.Text = CFPROID
            LabelStoryID.text = StoryID


            Call LoadStory(StoryID)
            Call ShowStories()
        End If
    End Sub

    Private Sub LoadStory(StoryID As String)

        Try

            Dim sqlstr As String = _
              "SELECT StoryID, StoryHeader," &
              "Caption, ShortDescription," &
              "Description, ImageURL1," &
              "LastUpdated, StoryURL, ViewCount,ID " &
              "FROM  Stories " &
              "Where StoryID = '" & StoryID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                clsData.NullChecker(tmptable, 0)

                Dim drow As DataRow = tmptable.Rows(0)
                Image1.ImageUrl = "~/stories/" & drow("ImageURL1")
                LabelStoryHeader.Text = drow("StoryHeader")
                LabelLastUpdated.Text = "Last Updated: " & Format(drow("LastUpdated"), "dd MMMM yyyy")
                LabelCaption.Text = drow("Caption")
                LabelShortDescription.Text = drow("ShortDescription")
                LabelDescription.Text = drow("Description")

                HyperLinkReadMore.NavigateUrl = drow("StoryURL").ToString

                'HyperLinkReadMore.NavigateUrl = "storyviewer.aspx?storyid=" & StoryID

                drow("ViewCount") = drow("ViewCount") + 1

                Call clsData.SaveData("Stories", tmptable, sqlstr, False, clsData.constr)

            End If


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub

   
    Private Sub ShowStories()

        Dim sqlstr As String = _
          "SELECT Top (10) StoryID, " &
          "StoryHeader, ShortDescription," &
          "ImageURL, LastUpdated,ID " &
          "FROM  Stories " &
          "Order By StoryID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        For Each drow In tmptable.Rows
            clsData.NullChecker(tmptable, a)
            drow("ImageURL") = "~/stories/" & drow("ImageURL")
            a = a + 1
        Next

        DataListStories.DataSource = tmptable
        DataListStories.DataBind()

    End Sub
    Protected Sub ImageButton1_Click(sender As Object, e As ImageClickEventArgs)
        Dim ImageButn As ImageButton = CType(sender, ImageButton)
        Call LoadStory(ImageButn.CommandArgument.ToString)
    End Sub

    Protected Sub LinkHeader_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Call LoadStory(link.CommandArgument.ToString)
    End Sub

  
End Class