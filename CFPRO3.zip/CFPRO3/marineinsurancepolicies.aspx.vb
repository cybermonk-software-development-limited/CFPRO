﻿Public Class marineinsurancepolicies
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim AuthAgent As Boolean

            If Not IsNothing(Request.Cookies("UserType")) Then
                If Request.Cookies("UserType").Value = "cfagent" Then
                    AuthAgent = True
                End If
            End If


            Dim CFPROID As String = ""
            Dim CSDID As String = ""

            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, "", "", Image1.ImageUrl, "", AuthAgent, "", False)

            If CSDID = "" Then
                HyperLinkHome.Text = "Home"
                HyperLinkHome.NavigateUrl = "~/index.aspx"
            Else
                HyperLinkHome.Text = "Dashboard"
                HyperLinkHome.NavigateUrl = "~/cfprodashboard.aspx"
            End If


            LabelCSDID.Text = CSDID
            LabelCFPROID.Text = CFPROID

            Dim EmailAddress As String = ""

            If Not IsNothing(Request.Cookies("CFPROMCI")) Then
                Dim tmpPolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMCI").Value)

                Dim tmpstr() As String = tmpPolicyID.Split("|")
                ReDim Preserve tmpstr(1)

                EmailAddress = tmpstr(1)
                LabelEmailAddress.Text = EmailAddress
            End If

            Call LoadPolicies(CFPROID, CSDID, EmailAddress)
            Call LoadInsurer()

            LabelFromPageURL.Text = Page.Request.UrlReferrer.ToString
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub

    Private Sub LoadPolicies(CFPROID As String, CSDID As String, EmailAddress As String)

        Dim tmpstr As String = ""

        If Not EmailAddress = "" Then
            If Not CFPROID = "" Then
                tmpstr = "Where EmailAddress ='" & EmailAddress & "' " &
                         "Or CFPROID ='" & CFPROID & "' "
            Else
                tmpstr = "Where EmailAddress ='" & EmailAddress & "' "
            End If

        ElseIf Not CSDID = "" Then
            If Not CFPROID = "" Then
                tmpstr = "Where CSDID ='" & CSDID & "' " &
                         "Or CFPROID ='" & CFPROID & "' "
            Else
                tmpstr = "Where CSDID ='" & CSDID & "' "
            End If
        Else
            LabelPolicyCount.Text = "0 - Marine Insurance Cover Notes"
            Exit Sub
        End If

        Dim sqlstr As String =
              "SELECT CSDID, PolicyID,PurchaseDate," &
              "UserNames, EmailAddress, " &
              "Telephone,ClientNames," &
              "ClientEmailAddress, ClientTelephone," &
              "CategoryID, CargoID," &
              "AmountInsured,Currency," &
              "ExchangeRate,AmountInsuredKES, " &
              "Premium,Total, Status,ID " &
              "FROM MarineInsurancePolicies " &
               tmpstr &
              "Order by ID Desc;"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim sqlstr1 As String = _
            "SELECT CargoID, CargoDesc, Conditions,CategoryID  " & _
            "FROM MarineCargo "

        Dim tmptable1 As New DataTable
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


        Dim col1 As New DataColumn("PolicyID1", Type.GetType("System.String"))
        Dim col2 As New DataColumn("PolicyURL", Type.GetType("System.String"))
        Dim col3 As New DataColumn("PolicyDetails", Type.GetType("System.String"))
        Dim col4 As New DataColumn("PolicyAmount", Type.GetType("System.String"))
        Dim col5 As New DataColumn("PolicyAmountKES", Type.GetType("System.String"))
        Dim col6 As New DataColumn("PolicyIDnID", Type.GetType("System.String"))
        Dim col7 As New DataColumn("CargoDesc", Type.GetType("System.String"))
        Dim col8 As New DataColumn("ShowDelete", Type.GetType("System.Boolean"))


        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)
        tmptable.Columns.Add(col8)

        Dim dv As New DataView(tmptable1)

        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)

            dv.RowFilter = "CargoID ='" & drow("CargoID") & "'"

            If dv.Count > 0 Then
                Call clsData.NullChecker1(dv, 0)
                drow("CargoDesc") = "Cargo Type: " & dv(0)("CargoDesc")
            End If

            drow("PolicyID1") = "Cover Note / Policy  No: " & drow("PolicyID")
            drow("PolicyURL") = "marineinsurancecovernote.aspx?policyid=" & HttpUtility.UrlEncode(clsEncr.EncryptString(drow("PolicyID")))
            drow("PolicyDetails") = "Policy Holder: " & drow("ClientNames") & ", Email: " & drow("ClientEmailAddress")


            drow("PolicyAmount") = "Invoice Amount: " & drow("Currency") & " " & Format(drow("AmountInsured"), "#,##0.00") & ",  Exchange Rate: " & Format(drow("ExchangeRate"), "#,##0.00")
            drow("PolicyAmountKES") = "Insured Amount:  KES " & Format(drow("AmountInsuredKES"), "#,##0.00") & ", Premium: KES " & Format(drow("Premium"), "#,##0.00") & ", Total: KES " & Format(drow("Total"), "#,##0.00")
            drow("PolicyIDnID") = drow("PolicyID") & "|" & drow("ID")


            If LCase(drow("Status")) = "started" Then
                drow("ShowDelete") = CBool(1)
            Else
                drow("ShowDelete") = CBool(0)
            End If
            a = a + 1
        Next

        LabelPolicyCount.Text = tmptable.Rows.Count & " - Marine Insurance Policies"
        DataList1.DataSource = tmptable
        DataList1.DataBind()

    End Sub

    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, " & _
            "Insurer,ProductName," & _
            "Description, URL," & _
            "EmailAddress,Telephone, SystemFees " & _
            "FROM MarineCargoInsurer "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)


        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)
            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")

            HyperLinkCompany.Text = drow("Insurer")
            HyperLinkCompany.NavigateUrl = drow("URL")


            LabelContacts.Text = drow("Contacts")
            LabelAboutPolicyURL.Text = "marineproductdesc.aspx?insurerid=" & drow("InsurerID")

        End If

    End Sub

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Call ShowItem(sender)
    End Sub

    Private Sub ShowItem(sender As Object)
        Try
            Dim link As LinkButton = CType(sender, LinkButton)
            Dim tmpstr As String = link.CommandArgument

            iframe1.Attributes("src") = tmpstr
            ModalPopupExtender1.Show()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub Button14_Click(sender As Object, e As EventArgs)
        Call DeletePolicy(sender)
    End Sub

    Private Sub DeletePolicy(Sender As Object)
        Dim Button As Button = CType(sender, Button)
        Dim tmpstr() As String = Button.CommandArgument.Split("|")

        ReDim Preserve tmpstr(1)

        Dim PolicyID As String = tmpstr(0)
        Dim ID As Integer = tmpstr(1)

        Dim sqlstr As String = _
               "SELECT FileID, FileExt, ID " &
               "FROM Documents " &
               "Where PolicyID = '" & PolicyID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim DocumentsPath As String = HttpContext.Current.Server.MapPath(".") & "\documents\"
        Dim tmpfile As String = ""

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            For a = 0 To tmptable.Rows.Count - 1
                drow = tmptable.Rows(a)

                If Not drow.RowState = DataRowState.Deleted Then
                    Call clsData.NullChecker(tmptable, a)
                    tmpfile = DocumentsPath & drow("FileID") & "." & drow("FileExt")
                    If IO.File.Exists(tmpfile) Then
                        IO.File.Delete(tmpfile)
                    End If
                End If
                drow.Delete()
            Next
            Call clsData.SaveData("Documents", tmptable, sqlstr, True, clsData.constr)

        End If

        Dim sqlstr1 As String = _
              "SELECT  ID " &
              "FROM MarineInsurancePolicies " &
              "Where ID = " & ID & " "

        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


        Dim drow1 As DataRow

        If tmptable1.Rows.Count > 0 Then
            drow1 = tmptable1.Rows(0)
            drow1.Delete()
            Call clsData.SaveData("MarineInsurancePolicies", tmptable1, sqlstr1, True, clsData.constr)
        End If

        Call LoadPolicies(LabelCFPROID.Text, LabelCSDID.Text, LabelEmailAddress.Text)

    End Sub
End Class


