﻿
Imports System.IO
Imports System.Drawing
Public Class fileclosing
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim UserName As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", UserName, "", "", "", "", True, "", False)

            LabelUserName.Text = UserName
            LabelCFPROID.Text = CFPROID
            AutoCompleteExtender1.ContextKey = CFPROID

            Dim JobID As String = Request.QueryString("jobid")
            Call LoadCFAgentUsers(CFPROID)

            Call LoadFileClosingData(CFPROID, JobID, UserName)
        End If
    End Sub



    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPreparedBy, sqlstr, clsData.constr, 0)
        Call clsData.PopCombo(ComboCheckedBy, sqlstr, clsData.constr, 0)

        ComboPreparedBy.Items.Insert(0, "")
        ComboCheckedBy.Items.Insert(0, "")
    End Sub



    Private Sub LoadFileClosingData(CFPROID As String, JobID As String, UserName As String)

        Dim sqlstr As String =
                      "Select InvoiceNo,InvoiceDate,InvoiceAmount," &
                      "DeliveryOrderCharges,ContainerDeposit," &
                      "HandoverFees,ShippingExpenses," &
                      "CFSCharges,RemasharlingFees," &
                      "StorageCharges,ShoreHandlingFees," &
                      "VerificationExpenses,TruckAlterationFee," &
                      "RoadToll,WareHouseRent,ReleaseCharges," &
                      "TransportCharges,DispatchDate," &
                      "FileClosingBy,FileClosingCheckedBy," &
                      "TransporterID, AgreedRate,QuotationNo," &
                      "ContainerDepositRemarks,VerificationRemarks," &
                      "PortCustomsRemarks,CleareanceTransportRemarks,ID " &
                      "From Jobs " &
                      "Where CFPROID ='" & CFPROID & "' " &
                      "And JobId ='" & JobID & "' "



        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        LabelJobID.Text = JobID


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            TextDeliveryOrderFees.Text = Format(drow("DeliveryOrderCharges"), "#,##0.#0")
            TextHandingOverFee.Text = Format(drow("HandoverFees"), "#,##0.#0")
            TextContainerDeposit.Text = Format(drow("ContainerDeposit"), "#,##0.#0")
            TextShippingExpenses.Text = Format(drow("ShippingExpenses"), "#,##0.#0")
            TextShippingRemarks.Text = drow("ContainerDepositRemarks")

            TextCFSCharges.Text = Format(drow("CFSCharges"), "#,##0.#0")
            TextRemarshaling.Text = Format(drow("RemasharlingFees"), "#,##0.#0")
            TextShoreHandling.Text = Format(drow("ShoreHandlingFees"), "#,##0.#0")
            TextStorageCharges.Text = Format(drow("StorageCharges"), "#,##0.#0")
            TextVerificationExpenses.Text = Format(drow("VerificationExpenses"), "#,##0.#0")


            TextTruckAlterationFee.Text = Format(drow("TruckAlterationFee"), "#,##0.#0")
            TextRoadToll.Text = Format(drow("RoadToll"), "#,##0.#0")
            TextWareHouseRent.Text = Format(drow("WareHouseRent"), "#,##0.#0")
            TextReleaseCharges.Text = Format(drow("ReleaseCharges"), "#,##0.#0")


            TextTransportCharges.Text = Format(drow("TransportCharges"), "#,##0.#0")
            TextTransportedBy.Text = clsGetIdentities.GetTransporter(CFPROID, drow("TransporterID"))
            nTransporterID.Value = drow("TransporterID")

            TextInvoiceNo.Text = drow("InvoiceNo")
            TextInvoiceDate.Text = Format(drow("InvoiceDate"), "dd MMM yyyy")
            TextInvoiceAmount.Text = Format(drow("InvoiceAmount"), "#,##0.#0")


            TextAgreedRate.Text = Format(drow("AgreedRate"), "#,##0.#0")
            TextQuotationNo.Text = drow("QuotationNo")
            TextDispatchDate.Text = Format(drow("DispatchDate"), "dd MMM yyyy")


            TextShippingRemarks.Text = drow("ContainerDepositRemarks")
            TextVerificationRemarks.Text = drow("VerificationRemarks")
            TextPortCustomsRemarks.Text = drow("PortCustomsRemarks")
            TextCleareanceTransportRemarks.Text = drow("CleareanceTransportRemarks")




            ComboPreparedBy.Text = drow("FileClosingBy")
            ComboCheckedBy.Text = drow("FileClosingCheckedBy")

            If drow("FileClosingBy") = "" Then
                ComboPreparedBy.Text = UserName
            End If

        End If

    End Sub


    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveDeclaration(LabelCFPROID.Text, LabelJobID.Text)
    End Sub

    Private Sub SaveDeclaration(CFPROID As String, JobID As String)

        Try

            Dim sqlstr As String =
                      "Select InvoiceNo,InvoiceDate,InvoiceAmount," &
                      "DeliveryOrderCharges,ContainerDeposit," &
                      "HandoverFees,ShippingExpenses," &
                      "CFSCharges,RemasharlingFees," &
                      "StorageCharges,ShoreHandlingFees," &
                      "VerificationExpenses,TruckAlterationFee," &
                      "RoadToll,WareHouseRent,ReleaseCharges," &
                      "TransportCharges,DispatchDate," &
                      "FileClosingBy,FileClosingCheckedBy," &
                      "TransporterID, AgreedRate,QuotationNo," &
                      "ContainerDepositRemarks,VerificationRemarks," &
                      "PortCustomsRemarks,CleareanceTransportRemarks,ID " &
                      "From Jobs " &
                      "Where CFPROID ='" & CFPROID & "' " &
                      "And JobId ='" & JobID & "' "



            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            LabelJobID.Text = JobID


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)


                drow("ContainerDeposit") = TextContainerDeposit.Text
                drow("DeliveryOrderCharges") = Trim(TextDeliveryOrderFees.Text)
                drow("HandoverFees") = Trim(TextHandingOverFee.Text)
                drow("ShippingExpenses") = Trim(TextShippingExpenses.Text)

                drow("CFSCharges") = Trim(TextCFSCharges.Text)
                drow("RemasharlingFees") = Trim(TextRemarshaling.Text)
                drow("ShoreHandlingFees") = TextShoreHandling.Text
                drow("StorageCharges") = Trim(TextStorageCharges.Text)
                drow("VerificationExpenses") = Trim(TextVerificationExpenses.Text)

                drow("TruckAlterationFee") = Trim(TextTruckAlterationFee.Text)
                drow("RoadToll") = Trim(TextRoadToll.Text)
                drow("WareHouseRent") = Trim(TextWareHouseRent.Text)
                drow("ReleaseCharges") = Trim(TextReleaseCharges.Text)


                drow("TransportCharges") = Trim(TextTransportCharges.Text)
                drow("TransporterID") = nTransporterID.Value

                drow("InvoiceNo") = Trim(TextInvoiceNo.Text)
                drow("InvoiceDate") = Trim(TextInvoiceDate.Text)
                drow("InvoiceAmount") = Trim(TextInvoiceAmount.Text)

                drow("AgreedRate") = Trim(TextAgreedRate.Text)
                drow("QuotationNo") = Trim(TextQuotationNo.Text)

                drow("DispatchDate") = Trim(TextDispatchDate.Text)


                drow("ContainerDepositRemarks") = Trim(TextShippingRemarks.Text)
                drow("VerificationRemarks") = Trim(TextVerificationRemarks.Text)
                drow("PortCustomsRemarks") = Trim(TextPortCustomsRemarks.Text)
                drow("CleareanceTransportRemarks") = Trim(TextCleareanceTransportRemarks.Text)

                drow("FileClosingBy") = ComboPreparedBy.Text
                drow("FileClosingCheckedBy") = ComboCheckedBy.Text

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

                Call LoadFileClosingData(CFPROID, JobID, LabelUserName.Text)
            End If

        Catch ex As Exception
            LabelMessage1.Text = "Error Saving Data. Check values"
        End Try
    End Sub


    <System.Web.Script.Services.ScriptMethod(),
  System.Web.Services.WebMethod()>
    Public Shared Function SearchTransporter(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As List(Of String)
        Return clsGetIdentities.SearchTransporter(prefixText, count, contextKey)
    End Function

    Protected Sub ButtonFileClosingForm_Click(sender As Object, e As EventArgs) Handles ButtonFileClosingForm.Click

        Dim FileClosingForm As String = clsFileClosingFormPDF.CreateFileClosingFormPDF(LabelCFPROID.Text, LabelJobID.Text, LabelMessage1.Text)

        If File.Exists(Server.MapPath(FileClosingForm)) Then
            LoadDialog(FileClosingForm, "File Closing Summary", 515, 780)
        Else
            ButtonFileClosingForm.Text = "No file."
        End If

    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl

        ModalPopupExtender4.CancelControlID = "ButtonCloseDialog"

        ModalPopupExtender4.Show()
    End Sub
End Class