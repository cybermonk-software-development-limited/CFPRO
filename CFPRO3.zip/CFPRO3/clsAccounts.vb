﻿Imports System.Net


Public Class clsAccounts




    Shared Function LoadCompanies(CFPROID As String, ByRef ComboCompanies As DropDownList, ByRef ErrMsg As String) As Integer
        Try
            ComboCompanies.Items.Clear()

            Dim sqlstr As String =
                      "SELECT  CompanyID,CompanyName," &
                      "CFPROID,ID " &
                      "FROM  Companies " &
                      "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim a As Integer
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    ComboCompanies.Items.Add(drow("CompanyName"))
                    ComboCompanies.Items(a).Value = (drow("CompanyID"))
                    a = a + 1
                Next
            End If

            Return tmptable.Rows.Count

        Catch ex As Exception
            ErrMsg = ex.Message + ex.StackTrace
        End Try

    End Function


    Shared Sub LoadCurrencies(ByRef ComboCurrency As DropDownList, ByRef ErrMsg As String)
        Try
            ComboCurrency.Items.Clear()
            Dim sqlstr As String =
                "SELECT  CurrencyID, Currency, CurrencyCode " &
                 "FROM  Currencies " &
                 "Order by CurrencyCode Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim a As Integer
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    ComboCurrency.Items.Add(drow("CurrencyCode") & " - " & drow("Currency"))
                    ComboCurrency.Items(a).Value = (drow("CurrencyID"))
                    a = a + 1
                Next
            End If
        Catch ex As Exception
            ErrMsg = ex.Message + ex.StackTrace
        End Try
    End Sub


    Shared Function GetLocalCurrency(CFPROID As String) As String()
        Dim sqlstr As String =
                        "Select LocalCurrencyID,ID " &
                        "From CFPROAccounts " &
                        "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr(2) As String
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            If Not drow("LocalCurrencyID") = "" Then
                tmpstr = GetCUrrencyNameandCode(drow("LocalCurrencyID"))
            End If

        End If

        Return tmpstr


    End Function


    Shared Function GetCurrencyNameandCode(CurrencyID As String) As String()
        Dim sqlstr As String =
                "SELECT  CurrencyID, Currency, CurrencyCode " &
                 "FROM  Currencies " &
                 "Where CurrencyID = '" & CurrencyID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr(2) As String
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            tmpstr(0) = drow("CurrencyCode")
            tmpstr(1) = drow("Currency")
            tmpstr(2) = drow("CurrencyID")
        End If

        Return tmpstr
    End Function



    Shared Function convertCurrency(foreignCurrency As String, localcurrency As String, Optional ByRef ErrMsg As String = "") As String




        Dim Query As String = foreignCurrency & "_" & localcurrency
        Dim apiKey As String = "2fb610411a6626100f16"

        Try
            Dim json As String = GetConversion("https://free.currencyconverterapi.com/api/v6/convert?q=" & Query & "&compact=ultra&apiKey=" & apiKey)


            Dim currFrom As String
            Dim currTo As String
            Dim currrate As String = "0.0"

            If json <> "{}" Then

                Dim curr() As String = Split(json, ":")
                currFrom = Mid(curr(0), 3, 3)
                currTo = Mid(curr(0), 7, 3)
                currrate = CStr(curr(1))
                currrate = Left(curr(1), Len(currrate) - 1)

            End If
            ErrMsg = json & " -  (https://free.currencyconverterapi.com/)"
            Return Format(CDbl(currrate), "#,##0.00")

        Catch ex As Exception
            ErrMsg = ex.Message
        End Try

    End Function

    Shared Function GetConversion(sURL As String, Optional ByRef ErrMsg As String = Nothing) As String
        Try
            Dim webClient = New WebClient()
            Return webClient.DownloadString(sURL)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Sub LoadActiveCurrencies(CFPROID As String, ComboCurrency As DropDownList)

        ComboCurrency.Items.Clear()

        Dim sqlstr As String =
           "Select Currency, AccountCurrencies.CurrencyID, ExchangeRate " &
           "From Currencies, AccountCurrencies " &
           "Where AccountCurrencies.CurrencyID = Currencies.CurrencyID " &
           "And AccountCurrencies.CFPROID = '" & CFPROID & "'"

        Call clsData.PopComboWithValue(ComboCurrency, sqlstr, clsData.constr, 0, 1)

        Dim tmpstr() As String = clsAccounts.GetLocalCurrency(CFPROID)

        Dim nListitem As New ListItem
        nListitem.Text = tmpstr(1)
        nListitem.Value = tmpstr(2)

        ComboCurrency.Items.Insert(0, nListitem)

    End Sub

    Shared Function CurrencyRateandCode(CFPROID As String, CurrencyID As String) As String()

        Dim sqlstr As String =
         "Select Currency,CurrencyCode, ExchangeRate " &
         "From Currencies, AccountCurrencies " &
         "Where AccountCurrencies.CurrencyID = '" & CurrencyID & "'" &
         "And AccountCurrencies.CFPROID = '" & CFPROID & "' " &
         "And AccountCurrencies.CurrencyID = Currencies.CurrencyID "


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr(2) As String
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            tmpstr(0) = drow("ExchangeRate")
            tmpstr(1) = drow("CurrencyCode")
            tmpstr(2) = drow("Currency")
        End If

        Return tmpstr
    End Function
End Class
