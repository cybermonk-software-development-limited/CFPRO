﻿Public Class WebForm1
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            'Dim CSDWCFService As New CSDWCFService.CSDService1Client

            Label2.Text = ""
            Dim tmptable As New DataTable

            'tmptable = CSDWCFService.ProductAccountAdmins(Trim(TextProductID.Text), Trim(TextCsd.Text))
            'tmptable = CSDWCFService.ProductAccount(Trim(TextProductID.Text))

            'If tmptable.Rows.Count > 0 Then
            '    Dim dv As New DataView(tmptable)
            '    dv.Sort = "NextPaymentDate ASC "
            '    If dv.Count > 0 Then
            '        GridView1.DataSource = dv
            '        GridView1.DataBind()

            '    End If
            'End If
            Call clsCFPROAccount.CreateUpdateCFPROAccount(tmptable, Trim(TextProductID.Text), Trim(TextCsd.Text), True)
            GridView1.DataSource = tmptable
            GridView1.DataBind()

        Catch ex As Exception
            Label2.Text = ex.Message & ex.StackTrace
        End Try


    End Sub
End Class