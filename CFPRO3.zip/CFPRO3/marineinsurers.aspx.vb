﻿Imports System.Drawing
Imports System.Configuration
Public Class marineinsurers
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, "", True, "", False)
            Call LoadInsurers("")

        End If
    End Sub



    Private Sub LoadInsurers(SearchStr As String)
        Dim sqlstr As String =
            "SELECT InsurerID, Insurer," & _
            "ProductName, Rate," & _
            "Description, URL," & _
            "EmailAddress,Telephone " & _
            "FROM Insurers "

        If Not SearchStr = "" Then
            If SearchStr.Length <= 50 Then
                If clsSubs.CleanSql(SearchStr) Then
                    sqlstr = sqlstr & " Where insurer like '" & "%" & SearchStr & "%" & "' "
                End If
            End If
        End If

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col As New DataColumn("ItemCount", Type.GetType("System.String"))
        Dim col0 As New DataColumn("ImageUrL", Type.GetType("System.String"))
        Dim col1 As New DataColumn("Rate1", Type.GetType("System.String"))
        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))
        Dim col4 As New DataColumn("InsurerID1", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col0)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)

        Dim a As Integer
        Dim imageURL As String
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)
            If IO.File.Exists(Server.MapPath(".") & "\insurerimages\" & drow("InsurerID") & ".jpg") Then
                imageURL = "~/insurerimages/" & drow("InsurerID") & ".jpg"
            ElseIf IO.File.Exists(Server.MapPath(".") & "\insurerimages\" & drow("InsurerID") & ".png") Then
                imageURL = "~/insurerimages/" & drow("InsurerID") & ".png"
            Else
                imageURL = "~/insurerimages/000000000.png"
            End If

            drow("SendMessage") = "sendmessage.aspx"
            drow("ProductName") = "Product: " & drow("ProductName")
            drow("Contacts") = "Email: " & drow("EmailAddress") & " - Telephone:" & drow("Telephone")
            drow("Rate1") = "Our Rate: " & drow("Rate") & "%"
            drow("ImageURL") = imageURL

            a = a + 1

            drow("ItemCount") = a & "."
            drow("InsurerID1") = "marineproductdesc.aspx?insurerid=" & drow("InsurerID")
        Next

        If SearchStr = "" Then
            LabelMessage.Text = tmptable.Rows.Count & " Insurers "
        Else
            LabelMessage.Text = tmptable.Rows.Count & " Insurers found with or matching '" & SearchStr & "' "
        End If

        DataList1.DataSource = tmptable
        DataList1.DataBind()

    End Sub



    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image2.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Private Sub CalcCIF(InsRate As Double)
        Try
            Dim fob As Double = CDbl(Trim(TextFOB.Text))
            Dim freight As Double = CDbl(Trim(TextFreight.Text))
            Dim insurance As Double = ((fob + freight) * InsRate) / 100

            Dim total As Double = fob + freight + insurance
            TextCIFTotal.Text = Format(total, "#,##0.00")

            TextFOB.Text = Format(fob, "#,##0.00")
            TextFreight.Text = Format(freight, "#,##0.00")
            TextInsurance.Text = Format(insurance, "#,##0.00")
        Catch ex As Exception

        End Try
        'If IsNumeric(TextFOB.Text) Then

        'End If


    End Sub


    Private Sub LoadTarget(Title As String, src As String)
        ModalPopupExtender1.Show()
        LabelInput.Text = Title
        iframe1.Attributes("src") = src

    End Sub

    Protected Sub LinkButton1_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        LoadTarget("Send Message", link.CommandArgument.ToString)
    End Sub

    Protected Sub LinkButton4_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        LoadTarget("Marine Insurance Product Page", link.CommandArgument.ToString)
    End Sub

    Protected Sub LinkButton3_Click(sender As Object, e As EventArgs)
        Dim link As LinkButton = CType(sender, LinkButton)
        Call CalcCIF(link.CommandArgument.ToString)
    End Sub

    Protected Sub DataList1_ItemDataBound(sender As Object, e As DataListItemEventArgs) Handles DataList1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim tbl As HtmlTable
            tbl = e.Item.Controls(0).FindControl("itemtable")
            tbl.Attributes.Add("OnMouseOver", "this.className='highlightitemcolor'")
            tbl.Attributes.Add("OnMouseOut", "this.className='normalitemcolor'")
        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call LoadInsurers(Trim(TextSearch.Text))
    End Sub
End Class