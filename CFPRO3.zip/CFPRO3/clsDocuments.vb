﻿Imports AjaxControlToolkit

Public Class clsDocuments

    Shared Sub LoadDocuments(CFPROID As String, JobID As String, MessageID As String, _
                                          PolicyID As String, Datalist1 As DataList, DocumentTypeID As String,
                                                              ByRef Caption As String, DocumentPurpose As String,
                                                              DocumentType As String, Optional ByRef ErrMsg As String = "", Optional OpenDirect As Boolean = False)

        Try
            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""
            Dim tmpstr2 As String = ""


            If DocumentType = "jobdocuments" Then
                tmpstr = "Where Documents.CFPROID = '" & CFPROID & "' " &
                         "And JobID = '" & JobID & "' "
            ElseIf DocumentType = "attachments" Then
                tmpstr = "Where MessageID = '" & MessageID & "' "
            ElseIf DocumentType = "insurance" Then
                tmpstr = "Where PolicyID = '" & PolicyID & "' "
            End If



            If Not DocumentTypeID = "" Then
                tmpstr1 = "And Documents.DocumentTypeID  = '" & DocumentTypeID & "' "
            End If

            If Not DocumentPurpose = "" Then
                tmpstr2 = "And DocumentTypes.Purpose= '" & DocumentPurpose & "' "
            End If


            Dim Sqlstr As String = _
                "SELECT  FileID, FileExt,DocumentType," &
                "MessageID,JobID,PolicyID," &
                "DateUploaded,UploadedBy, " &
                "FileCount, Documents.ID " &
                "FROM Documents, DocumentTypes " &
                 tmpstr & tmpstr1 & tmpstr2 &
                "And DocumentTypes.CFPROID = '" & CFPROID & "' " &
                "And Documents.DocumentTypeID = DocumentTypes.DocumentTypeID " &
                "Order By Documents.ID Desc; "

            Dim tmptable As New DataTable()
            Call clsData.TableData(Sqlstr, tmptable, clsData.constr)


            Dim DocumentsPath As String = HttpContext.Current.Server.MapPath(".") & "\documents\"

            If IO.Directory.Exists(DocumentsPath) Then


                Dim col0 As New DataColumn("FileName", Type.GetType("System.String"))
                Dim col1 As New DataColumn("FileURL", Type.GetType("System.String"))
                Dim col2 As New DataColumn("FileSize", Type.GetType("System.String"))
                Dim col3 As New DataColumn("FileDate", Type.GetType("System.String"))
                Dim col4 As New DataColumn("FilePath", Type.GetType("System.String"))
                Dim col5 As New DataColumn("FileTypeImage", Type.GetType("System.String"))
                Dim col6 As New DataColumn("ShowRemove", Type.GetType("System.Boolean"))
                Dim col7 As New DataColumn("OpenDirect", Type.GetType("System.Boolean"))
                Dim col8 As New DataColumn("OpenDirect1", Type.GetType("System.Boolean"))

                tmptable.Columns.Add(col0)
                tmptable.Columns.Add(col1)
                tmptable.Columns.Add(col2)
                tmptable.Columns.Add(col3)
                tmptable.Columns.Add(col4)
                tmptable.Columns.Add(col5)
                tmptable.Columns.Add(col6)
                tmptable.Columns.Add(col7)
                tmptable.Columns.Add(col8)

                Dim drow As DataRow
                Dim a As Integer
                Dim filesize As Double = 0
                Dim fileinfo As IO.FileInfo


                Dim tmpfile As String
                Dim Filename As String = ""

                Dim UploadedBy As String = ""

                If Not IsNothing(HttpContext.Current.Request.Cookies("UserType")) Then
                    UploadedBy = HttpContext.Current.Request.Cookies("UserType").Value
                End If

                For a = 0 To tmptable.Rows.Count - 1
                    Call clsData.NullChecker(tmptable, a)
                    drow = tmptable.Rows(a)


                    If drow("FileCount") = 0 Then
                        Filename = drow("DocumentType")
                    Else
                        Filename = drow("DocumentType") & "-" & drow("FileCount")
                    End If

                    drow("FileName") = Filename
                    drow("OpenDirect") = OpenDirect
                    drow("OpenDirect1") = Not OpenDirect

                    tmpfile = DocumentsPath & drow("FileID") & "." & drow("FileExt")


                    If UploadedBy = "importer" Then
                        If drow("UploadedBy") = UploadedBy Then
                            drow("ShowRemove") = CBool(1)
                        Else
                            drow("ShowRemove") = CBool(0)
                        End If
                    Else
                        drow("ShowRemove") = CBool(1)
                    End If

                    If Not IO.File.Exists(tmpfile) Then
                        drow.Delete()
                    Else
                        fileinfo = New IO.FileInfo(tmpfile)

                        filesize = fileinfo.Length / 1048576
                        If filesize > 1 Then
                            drow("Filesize") = "Size: " & Format((filesize), "0.#0") & " MB"
                        Else
                            filesize = fileinfo.Length / 1024
                            drow("Filesize") = "Size: " & Format((filesize), "0.#0") & " KB"
                        End If

                        drow("FileURL") = "~/documents/" & fileinfo.Name
                        drow("FilePath") = tmpfile
                        drow("FileDate") = "Added: " & Format(drow("DateUploaded"), "dd MMM yyyy hh:mm tt")

                        If LCase(drow("FileExt")) = "pdf" Then
                            drow("FileTypeImage") = "pdf-icon2.png"

                        ElseIf LCase(drow("FileExt")) = "png" Then
                            drow("FileTypeImage") = "image-icon.png"

                        ElseIf LCase(drow("FileExt")) = "jpg" Then
                            drow("FileTypeImage") = "image-icon.png"

                        ElseIf LCase(drow("FileExt")) = "xls" Then
                            drow("FileTypeImage") = "excel-icon.png"

                        ElseIf LCase(drow("FileExt")) = "xlsx" Then
                            drow("FileTypeImage") = "excel-icon.png"

                        ElseIf LCase(drow("FileExt")) = "doc" Then
                            drow("FileTypeImage") = "word-icon.png"

                        ElseIf LCase(drow("FileExt")) = "docx" Then
                            drow("FileTypeImage") = "word-icon.png"

                        Else
                            drow("FileTypeImage") = "file-icon.png"
                        End If

                    End If

                Next

                tmptable.AcceptChanges()


                If Not MessageID = "" Then
                    Caption = "Attachments (" & tmptable.Rows.Count & ")"
                Else
                    Caption = "Documents (" & tmptable.Rows.Count & ")"
                End If

                Datalist1.DataSource = tmptable
                Datalist1.DataBind()



            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub


    Shared Sub SaveDocuments(CFPROID As String, JobID As String, MessageID As String,
                                         PolicyID As String, DocumentTypeID As String, FileID As String, FileExt As String,
                                                DateUploaded As String, CSDID As String, EmailAddress As String,
                                                CFPROUserID As String, Optional ByRef ErrMsg As String = "")
        Try

            Dim tmpstr As String = ""

            If Not JobID = "" Then
                tmpstr = "And JobID = '" & JobID & "' "
            End If

            If Not MessageID = "" Then
                tmpstr = "And MessageID = '" & MessageID & "' "
            End If

            If Not PolicyID = "" Then
                tmpstr = "And PolicyID = '" & PolicyID & "' "
            End If

            Dim UploadedBy As String = ""


            If Not IsNothing(HttpContext.Current.Request.Cookies("UserType")) Then
                UploadedBy = HttpContext.Current.Request.Cookies("UserType").Value
            End If

            Dim sqlstr As String = _
                "SELECT  FileID, FileExt," &
                "JobID, MessageID," &
                "PolicyID, DocumentTypeID," &
                "DateUploaded,CSDID," &
                "EmailAddress, CFPROUserID," &
                "CFPROID,FileCount," &
                "UploadedBy, ID " &
                "FROM Documents " &
                "Where CFPROID = '" & CFPROID & "' " &
                tmpstr


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim dv As New DataView(tmptable)
            dv.RowFilter = "DocumentTypeID = '" & DocumentTypeID & "' "

            Dim drow As DataRow = tmptable.NewRow

            drow("CFPROID") = CFPROID
            drow("FileID") = FileID
            drow("FileExt") = FileExt
            drow("DocumentTypeID") = DocumentTypeID

            drow("JobID") = JobID
            drow("MessageID") = MessageID
            drow("PolicyID") = PolicyID
            drow("FileCount") = dv.Count

            drow("CSDID") = CSDID
            drow("EmailAddress") = EmailAddress
            drow("CFPROUserID") = CFPROUserID

            drow("UploadedBy") = UploadedBy

            If IsDate(DateUploaded) Then
                drow("DateUploaded") = DateUploaded
            End If

            tmptable.Rows.Add(drow)

            Call clsData.SaveData("Documents", tmptable, sqlstr, False, clsData.constr)

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Sub LoadDocumentTypes(ComboDocumentType As DropDownList, Insurance As Integer, Purpose As String, ByRef ErrMsg As String)
        Try

            Dim CFPROID As String = ""
            Call clsAuth.AuthCFAgent(CFPROID, "", "", "", "", "", False)
            Dim tmpstr As String = ""

            If Insurance Then
                tmpstr = "Where Insurance = " & Insurance & " " &
                "And Purpose = '" & Purpose & "' "
            Else
                tmpstr = "Where CFPROID = '" & CFPROID & "' " &
                "And Purpose = 'Clearing' "
            End If

            Dim sqlstr As String = _
                   "Select DocumentType,DocumentTypeID  " & _
                   "From DocumentTypes " & _
                    tmpstr &
                   "Order By DocumentTypeID Asc;"

            ComboDocumentType.Items.Clear()
            ComboDocumentType.Items.Add("(Select)")
            ComboDocumentType.Items(0).Value = ""
            Call clsData.PopComboWithValue(ComboDocumentType, sqlstr, clsData.constr, 0, 1)
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub



    Shared Function GetFileID() As String


        Dim tmpFileID As Double

        Dim sqlstr As String =
         "Select top 1 ID " &
         "From Documents " &
         "Order By Id Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim tmpstr As String
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            tmpFileID = drow("ID")
            tmpFileID = tmpFileID + 1
            tmpstr = Format(tmpFileID, "000000000000#")
        Else
            tmpstr = Format(tmpFileID, "000000000000#")
        End If

        Return tmpstr & "-" & clsSubs.GetRandomNo


    End Function

    Shared Sub DeleteDocuments(CFPROID As String, ID As String, ByRef ErrMsg As String)
        Try


            Dim sqlstr As String = _
                "SELECT FileID, FileExt, ID " &
                "FROM Documents " &
                "Where ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Dim DocumentsPath As String = HttpContext.Current.Server.MapPath(".") & "\documents\"
                Dim tmpfile As String = DocumentsPath & drow("FileID") & "." & drow("FileExt")

                If IO.File.Exists(tmpfile) Then
                    IO.File.Delete(tmpfile)
                End If

                drow.Delete()
                Call clsData.SaveData("Documents", tmptable, sqlstr, True, clsData.constr)
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Sub FileUpload(CFPROID As String, JobID As String, MessageID As String,
                            PolicyID As String, FileUpload1 As FileUpload, Dateuploaded As String,
                            ModalPopupExtender1 As ModalPopupExtender, ByRef ComboDocumentType As DropDownList,
                            LabelAttachmentMessage As Label, ByRef Caption As String, Datalist1 As DataList,
                            CSDID As String, CFPROUserID As String, DocumentPurpose As String, DocumentType As String,
                            ByRef ErrMsg As String, Optional OpenDirect As Boolean = False)


        If ComboDocumentType.SelectedIndex = 0 Then
            LabelAttachmentMessage.Text = "Document Type Not Set"
            LabelAttachmentMessage.ForeColor = Drawing.Color.Red
            ModalPopupExtender1.Show()
            Exit Sub
        End If


        Dim filename As String = FileUpload1.FileName


        If FileUpload1.FileContent.Length <= 3145728 Then
            Dim tmpstr() As String = filename.Split(".")
            Dim a As Integer = tmpstr.GetUpperBound(0)
            ReDim Preserve tmpstr(a)


            If LCase(tmpstr(a)) = "pdf" Or LCase(tmpstr(a)) = "xlsx" Or LCase(tmpstr(a)) = "xls" Or _
                LCase(tmpstr(a)) = "doc" Or LCase(tmpstr(a)) = "docx" Or LCase(tmpstr(a)) = "jpg" Or LCase(tmpstr(a)) = "png" Then


                Dim DocumentsPath As String = HttpContext.Current.Server.MapPath(".") & "\documents\"

                If Not IO.Directory.Exists(DocumentsPath) Then
                    IO.Directory.CreateDirectory(DocumentsPath)
                End If

                If IsDate(Dateuploaded) Then
                    Dateuploaded = Format(CDate(Dateuploaded), "dd MMM yyyy hh:mm tt")
                Else
                    Dateuploaded = Format(Now, "dd MMM yyyy hh:mm tt")
                End If

                Dim FileID As String = clsDocuments.GetFileID
                Dim tmpfile As String = FileID & "." & tmpstr(a)
                Dim filepath As String = DocumentsPath & "\" & tmpfile


                Call clsDocuments.SaveDocuments(CFPROID, JobID, MessageID, PolicyID,
                                                 ComboDocumentType.SelectedValue, FileID, tmpstr(a), Dateuploaded,
                                                     CSDID, "", CFPROUserID, ErrMsg)
                FileUpload1.SaveAs(filepath)

                Call clsDocuments.LoadDocuments(CFPROID, JobID, MessageID, PolicyID, Datalist1, "", Caption, DocumentPurpose, DocumentType, ErrMsg, OpenDirect)

                LabelAttachmentMessage.Text = "Browse to File & Click 'Upload' (3MB max .pdf .xls/xlsx .doc/docx .jpg & .png format only)"
                LabelAttachmentMessage.ForeColor = Drawing.Color.Black
                ComboDocumentType.SelectedIndex = 0

            Else
                LabelAttachmentMessage.Text = "Error! - file  is not in pdf, jpg, xls/xlsx, doc/docx or png Format"
                LabelAttachmentMessage.ForeColor = Drawing.Color.Red
                ModalPopupExtender1.Show()
            End If

        Else
            LabelAttachmentMessage.Text = "Error! - File Size exceeds 3MB"
            LabelAttachmentMessage.ForeColor = Drawing.Color.Red
        End If

    End Sub

    Shared Function DocumentCount(CFPROID As String, JobID As String, MessageID As String, _
                                     PolicyID As String, DocumentPurpose As String, DocumentType As String, Optional ByRef ErrMsg As String = "") As Integer


        Try


            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""


            If DocumentType = "jobdocuments" Then
                tmpstr = "Where Documents.CFPROID = '" & CFPROID & "' " &
                         "And JobID = '" & JobID & "' "
            ElseIf DocumentType = "attachments" Then
                tmpstr = "Where MessageID = '" & MessageID & "' "
            ElseIf DocumentType = "insurance" Then
                tmpstr = "Where PolicyID = '" & PolicyID & "' "
            End If

            If Not DocumentPurpose = "" Then
                tmpstr1 = "And Purpose= '" & DocumentPurpose & "' "
            End If

            Dim Sqlstr As String = _
                "SELECT   Documents.ID " &
                "FROM Documents, DocumentTypes  " &
                tmpstr & tmpstr1 &
                "And  DocumentTypes.CFPROID = '" & CFPROID & "' " &
                "And Documents.DocumentTypeID = DocumentTypes.DocumentTypeID "


            Dim tmptable As New DataTable()
            Call clsData.TableData(Sqlstr, tmptable, clsData.constr)

            Return tmptable.Rows.Count


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function

End Class
