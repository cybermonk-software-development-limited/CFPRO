﻿Imports System.Drawing

Public Class depots
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadDepots(CFPROID, "")

        End If

    End Sub

    Private Sub LoadDepots(ByVal CFPROID As String, SearchStr As String)

        Try


            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Depot Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "SELECT Depot, CFPROID, ID " &
                                    "From  Depots " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                       tmpstr &
                                    "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridDepots.DataSource = tmptable
            GridDepots.DataBind()

            LabelCaption.Text = tmptable.Rows.Count & "  Depots"


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingDepots_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridDepots.SelectedIndexChanged
        Dim row As GridViewRow = GridDepots.Rows(GridDepots.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridDepots.Rows.Count - 1
            row = GridDepots.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridDepots.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingDepots_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridDepots.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridDepots, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditDepots(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditDepots(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridDepots.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please SELECT Depot."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Depot"
                Dim ID As Integer = GridDepots.SelectedValue
                Dim sqlstr As String = "SELECT Depot,ID " &
                                        "From  Depots " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("Depot")
                End If

            Else
                LabelAddEdit.Text = "Add  Depot"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditDepots(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveDepots(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveDepots(CFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If DepotsExists(CFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridDepots.SelectedIndex >= 0 Then
                    ID = GridDepots.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT Depot, CFPROID, ID " &
                                    "From  Depots " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Depot") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("Depots", tmptable, sqlstr, False, clsData.constr)

            Call LoadDepots(CFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function DepotsExists(CFPROID As String, Depots As String) As Boolean


        Dim sqlstr As String = "SELECT Depot " &
                                "From  Depots " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And Depots = " & Trim(Depots) & " "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridDepots.SelectedIndex >= 0 Then
            Call PromptDeleteDepots(GridDepots.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select Depot to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteDepots(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridDepots.Rows(GridDepots.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteDepots(GridDepots.SelectedValue)
    End Sub
    Private Sub DeleteDepots(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From Depots  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("Depots", tmptable, sqlstr, True, clsData.constr)

            Call LoadDepots(LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub


    'Private Function GetDepotsID() As String
    '    Try

    '        Dim tmpDepotsID As Integer

    '        Dim sqlstr As String = _
    '         "Select top 1 ID " & _
    '         "From Depots " & _
    '         "Order By Id Desc;"

    '        Dim tmptable As New DataTable()
    '        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

    '        Dim tmpstr As String
    '        If tmptable.Rows.Count > 0 Then
    '            Dim drow As DataRow = tmptable.Rows(0)
    '            tmpDepotsID = drow("ID")
    '            tmpDepotsID = tmpDepotsID + 1
    '            tmpstr = Format(tmpDepotsID, "000000000#")
    '        Else
    '            tmpstr = Format(tmpDepotsID, "000000000#")
    '        End If

    '        Return tmpstr & "-" & clsSubs.GetRandomNo

    '    Catch exp As Exception
    '        LabelMessage1.Text = exp.Message & exp.StackTrace
    '    End Try
    'End Function


    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadDepots(LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadDepots(LabelCFPROID.Text, "")
    End Sub



End Class