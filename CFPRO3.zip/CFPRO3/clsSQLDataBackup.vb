﻿


Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.IO

Public Class clsSQLDataBackup


    Private Shared Sub Main()
        Dim connectionString As String = GetConnectionString()

        Using sourceConnection As SqlConnection = New SqlConnection(connectionString)
            sourceConnection.Open()
            Dim commandRowCount As SqlCommand = New SqlCommand("SELECT COUNT(*) FROM " & "dbo.BulkCopyDemoMatchingColumns;", sourceConnection)
            Dim countStart As Long = System.Convert.ToInt32(commandRowCount.ExecuteScalar())
            Console.WriteLine("Starting row count = {0}", countStart)
            Dim commandSourceData As SqlCommand = New SqlCommand("SELECT ProductID, Name, " & "ProductNumber " & "FROM Production.Product;", sourceConnection)
            Dim reader As SqlDataReader = commandSourceData.ExecuteReader()

            Using destinationConnection As SqlConnection = New SqlConnection(connectionString)
                destinationConnection.Open()

                Using bulkCopy As SqlBulkCopy = New SqlBulkCopy(destinationConnection)
                    bulkCopy.DestinationTableName = "dbo.BulkCopyDemoMatchingColumns"

                    Try
                        bulkCopy.WriteToServer(reader)
                    Catch ex As Exception
                        Console.WriteLine(ex.Message)
                    Finally
                        reader.Close()
                    End Try
                End Using

                Dim countEnd As Long = System.Convert.ToInt32(commandRowCount.ExecuteScalar())
                Console.WriteLine("Ending row count = {0}", countEnd)
                Console.WriteLine("{0} rows were added.", countEnd - countStart)
                Console.WriteLine("Press Enter to finish.")
                Console.ReadLine()
            End Using
        End Using
    End Sub

    Private Shared Function GetConnectionString() As String
        Return "Data Source=(local); " & " Integrated Security=true;" & "Initial Catalog=AdventureWorks;"
    End Function


    Shared Sub SurroundingSub(destinationConnection As String, destinationTableName As String, Table As DataTable)
        Using bulkCopy As SqlBulkCopy = New SqlBulkCopy(destinationConnection)
            For Each col As DataColumn In Table.Columns
                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName)
            Next

            bulkCopy.BulkCopyTimeout = 600
            bulkCopy.DestinationTableName = destinationTableName
            bulkCopy.WriteToServer(Table)
        End Using

    End Sub

    Private Sub importfromexcel(uploadFileName As String)
        Dim connectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
   "Data Source=" & uploadFileName & ";" & _
   "Extended Properties=Excel 8.0;"

        Dim excelData As New DataTable

        Using myConnection As New OleDbConnection(connectionString)
            'Get all data from the InventoryData worksheet 
            Dim myCommand As New OleDbCommand
            myCommand.CommandText = "SELECT * FROM [InventoryData$]"
            myCommand.Connection = myConnection

            'Read data into DataTable 
            Dim myAdapter As New OleDbDataAdapter
            myAdapter.SelectCommand = myCommand
            myAdapter.Fill(excelData)

            myConnection.Close()
        End Using


        Using bulkCopy As New SqlBulkCopy(connectionString)
            bulkCopy.DestinationTableName = "InventoryItems"

            'Define column mappings 
            For Each col As DataColumn In excelData.Columns
                bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName)
            Next

            bulkCopy.WriteToServer(excelData)
        End Using

        Using destinationConnection As New SqlConnection(connectionString)
            destinationConnection.Open()

            Using bulkCopy As New SqlBulkCopy(destinationConnection)
                bulkCopy.DestinationTableName = "InventoryItems"

                bulkCopy.WriteToServer(excelData)
            End Using

            destinationConnection.Close()
        End Using

    End Sub


    Private Sub SurroundingSub()
        Dim SourceConnection As String = "Server=localhost\sqlexpress;Database=SourceDB;Trusted_Connection=True;"
        Dim DestinationConnection As String = "Server=localhost\sqlexpress;Database=DestinationDB;Trusted_Connection=True;"
        Dim TableNameWithSchema As String = "dbo.Person"
        Dim columns As List(Of String) = New List(Of String)() From {
            "ID",
            "FirstName",
            "LastName"
        }
    End Sub

    Private Shared Sub CopyTable(ByVal sourceConnection As String, ByVal destinationConnection As String, ByVal tableNameWithSchema As String, ByVal columns As String())
        Dim o As SqlBulkCopyOptions = SqlBulkCopyOptions.[Default]
        o = o Or SqlBulkCopyOptions.KeepIdentity
        o = o Or SqlBulkCopyOptions.KeepNulls
        o = o Or SqlBulkCopyOptions.TableLock

        Using bcp As SqlBulkCopy = New SqlBulkCopy(destinationConnection, o)
            bcp.BulkCopyTimeout = 0
            bcp.BatchSize = 20000
            bcp.DestinationTableName = tableNameWithSchema

            For Each c As String In columns
                Dim m As SqlBulkCopyColumnMapping = New SqlBulkCopyColumnMapping()
                m.DestinationColumn = c
                m.SourceColumn = c
                bcp.ColumnMappings.Add(m)
            Next

            Using sourceConn As SqlConnection = New SqlConnection(sourceConnection)
                sourceConn.Open()

                Using sourceComm As SqlCommand = New SqlCommand()
                    sourceComm.CommandTimeout = 100
                    sourceComm.Connection = sourceConn
                    sourceComm.Parameters.Clear()
                    sourceComm.CommandText = "SELECT * FROM " & tableNameWithSchema
                    sourceComm.CommandType = CommandType.Text

                    Using Reader As SqlDataReader = sourceComm.ExecuteReader()
                        bcp.WriteToServer(Reader)
                    End Using
                End Using
            End Using
        End Using
    End Sub

    Protected Sub btnBackup_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim sqlconn As SqlConnection = New SqlConnection("Data Source=TutorialsPanel-PC\SQLEXPRESS;Initial Catalog=TutorialsPanel;Integrated Security=True;Pooling=False")
        Dim sqlcmd As SqlCommand = New SqlCommand()

        Dim backupDestination As String = "C:\SQLBackUpFolder"

        If Not System.IO.Directory.Exists(backupDestination) Then
            System.IO.Directory.CreateDirectory("D:\SQLBackUpFolder")
        End If

        Try
            sqlconn.Open()
            sqlcmd = New SqlCommand("backup database TutorialsPanel to disk='" & backupDestination & "\" & DateTime.Now.ToString("ddMMyyyy_HHmmss") & ".Bak'", sqlconn)
            sqlcmd.ExecuteNonQuery()
            sqlconn.Close()
            ' Response.Write("Backup database successfully")
        Catch ex As Exception
            ' Response.Write(ex.Message)
        End Try
    End Sub



    Shared Sub ExcuteScript()
        Dim sqlconn As SqlConnection = New SqlConnection("Data Source=TutorialsPanel-PC\SQLEXPRESS;Initial Catalog=TutorialsPanel;Integrated Security=True;Pooling=False")
        Dim sqlcmd As SqlCommand = New SqlCommand()



        Dim script As String = File.ReadAllText("E:\Project Docs\MX462-PD\MX756_ModMappings1.sql")
        sqlconn.Open()
        sqlcmd = New SqlCommand(script, sqlconn)
        sqlcmd.ExecuteNonQuery()
        sqlconn.Close()



    End Sub

    Shared Function SurroundingSub(_ConnectionString As String) As DataTable
        Dim sqlConnection As SqlConnection = New SqlConnection()
        sqlConnection.ConnectionString = _ConnectionString
        sqlConnection.Open()

        Dim sqlQuery As String = "SELECT name FROM sys.tables Order By Name Asc;"
        Dim sqlCommand As SqlCommand = New SqlCommand(sqlQuery, sqlConnection)
        sqlCommand.CommandType = CommandType.Text

        Dim sqlDataAdapter As SqlDataAdapter = New SqlDataAdapter(sqlCommand)

        Dim tmptable As New DataTable
        sqlDataAdapter.Fill(tmptable)


        Return tmptable

    End Function



End Class

