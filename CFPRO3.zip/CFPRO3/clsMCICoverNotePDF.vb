﻿

Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf

Public Class clsMCICoverNotePDF
    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75

        contentByte.SetLineWidth(0.01)
        contentByte.SetRGBColorStroke(40, 40, 40)

        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x2, 842 - y2)

        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75

        contentByte.SetLineWidth(0.01)
        contentByte.SetRGBColorStroke(25, 25, 25)

        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - (y1 + height))
        contentByte.LineTo(x1, 842 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 842 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Sub MCICoverNotePDF(InstacoverDetails As DataTable, PolicyID As String, Attach As Boolean)

        Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeuil.ttf"
        Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
        Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
        Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\seguisbi.ttf"
        Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"
        Dim fontpath5 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeuib.ttf"
        Dim fontpath6 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\seguibl.ttf"

        Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontbv As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontbb As BaseFont = BaseFont.CreateFont(fontpath5, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontbbb As BaseFont = BaseFont.CreateFont(fontpath6, BaseFont.CP1252, BaseFont.EMBEDDED)

        Dim font6b As New Font(customfontb, 6)
        Dim font7b As New Font(customfontb, 7.4)

        Dim font7 As New Font(customfont, 7)

        Dim font8 As New Font(customfontb, 8)
        Dim font8i As New Font(customfonti, 8)
        Dim font8b As New Font(customfontb, 8)
        Dim font9 As New Font(customfont, 9)
        Dim font9b As New Font(customfontb, 9)
        Dim font11c As New Font(customfontc, 10.5)
        Dim font10b As New Font(customfontb, 10)
        Dim font10 As New Font(customfont, 10)
        Dim font12b As New Font(customfontb, 12)
        Dim font14b As New Font(customfontb, 14)
        Dim font18b As New Font(customfontbbb, 18)
        Dim font22 As New Font(customfont, 22)
        Dim font22b As New Font(customfontb, 22)
        Dim font22bb As New Font(customfontbb, 22)

        Dim brush As Drawing.Color
        Dim brush1 As Drawing.Color = Drawing.Color.FromArgb(15, 15, 15)
        Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(255, 0, 0)
        Dim brush3 As Drawing.Color = Drawing.Color.FromArgb(7, 103, 29)
        'Dim PDFReader As PdfReader = Nothing 'Read File

        ' Document starts here

        Dim CoverNoteLogoPath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\InstaCoverLogo.png"
        Dim QRCodePath As String = HttpContext.Current.Server.MapPath(".") & "\mcicovernotes\" & PolicyID & ".png"
        Dim CoverNotePDF As New Document(PageSize.A4, 0, 0, 0, 10)




        'New FileStream(regdocpath, FileMode.Create)

        Using memoryStream As New System.IO.MemoryStream()
            Dim PDFwriter As PdfWriter = PDFwriter.GetInstance(CoverNotePDF, memoryStream)

            Dim logo As Image = Image.GetInstance(CoverNoteLogoPath)
            Dim QRCode As Image = Image.GetInstance(QRCodePath)
            CoverNotePDF.Open()



            'Create line pens
            Dim pen As PdfContentByte = PDFwriter.DirectContent
            Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

            DrawRectangle(pen, 50, 50, 700, 1000)

            If File.Exists(CoverNoteLogoPath) Then
                logo.ScaleToFit(695, 80)
                logo.SetAbsolutePosition(50, 710)
                CoverNotePDF.Add(logo)
            Else
                DrawString("InstaCover Insurance Services", font22b, brush1, 50, 50, StringWriter)
            End If

            If File.Exists(QRCodePath) Then
                QRCode.ScaleToFit(100, 100)
                QRCode.SetAbsolutePosition(455, 700)
                CoverNotePDF.Add(QRCode)
            Else
                DrawRectangle(pen, 640, 60, 100, 100)
                DrawString("QR CODE", font11c, brush1, 655, 95, StringWriter)
            End If



            Dim drow As DataRow = InstacoverDetails.Rows(0)

            Dim tmpcontacts() As String = drow("Contacts").ToString.Split("|")
            ReDim Preserve tmpcontacts(1)
            DrawString("Email:", font10b, brush1, 60, 200, StringWriter)
            DrawString(tmpcontacts(0), font10, brush1, 150, 200, StringWriter)

            DrawString("Telephone:", font10b, brush1, 60, 225, StringWriter)
            DrawString(tmpcontacts(1), font10, brush1, 150, 225, StringWriter)



            DrawString("Serial No.:", font10b, brush1, 500, 200, StringWriter)
            DrawString(drow("PolicyID"), font10, brush1, 590, 200, StringWriter)
            DrawString("Status:", font10b, brush1, 500, 225, StringWriter)

            Dim tpmStatus As String
            If LCase(drow("Status")) = "started" Then
                brush = brush2
                tpmStatus = "NOT PAID"
            Else
                brush = brush3
                tpmStatus = "PAID"
            End If

            DrawString(tpmStatus, font18b, brush, 590, 225, StringWriter)



            DrawString("Cover Note", font22bb, brush1, 60, 250, StringWriter)

            DrawLine(pen, 55, 280, 745, 280)

            DrawString("Purchaser:", font10b, brush1, 60, 285, StringWriter)
            DrawString(drow("UserNames"), font10, brush1, 180, 285, StringWriter)
            DrawString("Telephone No.:", font10b, brush1, 400, 285, StringWriter)
            DrawString(drow("Telephone"), font10, brush1, 560, 285, StringWriter)
            DrawString("Email Address:", font10b, brush1, 60, 310, StringWriter)
            DrawString(drow("EmailAddress"), font10, brush1, 180, 310, StringWriter)

            DrawString("Policy Holder:", font10b, brush1, 60, 360, StringWriter)
            DrawString(drow("ClientNames"), font10, brush1, 180, 360, StringWriter)
            DrawString("Email Address:", font10b, brush1, 60, 385, StringWriter)
            DrawString(drow("ClientEmailAddress"), font10, brush1, 180, 385, StringWriter)
            DrawString("Telephone No.:", font10b, brush1, 400, 385, StringWriter)
            DrawString(drow("ClientTelephone"), font10, brush1, 560, 385, StringWriter)
            DrawString("P.I.N.:", font10b, brush1, 60, 410, StringWriter)
            DrawString(drow("ClientPIN"), font10, brush1, 180, 410, StringWriter)
            DrawString("ID No.:", font10b, brush1, 400, 410, StringWriter)
            DrawString(drow("ClientIDNo"), font10, brush1, 560, 410, StringWriter)

            DrawString("Policy Particulars", font14b, brush1, 60, 450, StringWriter)
            DrawLine(pen, 55, 470, 745, 470)

            DrawString("Insured Value:", font10b, brush1, 60, 475, StringWriter)
            DrawString(Format(drow("AmountInsured"), "#,##0.00"), font10, brush1, 180, 475, StringWriter)
            DrawString("Stamp Duty:", font10b, brush1, 400, 475, StringWriter)
            DrawString(Format(drow("StampDuty"), "#,##0.00"), font10, brush1, 560, 475, StringWriter)
            DrawString("Premium:", font10b, brush1, 60, 500, StringWriter)
            DrawString(Format(drow("Premium"), "#,##0.00"), font10, brush1, 180, 500, StringWriter)
            DrawString("Policy Holders Fund:", font10b, brush1, 400, 500, StringWriter)
            DrawString(Format(drow("PolicyHolderFund"), "#,##0.00"), font10, brush1, 560, 500, StringWriter)
            DrawString("Total Paid(KES):", font10b, brush1, 60, 525, StringWriter)
            DrawString(Format(drow("Total"), "#,##0.00"), font10, brush1, 180, 525, StringWriter)
            DrawString("Training Levy:", font10b, brush1, 400, 525, StringWriter)
            DrawString(Format(drow("TrainingLevy"), "#,##0.00"), font10, brush1, 560, 525, StringWriter)
            DrawString("System Fee:", font10b, brush1, 400, 550, StringWriter)
            DrawString(Format(drow("SystemFees"), "#,##0.00"), font10, brush1, 560, 550, StringWriter)

            DrawLine(pen, 55, 570, 745, 570)

            DrawString("Invoice No:", font10b, brush1, 60, 595, StringWriter)
            DrawString(drow("InvoiceNo"), font10, brush1, 180, 595, StringWriter)
            DrawString("B.L. No.:", font10b, brush1, 60, 620, StringWriter)
            DrawString(drow("BL"), font10, brush1, 180, 620, StringWriter)
            DrawString("Country of Origin:", font10b, brush1, 60, 645, StringWriter)
            DrawString(drow("BLCountry"), font10, brush1, 180, 645, StringWriter)

            DrawString("Description of Goods:", font10b, brush1, 60, 690, StringWriter)
            DrawString(drow("Goods"), font10, brush1, 60, 715, StringWriter)

            DrawLine(pen, 55, 775, 745, 775)

            DrawString("This policy covers imports and exports while being shipped to and out of Kenya/East Africa.", font10b, brush1, 60, 780, StringWriter)

            DrawString("Cover for physical loss damage to all cargo being imported or exported around the world.", font9, brush1, 60, 805, StringWriter)

            CoverNotePDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")
            CoverNotePDF.Close()
            Dim bytes As Byte() = memoryStream.ToArray()



            If Attach Then


                Dim CoverNotePath As String = HttpContext.Current.Server.MapPath(".") & "\mcicovernotes"
                If Not Directory.Exists(CoverNotePath) Then
                    Directory.CreateDirectory(CoverNotePath)
                End If
                Dim CoverNotePDFName As String = CoverNotePath & "\MCI Cover Note " & PolicyID & ".pdf"

                If File.Exists(CoverNotePDFName) Then
                    File.Delete(CoverNotePDFName)
                End If

                ' Write out PDF from memory stream. 
                Using fs As FileStream = File.Create(CoverNotePDFName)
                    fs.Write(bytes, 0, CInt(bytes.Length))
                    fs.Close()
                End Using

            Else

                HttpContext.Current.Response.ClearContent()
                HttpContext.Current.Response.ClearHeaders()
                HttpContext.Current.Response.ContentType = "application/pdf"
                HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=MCI Cover Note " & PolicyID & ".pdf")
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache)
                HttpContext.Current.Response.Buffer = True


                HttpContext.Current.Response.BinaryWrite(bytes)

                HttpContext.Current.Response.End()
                HttpContext.Current.Response.Flush()
                HttpContext.Current.Response.Clear()
                HttpContext.Current.Response.Close()
            End If

            memoryStream.Close()
        End Using
    End Sub

End Class
