﻿Public Class progressreportviewer
    Inherits System.Web.UI.Page

    Friend JobId As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            'Dim imgurl As String = ""
            Dim CSDID As String = ""
            Dim CFPROID As String = ""

            Call clsAuth.UserLogin(CSDID, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, "",
                                                "", Image1.ImageUrl, "", False, "", False)

            LabelCFPROID.Text = CFPROID

            Dim PDFProgressReport As String = ""

            If Not Request.QueryString("pdfprogressreport") Is Nothing Then
                PDFProgressReport = clsEncr.DecryptString(Request.QueryString("pdfprogressreport"))
            End If


            iFrame1.Attributes("src") = PDFProgressReport
            iframe1.Attributes("style") = "height:" & 650 & "px; width:" & 1196 & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub




End Class