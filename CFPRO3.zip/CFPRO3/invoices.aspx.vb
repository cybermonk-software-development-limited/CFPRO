﻿Public Class invoices
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim Usertype As String = Request.QueryString("usertype")
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""



            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID

            Dim ClientID As String = Request.QueryString("clientid")

            Call LoadJobStatus(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadCompanies()
            Call LoadSendInvoiceAlert(CFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If



    End Sub



    Private Sub LoadInvoices(CFPROID As String)

        Try

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = " And Jobs.JobDate >= '" & TextFromDate.Text & "' " &
                  " And Jobs.Jobdate <= '" & TextToDate.Text & "' "
            Else

                tmpstr = " And ID > 0 "
            End If


            Select Case ComboLoadedJobs.Text
                Case "Open Jobs"
                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "
                Case "All Jobs"

                    tmpstr = tmpstr

                Case "Closed Jobs"
                    tmpstr = tmpstr &
                                " And Jobs.JobStatus Like '%Closed%' "

                Case "Jobs Kept Visible"
                    tmpstr = " (" & tmpstr &
                       "Or  Jobs.KeepVisible = 1) "

            End Select

            Dim sqlstr As String =
                "Select Top " & ComboSelectTop.Text & " " &
                "JobID,Jobs.ClientID, Client,  " &
                "JobTypeID,BL,ReferenceNo, " &
                "ReferenceNo1, JobStatus," &
                "JobDate,Jobs.ID  " &
                "From Jobs,Clients " &
                "Where Jobs.ClientID = Clients.ClientID " &
                "And Jobs.CFPROID = '" & CFPROID & "' " &
                "And Clients.CFPROID  = '" & CFPROID & "' " &
                 tmpstr &
                "Order by Jobs.ID Desc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
                "SELECT InvoiceID, JobInvoiceHeader.JobID," &
                "JobInvoiceHeader.InvoiceNo, " &
                "InvoiceDate, CurrencyID, Cost, Total," &
                "Paid, Balance, SubTotal," &
                "ApplyVAT, VATinclusive," &
                "InvoiceHeader, InvoiceSendDate," &
                "VATAmount, JobInvoiceHeader.PDFInvoiceName," &
                "CurrencyRate, InvoicetypeID, " &
                "JobInvoiceHeader.CFPROID " &
                "From  Jobs, JobInvoiceHeader " &
                "Where JobInvoiceHeader.JobID = Jobs.JobID   " &
                "And JobInvoiceHeader.CFPROID  = '" & CFPROID & "' " &
                 tmpstr &
                 "Order by JobInvoiceHeader.ID Desc;"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim sqlstr2 As String =
              "Select CurrencyID, CurrencyCode " &
              "FROM Currencies "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            Dim col1 As New DataColumn("InvoiceDet", Type.GetType("System.String"))
            Dim col2 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col3 As New DataColumn("CurrencyCode", Type.GetType("System.String"))
            Dim col4 As New DataColumn("InvoiceEnabled", Type.GetType("System.Boolean"))



            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)

            Dim a, b, c As Integer
            Dim drow, drow1 As DataRow
            Dim col As DataColumn

            Dim dv1 As New DataView(tmptable1)
            b = tmptable.Rows.Count - 1

            For a = 0 To tmptable1.Columns.Count - 1
                col = tmptable1.Columns(a)
                If Not col.ColumnName = "ID" And Not col.ColumnName = "JobID" Then
                    col = New DataColumn(col.ColumnName, col.DataType)
                    tmptable.Columns.Add(col)
                End If
            Next

            For a = 0 To b

                drow = tmptable.Rows(a)
                drow1 = tmptable.Rows(a)
                dv1.RowFilter = "JobID = '" & drow("JobID") & "' "

                For c = 0 To dv1.Count - 1
                    If c = 0 Then
                        For Each col In tmptable1.Columns
                            If Not col.ColumnName = "ID" Then
                                drow1(col.ColumnName) = dv1(0)(col.ColumnName)
                            End If
                        Next
                    Else
                        drow1 = tmptable.NewRow
                        For Each col In tmptable.Columns
                            drow1(col.ColumnName) = drow(col.ColumnName)
                        Next
                        For Each col In tmptable1.Columns
                            If Not col.ColumnName = "ID" Then
                                drow1(col.ColumnName) = dv1(0)(col.ColumnName)
                            End If
                        Next
                        tmptable.Rows.Add(drow1)
                    End If
                Next


            Next

            a = 0
            Dim dv2 As New DataView(tmptable2)
            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                    If drow("InvoiceID") = "" Then
                        drow("InvoiceID") = "Not Invoiced"
                        drow("InvoiceNo") = "Not Invoiced"
                        drow("InvoiceEnabled") = CBool(0)
                    Else
                        drow("InvoiceEnabled") = CBool(1)
                    End If

                    drow("InvoiceDet") = "jobid=" & drow("JobID") & "&invoiceid=" & drow("InvoiceID")

                    dv2.RowFilter = "CurrencyID = '" & drow("CurrencyID") & "' "

                    If dv2.Count > 0 Then
                        Call clsData.NullChecker1(dv2, 0)
                        drow("CurrencyCode") = dv2(0)("CurrencyCode")
                    End If
                    a = a + 1
                Next
            End If


            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Invoices"
                tmptable.Rows.Add(drow)
            End If


            Session("JobInvoices") = tmptable

            Dim dv As New DataView(tmptable)
            Call CalcTotal(dv, "")

            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()

            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "InvoiceDate" Then
                dv.Sort = "InvoiceDate " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort


            End If

            LabelFilterStr.Text = dv.RowFilter
            LabelSortStr.Text = dv.Sort

            GridInvoices.DataSource = dv
            GridInvoices.DataBind()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadJobStatus(CFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus " &
       "Where CFPROID = '" & CFPROID & "' "

        ComboJobStatus.Items.Clear()
        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select ItemDescription,ItemID " &
         "From KPIProgress "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr1, clsData.constr, 0, 1)

        ComboJobStatus.Items.Insert(0, "(All)")
        ComboJobStatus.Items(ComboJobStatus.Items.Count - 1).Value = "0"
    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Private Sub LoadCompanies()
        Try
            ComboInvoiceCompany.Items.Clear()

            Dim CFAgentName As String = ""
            Dim CFPROID As String = ""
            Call clsAuth.AuthCFAgent(CFPROID, CFAgentName, "", "", "", "", False)

            If CFAgentName.Length > 25 Then
                CFAgentName = Trim(Mid(CFAgentName, 1, 25))
            End If

            ComboInvoiceCompany.Items.Add(CFAgentName)
            ComboInvoiceCompany.Items(0).Value = CFPROID

            Dim sqlstr As String =
                      "SELECT  CompanyID," &
                      "CompanyName, DynamicsNAVUrl," &
                      "CFPROID,ID " &
                      "FROM  Companies " &
                      "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim a As Integer = 1
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a - 1)
                    ComboInvoiceCompany.Items.Add(drow("CompanyName"))
                    ComboInvoiceCompany.Items(a).Value = (drow("CompanyID"))
                    a = a + 1
                Next
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try

    End Sub

    Private Sub CalcTotal(dv As DataView, tmpcaption As String)
        Try


            Dim a As Integer
            Dim Cost, Amount, TotalTax, Total, Paid, Balance As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Cost = Cost + dv(a)("Cost")
                Amount = Amount + dv(a)("SubTotal")
                TotalTax = TotalTax + dv(a)("VATAmount")
                Total = Total + dv(a)("Total")

                Paid = Paid + dv(a)("Paid")
                Balance = Balance + dv(a)("Balance")

            Next

            TextTotalCost.Text = Format(Cost, "#,##0.00")
            TextSubTotal.Text = Format(Amount, "#,##0.00")
            TextTotalTax.Text = Format(TotalTax, "#,##0.00")
            TextTotal.Text = Format(Total, "#,##0.00")

            TextPaid.Text = Format(Paid, "#,##0.00")
            TextBalance.Text = Format(Balance, "#,##0.00")


            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            End If

            If tmpcaption = "" Then
                LabelReportCaption.Text = dv.Count & " Jobs : " & " | " & tmpstr
            Else
                LabelReportCaption.Text = dv.Count & " Jobs : " & " " & tmpcaption & " | " & tmpstr
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub


    Protected Sub LinkButton5_Click(sender As Object, e As EventArgs)

        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim tmpstr As String = linkbutton.CommandArgument.ToString

        Call LoadDialog("invoice.aspx?" & tmpstr, "Job Invoice", 665, 980)

    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl


        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender1.Y = 40
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender1.Y = 100
        Else
            ModalPopupExtender1.Y = -1
        End If


        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadInvoices(LabelCFPROID.Text)
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckClient.Checked = True


        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub



    Private Sub PreDefine(ByVal Selection As String, CFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadInvoices(CFPROID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetCurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2



                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadInvoices(CFPROID)


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckClient.Checked, CheckInvoiceStatus.Checked, CheckConsignee.Checked,
                                 CheckJobType.Checked, CheckJobStatus.Checked, CheckDispatched.Checked,
                                  LabelMessage1.Text)
    End Sub

    Private Sub CompoundFilter(client As Boolean, invoicestatus As Boolean, consignee As Boolean,
                              jobType As Boolean, jobstatus As Boolean, dispatched As Boolean,
                             Optional ByRef ErrMsg As String = "")
        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer


            If IsNothing(Session("JobInvoices")) Then
                Call LoadInvoices(LabelCFPROID.Text)
            End If

            Dim tmptable As DataTable = Session("JobInvoices")

            Dim dv As New DataView(tmptable)
            'dv.Sort = Nothing
            'dv.RowFilter = Nothing



            If client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "ClientID = '" & Trim(LabelClientID.Text) & "' "
                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If invoicestatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)

                If ComboInvoiceStatus.SelectedItem.Text = "With Invoice" Then
                    If b = 0 Then
                        tmpstr(a) = "InvoiceID <> 'Not Invoiced' "
                    Else
                        tmpstr(a) = " And InvoiceID <> 'Not Invoiced' "
                    End If

                ElseIf ComboInvoiceStatus.SelectedItem.Text = "Without Invoice" Then
                    If b = 0 Then
                        tmpstr(a) = "InvoiceID = 'Not Invoiced' "
                    Else
                        tmpstr(a) = " And InvoiceID = 'Not Invoiced' "
                    End If

                End If

                tmpstr1(a) = "Invoice Status: " & UCase(ComboInvoiceStatus.Text)
                b = b + 1
            End If

            If consignee Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ImporterID = '" & Trim(LabelImporterID.Text) & "' "
                Else
                    tmpstr(a) = " And ImporterID = '" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                b = b + 1
            End If

            If jobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                b = b + 1
            End If



            If jobstatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus Like '%" & Trim(ComboJobStatus.Text) & "%' "
                Else
                    tmpstr(a) = " And JobStatus Like '%" & Trim(ComboJobStatus.Text) & "%' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.Text
                b = b + 1
            End If


            If dispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus Like '%Dispatch%' "
                Else
                    tmpstr(a) = " And JobStatus Like '%Dispatch%' "
                End If

                tmpstr1(a) = "Dispatched: " & CBool(dispatched)
                b = b + 1
            End If



            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2

            GridInvoices.DataSource = dv
            GridInvoices.DataBind()


            LabelFilterStr.Text = tmpstr2
            LabelReportCaption.Text = dv.Count & " Invoices"


            Call CalcTotal(dv, tmpstr3)

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelFilters.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub
    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExportToExcel()
    End Sub

    Private Sub ExportToExcel()

        Dim totals(5) As String


        totals(0) = "Sub Total: " & TextSubTotal.Text
        totals(1) = "Total Tax: " & TextTotalTax.Text
        totals(2) = "Total Amount : " & TextTotal.Text
        totals(3) = "Total Paid : " & TextPaid.Text
        totals(4) = "Total Balance : " & TextBalance.Text
        totals(5) = "Total Cost : " & TextTotalCost.Text

        Dim tmpfields(11) As String
        tmpfields(0) = "ReferenceNo"
        tmpfields(1) = "Client"
        tmpfields(2) = "JobDate"
        tmpfields(3) = "InvoiceNo"
        tmpfields(4) = "CurrencyCode"
        tmpfields(5) = "InvoiceDate"
        tmpfields(6) = "Cost"
        tmpfields(7) = "SubTotal"
        tmpfields(8) = "VATAmount"
        tmpfields(9) = "Total"
        tmpfields(10) = "Paid"
        tmpfields(11) = "Balance"


        Dim tmpfields1(11) As String
        tmpfields1(0) = "ReferenceNo"
        tmpfields1(1) = "Client"
        tmpfields1(2) = "Job Date"
        tmpfields1(3) = "InvoiceNo"
        tmpfields1(4) = "Currency"
        tmpfields1(5) = "Invoice Date"
        tmpfields1(6) = "Cost"
        tmpfields1(7) = "SubTotal"
        tmpfields1(8) = "VATAmount"
        tmpfields1(9) = "Total"
        tmpfields1(10) = "Paid"
        tmpfields1(11) = "Balance"


        Dim tmptable As DataTable = Session("JobInvoices")


        Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Invoice Items", "Invoice Items",
                                             LabelReportCaption.Text, True, totals, 0, "", tmpfields, tmpfields1, tmptable, False)

    End Sub


    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)


        If dv Is Nothing Then

            If IsNothing(Session("JobInvoices")) Then
                Call LoadInvoices(LabelCFPROID.Text)
            End If

            Dim JobsTable As DataTable = Session("JobInvoices")
            dv = New DataView(JobsTable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()

        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "InvoiceDate" Then
            dv.Sort = "InvoiceDate " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridInvoices.DataSource = dv
            GridInvoices.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call CalcTotal(dv, "")
        End If

    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "InvoiceDate"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "JobID"
        Else
            Return "JobDate"
        End If
    End Function

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("JobInvoices")) Then
            Call LoadInvoices(LabelCFPROID.Text)
        End If

        Dim tmptable As DataTable = Session("JobInvoices")
        Dim dv As DataView = New DataView(tmptable)

        dv.RowFilter = " (ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%') "

        GridInvoices.DataSource = dv
        GridInvoices.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching " & " " & Trim(SearchStr)

        Call CalcTotal(dv, tmpstr)

    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadInvoices(LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call ClearFilters()
        Call LoadInvoices(LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub LinkButton6_Click(sender As Object, e As EventArgs)

    End Sub


    Private Sub LoadSendInvoiceAlert(CFPROID As String)


        Dim sqlstr As String =
                  "Select SendInvoiceAlerts, ID " &
                  "From CFPROAccounts " &
                  "Where CFPROID = '" & CFPROID & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            CheckSendInvoiceAlerts.Checked = drow("SendInvoiceAlerts")
        End If

    End Sub

    Protected Sub CheckSendInvoiceAlerts_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSendInvoiceAlerts.CheckedChanged
        Call SaveSendInvoiceAlert(LabelCFPROID.Text)
    End Sub


    Private Sub SaveSendInvoiceAlert(CFPROID As String)

        Dim sqlstr As String =
                  "Select SendInvoiceAlerts, ID " &
                  "From CFPROAccounts " &
                  "Where CFPROID = '" & CFPROID & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            drow("SendInvoiceAlerts") = CheckSendInvoiceAlerts.Checked

            Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, False, clsData.constr)
        End If

    End Sub
End Class

