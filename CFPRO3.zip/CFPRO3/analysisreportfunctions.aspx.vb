﻿
Imports System.Net
Imports System.Drawing
Public Class analysisreportfunctions
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLoggedIn("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub

    Protected Sub LinkInvoiceSettings_Click(sender As Object, e As EventArgs) Handles LinkInvoiceSettings.Click
        If clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00006") Then
            Response.Redirect("invoicesettings.aspx")
        Else
            LabelMessage.Text = "User Not Allowed."
            LabelMessage.ForeColor = Color.Red
        End If
    End Sub
End Class