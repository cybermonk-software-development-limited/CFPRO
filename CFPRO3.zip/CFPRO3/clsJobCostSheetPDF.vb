﻿


Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf


Public Class clsJobCostSheetPDF


    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x2, 595 - y2)
        contentByte.SetLineWidth(0.001)
        contentByte.SetRGBColorStroke(0, 0, 0)
        contentByte.Stroke()
    End Sub

    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - y1)
        contentByte.LineTo(x1 + width, 595 - (y1 + height))
        contentByte.LineTo(x1, 595 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 595 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Private Shared Sub DrawParagraph(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single,
                                                                                           ByRef contentByte As PdfContentByte, ByVal align As String)

        x1 = x1 * 0.75
        y1 = y1 * 0.75

        Dim x2 = (x1 * 0.75) + 500
        Dim y2 = (y1 * 0.75) + 200

        Dim fnt As Single = font.Size * 0.75
        Dim ct As New ColumnText(contentByte)


        If align = "right" Then
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_RIGHT)

        ElseIf align = "center" Then
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_CENTER)

        Else
            ct.SetSimpleColumn(x1, y2, x2, 600 - y1, 0.8, Element.ALIGN_LEFT)
        End If


        ct.AddElement(New Paragraph(nString, font))
        ct.Go()
    End Sub



    Shared Function CreateJobCostSheet(CFPROID As String, InvoiceID As String, JobID As String,
                                                   CompanyID As String, PrintedBy As String, Optional ErrMSg As String = Nothing) As String
        Try



            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeui.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\segoeuib.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"
            Dim fontpath5 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\calibrib.ttf"
            Dim fontpath6 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\calibri.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb1 As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath5, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontk As BaseFont = BaseFont.CreateFont(fontpath6, BaseFont.CP1252, BaseFont.EMBEDDED)

            Dim font6b As New Font(customfontb, 6)
            Dim font4b As New Font(customfontb, 4)
            Dim font7b As New Font(customfontb, 8)
            Dim font7b1 As New Font(customfontb1, 7)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfont, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            Dim font11c As New Font(customfontc, 10.5)
            Dim font10 As New Font(customfontc, 10)
            Dim font11 As New Font(customfontk, 11)
            Dim font7k As New Font(customfontk, 8)
            Dim font10b As New Font(customfontb, 10)
            Dim font16a As New Font(customfont, 16)
            Dim font16b As New Font(customfontb, 16)
            Dim font14b As New Font(customfontb, 20)
            Dim font22b As New Font(customfontb, 24)
            Dim font13b As New Font(customfontb, 13)
            Dim font13 As New Font(customfont, 13)
            Dim font9c As New Font(customfontb, 9)
            Dim font36b As New Font(customfontb, 36)
            Dim font8c As New Font(customfontc, 8)
            Dim font7c As New Font(customfontc, 7)
            Dim font11b As New Font(customfontb, 11)
            Dim font20b As New Font(customfontb, 20)
            Dim font5b As New Font(customfontb, 5)
            Dim font17b As New Font(customfontb, 17)

            Dim drf As New Drawing.StringFormat()

            Dim brush1 As Drawing.Color = Drawing.Color.FromArgb(61, 61, 61)
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
            Dim FontMark As Font
            Dim Mark As String
            FontMark = New Font(customfontm, 14)
            Mark = "P"

            'Dim brush1 As Drawing.Color = Drawing.Color.FromArgb(61, 61, 61)
            'Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)


            Dim pencolor As Drawing.Color = Drawing.Color.FromArgb(200, 200, 200)


            Dim sqlstr As String =
                             "Select CFAgentName,CFAgentAddress,LogoURL,ID " &
                             "From CFPROAccounts " &
                             "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmptable1 As DataTable = CostSheetHeader(CFPROID, InvoiceID, JobID)


            Dim drow1 As DataRow
            If tmptable1.Rows.Count > 0 Then
                drow1 = tmptable1.Rows(0)
                Dim tmptable2 As DataTable = CostSheetItems(CFPROID, InvoiceID, JobID, drow1("CurrencyID"))

                Dim JobCostSheetPDF As New Document(PageSize.A4, 0, 0, 0, 10)
                Using memoryStream As New System.IO.MemoryStream()


                    Dim PDFwriter As PdfWriter = PdfWriter.GetInstance(JobCostSheetPDF, memoryStream)
                    JobCostSheetPDF.Open()
                    Dim pen As PdfContentByte = PDFwriter.DirectContent
                    Dim pen1 As PdfContentByte = PDFwriter.DirectContent
                    Dim pen2 As PdfContentByte = PDFwriter.DirectContent
                    Dim StringWriter As PdfContentByte = PDFwriter.DirectContent




                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    Dim logopath As String = ""
                    Dim cfagentlogo As String

                    Dim files() As String = Directory.GetFiles(HttpContext.Current.Server.MapPath(".") & "\cfagentimages\")
                    Dim nfile As String = ""


                    For Each nfile In files
                        cfagentlogo = Path.GetFileName(nfile)
                        If InStr(cfagentlogo, CFPROID, CompareMethod.Text) > 0 Then
                            logopath = nfile
                            Exit For
                        End If
                    Next


                    If logopath = "" Then
                        logopath = HttpContext.Current.Server.MapPath(".") & "\companyplaceholder.png"
                    End If

                    Dim logo As Image = Image.GetInstance(logopath)

                    logo.ScaleToFit(65, 65)
                    logo.SetAbsolutePosition(50, 735)
                    JobCostSheetPDF.Add(logo)



                    DrawString(drow("CFAgentName"), font14b, Drawing.Color.FromArgb(21, 21, 21), 170, -265, StringWriter)


                    Dim ct1 As New ColumnText(StringWriter)
                    ct1.SetSimpleColumn(128, 775, 350, -230)
                    ct1.AddElement(New Paragraph(drow("CFAgentAddress"), font7b))
                    ct1.Go()



                    DrawString("Job Cost Sheet", font22b, Drawing.Color.FromArgb(31, 31, 31), 70, -152, StringWriter)

                    DrawLine(pen, 60, -118, 735, -118)
                    DrawLine(pen, 60, -58, 735, -58)
                    DrawLine(pen, 60, -98, 735, -98)
                    DrawLine(pen, 60, -78, 735, -78)
                    DrawLine(pen, 60, -118, 60, -58)
                    DrawLine(pen, 165, -118, 165, -58)
                    DrawLine(pen, 415, -118, 415, -58)
                    DrawLine(pen, 490, -118, 490, -58)
                    DrawLine(pen, 735, -118, 735, -58)




                    DrawString("Client:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -113, StringWriter)
                    DrawString(drow1("Client"), font8b, Drawing.Color.FromArgb(21, 21, 21), 170, -113, StringWriter)

                    DrawString("Telephone:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -93, StringWriter)
                    DrawString(drow1("Telephone"), font8b, Drawing.Color.FromArgb(21, 21, 21), 170, -93, StringWriter)

                    DrawString("Email:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -73, StringWriter)
                    DrawString(drow1("Email"), font8b, Drawing.Color.FromArgb(21, 21, 21), 170, -73, StringWriter)

                    DrawString("Job ID:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, -113, StringWriter)
                    DrawString(drow1("JobID"), font8b, Drawing.Color.FromArgb(21, 21, 21), 495, -113, StringWriter)

                    DrawString("Reference No:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, -93, StringWriter)
                    DrawString(drow1("ReferenceNo"), font8b, Drawing.Color.FromArgb(21, 21, 21), 495, -93, StringWriter)

                    DrawString("Job Date:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, -73, StringWriter)
                    DrawString(Format(drow1("JobDate"), "dd MMM yyyy"), font8b, Drawing.Color.FromArgb(21, 21, 21), 495, -73, StringWriter)

                    DrawLine(pen, 60, 30, 735, 30)
                    DrawLine(pen, 60, 450, 735, 450)
                    DrawLine(pen, 60, 30, 60, 450)
                    DrawLine(pen, 735, 30, 735, 450)

                    DrawLine(pen, 90, 30, 90, 450)
                    DrawLine(pen, 255, 30, 255, 450)
                    DrawLine(pen, 305, 30, 305, 430)

                    DrawLine(pen, 415, 30, 415, 450)
                    DrawLine(pen, 490, 30, 490, 450)
                    DrawLine(pen, 555, 30, 555, 450)
                    DrawLine(pen, 635, 30, 635, 450)
                    DrawLine(pen, 690, 30, 690, 450)
                    DrawLine(pen, 60, 50, 735, 50)
                    DrawLine(pen, 350, 30, 350, 430)
                    DrawLine(pen, 60, 430, 735, 430)
                    DrawLine(pen, 60, -30, 735, -30)
                    DrawLine(pen, 60, -11, 735, -11)
                    DrawLine(pen, 60, 9, 735, 9)
                    DrawLine(pen, 60, -30, 60, 9)
                    DrawLine(pen, 735, -30, 735, 9)
                    DrawLine(pen, 415, -30, 415, 9)
                    DrawLine(pen, 490, -30, 490, 9)
                    DrawLine(pen, 165, -30, 165, 9)
                    DrawString("Users:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -42, StringWriter)
                    DrawString("Sales Person:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -25, StringWriter)
                    DrawString(clsSubs.GetSaleman(CFPROID, drow1("SalesmanID")), font8b, Drawing.Color.FromArgb(21, 21, 21), 170, -25, StringWriter)

                    DrawString("Job Type:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, -8, StringWriter)
                    DrawString(clsGetIdentities.SetJobType(drow1("JobTypeID"), CFPROID), font8b, Drawing.Color.FromArgb(21, 21, 21), 170, -8, StringWriter)


                    DrawString("Quotation:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, -25, StringWriter)
                    DrawString("Invoice Curr:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, -8, StringWriter)

                    Dim tmpstr() As String = clsAccounts.GetCurrencyNameandCode(drow1("CurrencyID"))
                    DrawString(UCase(tmpstr(1)), font8b, Drawing.Color.FromArgb(21, 21, 21), 495, -8, StringWriter)

                    DrawString("Item & Vendor", font7b, Drawing.Color.FromArgb(21, 21, 21), 95, 35, StringWriter)

                    Dim a As Integer
                    For Each drow2 In tmptable2.Rows
                        DrawString(a + 1 & ".", font7k, Drawing.Color.FromArgb(21, 21, 21), 65, (a * 35) + 68, StringWriter)

                        DrawParagraph(drow2("Item") & vbCrLf & drow2("Vendor"), font7, Drawing.Color.FromArgb(21, 21, 21), 95, (a * 35) + 68, StringWriter, "left")
                        DrawParagraph(Mid(drow2("UOC"), 1, 8), font7, Drawing.Color.FromArgb(21, 21, 21), 258, (a * 35) + 68, StringWriter, "left")
                        DrawParagraph(drow2("Quantity"), font7, Drawing.Color.FromArgb(21, 21, 21), 313, (a * 35) + 68, StringWriter, "left")
                        DrawParagraph(Format(drow2("Costrate"), "#,#0.00") & vbCrLf & drow2("Currency"), font7, Drawing.Color.FromArgb(21, 21, 21), 355, (a * 35) + 68, StringWriter, "right")
                        DrawParagraph(Format(drow2("Cost"), "#,#0.00") & vbCrLf & drow2("VendorInvoiceNo"), font7b1, Drawing.Color.FromArgb(21, 21, 21), 420, (a * 35) + 68, StringWriter, "right")
                        DrawParagraph(Format(drow2("SaleRate"), "#,#0.00"), font7, Drawing.Color.FromArgb(21, 21, 21), 495, (a * 35) + 68, StringWriter, "right")
                        DrawParagraph(Format(drow2("Amount"), "#,#0.00"), font7b1, Drawing.Color.FromArgb(21, 21, 21), 560, (a * 35) + 68, StringWriter, "right")
                        DrawParagraph(Format(drow2("ProfitPercent"), "#,#0.00"), font7, Drawing.Color.FromArgb(21, 21, 21), 640, (a * 35) + 68, StringWriter, "right")
                        DrawParagraph(Format(drow2("TaxPercent"), "#,#0.00"), font7, Drawing.Color.FromArgb(21, 21, 21), 695, (a * 35) + 68, StringWriter, "right")
                        If a >= 10 Then
                            Exit For
                        End If
                        a = a + 1
                    Next


                    DrawString("U.O.C", font7b, Drawing.Color.FromArgb(21, 21, 21), 260, 35, StringWriter)
                    DrawString("Qty", font7b, Drawing.Color.FromArgb(21, 21, 21), 310, 35, StringWriter)
                    DrawString("Cost/unit", font7b, Drawing.Color.FromArgb(21, 21, 21), 355, 35, StringWriter)
                    DrawString("Cost", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 35, StringWriter)
                    DrawString("Sale/Unit", font7b, Drawing.Color.FromArgb(21, 21, 21), 495, 35, StringWriter)
                    DrawString("Sale", font7b, Drawing.Color.FromArgb(21, 21, 21), 560, 35, StringWriter)
                    DrawString("Profit%", font7b, Drawing.Color.FromArgb(21, 21, 21), 640, 35, StringWriter)
                    DrawString("Tax %", font7b, Drawing.Color.FromArgb(21, 21, 21), 695, 35, StringWriter)
                    DrawString("Net amount due:", font7b, Drawing.Color.FromArgb(21, 21, 21), 260, 435, StringWriter)

                    Dim tmpstr1() As String = CalcTotals(tmptable2, ErrMSg)
                    DrawString(tmpstr1(0), font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 435, StringWriter)
                    DrawString(tmpstr1(1), font7b, Drawing.Color.FromArgb(21, 21, 21), 560, 435, StringWriter)
                    ' DrawString(tmpstr1(3), font7b, Drawing.Color.FromArgb(21, 21, 21), 650, 435, StringWriter)

                    DrawLine(pen, 60, 470, 735, 470)
                    DrawLine(pen, 60, 490, 735, 490)
                    DrawLine(pen, 60, 510, 735, 510)
                    DrawLine(pen, 60, 530, 735, 530)
                    DrawLine(pen, 60, 470, 60, 530)
                    DrawLine(pen, 735, 470, 735, 530)
                    DrawLine(pen, 165, 470, 165, 530)
                    DrawLine(pen, 255, 470, 255, 530)
                    DrawLine(pen, 360, 470, 360, 530)
                    DrawLine(pen, 415, 470, 415, 530)
                    DrawLine(pen, 555, 470, 555, 530)
                    DrawLine(pen, 635, 470, 635, 530)

                    DrawString("Credit Note Amount:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 475, StringWriter)
                    DrawString("Debit Note Amount:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 495, StringWriter)

                    DrawString("PURCHASE TOTAL:", font7b, Drawing.Color.FromArgb(21, 21, 21), 465, 495, StringWriter)
                    DrawString(tmpstr1(0), font7b, Drawing.Color.FromArgb(21, 21, 21), 560, 495, StringWriter)

                    DrawString("SALES TOTAL:", font7b, Drawing.Color.FromArgb(21, 21, 21), 485, 475, StringWriter)
                    DrawString(tmpstr1(1), font7b, Drawing.Color.FromArgb(21, 21, 21), 560, 475, StringWriter)


                    DrawString("PROFIT/LOSS %", font7b, Drawing.Color.FromArgb(21, 21, 21), 465, 515, StringWriter)
                    DrawString(tmpstr1(3) & " %", font7b, Drawing.Color.FromArgb(21, 21, 21), 560, 515, StringWriter)


                    DrawString("Total VAT Purchase:", font7b, Drawing.Color.FromArgb(21, 21, 21), 260, 495, StringWriter)
                    DrawString(tmpstr1(4), font7b, Drawing.Color.FromArgb(21, 21, 21), 365, 495, StringWriter)

                    DrawString("Total VAT Sales:", font7b, Drawing.Color.FromArgb(21, 21, 21), 260, 475, StringWriter)
                    DrawString(tmpstr1(5), font7b, Drawing.Color.FromArgb(21, 21, 21), 365, 475, StringWriter)



                    DrawLine(pen, 60, 550, 735, 550)
                    DrawLine(pen, 60, 570, 735, 570)
                    DrawLine(pen, 60, 590, 735, 590)
                    DrawLine(pen, 60, 610, 735, 610)
                    DrawLine(pen, 60, 630, 735, 630)
                    DrawLine(pen, 60, 550, 60, 630)
                    DrawLine(pen, 735, 550, 735, 630)
                    DrawLine(pen, 165, 550, 165, 630)
                    DrawLine(pen, 415, 550, 415, 630)
                    DrawLine(pen, 490, 550, 490, 630)

                    DrawString("Chargeable Weight:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 555, StringWriter)
                    DrawString("Weight:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 575, StringWriter)
                    DrawString("CBM:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 595, StringWriter)
                    DrawString("No of Containers:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 615, StringWriter)

                    Dim tmpstr2() As String = CargoTotals(CFPROID, JobID)
                    DrawString(tmpstr2(0), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 555, StringWriter)
                    DrawString(tmpstr2(0), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 575, StringWriter)
                    DrawString(tmpstr2(1), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 595, StringWriter)
                    DrawString(tmpstr2(2), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 615, StringWriter)

                    DrawString("From:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 555, StringWriter)
                    DrawString(UCase(drow1("BLCountry")), font7b, Drawing.Color.FromArgb(21, 21, 21), 495, 555, StringWriter)

                    DrawString("To:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 575, StringWriter)
                    DrawString(UCase(drow1("Destination")), font7b, Drawing.Color.FromArgb(21, 21, 21), 495, 575, StringWriter)

                    DrawString("Qty:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 595, StringWriter)
                    DrawString(tmpstr2(2), font7b, Drawing.Color.FromArgb(21, 21, 21), 495, 595, StringWriter)

                    DrawLine(pen, 60, 650, 735, 650)
                    DrawLine(pen, 60, 670, 735, 670)
                    DrawLine(pen, 60, 690, 735, 690)
                    DrawLine(pen, 60, 710, 735, 710)
                    DrawLine(pen, 60, 730, 735, 730)
                    DrawLine(pen, 60, 750, 735, 750)
                    DrawLine(pen, 60, 650, 60, 750)
                    DrawLine(pen, 735, 650, 735, 750)
                    DrawLine(pen, 165, 650, 165, 750)
                    DrawLine(pen, 415, 650, 415, 750)
                    DrawLine(pen, 490, 650, 490, 750)

                    DrawString("Invoice No:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 655, StringWriter)
                    DrawString(drow1("InvoiceNo"), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 655, StringWriter)

                    DrawString("Prepared By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 675, StringWriter)
                    DrawString(clsSubs.GetCFAgentUser(CFPROID, drow1("PreparedByID")), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 675, StringWriter)

                    DrawString("Reviewed By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 695, StringWriter)
                    DrawString(clsSubs.GetCFAgentUser(CFPROID, drow1("ReviewedByID")), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 695, StringWriter)

                    DrawString("Approved By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 715, StringWriter)
                    DrawString(clsSubs.GetCFAgentUser(CFPROID, drow1("ReviewedByID")), font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 715, StringWriter)



                    DrawString("Printed By:", font7b, Drawing.Color.FromArgb(21, 21, 21), 65, 735, StringWriter)
                    DrawString(PrintedBy, font7b, Drawing.Color.FromArgb(21, 21, 21), 170, 735, StringWriter)

                    DrawString("Invoice Date:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 655, StringWriter)
                    DrawString(Format(drow1("InvoiceDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 500, 655, StringWriter)

                    DrawString("Date Prepared: ", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 675, StringWriter)
                    DrawString(Format(drow1("PreparedByDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 500, 675, StringWriter)

                    DrawString("Date Reviewed:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 695, StringWriter)
                    DrawString(Format(drow1("ReviewedByDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 500, 695, StringWriter)

                    DrawString("Date Approved:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 715, StringWriter)
                    DrawString(Format(drow1("ReviewedByDate"), "dd MMM yyyy"), font7b, Drawing.Color.FromArgb(21, 21, 21), 500, 715, StringWriter)

                    DrawString("Printed On:", font7b, Drawing.Color.FromArgb(21, 21, 21), 420, 735, StringWriter)
                    DrawString(Format(Now, "dd MMM yyyy hh:mm tt"), font7b, Drawing.Color.FromArgb(21, 21, 21), 500, 735, StringWriter)


                    JobCostSheetPDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")
                    JobCostSheetPDF.Close()

                    Dim bytes As Byte() = memoryStream.ToArray()



                    Dim JobCostSheetPath As String = HttpContext.Current.Server.MapPath(".") & "\jobcostsheets"

                    If Not Directory.Exists(JobCostSheetPath) Then
                        Directory.CreateDirectory(JobCostSheetPath)
                    End If

                    If Not Directory.Exists(JobCostSheetPath & "\" & CFPROID) Then
                        Directory.CreateDirectory(JobCostSheetPath & "\" & CFPROID)
                    End If

                    If Not Directory.Exists(JobCostSheetPath & "\" & CFPROID & "\" & JobID) Then
                        Directory.CreateDirectory(JobCostSheetPath & "\" & CFPROID & "\" & JobID)
                    End If


                    Dim nJobCostSheetPDF As String = JobCostSheetPath & "\" & CFPROID & "\" & JobID & "\JobCostSheet" & InvoiceID & ".pdf"


                    If File.Exists(nJobCostSheetPDF) Then
                        File.Delete(nJobCostSheetPDF)
                    End If


                    ' Write out PDF from memory stream.

                    Using fs As FileStream = File.Create(nJobCostSheetPDF)
                        fs.Write(bytes, 0, CInt(bytes.Length))
                        fs.Close()
                    End Using

                    memoryStream.Close()

                    Return "~/jobcostsheets/" & CFPROID & "/" & JobID & "/JobCostSheet" & InvoiceID & ".pdf"
                End Using

            Else
                Return "~/jobcostsheets/JobCostSheet.pdf"
            End If

        Catch ex As Exception
            ErrMSg = ex.Message & ex.StackTrace
        End Try
    End Function

    Shared Function CostSheetHeader(CFPROID As String, InvoiceID As String, JobID As String, Optional ByRef ErrMsg As String = Nothing) As DataTable
        Try
            Dim sqlstr As String =
                "Select JobInvoiceHeader.JobID, CompanyID," &
                "JobTypeID,InvoiceID,Jobs.ClientID,Client," &
                "Telephone, Email,JobDate," &
                "JobInvoiceHeader.InvoiceNo,  " &
                "JobInvoiceHeader.InvoiceDate," &
                "CostSheetDate,Cost, Total, " &
                "Paid, Balance, SubTotal, " &
                "JobInvoiceHeader.VAT, ApplyVAT," &
                "VATinclusive, UserID," &
                "CurrencyID, InvoiceHeader," &
                 "BLCountry,Destination," &
                "InvoiceDueDate, VATAmount," &
                "CurrencyRate,ReferenceNo," &
                "PreparedByID,ReviewedByID,SalesmanID," &
                "PreparedByDate,ReviewedByDate," &
                "InvoicetypeID, JobInvoiceHeader.ID " &
                "FROM JobInvoiceHeader,Jobs,Clients " &
                "Where InvoiceID ='" & InvoiceID & "' " &
                "And JobInvoiceHeader.JobID ='" & JobID & "' " &
                "And Jobs.JobID ='" & JobID & "' " &
                "And JobInvoiceHeader.CFPROID ='" & CFPROID & "' " &
                "And Jobs.CFPROID ='" & CFPROID & "' " &
                "And Clients.ClientID = Jobs.ClientID " &
                "And Clients.CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
            End If

            Return tmptable

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function

    Shared Function CostSheetItems(CFPROID As String, InvoiceID As String,
                                                JobID As String, CurrencyID As String, Optional ByRef ErrMsg As String = Nothing) As DataTable
        Try

            Dim sqlstr As String =
                "SELECT JobInvoiceItems.ItemID," &
                "Item,UOC, Cost," &
                "CostRate, CurrencyID,ExchangeRate," &
                "SaleRate,Quantity, JobInvoiceItems.Amount," &
                "JobInvoiceItems.ApplyTax," &
                "JobInvoiceItems.TaxPercent,ProfitPercent," &
                "TaxAmount,VendorInvoiceNo, JobInvoiceItems.TaxType," &
                "Total, InvoiceID, " &
                "VendorID,VendorType,JobInvoiceItems.ID  " &
                "FROM  InvoiceItems, JobInvoiceItems " &
                "Where InvoiceID = '" & InvoiceID & "' " &
                "And JobInvoiceItems.JobID = '" & JobID & "' " &
                "And JobInvoiceItems.CFPROID = '" & CFPROID & "' " &
                "And InvoiceItems.CFPROID ='" & CFPROID & "' " &
                "And JobInvoiceItems.ItemID = InvoiceItems.ItemID " &
                "And JobInvoiceItems.CFPROID = InvoiceItems.CFPROID " &
                "Order By JobInvoiceItems.ID Asc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("Vendor", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Currency", Type.GetType("System.String"))
            Dim col2 As New DataColumn("TaxAmount1", Type.GetType("System.Double"))


            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)


            Dim a As Integer
            Dim drow As DataRow
            Dim tmpstr() As String

            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    If Not drow("VendorID") = "" Then
                        drow("Vendor") = clsSubs.GetVendor(CFPROID, drow("VendorID"), drow("VendorType"))
                    Else
                        drow("Vendor") = "Vendor not set"
                    End If

                    If Not drow("VendorInvoiceNo") = "" Then
                        drow("VendorInvoiceNo") = "Inv. " & drow("VendorInvoiceNo")
                    End If



                    If Not drow("CurrencyID") = "" Then
                        tmpstr = clsAccounts.CurrencyRateandCode(CFPROID, drow("CurrencyID"))
                        drow("Currency") = tmpstr(1) & " @ " & tmpstr(0)
                    End If

                    drow("Cost") = drow("CostRate") * drow("Quantity")
                    drow("Amount") = drow("SaleRate") * drow("Quantity")

                    If drow("CurrencyID") <> CurrencyID Then
                        drow("Cost") = drow("Cost") * drow("ExchangeRate")
                    End If

                    If drow("Cost") = 0 Then
                        drow("Cost") = 0.001
                    End If


                    If drow("ApplyTax") Then
                        drow("TaxAmount") = drow("Amount") * (drow("TaxPercent") / 100)
                        drow("TaxAmount1") = drow("Cost") * (drow("TaxPercent") / 100)
                    Else
                        drow("TaxAmount") = 0
                        drow("TaxAmount1") = 0
                    End If


                    drow("ProfitPercent") = (drow("Amount") - drow("Cost"))
                    drow("ProfitPercent") = drow("ProfitPercent") / drow("Cost")
                    drow("ProfitPercent") = drow("ProfitPercent") * 100

                    a = a + 1

                Next
            End If



            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Item") = "Invoice Items Not Set"
                tmptable.Rows.Add(drow)
            End If

            Return tmptable

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Function


    Shared Function CalcTotals(tmptable As DataTable, Optional ByRef ErrMsg As String = Nothing) As String()
        Try
            Dim a As Integer
            Dim Cost, Amount, ProfitLoss, TaxAmount1, TaxAmount As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                Cost = Cost + drow("Cost")
                Amount = Amount + drow("Amount")

                TaxAmount1 = TaxAmount1 + drow("TaxAmount1")
                TaxAmount = TaxAmount + drow("TaxAmount")

                a = a + 1

            Next
            ProfitLoss = Amount - Cost

            If Cost = 0 Then
                Cost = 0.001
            End If

            Dim tmpstr(5) As String

            tmpstr(0) = Format(Cost, "#,##0.00")
            tmpstr(1) = Format(Amount, "#,##0.00")
            tmpstr(2) = Format(ProfitLoss, "#,##0.00")
            tmpstr(3) = Format((ProfitLoss / Cost) * 100, "#,##0.00")
            tmpstr(4) = Format(TaxAmount1, "#,##0.00")
            tmpstr(5) = Format(TaxAmount, "#,##0.00")

            Return tmpstr
        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try

    End Function


    Shared Function CargoTotals(CFPROID As String, JobID As String) As String()
        Dim sqlstr As String = "SELECT Weight,CBM,ID " &
                                "From  JobCargo " &
                                "Where CFPROID = '" & CFPROID & "' " &
                                "And JobID = '" & JobID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim a As Integer
        Dim Weight, CBM As Double

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            Weight = Weight + drow("Weight")
            CBM = CBM + drow("CBM")
            a = a + 1
        Next

        Dim tmpstr(2) As String
        tmpstr(0) = Format(Weight, "#,##0.00")
        tmpstr(1) = Format(CBM, "#,##0.00")
        tmpstr(2) = Format(a, "#,##0")

        Return tmpstr

    End Function
End Class





