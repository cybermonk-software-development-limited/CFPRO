﻿
Imports System.Net.Mail
Public Class clsMessaging

    Friend Shared tmpUserCSDID As String
    Friend Shared TableMessageRecipents As New DataTable

    Shared Function EmailServerOK(ByRef EmailServer, ByRef EmailPort, ByRef EnableSsl, ByRef DefaulEmailto, ByRef Password) As Boolean

        Dim sqlstr As String = _
            "Select EmailServer, Port, " & _
            "EnableSSL,DefaultEmailTo," & _
            "Password, ID	" & _
            "From  EmailServer "

        Dim tmptable As New DataTable()
        Call clsData.Tabledata(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            EmailServer = drow("EmailServer")
            EmailPort = drow("Port")
            EnableSsl = drow("EnableSSL")
            DefaulEmailto = drow("DefaultEmailTo")
            Password = drow("Password")
            Return True

        Else
            Return False
        End If


    End Function




    Shared Function GetEmails(Purpose As String) As String()

        Dim tmpstr(3) As String


        Dim sqlstr As String = _
            "Select EmailUser, EmailAddress," & _
            "UserName,Password, ID	" & _
            "From  EmailAddresses " & _
            "Where Purpose ='" & Purpose & "' "

        Dim tmptable As New DataTable
        Call clsData.Tabledata(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            tmpstr(0) = drow("EmailUser")
            tmpstr(1) = drow("EmailAddress")
            tmpstr(2) = drow("UserName")
            tmpstr(3) = drow("Password")
            Return tmpstr
        Else
            tmpstr(0) = "-"
            tmpstr(1) = "-"
            tmpstr(2) = "-"
            tmpstr(3) = "-"
            Return tmpstr
        End If

    End Function

    Shared Function SendEmail(eFrom As String, eTo As String, eSubject As String, eBody As String, _
                       eUser As String, ePassword As String, EmailSender As String) As Boolean


        Dim EmailServer As String = ""
        Dim EmailPort As String = ""
        Dim EnableSsl As String = ""
        Dim DefaulEmailto As String = ""
        Dim Password As String = ""

        If EmailServerOK(EmailServer, EmailPort, EnableSsl, DefaulEmailto, Password) Then

            If eTo = "" Then
                eTo = DefaulEmailto
                ePassword = Password
            End If

            If Not EmailSender = "" Then
                eFrom = EmailSender & "<" & eFrom & ">"
            End If

            Dim nMailmessage As New MailMessage(eFrom, eTo)
            nMailmessage.Subject = eSubject
            nMailmessage.Body = eBody

            Dim nSmtpClient As New SmtpClient
            nSmtpClient.Host = EmailServer
            nSmtpClient.Port = EmailPort
            nSmtpClient.EnableSsl = EnableSsl
            nSmtpClient.Credentials = New System.Net.NetworkCredential(eTo, ePassword)

            nMailmessage.IsBodyHtml = False
            nSmtpClient.Send(nMailmessage)

            Return True
        Else

            Return False
        End If


    End Function


    Shared Sub NewMessage(HeaderID As String, SubjectID As String, MessageID As String, UserSubject As String, Message As String, CFPROID As String, SenderCSDID As String, _
                             SenderUserID As String, HasAttachment As Boolean, AttachmentFolder As String, Usertype As String, ByRef sendresult As String)
        Try


            Dim sqlstr As String = _
                  "SELECT HeaderID,HeaderType," & _
                  "LastMessageDate,CFPROID," & _
                  "SenderEmailAddress, ID " & _
                  "From  MessageHeaders " & _
                  "Where HeaderID  = '" & HeaderID & "' " & _
                  "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim HeaderType As String = "JobID"

            If HeaderID = "" Then
                HeaderID = MessageID
                HeaderType = "PublicID"
            End If

            Dim Messagedate As String = Format(Now, "dd MMM yyyy hh:mm:ss tt")

            Dim Drow As DataRow
            If tmptable.Rows.Count = 0 Then
                Drow = tmptable.NewRow
                Drow("CFPROID") = CFPROID
                Drow("HeaderID") = HeaderID
                Drow("HeaderType") = HeaderType
                Drow("LastMessageDate") = Messagedate
                tmptable.Rows.Add(Drow)
            Else
                Drow = tmptable.Rows(0)
                Drow("HeaderID") = HeaderID
                Drow("HeaderType") = HeaderType
                Drow("LastMessageDate") = Messagedate
            End If

            Call clsData.SaveData("MessageHeaders", tmptable, sqlstr, False, clsData.constr)



            Dim sqlstr1 As String = _
              "SELECT MessageID,JobID,MessageDate,  " & _
              "UserSubject,SubjectID," & _
              "Message, HasAttachment," & _
              "CFPROID,AttachmentFolder,ID  " & _
              "FROM Messages " & _
              "Where MessageID = '" & MessageID & "' " & _
              "And CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim drow1 As DataRow
            If tmptable1.Rows.Count = 0 Then
                drow1 = tmptable1.NewRow
                drow1("MessageID") = MessageID
                drow1("Message") = Message
                drow1("MessageDate") = Messagedate
                drow1("HeaderID") = HeaderID
                drow1("SubjectID") = SubjectID
                drow1("UserSubject") = UserSubject
                drow1("HasAttachment") = HasAttachment
                drow1("CFPROID") = CFPROID
                drow1("AttachmentFolder") = AttachmentFolder
                tmptable1.Rows.Add(drow1)

            End If
            Call clsData.SaveData("Messages", tmptable1, sqlstr1, False, clsData.constr)

            Dim sqlstr2 As String = _
             "SELECT MessageID, JobID, UserID,  " & _
             "IsRead, Direction, UserType," & _
             "CFPROID,EmailAddress, ID  " & _
             "FROM  MessageUserIDs " & _
             "Where MessageID ='" & MessageID & "' " & _
             "And CFPROID = '" & CFPROID & "' "


            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            drow1 = tmptable2.NewRow
            drow1("MessageID") = MessageID
            drow1("UserID") = SenderUserID
            drow1("UserCSDID") = SenderCSDID
            drow1("Direction") = "In"
            drow1("HeaderID") = HeaderID
            drow1("CFPROID") = CFPROID
            drow1("UserType") = Usertype
            drow1("IsRead") = 1
            tmptable2.Rows.Add(drow1)

            For Each Drow In TableMessageRecipents.Rows
                drow1 = tmptable2.NewRow
                drow1("MessageID") = MessageID
                drow1("UserCSDID") = Drow("UserCSDID")
                drow1("CFPROUserID") = Drow("CFPROUserID")
                drow1("UserType") = Drow("UserType")
                drow1("EmailAddress") = Drow("EmailAddress")
                drow1("Direction") = "Out"
                drow1("HeaderID") = HeaderID
                drow1("CFPROID") = CFPROID

                drow1("IsRead") = 0
                tmptable2.Rows.Add(drow1)
            Next

            Call clsData.SaveData("MessageUserIDs", tmptable2, sqlstr2, False, clsData.constr)

            sendresult = "sent"

        Catch exp As Exception
            sendresult = "notsent"
        Finally
            HttpContext.Current.Response.Redirect("sendmessage.aspx?sendresult=" & sendresult)
        End Try

    End Sub
    

    Shared Function MessageIDUsed(MessageID As String) As Boolean
        Try

            Dim sqlstr As String = _
             "Select MessageID  " & _
             "From Messages " & _
             "Where MessageID = '" & MessageID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Return True
            Else
                Return False
            End If

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "MessageIDExist")
        End Try
    End Function


   

   
  


End Class
