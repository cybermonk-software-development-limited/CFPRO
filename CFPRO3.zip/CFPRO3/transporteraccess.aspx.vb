﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Public Class transporteraccess
    Inherits System.Web.UI.Page
    Implements IPostBackEventHandler

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If clsData.constr = "" Then
            clsData.constr = clsEncr.constr
        End If

        If Not IsPostBack Then


            'Dim imgurl As String = ""
            Dim CFAgentCFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFAgentCFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True)

            LabelCFAgentCFPROID.Text = CFAgentCFPROID
            LabelCFPROUserID.Text = CFPROUserID

            Call LoadTransporterCargo(CFPROUserID, CFAgentCFPROID)

            Call LoadClients()

            ButtonExportToExcel.Attributes("onclick") = ClientScript.GetPostBackEventReference(Me, "ClickDiv")

        End If

    End Sub
    Private Sub LoadClients()
        Dim sqlstr As String =
        "Select Client From Clients " &
        "Order By Client Asc;"
        ComboClients.Items.Add("(All)")
        Call clsData.PopCombo(ComboClients, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadTransporterCargo(transporterId As String, CFAgentCFPROID As String)

        Dim cargoindex As Integer = GridTransporterCargo.SelectedIndex

        Dim sqlstr As String =
           "Select TOP 200 JobCargo.JobId,ContainerNo,Payload," &
           "JobCargo.TEU, JobCargo.Weight,JobCargo.CBM," &
           "VehicleNo,Clients.Client,Transporter," &
           "JobCargo.PortExitDate, JobCargo.CrossBorderDate, " &
           "JobCargo.ReturnDate,InterchangeNo,CFS,BL," &
           "ContainerStatus, JobCargo.RemainingDays, JobCargo.ID " &
           "From JobCargo,Jobs,Clients " &
           "Where JobCargo.JobID = Jobs.JobID " &
           "And Jobs.ClientID = Clients.ClientID Order By JobId Desc;"

        '"Where TransporterID = '" & transporterId & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col As New DataColumn("EditCargo", Type.GetType("System.String"))
        Dim col1 As New DataColumn("MoreCargoDetails", Type.GetType("System.String"))
        Dim col2 As New DataColumn("PortExitDate1", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)

        Dim a As Integer
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            drow("EditCargo") = "addeditcargo.aspx?jobcargoid=" & drow("ID")
            drow("MoreCargoDetails") = "addeditcargo.aspx?jobcargoid=" & drow("ID")

            If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
            Else
                drow("PortExitDate1") = "-"
            End If

            a = a + 1
        Next

        Call clsShippingStorage.SetRemainingDays(tmptable, drow("JobId"), LabelCFAgentCFPROID.Text, LabelMessage1.Text)
        LabelTransporterGridCaption.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "


        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Payload") = ""
            tmptable.Rows.Add(drow)
        End If

        If tmptable.Rows.Count > 5 Then
            PanelTransporterCargo.Height = 500
        Else
            GridTransporterCargo.Height = 20 + (tmptable.Rows.Count * 24)
            PanelTransporterCargo.Height = Nothing
        End If
        'TextGoods.Text = drow("Goods")

        GridTransporterCargo.DataSource = tmptable
        GridTransporterCargo.DataBind()

        If GridTransporterCargo.Rows.Count > 0 Then
            If cargoindex >= 0 And cargoindex <= GridTransporterCargo.Rows.Count - 1 Then


                GridTransporterCargo.SelectedIndex = cargoindex
                Dim row As GridViewRow = GridTransporterCargo.Rows(cargoindex)
                row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
            End If
            GridTransporterCargo.SelectedIndex = 0
            Dim row1 As GridViewRow = GridTransporterCargo.Rows(GridTransporterCargo.SelectedIndex)
            row1.BackColor = ColorTranslator.FromHtml("#FFE9B9")
            Call GetDescriptionOfGoods(GridTransporterCargo.SelectedValue)
        End If
        Call Calctotal(tmptable, "")
    End Sub
    Private Sub AddEditCargoItem(Edit As Boolean, CargoID As String)
        Try


            TextPortExitDate.Text = ""
            TextCrossBorderDate.Text = ""
            TextDestinationArrivalDate.Text = ""
            TextContainerReturnDate.Text = ""

            If Edit Then
                LabelCargoEdit.Text = "Edit"
                LabelCargoAddEditStatus.Text = "Edit Cargo Item"
            Else
                LabelCargoEdit.Text = "Add"
                LabelCargoAddEditStatus.Text = "Add Cargo Item"
                ' TextPortExitDate.Text = "1-Jan-1800"
            End If

            If CargoID = "" Then
                CargoID = "-1"
            End If

            If Edit Then

                Dim sqlstr1 As String =
                    "Select PortExitDate,CrossBorderDate," &
                    "ReturnDate,InterchangeNo," &
                    "DestinationArrivalDate,ID " &
                    "From JobCargo " &
                    "Where ID = " & CInt(CargoID) & " "


                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
                If tmptable1.Rows.Count > 0 Then
                    clsData.NullChecker(tmptable1, 0)

                    Dim drow As DataRow = tmptable1.Rows(0)

                    If drow("CrossBorderDate").ToString("dd-MMM-yyyy") = "01-Jan-1800" Then
                        TextCrossBorderDate.Text = ""
                    Else
                        TextCrossBorderDate.Text = Format(drow("CrossBorderDate"), "dd-MMM-yyyy")
                    End If

                    If drow("DestinationArrivalDate").ToString("dd-MMM-yyyy") = "01-Jan-1800" Then
                        TextDestinationArrivalDate.Text = ""
                    Else
                        TextDestinationArrivalDate.Text = Format(drow("DestinationArrivalDate"), "dd-MMM-yyyy")
                    End If

                    If drow("ReturnDate").ToString("dd-MMM-yyyy") = "01-Jan-1800" Then
                        TextContainerReturnDate.Text = ""
                    Else
                        TextContainerReturnDate.Text = Format(drow("ReturnDate"), "dd-MMM-yyyy")
                    End If

                    If drow("PortExitDate").ToString("dd-MMM-yyyy") = "01-Jan-1800" Then
                        TextPortExitDate.Text = ""
                    Else
                        TextPortExitDate.Text = Format(drow("PortExitDate"), "dd-MMM-yyyy")
                    End If

                    If Not IsDBNull(drow("InterchangeNo")) Then
                        If drow("InterchangeNo") = "" Then
                            LinkInterchangeDoc.Text = "No Interchange"
                        Else
                            LinkInterchangeDoc.Text = "Interchange: " & drow("InterchangeNo")
                        End If
                    Else
                        LinkInterchangeDoc.Text = "No Interchange"
                    End If
                End If
            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

        ModalPopupExtender2.Show()
    End Sub
    Protected Sub OnRowDataBound2(sender As Object, e As GridViewRowEventArgs) Handles GridTransporterCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridTransporterCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub



    Protected Sub OnSelectedIndexChanged2(sender As Object, e As EventArgs) Handles GridTransporterCargo.SelectedIndexChanged
        Dim row As GridViewRow = GridTransporterCargo.Rows(GridTransporterCargo.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridTransporterCargo.Rows.Count - 1
            row = GridTransporterCargo.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridTransporterCargo.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                Else
                    Call GetDescriptionOfGoods(GridTransporterCargo.SelectedValue)
                End If
            End If
        Next

    End Sub

    Private Sub GetDescriptionOfGoods(jobId As String)
        Dim sqlstr As String = "Select Goods " &
            "From Jobs " &
            "Where JobId = '" & jobId & "'"
        Dim tmptbl As New DataTable
        Call clsData.TableData(sqlstr, tmptbl, clsData.constr)
        If tmptbl.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptbl, 0)
            Dim drow As DataRow = tmptbl.Rows(0)
            TextGoods.Text = drow("Goods")
        End If
    End Sub

    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try

            Dim dv As DataView = tmptable.DefaultView
            Dim a As Integer
            Dim TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                'Qty = Qty + dv(a)("Quantity")
                Weight = Weight + CDbl(dv(a)("Weight"))
                CBM = CBM + CDbl(dv(a)("CBM"))

            Next

            'TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextTotalWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCBM.Text = Format(CBM, "#,##0.00")
            'TextTotalTeu.Text = Format(TEU, "#,##0.00")

            'Dim tmpstr As String


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Protected Sub ButtonEditCargo_Click(sender As Object, e As EventArgs) Handles ButtonEditCargo.Click
        Call AddEditCargoItem(True, GridTransporterCargo.SelectedValue.ToString())
    End Sub

    Protected Sub ButtonSaveCargo_Click(sender As Object, e As EventArgs) Handles ButtonSaveCargo.Click
        Call SaveCargoDates()
    End Sub

    Private Sub SaveCargoDates()

        Try
            Dim CargoID As String

            If LabelCargoEdit.Text = "Add" Then
                CargoID = "-1"
            Else
                CargoID = GridTransporterCargo.SelectedValue.ToString()
            End If

            Dim sqlstr As String =
             "Select PortExitDate,CrossBorderDate," &
                    "ReturnDate,InterchangeNo," &
                    "DestinationArrivalDate,ID " &
                    "From JobCargo " &
                    "Where ID = " & CInt(CargoID) & " "

            Dim isdelete As Boolean = False
            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow

            If LabelCargoEdit.Text = "Add" Then
                drow = tmptable.NewRow
                'drow("JobID") = ComboJobID.Text
                tmptable.Rows.Add(drow)

            ElseIf LabelCargoEdit.Text = "Edit" Then
                drow = tmptable.Rows(0)

            ElseIf LabelCargoEdit.Text = "Delete" Then
                drow = tmptable.Rows(0)
                drow.Delete()
                isdelete = True
                GoTo deleted
            End If

            If IsDate(Trim(TextPortExitDate.Text)) Then
                drow("PortExitDate") = Trim(TextPortExitDate.Text)
            End If

            If IsDate(Trim(TextCrossBorderDate.Text)) Then
                drow("CrossBorderDate") = Trim(TextCrossBorderDate.Text)
            End If

            If IsDate(Trim(TextContainerReturnDate.Text)) Then
                drow("ReturnDate") = Trim(TextContainerReturnDate.Text)
            End If

            If IsDate(Trim(TextDestinationArrivalDate.Text)) Then
                drow("DestinationArrivalDate") = Trim(TextDestinationArrivalDate.Text)
            End If

deleted:

            Call clsData.SaveData("JobCargo", tmptable, sqlstr, isdelete, clsData.constr)
            Call LoadTransporterCargo(LabelCFPROUserID.Text, LabelCFAgentCFPROID.Text)
            LabelMessage1.Text = "success editing"
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call FilterItem(TextSearch.Text)
    End Sub

    Private Sub FilterItem(ByVal Item As String)
        Try
            Dim cargoindex As Integer = GridTransporterCargo.SelectedIndex

            Dim sqlstr As String =
           "Select TOP 200 JobCargo.JobId,ContainerNo,Payload," &
           "JobCargo.TEU, JobCargo.Weight,JobCargo.CBM," &
           "VehicleNo,Clients.Client,Transporter," &
           "JobCargo.PortExitDate, JobCargo.CrossBorderDate, " &
           "JobCargo.ReturnDate,InterchangeNo,CFS,BL," &
           "ContainerStatus, JobCargo.RemainingDays,T812No, JobCargo.ID " &
           "From JobCargo,Jobs,Clients " &
           "Where JobCargo.JobID = Jobs.JobID " &
           "And Jobs.ClientID = Clients.ClientID Order By JobId Desc;"

            '"Where TransporterID = '" & transporterId & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("EditCargo", Type.GetType("System.String"))
            Dim col1 As New DataColumn("MoreCargoDetails", Type.GetType("System.String"))
            Dim col2 As New DataColumn("PortExitDate1", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)

            Dim a As Integer
            Dim drow As DataRow

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("EditCargo") = "addeditcargo.aspx?jobcargoid=" & drow("ID")
                drow("MoreCargoDetails") = "addeditcargo.aspx?jobcargoid=" & drow("ID")

                If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                    drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
                Else
                    drow("PortExitDate1") = "-"
                End If

                a = a + 1
            Next

            Call clsShippingStorage.SetRemainingDays(tmptable, drow("JobId"), LabelCFAgentCFPROID.Text, LabelMessage1.Text)
            LabelTransporterGridCaption.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "


            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Payload") = ""
                tmptable.Rows.Add(drow)
            End If

            If tmptable.Rows.Count > 5 Then
                PanelTransporterCargo.Height = 500
            Else
                GridTransporterCargo.Height = 20 + (tmptable.Rows.Count * 24)
                PanelTransporterCargo.Height = Nothing
            End If
            'TextGoods.Text = drow("Goods")

            Dim dv As DataView = tmptable.AsDataView

            If Item = "" Then
                dv.RowFilter = Nothing
            Else
                dv.RowFilter = "ContainerNo Like  '" & "%" & Item & "%" & "' " &
                    "Or Client Like '" & "%" & Item & "%" & "' " &
                    "Or VehicleNo Like '" & "%" & Item & "%" & "' " &
                    "Or T812No Like '" & "%" & Item & "%" & "' "
            End If
            LabelTransporterGridCaption.Text = "Container / Cargo & Transport Search : " & dv.Count & "  Items "
            GridTransporterCargo.DataSource = dv
            GridTransporterCargo.DataBind()

            If GridTransporterCargo.Rows.Count > 0 Then
                If cargoindex >= 0 And cargoindex <= GridTransporterCargo.Rows.Count - 1 Then


                    GridTransporterCargo.SelectedIndex = cargoindex
                    Dim row As GridViewRow = GridTransporterCargo.Rows(cargoindex)
                    row.BackColor = ColorTranslator.FromHtml("#FFF4DD")
                End If
                GridTransporterCargo.SelectedIndex = 0
                Dim row1 As GridViewRow = GridTransporterCargo.Rows(GridTransporterCargo.SelectedIndex)
                row1.BackColor = ColorTranslator.FromHtml("#FFE9B9")
                Call GetDescriptionOfGoods(GridTransporterCargo.SelectedValue)
            End If
            Call Calctotal(tmptable, "")




        Catch exp As Exception
            MsgBox(exp.Message, , "FilterItems")
        End Try
    End Sub
    Protected Sub ButtonExportToExcel_Click()
        Call ExportToExcel()
    End Sub

    Private Sub ExportToExcel()

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = GridTransporterCargo.Columns.Count
        Dim totalRows = GridTransporterCargo.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = GridTransporterCargo.Columns(col1 - 2).HeaderText
        Next

        workSheet.Cells("B3:M3").Merge = True
        workSheet.Cells("B4:M4").Merge = True

        workSheet.Cells("B3:M3").Style.Font.Size = 14
        workSheet.Cells("B4:M4").Style.Font.Size = 9
        workSheet.Cells("B3:M4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = LabelCFAgent.Text & " - Transporter Cargo"
        workSheet.Cells(4, 2).Value = LabelTransporterGridCaption.Text

        Dim row1 As GridViewRow
        Dim row As Integer
        For row = 5 To totalRows + 4
            row1 = GridTransporterCargo.Rows(row - 5)
            For col1 As Integer = 1 To totalCols
                workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1 - 1).Text
                If row1.Cells(col1 - 1).Text = "&nbsp;" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next


        Next

        Using rng As ExcelRange = workSheet.Cells("B5:M" & GridTransporterCargo.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:M5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":M" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        'workSheet.Cells("C" & row & ":D" & row).Merge = True
        'workSheet.Cells("E" & row & ":F" & row).Merge = True
        'workSheet.Cells("G" & row & ":I" & row).Merge = True
        'workSheet.Cells("J" & row & ":K" & row).Merge = True

        'workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        'workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        'workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        'workSheet.Cells("J" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Transporter Cargo " & Format(Now, "dd-MMM-yyyy hh:mm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub

    Public Sub RaisePostBackEvent(eventArgument As String) Implements IPostBackEventHandler.RaisePostBackEvent
        If Not String.IsNullOrEmpty(eventArgument) Then

            If eventArgument = "ClickDiv" Then
                Call ButtonExportToExcel_Click()
            End If
        End If
    End Sub
End Class