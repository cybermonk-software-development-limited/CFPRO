﻿
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.Net
Imports System.Globalization


Public Class clsSubs
    Friend Shared TableValueWords As New DataTable()
    Friend Shared randomkey As New System.Random()


    Shared Function GetRandomNo() As String
        Randomize()
        Return Format(randomkey.Next(1, 99), "0#") '
    End Function

    Shared Function GeneratePassword() As String
        Randomize()
        Return Format(randomkey.Next(1, 9999999), "0000000#") '
    End Function

    Shared Function CleanSql(tmpstr As String) As Boolean
        Dim tmpstr1(14) As String
        tmpstr1(0) = "'"
        tmpstr1(1) = "like"
        tmpstr1(2) = "%"
        tmpstr1(3) = "["
        tmpstr1(4) = "]"
        tmpstr1(5) = "<"
        tmpstr1(6) = ">"
        tmpstr1(7) = "="
        tmpstr1(8) = "--"
        tmpstr1(9) = "&"
        tmpstr1(10) = "_"
        tmpstr1(11) = ";"
        tmpstr1(12) = "drop"
        tmpstr1(13) = "insert"
        tmpstr1(14) = "update"

        Dim a As Integer
        For a = 0 To tmpstr1.GetUpperBound(0)
            If InStr(tmpstr, tmpstr1(a), CompareMethod.Text) > 0 Then
                Return False
            End If
        Next
        Return True
    End Function


    Shared Function AmountInWords(ByVal Amount As String) As String
        Try
            If TableValueWords.Rows.Count = 0 Then
                Dim sqlstr As String =
                "Select Amount,Word From AmountInWords"
                TableValueWords.Clear()
                Call clsData.TableData(sqlstr, TableValueWords, clsData.constr)
            End If
            Dim Drow As DataRow

            Amount = Format(CDbl(Val(Amount)), "###,###,###.#0")

            Dim tmpstr() As String = Amount.Split(",")

            Dim a, b, c, d, e, f, m, x As Integer
            Dim Wordstr(0) As String

            Dim tmpamount As String

            b = tmpstr.GetUpperBound(0)
            f = tmpstr.GetUpperBound(0)
            Dim tmpcent() As String

            tmpcent = tmpstr(f).Split(".")
            tmpstr(f) = tmpcent(0)

            ReDim Preserve tmpstr(f + 1)
            tmpstr(f + 1) = tmpcent(1)
            m = 0

            Wordstr(0) = ""
            x = x + 1

            For a = 0 To f + 1
                d = Len(tmpstr(a))

                For e = 1 To d

                    tmpamount = ""

                    If d = 3 Then
                        If e = 1 Then
                            tmpamount = Mid(tmpstr(a), 1, 1)
                        End If

                        If Val(Mid(tmpstr(a), 2, 1)) = 1 Then
                            If e = 2 Then
                                tmpamount = Mid(tmpstr(a), 2)
                            End If
                        Else
                            If e = 2 Then
                                tmpamount = Mid(tmpstr(a), 2, 1) & "0"
                            ElseIf e = 3 Then
                                tmpamount = Mid(tmpstr(a), 3, 1)
                            End If
                        End If

                    ElseIf d = 2 Then

                        If Val(Mid(tmpstr(a), 1, 1)) = 1 Then
                            If e = 1 Then
                                tmpamount = tmpstr(a)
                            End If
                        Else
                            If e = 1 Then
                                tmpamount = Mid(tmpstr(a), 1, 1) & "0"
                            ElseIf e = 2 Then
                                tmpamount = Mid(tmpstr(a), 2, 1)
                            End If
                        End If

                    ElseIf d = 1 Then
                        tmpamount = tmpstr(a)
                    End If

                    Dim found As Boolean
                    For Each Drow In TableValueWords.Rows
                        found = False
                        If Trim(tmpamount) = Trim(Drow("Amount")) Then
                            If IsDBNull(Drow("Word")) Then
                                Drow("Word") = ""
                            End If
                            found = True
                            Exit For
                        End If
                    Next

                    If found Then
                        If Not Trim(Drow("Word")) = "" Then
                            ReDim Preserve Wordstr(x)
                            Wordstr(x) = Drow("Word")
                            x = x + 1
                        End If

                        If d = 3 Then
                            If e = 1 Then
                                If Not tmpamount = "0" Then
                                    ReDim Preserve Wordstr(x)
                                    Wordstr(x) = "Hundred"
                                    x = x + 1

                                    If Not Val(Mid(tmpstr(a), 2, 1)) = 0 Then
                                        ReDim Preserve Wordstr(x)
                                        Wordstr(x) = "and"
                                        x = x + 1
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next

                If a <= f Then

                    c = 0
                    m = 0
                    For c = 0 To b
                        m = m + Len(tmpstr(c))
                    Next

                    If m > 3 Then
                        For Each Drow In TableValueWords.Rows
                            If Val(tmpstr(a)) = 0 Then
                                GoTo skip
                            End If
                            If Len(Drow("Amount")) > 3 Then
                                If m >= Len(Drow("Amount")) Then
                                    ReDim Preserve Wordstr(x)
                                    Wordstr(x) = Drow("Word")
                                    x = x + 1
                                    Exit For
                                End If
                            End If
skip:
                        Next
                    End If

                    If a = f - 1 Then

                        If Mid(tmpstr(f), 1, 1) = 0 Then
                            If Not Val(tmpstr(f)) = 0 Then
                                ReDim Preserve Wordstr(x)
                                Wordstr(x) = "and"
                                x = x + 1
                            End If
                        End If
                    End If
                    b = b - 1

                    If a = f Then
                        Dim tmpval As String
                        tmpval = Format(CDbl(Amount), "######")
                        If Not Val(tmpval) = 0 Then
                            If Not Val(tmpstr(f + 1)) = 0 Then
                                ReDim Preserve Wordstr(x)
                                Wordstr(x) = "and"
                                x = x + 1
                            End If
                        End If
                    End If
                Else
                    If Not Val(tmpstr(a)) = 0 Then
                        ReDim Preserve Wordstr(x)
                        Wordstr(x) = "Cents"
                        x = x + 1
                    End If
                End If
            Next

            If Val(Amount) = 0 Then
                ReDim Preserve Wordstr(x)
                Wordstr(x) = "Zero"
                x = x + 1
            End If

            ReDim Preserve Wordstr(x)
            Wordstr(x) = "Only."

            Return Trim(Join(Wordstr, " "))

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "AmountInWords")
        End Try

    End Function


    Shared Function Capitalise(ByVal TextStr As String) As String

        If Trim(LCase(TextStr)) = "n/a" Then
            Capitalise = LCase(TextStr)
            Exit Function
        End If

        Dim a(0), b, c As String
        Dim d As Single
        a = Split(TextStr, " ", -1)

        For d = 0 To a.GetUpperBound(0)
            a(d) = Trim(a(d))
            b = UCase(Mid(a(d), 1, 1))
            c = LCase(Mid(a(d), 2))
            a(d) = b & c
        Next

        Return Join(a, " ")

    End Function






    Shared Function GetRecordID(TableName As String, RecordIDField As String, CSDID As String) As Integer

        Dim sqlstr As String =
            "Select COUNT(" & RecordIDField & ") AS NextId " &
            "From " & TableName & " " &
            "Where CSDID = '" & CSDID & "' "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            Dim RecordID As Integer = drow(RecordIDField) + 1

            drow(RecordIDField) = RecordID

            Call clsData.SaveData(TableName, tmptable, sqlstr, False, clsData.constr)

            Return RecordID
        Else
            Return 0
        End If

    End Function


    Shared Function ResponseMessage(ResponseID As String) As String
        If CleanSql(ResponseID) Then
            Dim sqlstr As String =
                           "Select ResponseID,Response," &
                           "ProceedResponse,ProceedURL,ID " &
                           "From Responses " &
                           "Where ResponseID= '" & ResponseID & "' "

            Dim tmptable As New DataTable
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                Return drow("Response") & ";" & drow("ProceedResponse") & ";" & drow("ProceedURL")
            Else
                Return "Unknown Response ; ; "
            End If
        Else
            Return "Unknown Response ; ; "
        End If
    End Function





    Shared Function GetUserDetails(CSDID As String) As String()

        Dim tmpstr(3) As String
        tmpstr(0) = ""
        tmpstr(1) = "someone@example.com"
        tmpstr(2) = "0700000000"
        tmpstr(3) = ""


        Dim sqlstr As String =
            "Select CSDID, UserNames," &
            "EmailAddress, Telephone, Town " &
            "From UserAccounts " &
            "Where CSDID ='" & CSDID & "'"

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            tmpstr(0) = drow("UserNames")
            tmpstr(1) = drow("EmailAddress")
            tmpstr(2) = drow("Telephone")
            tmpstr(3) = drow("Town")
        End If


        Return tmpstr

    End Function




    Shared Function SelectedClients() As Array
        Dim sqlstr As String =
                 "Select  Client,ID " &
                 "From SelectedClients " &
                 "Order By ID Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        Dim drow As DataRow

        Dim tmpstr(0) As String

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            ReDim Preserve tmpstr(a)
            tmpstr(a) = Trim(drow("Client"))
            a = a + 1
        Next

        Return tmpstr

    End Function

    Shared Function SelectedAgents() As Array
        Dim sqlstr As String =
                 "Select  Agent,ID " &
                 "From SelectedAgents " &
                 "Order By ID Asc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer
        Dim drow As DataRow

        Dim tmpstr(0) As String

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)
            ReDim Preserve tmpstr(a)
            tmpstr(a) = Trim(drow("Agent"))
            a = a + 1
        Next

        Return tmpstr

    End Function





    Shared Sub SetLastReturnDate(JobID As String, GridJobCargo As DataGrid)

        Dim sqlstr As String =
               "Select  JobId,ReturnDate,Id " &
               "From Jobs " &
               "Where JobId ='" & JobID & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)

            Dim dv As DataView = GridJobCargo.DataSource

            dv.RowFilter = "JobID = '" & JobID & "'"

            Dim tmpdate As Date
            If dv.Count > 0 Then
                dv.Sort = "ReturnDate DESC"
                tmpdate = dv(0)("ReturnDate")
                dv.Sort = "ID ASC"
            Else
                tmpdate = "1-Jan-1800"
            End If

            drow("Returndate") = tmpdate
            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            dv.Sort = Nothing
            dv.RowFilter = Nothing
        End If

    End Sub

    Shared Sub SetLastCrossBorderDate(JobID As String, GridJobCargo As DataGrid)
        Dim sqlstr As String =
               "Select  JobId,CrossBorderDate,Id " &
               "From Jobs " &
               "Where JobId ='" & JobID & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)

            Dim dv As DataView = GridJobCargo.DataSource
            dv.RowFilter = "JobID =" & "'" & JobID & "'"

            Dim tmpdate As Date
            If dv.Count > 0 Then
                dv.Sort = "CrossBorderDate DESC"
                tmpdate = dv(0)("CrossBorderDate")
                dv.Sort = "ID ASC"
            Else
                tmpdate = "1-Jan-1800"
            End If

            dv.RowFilter = Nothing

            drow("CrossBorderDate") = tmpdate
            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            dv.Sort = Nothing
        End If
    End Sub


    Shared Function SetDispatchedStatus(JobId As String, GridJobCargo As DataGrid, sqlstr1 As String) As String()

        Dim sqlstr As String =
                        "Select  JobId,JobStatus,LastSlingDate," &
                                 "DispatchDate,CloseDate,Id " &
                                 "From Jobs " &
                                 "Where JobId ='" & JobId & "'"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)



        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)


            Dim dv As DataView = GridJobCargo.DataSource
            Dim tmpdate, tmpdate1 As Date

            dv.RowFilter = "JobID  = '" & JobId & "' "

            If dv.Count > 0 Then
                dv.Sort = "PortExitDate DESC"
                tmpdate = dv(0)("PortExitDate")
                tmpdate1 = dv(dv.Count - 1)("PortExitDate")
                dv.Sort = "ID ASC"
            End If
            dv.Sort = Nothing
            dv.RowFilter = Nothing

            Dim JobStatus As String = ""

            If drow("JobStatus") = "" Then
                If Not tmpdate = CDate("1-Jan-1800") Then
                    If Not tmpdate1 = CDate("1-Jan-1800") Then
                        JobStatus = "Dispatched"
                    Else
                        JobStatus = "Under Clearance"
                        tmpdate = "1-Jan-1800"
                    End If
                End If

                drow("DispatchDate") = tmpdate
                drow("JobStatus") = JobStatus
            End If
            Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)


            Dim sqlstr2 As String =
                            "Select ContainerStatus,JobStatus," &
                            "PortExitdate, Id " &
                            "From JobCargo " &
                            "Where JobId = '" & JobId & "' "
            Call SetCargoJobStatus(JobStatus, "", JobId, sqlstr2)

            Dim tmpstr(2) As String
            tmpstr(0) = JobStatus
            tmpstr(1) = tmpdate
            tmpstr(2) = drow("LastSlingDate")
            Return tmpstr
        End If
    End Function

    Shared Sub SetCargoJobStatus(ByVal JobStatus As String, ByVal DispatchDate As String, ByVal JobId As String, sqlstr1 As String)
        Try

            If Not JobStatus = "" Then
                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
                Dim drow As DataRow
                Dim a As Integer
                For Each drow In tmptable1.Rows
                    Call clsData.NullChecker(tmptable1, a)
                    drow("JobStatus") = JobStatus

                    If Not JobStatus = "Closed" Then
                        If Not drow("ContainerStatus") = "Returned" Then
                            If drow("ContainerStatus") = "Crossed Border" Then
                                drow("ContainerStatus") = JobStatus
                            End If
                        End If
                    End If
                    If JobStatus = "Dispatched" Then
                        If IsDate(DispatchDate) Then
                            If CDate(drow("PortExitdate")) = CDate("1-Jan-1800") Then
                                drow("PortExitdate") = DispatchDate
                            End If
                        End If
                    End If
                    a = a + 1
                Next

                Call clsData.SaveData("JobCargo", tmptable1, sqlstr1, False, clsData.constr)

            End If

        Catch exp As Exception
            MsgBox(exp.Message)
        End Try
    End Sub

    Shared Function SetPortExitDate(GridJobCargo As DataGrid, JobID As String, SetDate As String, sqlstr As String, LastSlingDate As Date, BerthingDate As Date) As String()
        Dim a As Integer = GridJobCargo.SelectedIndex
        Dim tmpstr(2) As String
        Dim dv As DataView = GridJobCargo.DataSource

        If a >= 0 Then


            Dim error1() As Integer
            Dim b As Integer

            Dim found As Boolean

            If Not Trim(SetDate) = "" Then
                If CDate(SetDate) < LastSlingDate Then
                    Return tmpstr
                End If

                a = GridJobCargo.SelectedIndex
                dv(a)("PortExitDate") = SetDate
                If CDate(SetDate) > CDate(dv(a)("ReturnDate")) And Not CDate(dv(a)("ReturnDate")) = CDate("1-Jan-1800") Then
                    ReDim Preserve error1(b)
                    error1(b) = a
                End If
            End If
        Else

            Return tmpstr
        End If



        If Not sqlstr = "" Then
            Call clsData.SaveData("JobCargo", dv.Table, sqlstr, False, clsData.constr)
        Else
            sqlstr = "Select Jobstatus,ContainerStatus," &
                        "PortExitDate, ID " &
                        "From JobCargo " &
                        "Where JobID = '" & JobID & "'"
        End If


        tmpstr = SetDispatchedStatus(JobID, GridJobCargo, sqlstr)




        Return tmpstr

    End Function


    Shared Function SetContainerStatus(GridJobCargo As DataGrid, JobId As String, sqlstr As String, LastSlingDate As Date, BerthingDate As Date, Status As String, UserRole As String) As Boolean
        Dim a As Integer
        a = GridJobCargo.SelectedIndex
        Dim dv As DataView = GridJobCargo.DataSource

        If a >= 0 Then


            Call clsData.NullChecker1(dv, a)
            If UserRole = "Operator" Then
                If dv(a)("ContainerStatus") = "Returned" Then
                    MsgBox("User Cannot Change Status for Retuned Container", MsgBoxStyle.Exclamation)
                    Return False
                End If
            End If

            Dim sqlstr1 As String =
            "Select Status " &
            "From ContainerStatus "


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)


            Dim drow As DataRow
            a = 0

            'For Each drow In tmptable.Rows
            '    Call NullChecker(tmptable, a)
            '    ListBox1.Items.Add(drow("Status"))
            '    a = a + 1
            'Next

            a = GridJobCargo.SelectedIndex
            'x.ListBox1.SelectedItem = dv(a)("ContainerStatus")
            'x.ShowDialog()

            Dim error1(), error2() As Integer
            Dim b, c As Integer

            Dim found As Boolean
            If Not Status = "Returned" Then

                If Not found Then
                    c = 0
                    a = GridJobCargo.SelectedIndex
                    dv(a)("ContainerStatus") = "" 'x.ListBox1.SelectedItem

                    If CDate(dv(a)("ReturnDate")) > CDate("1-Jan-1800") Then
                        dv(a)("ReturnDate") = "1-Jan-1800"
                        ReDim Preserve error2(c)
                        error2(c) = a
                        c = c + 1
                    End If
                End If
            End If

            If Status = "Returned" Then

                'x1.BerthingDate = BerthingDate
                'x1.LastslingDate = LastSlingDate

                'a = GridJobCargo.SelectedIndex
                'x1.TextReturnDate.Text = Format(dv(a)("ReturnDate"), "dd MMM yyyy")
                'x1.TextInterchangeNo.Text = dv(a)("InterchangeNo")



                '        If Not found Then
                '            b = 0
                '            a = GridJobCargo.SelectedIndex
                '            dv(a)("ContainerStatus") = x.ListBox1.SelectedItem
                '            dv(a)("ReturnDate") = x1.TextReturnDate.Text
                '            dv(a)("InterchangeNo") = x1.TextInterchangeNo.Text

                '            If CDate(x1.TextReturnDate.Text) < CDate(dv(a)("PortExitDate")) Then
                '                ReDim Preserve error1(b)
                '                error1(b) = a
                '                b = b + 1
                '            End If
                '        End If
                '    End If
                'End If

            End If

            If Not sqlstr = "" Then
                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)

                Dim drow2 As DataRow
                Dim col As DataColumn

                For a = 0 To dv.Count - 1
                    For Each drow2 In tmptable1.Rows
                        If drow2("Id") = dv(a)("Id") Then
                            For Each col In tmptable1.Columns
                                If Not LCase(col.ToString) = "id" Then
                                    drow2(col.ToString) = dv(a)(col.ToString)
                                End If
                            Next
                        End If
                    Next
                Next

                Call clsData.SaveData("JobCargo", tmptable1, sqlstr, False, clsData.constr)
            End If

            Call SetLastReturnDate(JobId, GridJobCargo)


            Return True
        Else

            Return False
        End If

    End Function



    Shared Sub GetCurrentMonth(ByRef FromDate As DateTime, ByRef ToDate As DateTime)
        Try
            Dim tmpdate As DateTime = Now
            Dim days As Integer
            days = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"

            Dim tmpdate1 As DateTime = ("1/" & tmpstr(tmpdate.Month) & "/" & tmpdate.Year)
            Dim tmpdate2 As DateTime = (days & "/" & tmpstr(tmpdate.Month) & "/" & tmpdate.Year)

            FromDate = Format(tmpdate1, "dd MMM yyyy hh:mm:ss tt")
            ToDate = Format(tmpdate2, "dd MMM yyyy hh:mm:ss tt")

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetcurrentMonth")
        End Try
    End Sub





    Shared Function GetLastID(CFPROID As String, UserCSDID As String, IDName As String) As String

        Dim tmpstr As String = ""
        If Not UserCSDID = "" Then
            tmpstr = "And UserCSDID = '" & UserCSDID & "' "
        End If

        Dim sqlstr As String = _
            "Select LastID,IDName," & _
            "CFPROID,UserCSDID," & _
            "UserType,ID " &
            "From IDsIncr " &
            "Where CFPROID ='" & CFPROID & "' " & _
            "And IDName ='" & IDName & "' " & _
            tmpstr

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim drow As DataRow
        Dim LastIDCount As Integer = 0
        Dim LastID As String

        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)
            LastID = drow("LastID")

            If LCase(IDName) = "messageid" Then
                If Not clsMessaging.MessageIDUsed(drow("LastID")) Then
                    Return LastID
                Else
                    Dim tmpLastID() As String = LastID.Split("-")
                    ReDim Preserve tmpLastID(1)
                    LastID = tmpLastID(1)
                End If
            End If

            LastIDCount = CInt(LastID) + 1
        Else
            drow = tmptable.NewRow
            drow("UserType") = HttpContext.Current.Session("UserType")
            drow("CFPROID") = CFPROID
            drow("UserCSDID") = UserCSDID
            drow("IDName") = IDName
            LastIDCount = 1
            tmptable.Rows.Add(drow)
        End If



        If LCase(IDName) = "jobid" Then
            LastID = Format(LastIDCount, "0000000000#")
        ElseIf LCase(IDName) = "messageid" Then
            LastID = UserCSDID & "-" & Format(LastIDCount, "0000000000#")
        Else
            LastID = Format(LastIDCount, "0000000000#")
        End If

        drow("LastID") = LastID
        Call clsData.SaveData("IDsIncr", tmptable, sqlstr, False, clsData.constr)

        Return LastID

    End Function
    Shared Sub ResizeImage(filename As String, savePath As String, maxWidth As Integer, maxHeight As Integer, cropHeight As Integer)

        ' Validate the uploaded file
        ' 1. The uploaded file should not be a blank file


        Dim ext As String = System.IO.Path.GetExtension(filename).TrimStart(".".ToCharArray()).ToLower()
        If (ext <> "jpeg") AndAlso (ext <> "jpg") AndAlso (ext <> "png") AndAlso (ext <> "gif") AndAlso (ext <> "bmp") Then
            Return
        End If

        ' Validation successful
        ' Load the image into Bitmap Object


        Dim uploadedImage As New Bitmap(filename)

        ' Set the maximum width and height here.
        ' You can make this versatile by getting these values from
        ' QueryString or textboxes

        ' Resize the image
        Dim resizedImage As Bitmap = GetScaledPicture(uploadedImage, maxWidth, maxHeight)

        'Save the image

        ' resizedImage.Save(savePath, uploadedImage.RawFormat)

        SaveCroppedImage(resizedImage, maxWidth, cropHeight, savePath, ext)

        ' Load the resized image on the browser

    End Sub


    Shared Function GetScaledPicture(source As Bitmap, maxWidth As Integer, maxHeight As Integer) As Bitmap
        Dim width As Integer, height As Integer
        Dim aspectRatio As Single = CSng(source.Width) / CSng(source.Height)

        If (maxHeight > 0) AndAlso (maxWidth > 0) Then
            If (source.Width < maxWidth) AndAlso (source.Height < maxHeight) Then
                'Return unchanged image
                Return source
            ElseIf aspectRatio > 1 Then
                ' Calculated width and height,
                ' and recalcuate if the height exceeds maxHeight
                width = maxWidth
                height = CInt(Math.Truncate(width / aspectRatio))
                If height > maxHeight Then
                    height = maxHeight
                    width = CInt(Math.Truncate(height * aspectRatio))
                End If
            Else
                ' Calculated width and height,
                ' and recalcuate if the width exceeds maxWidth
                height = maxHeight
                width = CInt(Math.Truncate(height * aspectRatio))
                If width > maxWidth Then
                    width = maxWidth
                    height = CInt(Math.Truncate(width / aspectRatio))
                End If
            End If
        ElseIf (maxHeight = 0) AndAlso (source.Width > maxWidth) Then
            ' If MaxHeight is not provided (unlimited), and
            ' the source width exceeds maxWidth,
            ' then recalculate height
            width = maxWidth
            height = CInt(Math.Truncate(width / aspectRatio))
        ElseIf (maxWidth = 0) AndAlso (source.Height > maxHeight) Then
            ' If MaxWidth is not provided (unlimited), and the
            ' source height exceeds maxHeight, then
            ' recalculate width
            height = maxHeight
            width = CInt(Math.Truncate(height * aspectRatio))
        Else
            'Return unchanged image
            Return source
        End If

        Dim newImage As Bitmap = GetResizedImage(source, width, height)
        Return newImage
    End Function

    Shared Function GetResizedImage(source As Bitmap, width As Integer, height As Integer) As Bitmap
        'This function creates the thumbnail image.
        'The logic is to create a blank image and to
        ' draw the source image onto it

        Dim thumb As New Bitmap(width, height)
        Dim gr As Graphics = Graphics.FromImage(thumb)

        gr.InterpolationMode = InterpolationMode.HighQualityBicubic
        gr.SmoothingMode = SmoothingMode.HighQuality
        gr.PixelOffsetMode = PixelOffsetMode.HighQuality
        gr.CompositingQuality = CompositingQuality.HighQuality

        gr.DrawImage(source, 0, 0, width, height)
        Return thumb
    End Function
    Shared Function SaveCroppedImage(image As Image, maxWidth As Integer, maxHeight As Integer, filePath As String, ext As String) As Boolean

        Dim nCodecInfo As String
        If ext = "jpg" Then
            nCodecInfo = "image/jpeg"
        Else
            nCodecInfo = "image/png"
        End If


        Dim jpgpngInfo As ImageCodecInfo = ImageCodecInfo.GetImageEncoders().Where(Function(codecInfo) codecInfo.MimeType = nCodecInfo).First()
        Dim finalImage As Image = image
        Dim bitmap As System.Drawing.Bitmap = Nothing
        Try
            Dim left As Integer = 0
            Dim top As Integer = 0
            Dim srcWidth As Integer = maxWidth
            Dim srcHeight As Integer = maxHeight

            bitmap = New System.Drawing.Bitmap(maxWidth, maxHeight)
            Dim croppedHeightToWidth As Double = CDbl(maxHeight) / maxWidth
            Dim croppedWidthToHeight As Double = CDbl(maxWidth) / maxHeight

            If image.Width > image.Height Then
                srcWidth = CInt(Math.Round(image.Height * croppedWidthToHeight))
                If srcWidth < image.Width Then
                    srcHeight = image.Height
                    left = (image.Width - srcWidth) / 2
                Else
                    srcHeight = CInt(Math.Round(image.Height * (CDbl(image.Width) / srcWidth)))
                    srcWidth = image.Width
                    top = (image.Height - srcHeight) / 2
                End If
            Else
                srcHeight = CInt(Math.Round(image.Width * croppedHeightToWidth))
                If srcHeight < image.Height Then
                    srcWidth = image.Width
                    'top = (image.Height - srcHeight) / 2
                    top = 0
                Else
                    srcWidth = CInt(Math.Round(image.Width * (CDbl(image.Height) / srcHeight)))
                    srcHeight = image.Height
                    left = (image.Width - srcWidth) / 2
                End If
            End If
            Using g As Graphics = Graphics.FromImage(bitmap)
                g.SmoothingMode = SmoothingMode.HighQuality
                g.PixelOffsetMode = PixelOffsetMode.HighQuality
                g.CompositingQuality = CompositingQuality.HighQuality
                g.InterpolationMode = InterpolationMode.HighQualityBicubic
                g.DrawImage(image, New Rectangle(0, 0, bitmap.Width, bitmap.Height), New Rectangle(left, top, srcWidth, srcHeight), GraphicsUnit.Pixel)
            End Using
            finalImage = bitmap
        Catch
        End Try

        Try
            Using encParams As New EncoderParameters(1)
                encParams.Param(0) = New EncoderParameter(Encoder.Quality, CLng(100))
                'quality should be in the range 
                '[0..100] .. 100 for max, 0 for min (0 best compression)
                finalImage.Save(filePath, jpgpngInfo, encParams)
                Return True
            End Using
        Catch
        End Try
        If bitmap IsNot Nothing Then
            bitmap.Dispose()
        End If
        Return False
    End Function


    Shared Function GetOffSetTime(nDate As String) As TimeSpan
        Dim d As DateTime = Convert.ToDateTime(nDate)
        Dim zone As TimeZone = TimeZone.CurrentTimeZone
        Dim local As TimeSpan = zone.GetUtcOffset(d)
        Return local
    End Function


    Shared Function isMobileBrowser() As Boolean
        Dim userAgent As String = HttpContext.Current.Request.ServerVariables("HTTP_USER_AGENT")
        Dim OS As New Regex("(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino", RegexOptions.IgnoreCase Or RegexOptions.Multiline)
        Dim device As New Regex("1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-", RegexOptions.IgnoreCase Or RegexOptions.Multiline)

        Dim deviceinfo As String = String.Empty

        If OS.IsMatch(userAgent) Then
            deviceinfo = OS.Match(userAgent).Groups(0).Value
        End If
        If device.IsMatch(userAgent.Substring(0, 4)) Then
            deviceinfo += device.Match(userAgent).Groups(0).Value
        End If

        If Not String.IsNullOrEmpty(deviceinfo) Then
            Return True
        Else
            Return False
        End If

    End Function

    Shared Function MobileHost()

        Dim host As String = HttpContext.Current.Request.Url.Host

        If host.Contains("local") Or clsAuth.IsIPAdress(host) Then
            host = host & ":90"
        End If

        Return "http://" & host


    End Function






    Shared Function RemoteFileExists(RemoteFile As String) As Boolean

        Dim exist As Boolean = False
        Try
            Dim request As HttpWebRequest = DirectCast(WebRequest.Create(RemoteFile), HttpWebRequest)
            Using response As HttpWebResponse = DirectCast(request.GetResponse(), HttpWebResponse)
                exist = response.StatusCode = HttpStatusCode.OK
            End Using
        Catch
            Return False
        End Try

        Return exist

    End Function


    Shared Sub CreateAccountDocumentTypes(CFPROID As String, ByRef tmptable1 As DataTable)

        Dim sqlstr As String =
            "SELECT  DocumentType, " &
            "DocumentTypeID, Purpose," &
            "CFPROID, ID " &
            "FROM  DocumentTypes " &
            "Where CFPROID = '0' " &
            "And Purpose = 'Clearing' " &
            "Order By ID Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        Dim a As Integer
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next
                drow1("CFPROID") = CFPROID
                drow1("Purpose") = "Clearing"
                tmptable1.Rows.Add(drow1)
                a = a + 1
            Next
        End If

        Call clsData.SaveData("DocumentTypes", tmptable1, sqlstr, False, clsData.constr)

        ' tmptable1.AcceptChanges()
    End Sub

    Shared Sub CreateAccountInvoiceItems(CFPROID As String, ByRef tmptable1 As DataTable, AllColums As Boolean)

        Dim sqlstr As String

        If Not AllColums Then
            sqlstr = "SELECT  ItemID, Item," &
            "CFPROID,ID " &
            "FROM  InvoiceItems " &
            "Where CFPROID = '0' " &
            "Order By ID Asc;"

        Else
            sqlstr =
             "SELECT  ItemID, Item," &
             "Amount, ApplyTax," &
             "TaxType, TaxPercent," &
             "CFPROID,ID " &
             "FROM  InvoiceItems " &
             "Where CFPROID = '0' " &
             "Order By ID Asc;"

        End If


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        Dim a As Integer

        Dim ItemID As Integer = CInt(GetInvoiceItemID())

        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next
                drow1("ItemID") = Format(ItemID, "0000000#")
                drow1("CFPROID") = CFPROID

                ItemID = ItemID + 1

                tmptable1.Rows.Add(drow1)
                a = a + 1
            Next

            Call clsData.SaveData("InvoiceItems", tmptable1, sqlstr, False, clsData.constr)

        End If



    End Sub



    Shared Sub CreateAccountInvoiceTypes(CFPROID As String, ByRef tmptable1 As DataTable)

        Dim sqlstr As String =
            "SELECT InvoiceTypeID," &
               "InvoiceType, CFPROID, ID " &
               "FROM InvoiceTypes " &
               "Where CFPROID = '0' " &
               "Order By ID Asc;"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        Dim a As Integer

        Dim InvoiceTypeID As Integer = CInt(GetInvoiceTypeID())
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next

                drow1("InvoiceTypeID") = Format(InvoiceTypeID, "00000#")
                drow1("CFPROID") = CFPROID

                InvoiceTypeID = InvoiceTypeID + 1
                tmptable1.Rows.Add(drow1)
                a = a + 1
            Next
        End If

        Call clsData.SaveData("InvoiceTypes", tmptable1, sqlstr, False, clsData.constr)

    End Sub


    Shared Function GetInvoiceTypeID(Optional ByRef ErrMsg As String = Nothing) As String
        Try

            Dim tmpInvoiceTypeID As Integer

            Dim sqlstr As String = _
             "Select top 1 ID " & _
             "From InvoiceTypes " & _
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpInvoiceTypeID = drow("ID")
                tmpInvoiceTypeID = tmpInvoiceTypeID + 1
                tmpstr = Format(tmpInvoiceTypeID, "00000#")
            Else
                tmpstr = Format(tmpInvoiceTypeID, "00000#")
            End If

            Return tmpstr

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function

    Shared Function GetInvoiceItemID(Optional ByRef ErrMsg As String = Nothing) As String
        Try

            Dim tmpInvoiceItemID As Integer

            Dim sqlstr As String = _
             "Select top 1 ID " & _
             "From InvoiceItems " & _
             "Order By Id Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpInvoiceItemID = drow("ID")
                tmpInvoiceItemID = tmpInvoiceItemID + 1
                tmpstr = Format(tmpInvoiceItemID, "0000000#")
            Else
                tmpstr = Format(tmpInvoiceItemID, "0000000#")
            End If

            Return tmpstr

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function
    Shared Sub CreateJobKPI(CFPROID As String, JobID As String)
        Dim sqlstr As String =
            "SELECT  JobID, ItemID," &
            "AlertID, UpdateDate," &
            "LastProcessed, LastSeen," &
            "CFPROID, ID " &
            "FROM  JopKPIProgress "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        Dim a As Integer
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow1 = tmptable.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = UCase(drow(col.ColumnName.ToString))
                    End If
                Next
                drow1("CFPROID") = CFPROID
                tmptable.Rows.Add(drow1)
                a = a + 1
            Next
        End If

        Call clsData.SaveData("JopKPIProgress", tmptable, sqlstr, False, clsData.constr)


    End Sub



    Shared Function GetTotalPages(totalrows As Integer, rowsperpage As Integer) As Integer

        Dim tmpstr() As String = CStr(totalrows / rowsperpage).Split(".")
        ReDim tmpstr(1)

        If Val(tmpstr(1)) > 0 Then
            Return Val(tmpstr(0)) + 1
        Else
            Return Val(tmpstr(0))
        End If

    End Function





    Shared Function GetExchangeRate(CFPROID As String, CurrencyID As String) As Double


        Dim sqlstr As String =
           "SELECT CurrencyID, ExchangeRate " &
           "FROM AccountCurrencies " &
           "Where CurrencyID ='" & CurrencyID & "' " &
           "And CFPROID ='" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            Return drow("ExchangeRate")
        Else
            Return 0
        End If


    End Function


    Shared Sub CountryList(ByRef ComboCountries As DropDownList, Optional ByRef ErrMsg As String = Nothing)

        Try


            ComboCountries.Items.Clear()


            Dim sqlstr As String =
                "SELECT   Country, Code, ID " &
                 "FROM   Countries " &
                 "Order By Country ASC; "


            Dim tmptable As New DataTable

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim listitem As ListItem

            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                listitem = New ListItem
                listitem.Text = UCase(drow("Code")) & " - " & drow("Country")
                listitem.Value = UCase(drow("Code"))

                ComboCountries.Items.Add(listitem)
            Next

            ComboCountries.Items.Insert(0, "(Select Country)")


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
    End Sub
    Shared Function GetCFAgent(CFPROID As String) As String

        Dim sqlstr As String = "Select CFAgentName, ID " &
                               "From CFPROAccounts " &
                               "Where CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("CFAgentName")
        Else
            Return ""
        End If

    End Function

    Shared Function GetClient(CFPROID As String, ClientID As String) As String

        Dim sqlstr As String = "Select Client, ID " &
                               "From Clients " &
                               "Where ClientID = '" & ClientID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("Client")
        Else
            Return ""
        End If

    End Function

    Shared Function GetVendor(CFPROID As String, VendorID As String, VendorType As String) As String


        If Not Trim(VendorID) = "" Then
            If VendorType = "supplier" Then
                Return GetSupplier(CFPROID, VendorID)

            ElseIf VendorType = "transporter" Then
                Return GetTransporter(CFPROID, VendorID)

            ElseIf VendorType = "shippingline" Then
                Return GetShippingLine(CFPROID, VendorID)

            ElseIf VendorType = "cfs" Then
                Return GetCFS(CFPROID, VendorID)

            End If
        Else
            Return "Vendor not set"
        End If


    End Function
    Shared Function GetTransporter(CFPROID As String, TransporterID As String) As String

        Dim sqlstr As String = "Select Transporter, ID " &
                               "From Transporters " &
                               "Where TransporterID = '" & TransporterID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("Transporter")
        Else
            Return "Vendor not set"
        End If

    End Function

    Shared Function GetSupplier(CFPROID As String, SupplierID As String) As String

        Dim sqlstr As String = "Select Supplier, ID " &
                               "From Suppliers " &
                               "Where SupplierID = '" & SupplierID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("Supplier")
        Else
            Return "Vendor not set"
        End If

    End Function
    Shared Function GetShippingLine(CFPROID As String, ShippingLineID As String) As String

        Dim sqlstr As String = "Select ShippingLine, ID " &
                               "From ShippingLines " &
                               "Where ShippingLineID = '" & ShippingLineID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("ShippingLine")
        Else
            Return "Vendor not set"
        End If

    End Function

    Shared Function GetCFS(CFPROID As String, CFSID As String) As String

        Dim sqlstr As String = "Select CFS, ID " &
                               "From CFS " &
                               "Where CFSID = '" & CFSID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)

            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("CFS")
        Else
            Return "Vendor not set"
        End If

    End Function
    Shared Function GetCompany(CFPROID As String, CompanyID As String) As String

        Dim sqlstr As String = "Select CompanyName, ID " &
                               "From Companies " &
                               "Where CompanyID = '" & CompanyID & "' " &
                               "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("CompanyName")
        Else
            Return ""
        End If

    End Function

    Shared Function GetSaleman(CFPROID As String, SalesmanID As String)
        Dim sqlstr As String =
            "Select Salesman,SalesmanID, ID " &
            "From Salesmen " &
            "Where SalesmanID = '" & SalesmanID & "' " &
            "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("Salesman")
        Else
            Return ""
        End If

    End Function

    Shared Function GetCFAgentUser(CFPROID As String, UserID As String)
        Dim sqlstr As String =
            "Select UserNames,UserID, ID " &
            "From CFAgentUsers " &
            "Where UserID = '" & UserID & "' " &
            "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("UserNames")
        Else
            Return ""
        End If

    End Function



    Shared Function AbsoluteDateTime(nDateTime As String) As String


        Dim tmpstr(12) As String
        tmpstr(1) = "Jan"
        tmpstr(2) = "Feb"
        tmpstr(3) = "Mar"
        tmpstr(4) = "Apr"
        tmpstr(5) = "May"
        tmpstr(6) = "Jun"
        tmpstr(7) = "Jul"
        tmpstr(8) = "Aug"
        tmpstr(9) = "Sep"
        tmpstr(10) = "Oct"
        tmpstr(11) = "Nov"
        tmpstr(12) = "Dec"

        Dim tmpstr1() As String = nDateTime.Split(" ")
        ReDim Preserve tmpstr1(3)

        tmpstr1(0) = tmpstr(tmpstr1(0))

        Return Join(tmpstr1, " ")

    End Function


    Shared Sub MergeDataTables(ByRef MainDataTable As DataTable, ByRef SecondDataTable As DataTable)

        Dim drow, drow1 As DataRow
        Dim col As String

        Dim dv1 As New DataView(MainDataTable)

        For a = 0 To SecondDataTable.Rows.Count - 1

            Call clsData.NullChecker(SecondDataTable, a)
            drow = SecondDataTable.Rows(a)

            drow1 = MainDataTable.NewRow

                For b = 0 To SecondDataTable.Columns.Count - 1
                    col = SecondDataTable.Columns(b).ColumnName
                    If Not LCase(col) = "id" Then
                        drow1(col) = drow(col)
                    End If
                Next

            MainDataTable.Rows.Add(drow1)

        Next

    End Sub
End Class
