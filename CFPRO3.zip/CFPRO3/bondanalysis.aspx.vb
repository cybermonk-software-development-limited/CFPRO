﻿Imports System.IO
Imports System.Drawing


Public Class bondanalysis
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID


            If Not clsAuth.UserAllowed(CFPROID, CFPROUserID, "00014") Then
                Response.Redirect(Page.Request.UrlReferrer.ToString)
            End If

            Dim Daysleft As Integer
            If clsAuth.PaymentWarning(CFPROID, Daysleft) Then
                If Daysleft <= -3 Then
                    Response.Redirect("cfprodashboard.aspx")
                End If
            End If

            Call LoadBonds(CFPROID)
            Call LoadBondStatus(CFPROID)
            Call LoadJobStatus(CFPROID)
            Call LoadJobTypes(CFPROID)
            Call LoadCFS(CFPROID)

            ComboPredefine.SelectedIndex = 9

            Call PreDefine(ComboPredefine.Text, CFPROID, CFPROUserID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If

    End Sub


    Private Sub LoadJobsWithBond(Scope As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim Opdate As String = "JobDate"


            Dim tmpstr As String = ""




            If Not Scope = "(All)" Then
                tmpstr = " And Jobs.JobDate >= '" & TextFromDate.Text & "' " &
                          " And Jobs.JobDate <= '" & TextToDate.Text & "' " &
                          "And BondAmount > 0 "

            Else
                tmpstr = " And ID > 0 " &
                          "And BondAmount > 0 "

            End If



            Select Case ComboLoadedJobs.Text
                Case "Open Jobs"
                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%'"

                Case "All Jobs"

                    tmpstr = tmpstr

                Case "Closed Jobs"
                    tmpstr = tmpstr &
                                " And Jobs.JobStatus Like '%Closed%' "

                Case "Jobs Kept Visible"
                    tmpstr = " (" & tmpstr &
                       "Or  Jobs.KeepVisible = 1) "

            End Select




            Dim sqlstr As String =
                    "Select Top " & ComboSelectTop.Text & " " &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "CustomsSystem,BL,OrderNo,Goods," &
                    "ShipperID,DeclarationPersonnel," &
                    "ShippingPersonnel,ShipStatus," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "JobTypeID,SOC,KeepVisible, EntryNo," &
                    "EntryRegistrationDate,EntryPassDate," &
                    "JobStatus,  BondID, " &
                    "BondAmount, BondStatus," &
                    "BondActiveDate, BondCancelDate," &
                    "BondRemarks,UserID,ID " &
                    "From Jobs " &
                    "Where CFPROID = '" & CFPROID & "' " &
                     tmpstr


            Dim tmptable As New DataTable("JobsData")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate, CrossBorderDate,ReturnDate," &
                  "JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID " &
                  tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                      "Select CFSID, CFS, " &
                      "LocalFreeDays, TransitFreeDays,ID " &
                      "From CFS " &
                      "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            'Dim sqlstr4 As String =
            '           "Select TOP 1 WITH TIES JobProgress.JobID," &
            '           "Status, Date " &
            '           "From JobProgress,Jobs " &
            '           "Where JobProgress.CFPROID = '" & CFPROID & "' " &
            '            "And Jobs.CFPROID = '" & CFPROID & "' " &
            '           "And JobProgress.JobID = Jobs.JobID " &
            '           tmpstr &
            '          "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"

            'Dim tmptable4 As New DataTable()
            'Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            'Dim dv4 As New DataView(tmptable4)



            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)



            Dim sqlstr6 As String =
                "SELECT BondID, BondDescription," &
                "BondNo, BondAmount," &
                "BondExpiry, Status, ID " &
                "FROM Bonds " &
                "Where CFPROID ='" & CFPROID & "' "


            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)

            Dim drow As DataRow
            Dim a, b, c As Integer


            Dim tmpstr3(0) As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("CFS", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            Dim col6 As New DataColumn("ReturnDate", Type.GetType("System.DateTime"))
            Dim col7 As New DataColumn("PortExitDate", Type.GetType("System.DateTime"))
            Dim col8 As New DataColumn("CrossBorderDate", Type.GetType("System.DateTime"))
            Dim col9 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col10 As New DataColumn("ContainerNos", Type.GetType("System.String"))
            Dim col11 As New DataColumn("Weight", Type.GetType("System.Double"))
            Dim col12 As New DataColumn("CrossedBorder", Type.GetType("System.Boolean"))
            Dim col13 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col14 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col15 As New DataColumn("BIFValue", Type.GetType("System.String"))
            Dim col16 As New DataColumn("BIFCancellation", Type.GetType("System.String"))
            Dim col17 As New DataColumn("BondNo", Type.GetType("System.String"))


            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)
            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)
            tmptable.Columns.Add(col17)

            Dim Weight As Double
            Dim tmpdate As Date = Now


            Dim CrossedBorder As Boolean

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If


                drow("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID, "")
                drow("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")

                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"

                c = 0
                Weight = 0




                CrossedBorder = True

                If dv1.Count > 0 Then
                    For b = 0 To dv1.Count - 1
                        Call clsData.NullChecker1(dv1, b)
                        c = c + 1
                        Weight = Weight + dv1(b)("Weight")

                        If CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                            CrossedBorder = False
                        End If

                        ReDim Preserve tmpstr3(b)
                        tmpstr3(b) = dv1(b)("ContainerNo")


                    Next

                    dv1.Sort = "PortExitDate DESC"

                    If dv1.Count > 0 Then
                        drow("PortExitDate") = dv1(0)("PortExitDate")
                    End If

                    dv1.Sort = "CrossBorderDate DESC"

                    If dv1.Count > 0 Then
                        drow("CrossBorderDate") = Format(dv1(0)("CrossBorderDate"), "dd MMM yyyy")
                    End If


                    dv1.Sort = "ReturnDate DESC"

                    If dv1.Count > 0 Then
                        drow("ReturnDate") = dv1(0)("ReturnDate")

                    End If


                End If

                drow("CrossedBorder") = CrossedBorder


                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Weight") = Weight


                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")

                End If

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")

                End If




                'dv4.RowFilter = "JobID = '" & drow("JobID") & "' "
                'If dv4.Count > 0 Then
                '    Call clsData.NullChecker1(dv4, 0)
                '    dv4.Sort = "Date DESC"
                '    drow("Status") = dv4(0)("Status")
                'End If

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    drow("Client") = Mid(dv5(0)("Client"), 1, 25)
                End If


                dv6.RowFilter = "BondID = '" & drow("BondID") & "' "

                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv6, 0)
                    drow("BondNo") = dv6(0)("BondNo")
                End If


                a = a + 1

            Next

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            If tmptable.Rows.Count > 10 Then
                PanelJobs.Height = 300
            Else
                PanelJobs.Height = Nothing
            End If



            Dim dv As New DataView(tmptable)


            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobID" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If


            LabelSortStr.Text = dv.Sort
            GridJobs.DataSource = dv
            GridJobs.DataBind()

            Session("BondAnalysisTable") = tmptable

            Call Calctotal(dv, "")



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub Calctotal(dv As DataView, ByVal tmpcaption1 As String)
        Try

            Dim a As Integer
            Dim Weight, BIF As Double

            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Weight = Weight + dv(a)("Weight")

                If InStr(dv(a)("BondStatus"), "cancelled", CompareMethod.Text) = 0 Then
                    BIF = BIF + dv(a)("BondAmount")
                End If

            Next

            TextTotalWeight.Text = Format(Weight, "#,##0.00")
            TextTotalBIF1.Text = Format(BIF, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " to " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            LabelReportCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr

            Call LoadBondSummary(LabelCFPROID.Text)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub LoadBonds(CFPROID As String)

        Dim sqlstr As String =
                "SELECT  BondNo, BondID " &
                "FROM Bonds " &
                "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboBondNo, sqlstr, clsData.constr, 0, 1)
        ComboBondNo.Items.Insert(0, "(All)")

    End Sub
    Private Sub LoadBondStatus(CFPROID As String)

        Dim sqlstr As String = "Select Status,ID " &
                                  "From  Bondstatus " &
                                  "Where CFPROID ='" & CFPROID & "' " &
                                  "Order By ID Asc;"

        Call clsData.PopComboWithValue(ComboBondStatus, sqlstr, clsData.constr, 0, 0)
        ComboBondStatus.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadJobStatus(CFPROID As String)

        Dim sqlstr As String =
       "Select Status " &
       "From CFAgentJobStatus " &
       "Where CFPROID = '" & CFPROID & "' "

        ComboJobStatus.Items.Clear()
        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr, clsData.constr, 0, 0)

        ComboJobStatus.Items.Add("----------")

        Dim sqlstr1 As String =
         "Select ItemDescription,ItemID " &
         "From KPIProgress "

        Call clsData.PopComboWithValue(ComboJobStatus, sqlstr1, clsData.constr, 0, 1)

        ComboJobStatus.Items.Insert(0, "(All)")
        ComboJobStatus.Items(ComboJobStatus.Items.Count - 1).Value = "0"
    End Sub


    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub


    Private Sub LoadCFS(CFPROID As String)
        Dim sqlstr As String =
        "Select CFS, CFSID " &
        "From CFS " &
        "Where CFPROID = '" & CFPROID & "' " &
        "Order By CFS Asc;"

        Call clsData.PopComboWithValue(ComboCFS, sqlstr, clsData.constr, 0, 1)
        ComboCFS.Items.Insert(0, "(All)")

    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelJobMessage.ForeColor = Color.Tomato
            LabelJobMessage.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()

        Call ClearFilters()
        Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If
                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If


                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterAgent" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterClient" Then
                    Continue For
                End If

                If cont.ID = "CheckJobStatus" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterConsignee" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterJobType" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterShipper" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCFS" Then
                    Continue For
                End If

                If cont.ID = "CheckCFAgentUser" Then
                    Continue For
                End If

                If cont.ID = "CheckFilterCustomsSystem" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitCrossedBorder" Then
                    Continue For
                End If

                If cont.ID = "CheckOmitDispatched" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String, CFPROUserID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM dd yyyy hh:mm:ss tt")

            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"



            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""

                    Call ClearFilters()
                    Call LoadJobsWithBond(ComboPredefine.Text, CFPROID, CFPROUserID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetCurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 2 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 6 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-6)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 12 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-12)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobsWithBond(ComboPredefine.Text, CFPROID, CFPROUserID)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub



    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal BondNo As Boolean, ByVal BondStatus As Boolean, ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean, ByVal OmitBondCancelled As Boolean, ByVal OmitCrossedBorder As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a As Integer = 0

            Dim CFPROID As String = LabelCFPROID.Text

            'If Not clsData.TableCacheOK(CFPROID, clsData.JobsTable) Then
            '    Call LoadJobsWithBond(ComboPredefine.Text,  CFPROID, False, True)
            'End If

            If IsNothing(Session("BondAnalysisTable")) Then
                Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If


            Dim BondAnalysisTable As New DataTable("BondAnalysisTable")
            BondAnalysisTable = DirectCast(Session("BondAnalysisTable"), DataTable)

            Dim dv As New DataView(BondAnalysisTable)

            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "AgentID = " & "'" & LabelAgentID.Text & "' "
                tmpstr1(a) = "Agent: " & TextAgent.Text
                tmpstr1(a) = "Agent : " & TextAgent.Text
                a = a + 1
            End If


            If Client Then

                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ClientID = " & "'" & LabelClientID.Text & "' "
                Else
                    tmpstr(a) = "And ClientID = " & "'" & LabelClientID.Text & "' "
                End If

                tmpstr1(a) = "Client: " & TextClient.Text
                a = a + 1


            End If

            If Importer Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "ImporterID = " & "'" & LabelImporterID.Text & "' "
                Else
                    tmpstr(a) = " And ImporterID = " & "'" & LabelImporterID.Text & "' "
                End If

                tmpstr1(a) = "Consignee: " & TextImporter.Text
                a = a + 1
            End If


            If BondNo Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "BondNo = " & "'" & ComboBondNo.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And BondNo = " & "'" & ComboBondNo.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Bond Number: " & ComboBondNo.SelectedItem.ToString
                a = a + 1
            End If


            If BondStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "BondStatus = " & "'" & ComboBondStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And BondStatus = " & "'" & ComboBondStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Bond Status: " & ComboBondStatus.SelectedItem.ToString
                a = a + 1
            End If



            If JobType Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And JobTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.SelectedItem.ToString
                a = a + 1
            End If

            If JobStatus Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                Else
                    tmpstr(a) = " And JobStatus = " & "'" & ComboJobStatus.SelectedItem.ToString & "' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.SelectedItem.ToString
                a = a + 1
            End If


            If CFS Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & ComboCFS.SelectedValue & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & ComboCFS.SelectedValue & "' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.SelectedItem.ToString
                a = a + 1
            End If


            If OmitBondCancelled Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "BondStatus  Not LIKE '%cancelled%' "
                Else
                    tmpstr(a) = " And BondStatus Not LIKE '%cancelled%' "
                End If

                tmpstr1(a) = " BONDS NOT YET CANCELLED: "
                a = a + 1
            End If


            If OmitCrossedBorder Then
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If a = 0 Then
                    tmpstr(a) = "CrossedBorder = 0 "
                Else
                    tmpstr(a) = " And CrossedBorder = 0 "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                a = a + 1
            End If


            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")


            dv.RowFilter = tmpstr2
            LabelFilterStr.Text = tmpstr2

            Call ApplySort(dv, False)

            GridJobs.DataSource = dv
            GridJobs.DataBind()


            Call Calctotal(dv, tmpstr3)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "JobDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "JobID"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "VesselETA"

        ElseIf RadioButtonList1.SelectedIndex = 4 Then
            Return "StorageDays"

        ElseIf RadioButtonList1.SelectedIndex = 5 Then
            Return "DemurrageDays"
        Else
            Return "JobDate"
        End If
    End Function


    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckAgent.Checked, CheckClient.Checked, CheckConsignee.Checked, CheckBondNo.Checked, CheckBondStatus.Checked,
                            CheckJobType.Checked, CheckJobStatus.Checked, CheckCFS.Checked, CheckOmitBondCancelled.Checked, CheckOmitCrossedBorder.Checked)
    End Sub


    Private Sub LoadPage(page As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        cff.Attributes("style") = "height:" & height + 5 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = page
        ModalPopupExtender1.Show()
    End Sub
    Protected Sub ButtonProgressUpdates_Click(sender As Object, e As EventArgs) Handles ButtonProgressUpdates.Click
        Try
            If GridJobs.SelectedValue Is Nothing Then
                LabelJobMessage.Text = "Please select an item"
            Else
                If GridJobs.SelectedIndex >= 0 Then

                End If

                Dim row As GridViewRow = GridJobs.SelectedRow

                Call LoadPage("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString & "&CFPROID=" &
                              LabelCFPROID.Text & "&referenceno=" & row.Cells(0).Text & "&jobdate=" &
                               row.Cells(1).Text & "&client=" &
                               row.Cells(2).Text, "Progress Update", 580, 780)
            End If
        Catch ex As Exception
            LabelMessage1.Text = ex.Message
        End Try
    End Sub




    Private Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call nSortOrder()
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call ClearFilters()
        Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
    End Sub


    Protected Sub ButtonButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("BondAnalysisTable")) Then
            Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
        End If

        Dim tmptable As DataTable = Session("BondAnalysisTable")
        Dim dv As DataView = New DataView(tmptable)

        dv.RowFilter = "BondNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or ContainerNos Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%' "

        GridJobs.DataSource = dv
        GridJobs.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        LabelReportCaption.Text = dv.Count & " Jobs Found Matching '" & Trim(SearchStr) & "'  | " & TextFromDate.Text & " to " & TextToDate.Text

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching '" & Trim(SearchStr) & "' "

        Call Calctotal(dv, tmpstr)

    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchImporter_Click(sender As Object, e As EventArgs) Handles ButtonSearchImporter.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "consignee", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchAgent_Click(sender As Object, e As EventArgs) Handles ButtonSearchAgent.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "agent", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)


        If dv Is Nothing Then

            If IsNothing(Session("BondAnalysisTable")) Then
                Call LoadJobsWithBond(ComboPredefine.Text, LabelCFPROID.Text, LabelCFPROUserID.Text)
            End If

            Dim JobsTable As DataTable = Session("BondAnalysisTable")
            dv = New DataView(JobsTable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()
        If SortBy = "JobDate" Then
            dv.Sort = "JobDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "JobId" Then
            dv.Sort = "ID " & tmpstrSort

        ElseIf SortBy = "VesselETA" Then
            dv.Sort = "VesselETA " & tmpstrSort

        End If



        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridJobs.DataSource = dv
            GridJobs.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call Calctotal(dv, "")
        End If

    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckClient.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Agent / Broker" Then
            LabelAgentID.Text = ItemID
            TextAgent.Text = Item
            CheckAgent.Checked = True

        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            LabelImporterID.Text = ItemID
            TextImporter.Text = Item
            CheckConsignee.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExcelBondReport()
    End Sub



    Private Sub ExcelBondReport()

        Dim totals(8) As String


        totals(0) = "Total Bond In Force: " & TextTotalBIF1.Text
        totals(1) = "Total Bonds Amount: " & TextTotalBond1.Text
        totals(3) = "Total Bonds Balance: " & TextTotalBalance1.Text
        totals(4) = "Total Weight: " & TextTotalWeight.Text & " (Tons)"
        totals(5) = ""
        totals(6) = ""
        totals(7) = LabelTotalsMessage.Text
        totals(8) = ""


        Dim tmpfields(8) As String
        tmpfields(0) = "ReferenceNo"
        tmpfields(1) = "Client"
        tmpfields(2) = "Goods"
        tmpfields(3) = "Weight"
        tmpfields(4) = "EntryNo"
        tmpfields(5) = "EntryPassDate"
        tmpfields(6) = "BondAmount"
        tmpfields(7) = "BondNo"
        tmpfields(8) = "BondStatus"


        Dim tmpfields1(8) As String
        tmpfields1(0) = "Reference No"
        tmpfields1(1) = "Client"
        tmpfields1(2) = "Goods"
        tmpfields1(3) = "Weight (Tons)"
        tmpfields1(4) = "Entry No (T810)"
        tmpfields1(5) = "Entry Pass Date"
        tmpfields1(6) = "BIF Value"
        tmpfields1(7) = "Bond No"
        tmpfields1(8) = "Bond Status"


        Dim tmptable As New DataTable("BondAnalysisTable")
        tmptable = DirectCast(Session("BondAnalysisTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Bond Report", "Bond Report",
                                                LabelReportCaption.Text, True, totals, 0, "", tmpfields, tmpfields1, tmptable, False)


    End Sub


    Protected Sub ButtonGo_Click(sender As Object, e As EventArgs) Handles ButtonGo.Click
        Call RefreshData()
    End Sub


    Protected Sub ComboBondStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBondStatus.SelectedIndexChanged
        CheckBondStatus.Checked = True
    End Sub

    Protected Sub ComboBondNo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBondNo.SelectedIndexChanged
        CheckBondNo.Checked = True
    End Sub

    Protected Sub ComboJobType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobType.SelectedIndexChanged
        CheckJobType.Checked = True
    End Sub

    Protected Sub ComboJobStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboJobStatus.SelectedIndexChanged
        CheckJobStatus.Checked = True
    End Sub
    Protected Sub ComboCFS_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFS.SelectedIndexChanged
        CheckCFS.Checked = True
    End Sub
    Protected Sub ButtonBondSummary_Click(sender As Object, e As EventArgs) Handles ButtonBondSummary.Click

        ModalPopupExtender3.Show()
    End Sub
    Private Sub LoadBondSummary(CFPROID As String)
        Try

            Dim sqlstr As String =
                "SELECT BondID, BondDescription," &
                "BondNo, BondAmount," &
                "BondExpiry, ID " &
                "FROM Bonds " &
                "Where CFPROID ='" & CFPROID & "' " &
                "Order By BondAmount Desc "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a, b, c As Integer
            Dim drow As DataRow
            Dim col As New DataColumn("AmountInforce", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("Balance", Type.GetType("System.Double"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)

            Dim tmptable1 As New DataTable("BondAnalysisTable")
            tmptable1 = DirectCast(Session("BondAnalysisTable"), DataTable)


            Dim Amount, AmountInforce, Balance As Double
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("Balance") = drow("BondAmount")
                a = a + 1
            Next

            a = 0


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                For Each drow1 In tmptable1.Rows
                    If drow1("BondID") = drow("BondID") Then
                        If InStr(drow1("BondStatus"), "cancelled", CompareMethod.Text) = 0 Then
                            drow("AmountInforce") = drow("AmountInforce") + drow1("BondAmount")
                            drow("Balance") = drow("Balance") - drow1("BondAmount")
                        End If
                    End If
                Next

                Amount = Amount + drow("BondAmount")
                AmountInforce = AmountInforce + drow("AmountInforce")
                Balance = Balance + drow("Balance")
                a = a + 1
            Next


            TextTotalBIF.Text = Format(AmountInforce, "#,##0.00")
            TextTotalBond.Text = Format(Amount, "#,##0.00")
            TextTotalBalance.Text = Format(Balance, "#,##0.00")



            Dim found As Boolean

            Dim dv As New DataView(tmptable1)

            If Not LabelFilterStr.Text = "" Then
                dv.RowFilter = LabelFilterStr.Text
            End If

            Dim tmpBondID(0) As String
            c = 0
            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                found = False

                For b = 0 To tmpBondID.GetUpperBound(0)
                    If tmpBondID(b) = dv(a)("BondID") Then
                        found = True
                        Exit For
                    End If
                Next

                If Not found Then
                    ReDim Preserve tmpBondID(c)
                    If c = 0 Then
                        tmpBondID(c) = "BondID = '" & dv(a)("BondID") & "' "
                    Else
                        tmpBondID(c) = " Or BondID = '" & dv(a)("BondID") & "' "
                    End If
                    c = c + 1
                End If

            Next
            Dim tmpbondfilter = Join(tmpBondID, " ")


            Dim dv1 As New DataView(tmptable)

            If InStr(tmpbondfilter, "BondID", CompareMethod.Text) > 0 Then
                dv1.RowFilter = tmpbondfilter
            Else
                dv1.RowFilter = "BondID = '0'"
            End If



            Dim Amount1, Balance1 As Double
            For a = 0 To dv1.Count - 1
                Call clsData.NullChecker1(dv1, a)
                Amount1 = Amount1 + dv1(a)("BondAmount")
                Balance1 = Balance1 + dv1(a)("Balance")
            Next

            TextTotalBond1.Text = Format(Amount1, "#,##0.00")
            TextTotalBalance1.Text = Format(Balance1, "#,##0.00")


            LabelBondSummaryCaption.Text = tmptable.Rows.Count & " Bonds"
            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("BondDescription") = "No Bonds"
                tmptable.Rows.Add(drow)
            End If

            Session("BondSummaryTable") = tmptable

            GridBonds.DataSource = tmptable
            GridBonds.DataBind()

            LabelMessage1.Text = ""

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonExportSummaryToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportSummaryToExcel.Click
        Call ExcelBondSummaryReport()
    End Sub

    Private Sub ExcelBondSummaryReport()

        Dim totals(5) As String

        totals(0) = "Total BIF: " & TextTotalBIF.Text
        totals(1) = "Total Amount: " & TextTotalBond.Text
        totals(2) = "Total Balance: " & TextTotalBalance.Text


        Dim tmpfields(5) As String
        tmpfields(0) = "BondDescription"
        tmpfields(1) = "BondNo"
        tmpfields(2) = "BondAmount"
        tmpfields(3) = "AmountInforce"
        tmpfields(4) = "Balance"
        tmpfields(5) = "BondExpiry"



        Dim tmpfields1(5) As String
        tmpfields1(0) = "Bond Description"
        tmpfields1(1) = "Bond No"
        tmpfields1(2) = "Amount"
        tmpfields1(3) = "In force"
        tmpfields1(4) = "Balance"
        tmpfields1(5) = "Expires"



        Dim tmptable As New DataTable("BondSummaryTable")
        tmptable = DirectCast(Session("BondSummaryTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Bond Summary", "Bond Summary",
                                                LabelBondSummaryCaption.Text, True, totals, 0, "", tmpfields, tmpfields1, tmptable, False)


    End Sub


End Class

