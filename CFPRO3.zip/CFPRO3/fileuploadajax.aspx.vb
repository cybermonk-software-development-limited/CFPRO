﻿Imports AjaxControlToolkit
Public Class fileuploadajax
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            LabelMessage.Text = "Drag & Drop file here or Browse to File & Click 'Upload' (3MB max pdf, jpeg, png, ms excel & ms word format only)"

        End If


    End Sub

    Protected Sub FileUpload(ByVal sender As Object, ByVal e As AjaxFileUploadEventArgs)

        Dim filename As String = System.IO.Path.GetFileName(e.FileName)

        Dim filedest As String = Server.MapPath(".") & "\jobdocuments\"
        Dim messageid As String = Request.QueryString("messageid")

        If e.FileSize <= 3145728 Then
            Dim tmpstr() As String = filename.Split(".")
            ReDim Preserve tmpstr(1)
            Dim filepath As String = filedest & filename & "-" & messageid & tmpstr(1)
            AjaxFileUpload1.SaveAs(filepath)

        End If




    End Sub


End Class


