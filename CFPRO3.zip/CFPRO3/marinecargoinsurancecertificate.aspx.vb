﻿Imports System.Drawing
Imports System.Configuration
Public Class marinecargoinsurancecertificate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, "", "", "", "", "", False, "", False)

            Call LoadInsurer()
            Call LoadPolicyDocuments()

        End If
    End Sub

    Private Sub LoadPolicy()
        Dim PolicyID As String = "-1"

        If Not IsNothing(Request.Cookies("CFPROMarineInsurance")) Then
            PolicyID = clsEncr.DecryptString(Request.Cookies("CFPROMarineInsurance").Value)
        End If

        Dim sqlstr As String =
             "SELECT CSDID, PolicyID," &
             "EmailAddress, NameofInsured," &
             "NameofPurchaser, Telephone," &
             "CategoryID, CargoID," &
             "AmountInsured, Premium," &
             "TrainingLevy, StampDuty," &
             "PolicyHolderFund, SystemFees," &
             "Total, Status, PurchaseDate," &
             "JobId,ID " &
             "FROM MarineInsurancePolicies " &
             "Where PolicyID ='" & PolicyID & "' " &
             "And Status ='" & "Started" & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            LabelEmailAddress.Text = drow("EmailAddress")

            If drow("Status") = "Started" Then
                LabelPolicyStatus.Text = "NOT PAID"
                LabelPolicyStatus.ForeColor = Color.Red
            Else
                LabelPolicyStatus.Text = "PAID"
                LabelPolicyStatus.ForeColor = Color.Green
            End If

            LabelNames.Text = drow("NameofPurchaser")
            LabelInsured.Text = drow("NameofInsured")

            LabelTelephone.Text = drow("Telephone")
            LabelTrainingLevy.Text = Format(drow("TrainingLevy"), "#,##0.00")
            LabelStampDuty.Text = Format(drow("StampDuty"), "#,##0.00")
            LabelPolicyHoldersFund.Text = Format(drow("PolicyHolderFund"), "#,##0.00")
            LabelSystemFees.Text = Format(drow("SystemFees"), "#,##0.00")

            LabelPremium.Text = Format(drow("Premium"), "#,##0.00")


            LabelIDNo.Text = drow("IDNo")
            LabelPIN.Text = drow("PIN")
            LabelTotal.Text = Format(drow("Total"), "#,##0.00")

            LabelPolicyID.Text = clsEncr.EncryptString(PolicyID)

        End If
    End Sub

    Private Sub LoadInsurer()
        Dim sqlstr As String =
            "SELECT InsurerID, " & _
            "Insurer,ProductName," & _
            "Description, URL," & _
            "EmailAddress,Telephone, SystemFees " & _
            "FROM MarineCargoInsurer "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col2 As New DataColumn("Contacts", Type.GetType("System.String"))
        Dim col3 As New DataColumn("SendMessage", Type.GetType("System.String"))

        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)

        Dim a As Integer

        Dim drow As DataRow

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)

            drow = tmptable.Rows(0)

            drow("Contacts") = "Email: " & drow("EmailAddress") & " | Telephone:" & drow("Telephone")

            HyperLinkCompany.Text = drow("Insurer")
            HyperLinkCompany.NavigateUrl = drow("URL")

            LabelContacts.Text = drow("Contacts")

        End If



    End Sub



    Private Sub LoadPolicyDocuments()
        Dim sqlstr As String =
            "SELECT  DocumentName, " & _
            "Purpose,Compulsory " & _
            "FROM  MarineInsuranceDocuments " &
            "Where Purpose = '" & "Policy" & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)




        Dim col1 As New DataColumn("FileURL", Type.GetType("System.String"))
        Dim col2 As New DataColumn("FileSize", Type.GetType("System.String"))
        Dim col3 As New DataColumn("FilePath", Type.GetType("System.String"))
        Dim col4 As New DataColumn("FilePath1", Type.GetType("System.String"))
        Dim col5 As New DataColumn("FileTypeImage", Type.GetType("System.String"))
        Dim col6 As New DataColumn("IsAttached", Type.GetType("System.Boolean"))
        Dim col7 As New DataColumn("DocStatus", Type.GetType("System.String"))
        Dim col8 As New DataColumn("DocCount", Type.GetType("System.String"))
        Dim col9 As New DataColumn("AttachText", Type.GetType("System.String"))

        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)
        tmptable.Columns.Add(col3)
        tmptable.Columns.Add(col4)
        tmptable.Columns.Add(col5)
        tmptable.Columns.Add(col6)
        tmptable.Columns.Add(col7)
        tmptable.Columns.Add(col8)
        tmptable.Columns.Add(col9)

        Dim drow As DataRow
        Dim a, b, c As Integer
        Dim filepath As String = Server.MapPath(".") & "\marinecargodocuments\" & LabelPolicyID.Text & "\"

        LabelMessage1.Text = filepath

        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)

            drow("DocCount") = a + 1 & "."
            'drow("FileTypeImage") = "file-icon.png"

            'If drow("Compulsory") Then
            '    drow("DocStatus") = "Required"
            'End If

            'drow("IsAttached") = 0

            If IO.Directory.Exists(filepath) Then
                Dim tmpfiles() As String = IO.Directory.GetFiles(filepath)

                Dim filesize As Double = 0
                Dim fileinfo As IO.FileInfo
                For Each tmpfile In tmpfiles
                    fileinfo = New IO.FileInfo(tmpfile)

                    If InStr(fileinfo.Name, drow("DocumentName"), CompareMethod.Text) > 0 Then

                        drow("DocumentName") = fileinfo.Name
                        drow("IsAttached") = 1
                        drow("AttachText") = "Change"
                        drow("DocStatus") = "Attached"
                        c = c + 1

                        filesize = fileinfo.Length / 1048576
                        If filesize > 1 Then
                            drow("Filesize") = "Size :" & Format((filesize), "0.#0") & " MB"
                        Else
                            filesize = fileinfo.Length / 1024
                            drow("Filesize") = "Size :" & Format((filesize), "0.#0") & " KB"
                        End If

                        drow("FileURL") = "~/marinecargodocuments/" & LabelPolicyID.Text & "/" & fileinfo.Name
                        drow("FilePath") = tmpfile

                        Dim tmpstr() As String = fileinfo.Name.Split(".")
                        b = tmpstr.GetUpperBound(0)
                        ReDim Preserve tmpstr(b)
                        If LCase(tmpstr(b)) = "pdf" Then
                            drow("FileTypeImage") = "pdf-icon2.png"
                        ElseIf LCase(tmpstr(b)) = "png" Or LCase(tmpstr(b)) = "jpg" Then
                            drow("FileTypeImage") = "image-icon.png"

                        ElseIf LCase(tmpstr(b)) = "xls" Or LCase(tmpstr(a)) = "xlsx" Then
                            drow("FileTypeImage") = "excel-icon.png"

                        ElseIf LCase(tmpstr(b)) = "docx" Or LCase(tmpstr(b)) = "docx" Then
                            drow("FileTypeImage") = "word-icon.png"
                        Else
                            drow("FileTypeImage") = "file-icon.png"
                        End If


                    Else

                        drow("AttachText") = "Attach"
                        drow("DocStatus") = "NOT Attached"
                        drow("FileTypeImage") = "file-icon.png"
                    End If


                Next
            Else
                drow("AttachText") = "Attach"
                drow("DocStatus") = "NOT Attached"
                drow("FileTypeImage") = "file-icon.png"
            End If

            a = a + 1
        Next


        DataList1.DataSource = tmptable
        DataList1.DataBind()
        LabelAttachments.Text = "Attached Documents (" & c & ")"

    End Sub




    Private Sub LoadSendMessage(page As String, title As String)
        LabTitle.Text = title
        iframe1.Attributes("src") = page
        ModalPopupExtender3.Show()
    End Sub


    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        Dim JobID As String = ""
        LoadSendMessage("sendmessage.aspx?jobid=" & JobID & "&filetype=jobdocuments&sendercsdid=" & LabelCSDID.Text & "&receivercsdid=" & LabelCFAgentCFPROID.Text & "&cfagentcfproid=" & LabelCFAgentCFPROID.Text, "Send Message")
    End Sub


    Private Sub LoadJob()
        LabelMessage.Text = "Invalid Job ID"
        LabelMessage.ForeColor = Color.Red

        If TextJobID.Text = "" Then
            LabelMessage.Text = "Invalid Job ID, please get a valid Job ID from your C&F Agent"
            LabelMessage.ForeColor = Color.Red
            Exit Sub
        End If
        Dim tmpstr() As String = TextJobID.Text.Split("-")
        ReDim Preserve tmpstr(1)

        Dim JobId As String = tmpstr(0)
        Dim CFAgentCFPROID As String = tmpstr(1)

        Try
            Dim sqlstr As String = _
                    "Select JobId," & _
                     "BL,BLCountry,ID" & _
                    "From Jobs " & _
                    "Where JobId ='" & JobId & "' " & _
                    "And CFAgentCFPROID = '" & CFAgentCFPROID & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)


                LabelBL.Text = drow("BL")
                LabelCountry.Text = drow("BLCountry")

                LabelGoods.Text = drow("Goods")

                Dim sqlstr1 As String = _
                  "Select JobId,ContainerNo,Payload," & _
                  "TEU,Weight,CBM,ID" & _
                  "From JobCargo " & _
                  "Where JobID = '" & JobId & "' " & _
                  "And CFAgentCFPROID = '" & CFAgentCFPROID & "' "


                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                LabelCargoDetails.Text = "Container / Cargo : " & tmptable1.Rows.Count & "  Items "

                If tmptable.Rows.Count = 0 Then
                    drow = tmptable.NewRow
                    drow("Payload") = ""
                    tmptable.Rows.Add(drow)
                End If

                GridJobCargo.DataSource = tmptable1
                GridJobCargo.DataBind()

            End If

        Catch exp As Exception

        End Try

    End Sub

   


    Protected Sub ButtonLodgeClaim0_Click(sender As Object, e As EventArgs) Handles ButtonLodgeClaim0.Click
        Call LoadJob()
    End Sub

    Protected Sub CheckAttachDocuments_CheckedChanged(sender As Object, e As EventArgs) Handles CheckAttachDocuments.CheckedChanged
        PanelAttachments.Visible = CheckAttachDocuments.Checked
    End Sub
End Class


