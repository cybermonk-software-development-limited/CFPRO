﻿Imports System.Globalization
Public Class productaccount
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim CSDID As String = ""


            If CSDID = "" Then
                If Not IsNothing(Request.QueryString("csdid")) Then
                    CSDID = Request.QueryString("csdid")
                End If
            End If

            'check if csdid CFPRO admin' show readonlypage
            LabelCSDID1.Text = CSDID

            Dim CFPROAccountID As String = ""

            If Not IsNothing(Request.QueryString("CFPROAccountid")) Then
                CFPROAccountID = clsEncr.DecryptString(Request.QueryString("CFPROAccountid"))

                If Not CheckAccountAdmins(CFPROAccountID, CSDID) Then
                    If IsNothing(Request.Cookies("CSDAdmin")) Then
                        Response.Redirect("CFPROAccountreadonly.aspx?accits=1&CFPROAccountid=" &
                                           HttpUtility.UrlEncode(clsEncr.EncryptString(CFPROAccountID)))
                    End If
                End If
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", "", "", "", ImageLogo.ImageUrl, True, "cfagent", True)



            Call LoadCountries()
            Call LoadBanks()

            If Not CSDID = "" Then
                CSDID = clsEncr.DecryptString(CSDID)
            End If


            Call LoadCFPROAccount(CFPROAccountID, CFPROID, CSDID)
        End If

        LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

    End Sub


    Private Sub LoadCFPROAccount(ByVal CFPROAccountID As String, CFPROID As String, CSDID As String)

        Try

            Dim tmpstr As String = ""
            Dim tmpstr1 As String = ""

            If IsNothing(Request.QueryString("csdadmin")) Then
                tmpstr = "FROM ProductAccounts, Products,ProductAccountAdmins "
                tmpstr1 = "And ProductAccountAdmins.CFPROAccountID ='" & CFPROAccountID & "' "
            Else
                tmpstr = "FROM ProductAccounts, Products "
            End If

            Dim sqlstr As String = _
               "SELECT CFPROAccounts.CFPROAccountID, " & _
               "CFPROAccounts.CFPROID," & _
               "AccountName, Address, Telephone," & _
               "EmailAddress, City," & _
               "Country, AccountStatus," & _
               "EnableDigitalCommerce, BankName, BankCode," & _
               "BankBranch, BranchCode, BankAccountNo," & _
               "RemmitanceInterval,RemmitanceMinAmount, " &
               "BusinessDescription, BusinessURL," & _
               "MarketerAccountID, CFPROName, " &
               "ImageURL,OnlineURL,LogoURL " &
               tmpstr &
               "Where CFPROAccounts.CFPROAccountID = '" & CFPROAccountID & "' " & _
               tmpstr1 & _
               "And CFPROs.CFPROID = CFPROAccounts.CFPROID "


            Dim tmptable As New DataTable
            tmptable.TableName = "CFPROAccount"


            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim imageurl1 As String = "companyplaceholder.png"
            Dim imageurl As String = "CFPROimage.png"

            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)

                drow = tmptable.Rows(0)

                LabelProductName.Text = drow("CFPROName") & "  CFPRO Account"



                If IO.File.Exists(Server.MapPath(".\") & drow("ImageURL")) Then
                    imageurl = drow("ImageURL")
                End If



                Call LoadBankBranches(drow("BankCode"), False)

                LabelCFPROID.Text = drow("CFPROAccountID")

                'LabelCFPROAccountID1.Text = clsEncr.EncryptString(drow("CFPROAccountID"))
                LabelCSDID1.Text = clsEncr.EncryptString(CSDID)

                LabelAccountStatus.Text = drow("AccountStatus")

                TextAccountName.Text = drow("AccountName")
                TextEmailAddress.Text = drow("EmailAddress")
                TextTelephone.Text = drow("Telephone")

                TextAddress.Text = drow("Address")
                TextCity.Text = drow("City")

                TextBusinessDescription.Text = drow("BusinessDescription")
                TextBusinessURL.Text = drow("BusinessURL")

                ComboBankName.SelectedValue = drow("BankCode")
                TextBankCode.Text = drow("BankCode")


                ComboBankBranch.SelectedValue = drow("BranchCode")
                TextBranchCode.Text = drow("BranchCode")

                TextBankAccountNo.Text = drow("BankAccountNo")

                TextMinimumRemittance.Text = drow("RemmitanceMinAmount")
                CheckEnableCommerce.Checked = drow("EnableDigitalCommerce")

                LabelOnlineURL.Text = drow("OnlineURL")

                If Not Trim(drow("RemmitanceInterval")) = "" Then
                    ComboRemittanceInterval.Text = drow("RemmitanceInterval")
                End If

                If Not Trim(drow("Country")) = "" Then
                    ComboCountry.Text = drow("Country")
                End If



                Dim tmpimg As String = "\businesslogos\" & drow("LogoURL")


                If IO.File.Exists(Server.MapPath(".\") & tmpimg) Then
                    imageurl1 = tmpimg
                    ButtonSetBusinessLogo.Text = "Change Business Logo"
                Else
                    ButtonSetBusinessLogo.Text = "Set Business Logo"
                End If

                Call LoadCFPROAccountItems(CFPROAccountID)
                Call CheckAccountAdmins(CFPROAccountID, CSDID)
            Else


                Dim sqlstr1 As String = _
                   "SELECT CFPROID, ImageURL, CFPROName " & _
                   "From CFPROs " &
                   "Where CFPROID = '" & CFPROID & "'"

                Dim tmptable1 As New DataTable
                Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                If tmptable1.Rows.Count > 0 Then
                    Call clsData.NullChecker(tmptable1, 0)
                    drow = tmptable1.Rows(0)

                    LabelProductName.Text = drow("CFPROName") & "  CFPRO Account"

                    If IO.File.Exists(Server.MapPath(".\") & drow("ImageURL")) Then
                        imageurl = drow("ImageURL")
                    End If


                End If

                ButtonSetBusinessLogo.Text = ""
             

            End If

            Image2.ImageUrl = imageurl
            ImageLogo.ImageUrl = imageurl1


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadCFPROAccountItems(CFPROAccountID As String)

        Try

            Dim sqlstr As String = _
               "SELECT ItemAccountID, ItemStatus, NextPaymentDate," & _
               "CurrentUseCount,PaidUseCount," & _
               "ItemDescription, ItemStatus, AutoRenew, CreditDescription, " & _
               "Amount, MinQuantity, OptionImage," & _
               "PayItems.CFPROID,PayItems.OptionID " & _
               "FROM CFPROAccountItems,PayItems, CFPROOptions " &
               "Where CFPROAccountItems.CFPROAccountID = '" & CFPROAccountID & "' " & _
               "And PayItems.ItemID = CFPROAccountItems.PayItemID " & _
               "And CFPROOptions.CFPROID = PayItems.CFPROID  " &
               "And CFPROOptions.OptionID = PayItems.OptionID  "

            Dim tmptable As New DataTable
            tmptable.TableName = "CFPROAccountItems"


            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer

            Dim col As New DataColumn("RenewTopUp", Type.GetType("System.String"))
            tmptable.Columns.Add(col)

            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    drow("Amount") = drow("Amount") * drow("MinQuantity")
                    drow("RenewTopUp") = drow("CFPROID") & "|" & drow("OptionID")

                    If drow("CreditDescription") = "" Then
                        drow("CreditDescription") = "Normal Subscription / Payment"
                    End If
                    a = a + 1
                Next
        
            End If



            LabelAccountItems.Text = tmptable.Rows.Count & " Account Items"

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelMessage1.Text = ""
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Private Sub LoadBanks()

        Dim sqlstr As String = _
            "SELECT  BankName, BankCode " & _
            "FROM  Banks " & _
            "Order By BankName Asc;"

        Dim tmptable As New DataTable
        tmptable.TableName = "Banks"



        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer

        ComboBankName.Items.Clear()

        If tmptable.Rows.Count > 0 Then
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ComboBankName.Items.Add(drow("BankName"))
                ComboBankName.Items(a).Value = (drow("Bankcode"))
                a = a + 1
            Next

        End If


        ComboBankName.Items.Insert(0, "(Select)")



    End Sub

    Private Sub LoadBankBranches(BankCode As String, showpopup As Boolean)

        Dim sqlstr As String = _
            "SELECT  BranchName, BranchCode " & _
            "FROM  BankBranches " & _
            "Where BankCode = '" & BankCode & "' " &
            "Order By BranchName Asc;"

        Dim tmptable As New DataTable
        tmptable.TableName = "BankBranches"



        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim a As Integer

        ComboBankBranch.Items.Clear()

        If tmptable.Rows.Count > 0 Then
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ComboBankBranch.Items.Add(drow("BranchName"))
                ComboBankBranch.Items(a).Value = (drow("BranchCode"))
                a = a + 1
            Next

        End If

        ComboBankBranch.Items.Insert(0, "(Select)")
        TextBankCode.Text = BankCode
        TextBranchCode.Text = ""
        If showpopup Then
            ModalPopupExtender2.Show()
        End If


    End Sub
    Protected Sub ComboBankName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBankName.SelectedIndexChanged
        Call LoadBankBranches(ComboBankName.Items(ComboBankName.SelectedIndex).Value, True)

    End Sub

    Protected Sub ComboBankBranch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBankBranch.SelectedIndexChanged
        TextBranchCode.Text = ComboBankBranch.Items(ComboBankBranch.SelectedIndex).Value
        ModalPopupExtender2.Show()

    End Sub



    Private Sub LoadCountries()
        Dim slCountry As New SortedList()
        Dim Key As String = ""
        Dim Value As String = ""

        ComboCountry.DataTextField = "Key"
        ComboCountry.DataValueField = "Value"

        For Each info As CultureInfo In CultureInfo.GetCultures(CultureTypes.SpecificCultures)
            Dim info2 As New RegionInfo(info.LCID)
            If Not slCountry.Contains(info2.EnglishName) Then
                Value = info2.EnglishName
                Key = info2.EnglishName
                slCountry.Add(Key, Value)
            End If
        Next

        ComboCountry.DataSource = slCountry
        ComboCountry.DataBind()
        ComboCountry.Items.Insert(0, "(Select)")

    End Sub



    Private Sub BlanksDash(tmptable As DataTable)
        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            For a = 0 To tmptable.Columns.Count - 1
                If Not IsDate(drow(a)) Then
                    If Not IsNumeric(drow(a)) Then
                        If drow(a) = "" Then
                            drow(a) = "--"

                        End If
                    End If
                End If
            Next
        End If
    End Sub


    Protected Sub Button7_Click(sender As Object, e As EventArgs) Handles ButtonSetBusinessLogo.Click
        Call SetBusinessLogo()
    End Sub

    Private Sub SetBusinessLogo()
        iFrame1.Attributes("style") = "height:390px; width:682px;" & LabeliFrameBgStyle.Text
        iFrame1.Attributes("src") = "fileupload.aspx?filetype=businesslogo&CFPROAccountid=" & _
                        HttpUtility.UrlEncode(clsEncr.EncryptString(LabelCFPROID.Text)) & _
                        "&csdid=" & HttpUtility.UrlEncode(Request.QueryString("csdid"))

        ImageLogo.ImageUrl = "companyplaceholder.png"
        ModalPopupExtender1.Show()

    End Sub

    Private Function CheckAccountAdmins(ByVal CFPROAccountID As String, ByVal CSDID As String) As Boolean

        Dim sqlstr As String = _
           "SELECT  CSDID " & _
           "FROM  CFPROAccountAdmins " & _
           "Where CFPROAccountID = '" & CFPROAccountID & "' "

        Dim tmptable As New DataTable
        tmptable.TableName = "CFPROAccount"

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)
        Dim found As Boolean

        Dim a As Integer
        For Each drow In tmptable.Rows
            Call clsData.NullChecker(tmptable, a)

            If drow("CSDID") = CSDID Then
                found = True
            End If
            a = a + 1
        Next

        ' ButtonAccountAdmins.Text = "Account Admins - " & tmptable.Rows.Count

        Return found

    End Function

    Protected Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click
        Call SaveCFPROAccount("accountdetails")
    End Sub
    Private Sub SaveCFPROAccount(ItemsToSave As String)

        LabelCommerceMessage.ForeColor = Drawing.Color.Black
        LabelAccountMessage.ForeColor = Drawing.Color.Black

        LabelAccountMessage.Text = ""
        LabelCommerceMessage.Text = "Digital Commerce Details"



        Dim CFPROAccountID As String = clsEncr.DecryptString(Request.QueryString("CFPROAccountid"))


        Dim sqlstr As String = _
           "SELECT CFPROAccountID,CFPROID, " & _
           "AccountName, Address, Telephone," & _
           "EmailAddress, City," & _
           "Country, AccountStatus," & _
           "EnableDigitalCommerce, BankName,BankCode," & _
           "BankBranch,BranchCode,BankAccountNo," & _
           "RemmitanceInterval,RemmitanceMinAmount, " &
           "BusinessDescription, BusinessURL, ID  " &
           "FROM CFPROAccounts " &
           "Where CFPROAccountID = '" & CFPROAccountID & "' "


        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow As DataRow
        If tmptable.Rows.Count > 0 Then
            drow = tmptable.Rows(0)
        Else
            drow = tmptable.NewRow
            drow("CFPROAccountID") = "GetCFPROAccountID"
            tmptable.Rows.Add(drow)
        End If



        drow("AccountName") = Trim(TextAccountName.Text)
        drow("EmailAddress") = Trim(TextEmailAddress.Text)
        drow("Telephone") = Trim(TextTelephone.Text)

        drow("BusinessDescription") = Mid(Trim(TextBusinessDescription.Text), 1, 355)
        drow("Address") = Trim(TextAddress.Text)
        drow("BusinessURL") = Trim(TextBusinessURL.Text)


        drow("City") = Trim(TextCity.Text)

        If ComboBankName.SelectedIndex > 0 Then
            drow("BankName") = ComboBankName.SelectedItem.ToString
        End If

        drow("BankCode") = Trim(TextBankCode.Text)


        If ComboBankBranch.SelectedIndex > 0 Then
            drow("BankBranch") = ComboBankBranch.SelectedItem.ToString
        End If


        drow("BranchCode") = Trim(TextBranchCode.Text)

        drow("BankAccountNo") = Trim(TextBankAccountNo.Text)


        drow("RemmitanceMinAmount") = Trim(TextMinimumRemittance.Text)

        drow("RemmitanceInterval") = ComboRemittanceInterval.Text

        If ComboCountry.SelectedIndex > 0 Then
            drow("Country") = ComboCountry.Text
        End If

        drow("EnableDigitalCommerce") = CheckEnableCommerce.Checked


        If ItemsToSave = "digitalcommerce" Then
            If Not CheckAgreeToTerms.Checked Then
                LabelCommerceMessage.Text = "You Must Agree to the Terms."
                LabelCommerceMessage.ForeColor = Drawing.Color.Red
                CheckEnableCommerce.Checked = False
                Exit Sub
            End If
        End If

        Call clsData.SaveData("CFPROAccounts", tmptable, sqlstr, False, clsData.constr)

        If ItemsToSave = "digitalcommerce" Then
            ModalPopupExtender2.Show()
        End If



        'If ItemsToSave = "accountdetails" Then
        '    LabelAccountMessage.Text = "Details NOT Saved."
        '    LabelAccountMessage.ForeColor = Drawing.Color.Red

        'ElseIf ItemsToSave = "digitalcommerce" Then
        '    LabelCommerceMessage.Text = "Details NOT Saved."
        '    LabelCommerceMessage.ForeColor = Drawing.Color.Red
        '    ModalPopupExtender2.Show()
        'End If



    End Sub

    Protected Sub ButtonEcommerce_Click(sender As Object, e As EventArgs) Handles ButtonEcommerce.Click
        ModalPopupExtender2.Show()
    End Sub

    Protected Sub ButtonSaveCommerce_Click(sender As Object, e As EventArgs) Handles ButtonSaveCommerce.Click
        Call SaveCFPROAccount("digitalcommerce")

    End Sub


    Protected Sub CheckEnableCommerce_CheckedChanged(sender As Object, e As EventArgs) Handles CheckEnableCommerce.CheckedChanged
        If CheckEnableCommerce.Checked Then
            ModalPopupExtender2.Show()
        End If
    End Sub



    Protected Sub ButtonRenewTopUp_Click(sender As Object, e As EventArgs)
        Dim Button As Button = CType(sender, Button)

        Dim CFPRO() As String = Button.CommandArgument.ToString.Split("|")
        ReDim Preserve CFPRO(1)

        Me.Page.ClientScript.RegisterClientScriptBlock(GetType(String), "", "self.parent.location='CFPROstart.aspx?CFPROid=" & CFPRO(0) & "&optionid=" & CFPRO(1) & "';", True)

    End Sub


    

End Class