﻿Public Class importerjobvisibility
    Inherits System.Web.UI.Page

    Friend Shared TableFilter As DataTable
    Friend Shared RowFilter As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then


            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""

            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "importer", True)

            LabelCFPROID.Text = CFPROID
            LabelCFPROUserID.Text = CFPROUserID

            ComboPredefine.SelectedIndex = 5

            Call GetClientName(CFPROID, CFPROUserID)
            Call PreDefine(ComboPredefine.Text, CFPROID)

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
        End If
    End Sub


    Private Sub GetClientName(CFPROID As String, CFPROUserID As String)
        Dim sqlstr As String = _
                          "Select Clients.Client " & _
                          "FROM CFPROAccountConnect, Clients " & _
                          "Where  CFPROAccountConnect.CFPROID = '" & CFPROID & "' " &
                          "And  Clients.CFPROID = '" & CFPROID & "' " &
                          "And  CFPROAccountConnect.CFPROUserID  = '" & CFPROUserID & "' " &
                          "And  CFPROAccountConnect.Usertype = 'importer' " &
                          "And  CFPROAccountConnect.CFPROUserID =  Clients.ClientID "



        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            LabelImporterHeader.Text = drow("Client") & "'s Consignments"
        End If

    End Sub

    Private Sub LoadJobs(CFPROID As String, CFPROUserID As String, SearchStr As String, Scope As String)
        Try

            Dim tmpstrdate1, tmpstrdate2 As String


            Dim tmpstr As String = ""

            tmpstrdate1 = "'" & TextFromDate.Text & "' "
            tmpstrdate2 = "'" & TextToDate.Text & "' "

            If Not LCase(Scope) = "(all)" Then
                tmpstr = "And Jobs.JobDate >= " & tmpstrdate1 & " " &
                         "And Jobs.JobDate <= " & tmpstrdate2 & " "
            Else
                tmpstr = "And ID > 0 "
            End If

            Dim SortBy As String = nSortOrder()


            Dim tmpstr1 As String = ""


            If SortBy = "JobDate" Then
                tmpstr1 = "Order By JobDate Desc;"

            ElseIf SortBy = "ReferenceNo" Then
                tmpstr1 = "Order By ReferenceNo Desc;"

            ElseIf SortBy = "JobID" Then
                tmpstr1 = "Order By ID Desc;"
            End If




            Dim sqlstr As String = _
                    "Select Top " & ComboSelectTop.Text &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ShipperID," &
                    "BL, CFSID, " &
                    "Goods, VesselID,InvoiceNo, " &
                    "ShippingLineID," &
                    "DispatchDate,JobType," &
                    "UserID, ID " &
                    "From Jobs " & _
                    "Where ClientID = '" & CFPROUserID & "' " &
                    "And CFPROID = '" & CFPROID & "' " &
                    "And ReferenceNo <> '" & "" & "' " &
                    tmpstr & tmpstr1


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            Dim JobDate As String = "1-Jan-1900"
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(tmptable.Rows.Count - 1)
                JobDate = drow("JobDate")
            End If



            Dim sqlstr1 As String =
                  "Select JobCargo.JobID,ContainerNo," &
                   "JobCargo.TEU, JobCargo.CBM," &
                   "JobCargo.Weight, ContainerStatus," &
                   "ReturnDate, JobCargo.ID " &
                   "From JobCargo, Jobs " &
                   "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                   "And JobCargo.JobID = Jobs.JobID " &
                   tmpstr

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)



            Dim sqlstr2 As String =
                    "Select CFS,CFSID " &
                    "From CFS " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)

            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)



            Dim sqlstr4 As String = _
               "Select JobProgress.JobID, JobProgress.Status," & _
               "JobProgress.UserID,JobProgress.Date," & _
               "JobProgress.ID " & _
               "From JobProgress,Jobs " & _
               "Where JobProgress.CFPROID = '" & CFPROID & "' " & _
               "And Jobs.CFPROID = '" & CFPROID & "' " & _
              "And JobProgress.JobID = Jobs.JobID " &
               tmpstr &
               "Order By Date Desc;"

            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstr4, tmptable4, clsData.constr)
            Dim dv4 As New DataView(tmptable4)


            Dim sqlstr6 As String = _
                      "Select UserCSDID,CFPROuserID " & _
                      "FROM CFPROAccountConnect " & _
                      "Where  CFPROID = '" & CFPROID & "' "

            Dim tmptable6 As New DataTable
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim sqlstr7 As String =
                  "Select ShipperID, Shipper " &
                  "From Shippers " &
                  "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)


            Dim a, b, c As Integer

            Dim tmpdate As Date = Now
            Dim found As Boolean
            Dim tmpstr3() As String


            Dim col1 As New DataColumn("JobCount", Type.GetType("System.String"))
            Dim col2 As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col3 As New DataColumn("Shipper", Type.GetType("System.String"))
            Dim col4 As New DataColumn("JobView", Type.GetType("System.String"))

            Dim col5 As New DataColumn("Vessel", Type.GetType("System.String"))
            Dim col6 As New DataColumn("ShippingLine", Type.GetType("System.String"))
            Dim col7 As New DataColumn("VesselETA", Type.GetType("System.String"))
            Dim col8 As New DataColumn("BerthingDate", Type.GetType("System.String"))
            Dim col9 As New DataColumn("LastSlingDate", Type.GetType("System.String"))

            Dim col10 As New DataColumn("UserImageURL", Type.GetType("System.String"))
            Dim col11 As New DataColumn("UserNames", Type.GetType("System.String"))
            Dim col12 As New DataColumn("ContainerNos", Type.GetType("System.String"))

            Dim col13 As New DataColumn("CBM", Type.GetType("System.Double"))
            Dim col14 As New DataColumn("Weight", Type.GetType("System.Double"))
            Dim col15 As New DataColumn("CFS", Type.GetType("System.String"))

            Dim col16 As New DataColumn("DaysTaken", Type.GetType("System.Double"))

            Dim col17 As New DataColumn("RemainingDays", Type.GetType("System.Double"))
            Dim col18 As New DataColumn("Containers", Type.GetType("System.Double"))

            Dim col19 As New DataColumn("Status", Type.GetType("System.String"))
            Dim col20 As New DataColumn("Visible", Type.GetType("System.Boolean"))

            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)

            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)
            tmptable.Columns.Add(col10)
            tmptable.Columns.Add(col11)

            tmptable.Columns.Add(col12)
            tmptable.Columns.Add(col13)
            tmptable.Columns.Add(col14)
            tmptable.Columns.Add(col15)
            tmptable.Columns.Add(col16)

            tmptable.Columns.Add(col17)
            tmptable.Columns.Add(col18)

            tmptable.Columns.Add(col19)
            tmptable.Columns.Add(col20)

            Dim CBM, Weight, TEU As Double

            Dim UserImageURL As String = ""

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)


                drow("ReferenceNo") = Mid(drow("ReferenceNo"), 1, 25) & " " & Mid(drow("ReferenceNo1"), 1, 25)
                drow("JobView") = "progressreport.aspx?loadedbyimporter=1&jobid=" & drow("JobID")
                drow("Visible") = 1
                found = False
                tmpdate = Now

                '......


                dv1.RowFilter = "JobID = " & "'" & drow("JobID") & "'"
                drow("Containers") = dv1.Count

                ' drow("Goods") = Mid(drow("Goods"), 1, 50)

                c = 0
                TEU = 0
                CBM = 0
                Weight = 0

                ReDim tmpstr3(c)
                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)

                    ReDim Preserve tmpstr3(c)
                    tmpstr3(c) = dv1(b)("ContainerNo")
                    c = c + 1

                    CBM = CBM + dv1(b)("CBM")
                    Weight = Weight + dv1(b)("Weight")
                    TEU = TEU + Val(dv1(b)("TEU"))
                Next

                drow("ContainerNos") = Join(tmpstr3, " ")

                drow("TEU") = TEU
                drow("CBM") = CBM
                drow("Weight") = Weight



                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("CFS") = dv2(0)("CFS")
                End If

                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")
                    drow("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), drow("DispatchDate"))

                End If



                dv4.RowFilter = "JobID = " & "'" & drow("JobID") & "' "

                If dv4.Count > 0 Then
                    drow("Status") = dv4(0)("Status")
                End If


                'dv6.RowFilter = "CFPROUserID = '" & drow("UserID") & "' "

                'If dv6.Count > 0 Then
                '    If File.Exists(Server.MapPath("~/userimages/" & dv6(0)("UserCSDID") & ".png")) Then
                '        UserImageURL = "~/userimages/" & dv6(0)("UserCSDID") & ".png"
                '    ElseIf File.Exists(Server.MapPath("~/userimages/" & dv6(0)("UserCSDID") & ".jpg")) Then
                '        UserImageURL = "~/userimages/" & dv6(0)("UserCSDID") & ".jpg"
                '    Else
                '        UserImageURL = "imageplaceholder.png"
                '    End If
                'Else
                '    UserImageURL = "imageplaceholder.png"
                'End If


                'drow("UserImageURL") = UserImageURL



                dv7.RowFilter = "ShipperID = " & "'" & drow("ShipperID") & "' "

                If dv7.Count > 0 Then
                    drow("Shipper") = Mid(dv7(0)("Shipper"), 1, 30)
                End If


                a = a + 1

                drow("JobCount") = a & "."

            Next


            Session("ImporterJobs") = tmptable

            Call Calctotal(tmptable)

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                drow("Visible") = 0
                tmptable.Rows.Add(drow)
            End If


            If tmptable.Rows.Count > 8 Then
                PanelJobs.Height = 355
            Else
                PanelJobs.Height = Nothing
            End If


            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelMessage1.Text = ""

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub





    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()

        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)

    End Sub


    Private Sub Calctotal(tmptable As DataTable)
        Try

            Dim dv As DataView = tmptable.DefaultView
            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Containers")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")
            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String
            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text
            Else
                tmpstr = "All Jobs In System"
            End If


            LabelReportCaption.Text = dv.Count & " Consignments: " &
                                        TextFromDate.Text & " | " & tmpstr




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Function nSortOrder() As String

        Select Case RadioButtonList1.SelectedIndex
            Case 0
                Return "JobDate"
            Case 1
                Return "ReferenceNo"
            Case 2
                Return "JobId"
            Case -1
                Return "JobDate"
        End Select

    End Function

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)

    End Sub

    Private Sub PreDefine(ByVal Selection As String, CFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day



            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""

                    Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 3 months"

                    Dim tmpstr(12) As String
                    tmpstr(1) = "Jan"
                    tmpstr(2) = "Feb"
                    tmpstr(3) = "Mar"
                    tmpstr(4) = "Apr"
                    tmpstr(5) = "May"
                    tmpstr(6) = "Jun"
                    tmpstr(7) = "Jul"
                    tmpstr(8) = "Aug"
                    tmpstr(9) = "Sep"
                    tmpstr(10) = "Oct"
                    tmpstr(11) = "Nov"
                    tmpstr(12) = "Dec"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")


            Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call LoadJobs(LabelCFPROID.Text, LabelCFPROUserID.Text, "", ComboPredefine.Text)
    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonSearch_Click1(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        Dim dv As New DataView(TableFilter)

        dv.RowFilter = "ReferenceNo Like '%" & Trim(SearchStr) & "'% " &
                       "Or ContainerNos Like '%" & Trim(SearchStr) & "'% " &
                        "Or Goods Like '%" & Trim(SearchStr) & "'% " &
                        "Or BL Like '%" & Trim(SearchStr) & "'% "

        DataList1.DataSource = dv
        DataList1.DataBind()

        LabelReportCaption.Text = dv.Count & " Consignments Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

    End Sub


    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExportToExcel()

    End Sub
    Private Sub ExportToExcel()


        Dim tmpfields(8) As String
        tmpfields(0) = "ReferenceNo"
        tmpfields(1) = "JobDate"
        tmpfields(2) = "Shipper"
        tmpfields(3) = "Goods"
        tmpfields(4) = "VesselETA"
        tmpfields(5) = "CFS"
        tmpfields(6) = "BL"
        tmpfields(7) = "RemainingDays"
        tmpfields(8) = "Status"



        Dim tmptable As DataTable = Session("ImporterJobs")
        Call clsExportToExcel.ExportToExcel("", "", "", LabelImporterHeader.Text, LabelImporterHeader.Text,
                                            LabelReportCaption.Text, False, Nothing, 0, "", tmpfields, Nothing, tmptable, False)

    End Sub




    Private Sub CompoundFilter(ByVal Importer As Boolean, ByVal CFS As Boolean)

        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer
            Dim dv As DataView = New DataView(TableFilter)
            dv.Sort = Nothing
            dv.RowFilter = Nothing


            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipperID = " & "'" & LabelShipperID.Text & "' "
                End If

                tmpstr1(a) = "Shipper: " & TextShipper.Text
                b = b + 1
            End If



            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFSID =" & "'" & LabelCFSID.Text & "' "
                Else
                    tmpstr(a) = " And CFSID = " & "'" & LabelCFSID.Text & "' "
                End If

                tmpstr1(a) = "CFS: " & TextCFS.Text.ToString
                b = b + 1
            End If



            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2
            RowFilter = tmpstr2

            DataList1.DataSource = dv
            DataList1.DataBind()


            LabelReportCaption.Text = dv.Count & " Consignments: " & tmpstr3 & " | " & TextFromDate.Text & " to " & TextToDate.Text



            'Call Calctotal(tm)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
            'MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub

    Protected Sub ButtonSearchConsignee_Click(sender As Object, e As EventArgs) Handles ButtonSearchConsignee.Click
        CheckImporter.Checked = True
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "shipper", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonSearchCFS_Click(sender As Object, e As EventArgs) Handles ButtonSearchCFS.Click
        CheckCFS.Checked = True
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "cfs", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub

    Protected Sub ButtonApplyDates0_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates0.Click
        Call CompoundFilter(CheckImporter.Checked, CheckCFS.Checked)
    End Sub


    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender, LabelItem.Text)
    End Sub

    Private Sub SetItem(sender As Object, ItemType As String)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If ItemType = "cfs" Then
            LabelCFSID.Text = ItemID
            TextCFS.Text = Item

        ElseIf ItemType = "consignee" Then
            LabelShipperID.Text = ItemID
            TextShipper.Text = Item
        End If
        ModalPopupExtender2.Hide()


    End Sub




    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItem.Text = "consignee" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearch.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        Else
            Call clsGetIdentities.SearchCFS(LabelCFPROID.Text, Trim(TextSearch.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, LabelMessage1.Text)
        End If
    End Sub
End Class