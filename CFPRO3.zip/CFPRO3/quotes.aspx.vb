﻿Public Class quotes
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            Dim Usertype As String = Request.QueryString("usertype")
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""



            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)

            LabelCFPROID.Text = CFPROID

            Dim ClientID As String = Request.QueryString("clientid")
            Call LoadJobTypes(CFPROID)

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, CFPROID)
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If



    End Sub

    Private Sub LoadQuotes(CFPROID As String)

        Try

            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = " And QuoteDate >= '" & TextFromDate.Text & "' " &
                  " And Quotedate <= '" & TextToDate.Text & "' "
            Else

                tmpstr = " And ID > 0 "
            End If


            Dim sqlstr As String =
                "SELECT QuoteID," &
                "QuoteNo,Client, " &
                "QuoteDate, CurrencyID,Total, " &
                "SubTotal,ApplyVAT,PDFQuoteName, " &
                "VATinclusive,VATAmount, " &
                "CurrencyRate, JobTypeID, " &
                "QuoteHeader.CFPROID,QuoteHeader.ID " &
                "From QuoteHeader,Clients " &
                "Where QuoteHeader.ClientID = Clients.ClientID " &
                "And QuoteHeader.CFPROID  = '" & CFPROID & "' " &
                 "And Clients.CFPROID  = '" & CFPROID & "' " &
                 tmpstr &
                 "Order by QuoteHeader.ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr2 As String =
              "Select CurrencyID, CurrencyCode " &
              "FROM Currencies "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            Dim col1 As New DataColumn("QuoteDet", Type.GetType("System.String"))
            Dim col2 As New DataColumn("JobUrl", Type.GetType("System.String"))
            Dim col3 As New DataColumn("CurrencyCode", Type.GetType("System.String"))
            Dim col4 As New DataColumn("JobType", Type.GetType("System.String"))
            Dim col5 As New DataColumn("ReferenceNo", Type.GetType("System.String"))
            Dim col6 As New DataColumn("ViewQuotePDF", Type.GetType("System.String"))


            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            Dim a As Integer
            Dim drow As DataRow



            a = 0

            Dim dv2 As New DataView(tmptable2)

            If tmptable.Rows.Count > 0 Then
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    drow("JobUrl") = "JobeEntry.aspx?JobID=" & drow("JobID")
                    drow("ViewQuotePDF") = "View PDF"
                    drow("QuoteDet") = "quoteid=" & drow("QuoteID")
                    dv2.RowFilter = "CurrencyID = '" & drow("CurrencyID") & "' "

                    drow("JobType") = clsGetIdentities.SetJobType(drow("JobTypeID"), CFPROID)

                    'If drow("JobType") = "" Then
                    '    drow("ReferenceNo") = "None"
                    'End If

                    If dv2.Count > 0 Then
                        Call clsData.NullChecker1(dv2, 0)
                        drow("CurrencyCode") = dv2(0)("CurrencyCode")
                    End If
                    a = a + 1
                Next
            End If


            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("QuoteNo") = "No Quotes"
                tmptable.Rows.Add(drow)
            End If


            Session("QuotesTable") = tmptable

            Dim dv As New DataView(tmptable)
            Call CalcTotal(dv, "")

            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = nSortOrder()

            If SortBy = "QuoteDate" Then
                dv.Sort = "QuoteDate " & tmpstrSort

            ElseIf SortBy = "QuoteID" Then
                dv.Sort = "ID " & tmpstrSort


            End If

            LabelFilterStr.Text = dv.RowFilter
            LabelSortStr.Text = dv.Sort

            GridQuotes.DataSource = dv
            GridQuotes.DataBind()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub



    Private Sub LoadJobTypes(CFPROID As String)
        Dim sqlstr As String =
         "Select JobType, JobTypeID " &
         "From JobTypes " &
         "Where CFPROID = '" & CFPROID & "' "

        Call clsData.PopComboWithValue(ComboJobType, sqlstr, clsData.constr, 0, 1)
        ComboJobType.Items.Insert(0, "(All)")

    End Sub

    Protected Sub ButtonSearchClient_Click(sender As Object, e As EventArgs) Handles ButtonSearchClient.Click
        Call clsGetIdentities.LoadItems(LabelCFPROID.Text, "client", DataList2, LabelItemType, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
    End Sub





    Private Sub CalcTotal(dv As DataView, tmpcaption As String)
        Try


            Dim a As Integer
            Dim Amount, TotalTax, Total As Double


            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)

                           Amount = Amount + dv(a)("SubTotal")
                TotalTax = TotalTax + dv(a)("VATAmount")
                Total = Total + dv(a)("Total")


            Next


            TextSubTotal.Text = Format(Amount, "#,##0.00")
            TextTotalTax.Text = Format(TotalTax, "#,##0.00")
            TextTotal.Text = Format(Total, "#,##0.00")


            Dim tmpstr As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text
            End If

            If tmpcaption = "" Then
                LabelReportCaption.Text = dv.Count & " Quotes : " & " | " & tmpstr
            Else
                LabelReportCaption.Text = dv.Count & " Quotes: " & " " & tmpcaption & " | " & tmpstr
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True)
    End Sub


    Protected Sub LinkQuoteNo_Click(sender As Object, e As EventArgs)

        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim tmpstr As String = linkbutton.CommandArgument.ToString

        Call LoadDialog("quote.aspx?" & tmpstr, "Quote", 665, 980)

    End Sub

    Protected Sub ButtonNewQuote_Click(sender As Object, e As EventArgs) Handles ButtonNewQuote.Click
        Call LoadDialog("quote.aspx?qouteid=1", "Quote", 665, 980)
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl


        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender1.Y = 40
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender1.Y = 100
        Else
            ModalPopupExtender1.Y = -1
        End If


        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadQuotes(LabelCFPROID.Text)
    End Sub

    Protected Sub LinkSelectedItem_Click(sender As Object, e As EventArgs)
        Call SetItem(sender)
    End Sub

    Private Sub SetItem(sender As Object)

        Dim link As LinkButton = CType(sender, LinkButton)
        Dim ItemID As String = link.CommandArgument.ToString
        Dim Item As String = link.Text

        If LabelItemType.Text = "Search / Select Client" Then
            LabelClientID.Text = ItemID
            TextClient.Text = Item
            CheckClient.Checked = True
        End If

        ModalPopupExtender2.Hide()

    End Sub



    Private Sub PreDefine(ByVal Selection As String, CFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadQuotes(CFPROID)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetCurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2



                Case "last 3 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadQuotes(CFPROID)


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyFilters_Click(sender As Object, e As EventArgs) Handles ButtonApplyFilters.Click
        Call CompoundFilter(CheckClient.Checked, CheckQuoteStatus.Checked,
                                 CheckJobType.Checked, LabelMessage1.Text)
    End Sub

    Private Sub CompoundFilter(client As Boolean, quotestatus As Boolean,
                              QuoteType As Boolean, Optional ByRef ErrMsg As String = "")
        Try


            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer


            If IsNothing(Session("QuoteQuotes")) Then
                Call LoadQuotes(LabelCFPROID.Text)
            End If

            Dim tmptable As DataTable = Session("QuoteQuotes")

            Dim dv As New DataView(tmptable)
            'dv.Sort = Nothing
            'dv.RowFilter = Nothing



            If client Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                tmpstr(a) = "ClientID = '" & Trim(LabelClientID.Text) & "' "
                tmpstr1(a) = "Client: " & TextClient.Text
                b = b + 1


            End If

            If quotestatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)

                If ComboQuoteStatus.SelectedItem.Text = "With Quote" Then
                    If b = 0 Then
                        tmpstr(a) = "QuoteID <> 'Not Quoted' "
                    Else
                        tmpstr(a) = " And QuoteID <> 'Not Quoted' "
                    End If

                ElseIf ComboQuoteStatus.SelectedItem.Text = "Without Quote" Then
                    If b = 0 Then
                        tmpstr(a) = "QuoteID = 'Not Quoted' "
                    Else
                        tmpstr(a) = " And QuoteID = 'Not Quoted' "
                    End If

                End If

                tmpstr1(a) = "Quote Status: " & UCase(ComboQuoteStatus.Text)
                b = b + 1
            End If


            If QuoteType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "QuoteTypeID = '" & ComboJobType.SelectedValue & "' "
                Else
                    tmpstr(a) = " And QuoteTypeID = '" & ComboJobType.SelectedValue & "' "
                End If

                tmpstr1(a) = "QuoteType: " & ComboJobType.SelectedItem.ToString
                b = b + 1
            End If



            If quotestatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "QuoteStatus Like '%" & Trim(ComboQuoteStatus.Text) & "%' "
                Else
                    tmpstr(a) = " And QuoteStatus Like '%" & Trim(ComboQuoteStatus.Text) & "%' "
                End If

                tmpstr1(a) = "Quote Status : " & ComboQuoteStatus.Text
                b = b + 1
            End If





            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, " ")


            dv.RowFilter = tmpstr2

            GridQuotes.DataSource = dv
            GridQuotes.DataBind()


            LabelFilterStr.Text = tmpstr2
            LabelReportCaption.Text = dv.Count & " Quotes"


            Call CalcTotal(dv, tmpstr3)

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In Panel1.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedQuoteHeader" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddQuoteDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub
    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click
        Call ExportToExcel()
    End Sub

    Private Sub ExportToExcel()

        Dim totals(4) As String


        totals(0) = "Sub Total: " & TextSubTotal.Text
        totals(1) = "Total Tax: " & TextTotalTax.Text
        totals(2) = "Total Amount : " & TextTotal.Text


        Dim tmpfields(11) As String
        tmpfields(0) = "ReferenceNo"
        tmpfields(1) = "Client"
        tmpfields(2) = "QuoteDate"
        tmpfields(3) = "QuoteNo"
        tmpfields(4) = "CurrencyCode"
        tmpfields(5) = "QuoteDate"
        tmpfields(6) = "SubTotal"
        tmpfields(7) = "VATAmount"
        tmpfields(8) = "Total"


        Dim tmpfields1(11) As String
        tmpfields1(0) = "ReferenceNo"
        tmpfields1(1) = "Client"
        tmpfields1(2) = "Quote Date"
        tmpfields1(3) = "QuoteNo"
        tmpfields1(4) = "Currency"
        tmpfields1(5) = "Quote Date"
        tmpfields1(6) = "SubTotal"
        tmpfields1(7) = "VATAmount"
        tmpfields1(8) = "Total"


        Dim tmptable As DataTable = Session("QuotesTable")

        Call clsExportToExcel.ExportToExcel("", LabelFilterStr.Text, LabelSortStr.Text, "Quote Items", "Quote Items",
                                             LabelReportCaption.Text, True, totals, 0, "", tmpfields, tmpfields1, tmptable, False)

    End Sub


    Protected Sub ButtonApplySort_Click(sender As Object, e As EventArgs) Handles ButtonApplySort.Click
        Call ApplySort(Nothing, True)
    End Sub

    Private Sub ApplySort(dv As DataView, Databind As Boolean)


        If dv Is Nothing Then

            If IsNothing(Session("QuoteQuotes")) Then
                Call LoadQuotes(LabelCFPROID.Text)
            End If

            Dim QuoteHeaderTable As DataTable = Session("QuoteQuotes")
            dv = New DataView(QuoteHeaderTable)
        End If


        Dim tmpstrSort As String


        If ComboSortOrder.Text = "Z-A" Then
            tmpstrSort = " DESC"
        Else
            tmpstrSort = " ASC"
        End If

        Dim SortBy As String = nSortOrder()

        If SortBy = "QuoteDate" Then
            dv.Sort = "QuoteDate " & tmpstrSort

        ElseIf SortBy = "ReferenceNo" Then
            dv.Sort = "ReferenceNo " & tmpstrSort

        ElseIf SortBy = "QuoteDate" Then
            dv.Sort = "QuoteDate " & tmpstrSort

        ElseIf SortBy = "QuoteId" Then
            dv.Sort = "ID " & tmpstrSort

        End If

        LabelSortStr.Text = dv.Sort

        If Not LabelFilterStr.Text = "" Then
            dv.RowFilter = LabelFilterStr.Text
        End If


        If Databind Then
            GridQuotes.DataSource = dv
            GridQuotes.DataBind()
        End If

        If LabelFilterStr.Text = "" Then
            Call CalcTotal(dv, "")
        End If

    End Sub

    Private Function nSortOrder() As String
        If RadioButtonList1.SelectedIndex = 0 Then
            Return "QuoteDate"
        ElseIf RadioButtonList1.SelectedIndex = 1 Then
            Return "QuoteDate"
        ElseIf RadioButtonList1.SelectedIndex = 2 Then
            Return "ReferenceNo"
        ElseIf RadioButtonList1.SelectedIndex = 3 Then
            Return "QuoteID"
        Else
            Return "QuoteDate"
        End If
    End Function

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call Search(TextSearch.Text)
    End Sub

    Private Sub Search(SearchStr As String)

        If IsNothing(Session("QuoteQuotes")) Then
            Call LoadQuotes(LabelCFPROID.Text)
        End If

        Dim tmptable As DataTable = Session("QuoteQuotes")
        Dim dv As DataView = New DataView(tmptable)

        dv.RowFilter = " (ReferenceNo Like '%" & Trim(SearchStr) & "%' " &
                        "Or ReferenceNo1 Like '%" & Trim(SearchStr) & "%' " &
                        "Or Client Like '%" & Trim(SearchStr) & "%' " &
                        "Or BL Like '%" & Trim(SearchStr) & "%') "

        GridQuotes.DataSource = dv
        GridQuotes.DataBind()

        LabelFilterStr.Text = dv.RowFilter

        LabelReportCaption.Text = dv.Count & " QuoteHeader Found Matching " & " " & Trim(SearchStr) & " | " & TextFromDate.Text & " to " & TextToDate.Text

        LabelFilterStr.Text = dv.RowFilter

        Dim tmpstr As String = "Found Matching " & " " & Trim(SearchStr)

        Call CalcTotal(dv, tmpstr)

    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadQuotes(LabelCFPROID.Text)
    End Sub

    Protected Sub ButtonSearchItem_Click(sender As Object, e As EventArgs) Handles ButtonSearchItem.Click
        If LabelItemType.Text = "Search / Select Client" Then
            Call clsGetIdentities.SearchClient(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Agent" Then
            Call clsGetIdentities.SearchAgent(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        ElseIf LabelItemType.Text = "Search / Select Consignee / Importer" Then
            Call clsGetIdentities.SearchImporter(LabelCFPROID.Text, Trim(TextSearchItem.Text), DataList2, LabelItemMessage, LabelItemHeader, ModalPopupExtender2, , LabelMessage1.Text)
        End If

    End Sub

    Protected Sub LinkQuotePDF_Click(sender As Object, e As EventArgs)

    End Sub
End Class

