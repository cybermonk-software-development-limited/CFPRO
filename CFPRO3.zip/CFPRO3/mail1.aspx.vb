﻿
Imports System.Data
Imports System.Drawing
Imports System.IO
Imports System.Net
Imports System.Net.Mail
Imports System.Web.UI.HtmlControls
Imports OfficeOpenXml

Public Class mail1
    Inherits System.Web.UI.Page
    Dim bytes As Byte()
    Dim attachmentName As String = "Attachment"
    Shared itemId As String = ""
    Dim userName As String = ""
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then

            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            If Request.QueryString("msgSender") IsNot Nothing Then
                TextFrom.Text = Request.QueryString("msgSender")
            End If

            If Request.QueryString("msgReceiver") IsNot Nothing Then
                TextTo.Text = Request.QueryString("msgReceiver")
            End If

            If Request.QueryString("msgSubject") IsNot Nothing Then
                TextSubject.Text = Request.QueryString("msgSubject")
            End If

            If Request.QueryString("msgBody") IsNot Nothing Then
                TextMessageBody.Text = Request.QueryString("msgBody")
            End If

            If Request.QueryString("attachmentName") IsNot Nothing Then
                attachmentName = Request.QueryString("attachmentName")
                lblAttachments.Text = Request.QueryString("attachmentName")
            End If

            If Request.QueryString("msgAttachment") IsNot Nothing Then
                'bytes = Request.QueryString("msgAttachment").ToArray
            End If

            If Request.QueryString("itemId") IsNot Nothing Then
                itemId = Request.QueryString("itemId")
            End If

            If Request.QueryString("userName") IsNot Nothing Then
                userName = Request.QueryString("userName")
            End If

        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim mm As New MailMessage(TextFrom.Text, TextTo.Text)
            mm.Subject = TextSubject.Text
            mm.Body = TextMessageBody.Text
            bytes = clsReleaseOrderPDF.ReleaseOrderEmail(attachmentName, itemId, userName)
            mm.Attachments.Add(New Attachment(New MemoryStream(bytes), attachmentName))
            mm.IsBodyHtml = True
            Dim smtp As New SmtpClient()
            smtp.Host = "smtp.gmail.com"
            smtp.EnableSsl = True
            Dim NetworkCred As New NetworkCredential()
            NetworkCred.UserName = "wssilverpg@gmail.com"
            NetworkCred.Password = "1236silver"
            smtp.UseDefaultCredentials = True
            smtp.Credentials = NetworkCred
            smtp.Port = 587
            smtp.Send(mm)
            lblMessages.ForeColor = Color.Green
            lblMessages.Text = "Message Sent Successfully!"
        Catch ex As Exception
            lblMessages.ForeColor = Color.Red
            lblMessages.Text = "There was an error sending the message."
        End Try
    End Sub

End Class