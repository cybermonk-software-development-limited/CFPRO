﻿Imports System.Net
Imports System.IO
Imports System.Web.Script.Serialization


Public Class clsReCaptcha

    Shared Function ValidateReCaptcha(SecretKey As String, Response As String, ByRef errmsg As String) As Boolean

        Dim Valid As Boolean = False
        'Request to Google Server

        Dim req As HttpWebRequest = DirectCast(WebRequest.Create("https://www.google.com/recaptcha/api/siteverify?secret=" & SecretKey & "&response=" & Response), HttpWebRequest)
        Try
            'Google recaptcha Response
            Using wResponse As WebResponse = req.GetResponse()


                Using readStream As New StreamReader(wResponse.GetResponseStream())
                    Dim jsonResponse As String = readStream.ReadToEnd()
                    errmsg = jsonResponse
                    Dim js As New JavaScriptSerializer()
                    Dim ReCaptchaData As clsReCaptcha = js.Deserialize(Of clsReCaptcha)(jsonResponse)
                    ' Deserialize Json
                    Valid = Convert.ToBoolean(ReCaptchaData.success)
                End Using
            End Using


            Return Valid
        Catch exp As WebException
            errmsg = exp.Message
        End Try
    End Function

    Public Property success() As String
        Get
            Return m_success
        End Get

        Set(value As String)
            m_success = value
        End Set
    End Property
    Private m_success As String
End Class
