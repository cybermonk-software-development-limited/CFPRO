﻿

Imports System.IO
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Public Class clsReleaseOrderPDF

    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, color As Drawing.Color, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75

        contentByte.SetRGBColorStroke(color.R, color.G, color.B)

        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x2, 842 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, color As Drawing.Color, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.SetRGBColorStroke(color.R, color.G, color.B)
        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - (y1 + height))
        contentByte.LineTo(x1, 842 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 842 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    'Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
    '    contentByte.MoveTo(x1, y1)
    '    contentByte.LineTo(x2, y2)
    '    contentByte.Stroke()
    'End Sub
    'Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
    '    contentByte.MoveTo(x1, y1)
    '    contentByte.LineTo(x1 + width, y1)
    '    contentByte.LineTo(x1 + width, y1 + height)
    '    contentByte.LineTo(x1, y1 + height)
    '    'Path closed And stroked
    '    contentByte.ClosePathStroke()
    'End Sub

    'Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)

    '    contentByte.SetRGBColorFill(color.R, color.G, color.B)
    '    contentByte.BeginText()
    '    contentByte.SetFontAndSize(font.BaseFont, font.Size)
    '    contentByte.SetTextMatrix(x1, y1)
    '    contentByte.ShowText(nString)
    '    contentByte.EndText()


    'End Sub
    Shared Function ReleaseOrderDoc(ROPDFName As String, releaseOrderId As String, userName As String) As Byte()

        Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
        Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
        Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
        Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
        Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

        Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)

        Dim small As New Font(customfont, 5)
        Dim font6 As New Font(customfont, 6)
        Dim font6b As New Font(customfontb, 6.4)
        Dim font7b As New Font(customfontb, 7.4)

        Dim font7 As New Font(customfont, 7)

        Dim font8 As New Font(customfontb, 8)
        Dim font8i As New Font(customfonti, 8)
        Dim font8b As New Font(customfontb, 8)
        Dim font9 As New Font(customfont, 9)
        Dim font11c As New Font(customfontc, 10.5)
        Dim font10b As New Font(customfontb, 10)

        Dim arial8 As New Font(customfont, 8)

        Dim FontMark As Font
        Dim Mark As String
        FontMark = New Font(customfontm, 14)
        Mark = "P"

        Dim brush1 As Drawing.Color = Drawing.Color.Black
        Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
        'Dim PDFReader As PdfReader = Nothing 'Read File

        ' Document starts here

        Dim regdocpath As String = HttpContext.Current.Server.MapPath(".") & "\regdocs\" & ROPDFName & ".pdf"
        Dim doclogospath As String = HttpContext.Current.Server.MapPath(".") & "\cfslogos\cfproonlinelogo.png"
        Dim docwatermarkpath As String = HttpContext.Current.Server.MapPath(".") & "\cfslogos\cfprowatermark.png"
        Dim signaturepath As String = HttpContext.Current.Server.MapPath(".") & "\cfssignatures\sign1.png"

        Dim ReleaseOrderPDF As New Document(PageSize.A4, 0, 0, 0, 50)

        'Using Fstream As New FileStream(savepath, FileMode.Create)

        Using memoryStream As New System.IO.MemoryStream()



            Dim Writer As PdfWriter = PdfWriter.GetInstance(ReleaseOrderPDF, memoryStream)


            ReleaseOrderPDF.Open()
            If File.Exists(doclogospath) Then
                Dim logo As Image = Image.GetInstance(doclogospath)
                logo.ScaleToFit(172, 43.35)
                logo.SetAbsolutePosition(205, 788)
                ReleaseOrderPDF.Add(logo)
            End If


            If File.Exists(docwatermarkpath) Then
                Dim watermark As Image = Image.GetInstance(docwatermarkpath)
                watermark.ScaleToFit(400, 227)
                watermark.SetAbsolutePosition(100, 294)
                ReleaseOrderPDF.Add(watermark)
            End If

            Dim sqlstr As String =
             "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFSID, ID " &
             "From ReleaseOrders " &
             "Where ReleaseOrderId= '" & releaseOrderId & "'"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr, tmptable1, clsData.constr)
            Dim releaseOrderDv = New DataView(tmptable1)

            Dim sqlstr2 As String =
             "Select	UserID,RecordId," &
            "RecordID1, MarksNos,RecordDate, " &
            "DescriptionofGoods,[Weight]," &
            "CubicMeters,SeaFreightCharges,Id " &
            "From ReleaseOrderGoods " &
            "Where RecordId ='" & releaseOrderId & "'"

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim releaseOrderGoodsDv = New DataView(tmptable2)

            'logo added

            'Create line pens


            Dim pen As PdfContentByte = Writer.DirectContent
            Dim pen1 As PdfContentByte = Writer.DirectContent
            Dim pen2 As PdfContentByte = Writer.DirectContent

            Dim pencolor As Drawing.Color = Drawing.Color.FromArgb(102, 102, 102)


            pen.SetLineWidth(0)
            pen1.SetLineWidth(0.5)
            pen2.SetLineWidth(0.5)


            Dim StringWriter As PdfContentByte = Writer.DirectContent

            'DrawString("VAT No. XXXXXXXX", font7b, Drawing.Color.Black, 20, 40, StringWriter)
            DrawString("PIN No. XXXXXXXXXXX", font7b, Drawing.Color.Black, 20, 55, StringWriter)
            DrawString("RO #" & releaseOrderId, font7b, Drawing.Color.Black, 680, 55, StringWriter)
            DrawRectangle(pen1, pencolor, 20, 75, 753, 1027)

            DrawString("1. Importers Name Address", font7, Drawing.Color.Black, 25, 80, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Importer")) Then
                DrawString(releaseOrderDv(0)("Importer"), arial8, brush2, 25, 95, StringWriter)
            End If
            If Not IsDBNull(releaseOrderDv(0)("ImporterAddress")) Then
                DrawString(releaseOrderDv(0)("ImporterAddress"), arial8, brush2, 25, 110, StringWriter)
            End If

            DrawLine(pen1, pencolor, 20, 175, 420, 175)

            DrawString("6. Supplier's Name Address", font7, Drawing.Color.Black, 25, 180, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("SupplierName")) Then
                DrawString(releaseOrderDv(0)("SupplierName"), arial8, brush2, 25, 195, StringWriter)
            End If
            If Not IsDBNull(releaseOrderDv(0)("SupplierAddress")) Then
                DrawString(releaseOrderDv(0)("SupplierAddress"), arial8, brush2, 25, 210, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 245, 420, 245)

            DrawString("8. Clearing Agent's Name", font7, Drawing.Color.Black, 25, 250, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Signatory")) Then
                DrawString(releaseOrderDv(0)("Signatory"), arial8, brush2, 25, 265, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 315, 420, 315)

            DrawString("10. Buyer if not Importer", font7, Drawing.Color.Black, 25, 320, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Buyer")) Then
                DrawString(releaseOrderDv(0)("Buyer"), arial8, brush2, 25, 335, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 355, 420, 355)

            Dim markPosX As Single = 0
            If Not IsDBNull(releaseOrderDv(0)("DisposalCode")) Then
                Dim dcode As String = UCase(releaseOrderDv(0)("DisposalCode"))
                If dcode = "ROAD" Then
                    markPosX = 25
                ElseIf dcode = "SEA" Then
                    markPosX = 125
                ElseIf dcode = "AIR" Then
                    markPosX = 225
                ElseIf dcode = "RAIL" Then
                    markPosX = 325
                Else
                    markPosX = 0
                End If
            End If

            DrawString("12. Disposal Code", font7, Drawing.Color.Black, 25, 360, StringWriter)
            DrawRectangle(pen1, pencolor, 20, 380, 30, 20)


            DrawString("ROAD", font8b, Drawing.Color.Black, 55, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 120, 380, 30, 20)
            DrawString("SEA", font8b, Drawing.Color.Black, 155, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 220, 380, 30, 20)
            DrawString("AIR", font8b, Drawing.Color.Black, 255, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 320, 380, 30, 20)
            DrawString("RAIL", font8b, Drawing.Color.Black, 355, 385, StringWriter)

            If markPosX = 0 Then
                'Do nothing
            Else
                DrawString("P", FontMark, Drawing.Color.Blue, markPosX, 385, StringWriter)
            End If

            DrawLine(pen1, pencolor, 20, 400, 420, 400)

            DrawLine(pen1, pencolor, 220, 400, 220, 520)

            DrawString("14. Rotation Number", font7, Drawing.Color.Black, 25, 405, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("RotationNo")) Then
                DrawString(releaseOrderDv(0)("RotationNo"), arial8, brush2, 25, 420, StringWriter)
            End If
            DrawString("15. Date of Report", font7, Drawing.Color.Black, 225, 405, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("DateOfReport")) Then
                If Not releaseOrderDv(0)("DateOfReport") = "1/1/1800" Then
                    DrawString(CDate(releaseOrderDv(0)("DateOfReport")).ToString("dd MMM yyyy"), arial8, brush2, 225, 420, StringWriter)
                End If
            End If

            DrawLine(pen1, pencolor, 20, 440, 420, 440)

            DrawString("17. Vessel/Aircraft/Vehicle No.", font7, Drawing.Color.Black, 25, 445, StringWriter)
            '----------------------------------------------------vehicle/vessel,aircraft.......................................
            DrawString("18. Port of Loading", font7, Drawing.Color.Black, 225, 445, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortOfLoading")) Then
                DrawString(releaseOrderDv(0)("PortOfLoading"), arial8, brush2, 225, 460, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 480, 420, 480)

            DrawString("20. Port of Discharge", font7, Drawing.Color.Black, 25, 485, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortOfDischarge")) Then
                DrawString(releaseOrderDv(0)("PortOfDischarge"), arial8, brush2, 25, 500, StringWriter)
            End If
            DrawString("21. Port Account No.", font7, Drawing.Color.Black, 225, 485, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortAccountNo")) Then
                DrawString(releaseOrderDv(0)("PortAccountNo"), arial8, brush2, 225, 500, StringWriter)
            End If
            '---------------------Upper Right Column that starts at item #2 and ends at item #19...--
            DrawLine(pen1, pencolor, 420, 75, 420, 520)
            DrawString("2. Bill of Lading /Airway Bill No.", font7, Drawing.Color.Black, 425, 80, StringWriter)
            DrawString("Delivery Sheet No.", font7, Drawing.Color.Black, 477, 93, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("BillOfLadingNo")) Then
                DrawString(releaseOrderDv(0)("BillOfLadingNo"), arial8, brush2, 425, 108, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 150, 773, 150)

            DrawString("4. Manifest endorsed", font7, Drawing.Color.Black, 425, 155, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ManifestPage")) Then
                DrawString(releaseOrderDv(0)("ManifestPage"), arial8, brush2, 465, 170, StringWriter)
            Else

            End If
            If Not IsDBNull(releaseOrderDv(0)("ManifestDate")) Then
                If Not releaseOrderDv(0)("ManifestDate") = "1/1/1800" Then
                    DrawString(CDate(releaseOrderDv(0)("ManifestDate")).ToString("dd MMM yyyy"), arial8, brush2, 520, 170, StringWriter)
                End If

            End If
            DrawString("Page No:", font7, Drawing.Color.Black, 425, 170, StringWriter)
            DrawString("Date:", font7, Drawing.Color.Black, 490, 170, StringWriter)
            DrawString("Signature:", font7, Drawing.Color.Black, 425, 196, StringWriter)
            DrawLine(pen1, pencolor, 420, 210, 597, 210)

            DrawString("7. Import License / Permit No.", font7, Drawing.Color.Black, 425, 215, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ImportLicenceNo")) Then
                DrawString(releaseOrderDv(0)("ImportLicenceNo"), arial8, brush2, 425, 227, StringWriter)
            End If
            DrawLine(pen1, pencolor, 597, 75, 597, 240)

            DrawString("3. Customs Assigned Number", font7, Drawing.Color.Black, 602, 80, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CustomsAssignNo")) Then
                DrawString(releaseOrderDv(0)("CustomsAssignNo"), arial8, brush2, 602, 95, StringWriter)
            End If
            'DrawLine(pen1, pencolor, 597, 135, 773, 135)

            'DrawString("5. M.P.R.O. SERIAL No.", font7, Drawing.Color.Black, 602, 140, StringWriter)
            'If Not IsDBNull(releaseOrderDv(0)("SerialNo")) Then
            '    DrawString(releaseOrderDv(0)("SerialNo"), arial8, brush2, 602, 155, StringWriter)
            'End If

            DrawLine(pen1, pencolor, 420, 240, 773, 240)

            DrawString("9. Shipping Line", font7, Drawing.Color.Black, 425, 245, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ShippingLine")) Then
                DrawString(releaseOrderDv(0)("ShippingLine"), arial8, brush2, 425, 260, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 285, 773, 285)

            DrawString("11. Country of Origin", font7, Drawing.Color.Black, 425, 290, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CountryOfOrigin")) Then
                DrawString(releaseOrderDv(0)("CountryOfOrigin"), arial8, brush2, 425, 305, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 325, 773, 325)

            DrawString("16. Country of Final Destination:", font7, Drawing.Color.Black, 425, 330, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CountryOfDestination")) Then
                DrawString(releaseOrderDv(0)("CountryOfDestination"), arial8, brush2, 425, 345, StringWriter)
            End If
            DrawLine(pen1, pencolor, 597, 325, 597, 370)
            DrawString("Accepted Value:-", font7, Drawing.Color.Black, 602, 330, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("AcceptedValue")) Then
                DrawString(releaseOrderDv(0)("AcceptedValue"), arial8, brush2, 602, 345, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 370, 773, 370)

            DrawString("19. Value (port only) Kes.:", font7, Drawing.Color.Black, 425, 375, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ValueinKES")) Then
                DrawString(releaseOrderDv(0)("ValueinKES"), arial8, brush2, 425, 390, StringWriter)
            End If
            DrawString("Words: ", font7b, Drawing.Color.Black, 425, 410, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 392, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 410, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 428, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 446, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 464, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 482, StringWriter)
            'DrawString("......................................................................................................................", font7, brush1, 460, 500, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ValueInWords")) Then


                Dim rect1 As Rectangle = New Rectangle(465 * 0.75, 842 - 0.75 * 520, 0.75 * 773, 842 - 0.75 * 430)

                Dim ct1 As ColumnText = New ColumnText(StringWriter)

                ct1.SetSimpleColumn(rect1)
                arial8.Color = BaseColor.BLUE
                ct1.AddElement(New Paragraph(releaseOrderDv(0)("ValueInWords"), arial8))
                ct1.Go()
            End If

            '----------------------Line above item #22....................----------------------------
            DrawLine(pen1, pencolor, 20, 520, 773, 520)

            DrawString("22. Marks and No's", font7, Drawing.Color.Black, 25, 525, StringWriter)

            DrawLine(pen1, pencolor, 200, 520, 200, 740)

            DrawString("23. Total No. and kind of packages in words", font7, Drawing.Color.Black, 205, 525, StringWriter)

            If releaseOrderGoodsDv.Count > 0 Then
                Dim y As Single = 585
                For count As Integer = 0 To releaseOrderGoodsDv.Count - 1 Step 1
                    If Not IsDBNull(releaseOrderGoodsDv(count)("MarksNos")) Then
                        DrawString(releaseOrderGoodsDv(count)("MarksNos"), arial8, brush2, 25, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("DescriptionofGoods")) Then
                        'DrawString(releaseOrderGoodsDv(count)("DescriptionofGoods"), arial8, brush2, 205, y + count * 30, StringWriter)
                        Dim rect4 As Rectangle = New Rectangle(205 * 0.75, 842 - 0.75 * (y + 15 + count * 30), 0.75 * 460, 842 - 0.75 * (y - 15 + count * 30))

                        Dim ct4 As ColumnText = New ColumnText(StringWriter)

                        ct4.SetSimpleColumn(rect4)
                        arial8.Color = BaseColor.BLUE
                        arial8.Size = 7
                        ct4.AddElement(New Paragraph(releaseOrderGoodsDv(count)("DescriptionofGoods"), arial8))
                        ct4.Go()
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("Weight")) Then
                        DrawString(releaseOrderGoodsDv(count)("Weight"), arial8, brush2, 465, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("CubicMeters")) Then
                        DrawString(releaseOrderGoodsDv(count)("CubicMeters"), arial8, brush2, 565, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("SeaFreightCharges")) Then
                        DrawString(releaseOrderGoodsDv(count)("SeaFreightCharges"), arial8, brush2, 665, y + count * 30, StringWriter)
                    End If
                Next
            End If

            If Not IsDBNull(releaseOrderDv(0)("KindofPackage")) Then
                DrawString(releaseOrderDv(0)("KindofPackage"), arial8, brush2, 205, 537, StringWriter)
            End If
            'DrawString("...........................................................................................", font7, Drawing.Color.Black, 220, 547, StringWriter)

            DrawLine(pen1, pencolor, 460, 520, 460, 740)

            DrawString("24. Weight", font7, Drawing.Color.Black, 465, 525, StringWriter)
            DrawString("Kg.", font7, Drawing.Color.Black, 480, 540, StringWriter)

            DrawLine(pen1, pencolor, 560, 520, 560, 740)

            DrawString("25. Cubic Meters", font7, Drawing.Color.Black, 565, 525, StringWriter)
            DrawString("(CBM)", font7, Drawing.Color.Black, 580, 540, StringWriter)

            DrawLine(pen1, pencolor, 660, 520, 660, 740)

            DrawString("27. Sea Freight", font7, Drawing.Color.Black, 665, 525, StringWriter)
            DrawString("including surcharges", font7, Drawing.Color.Black, 680, 540, StringWriter)

            DrawLine(pen1, pencolor, 20, 560, 773, 560)

            DrawString("26. Description of Goods", font7, Drawing.Color.Black, 205, 565, StringWriter)

            DrawLine(pen1, pencolor, 20, 740, 773, 740)

            DrawString("REVENUE", font7b, Drawing.Color.Black, 145, 753, StringWriter)
            DrawString("ACCOUNTS", font7b, Drawing.Color.Black, 360, 753, StringWriter)
            DrawString("OFFICE", font7b, Drawing.Color.Black, 620, 753, StringWriter)

            DrawLine(pen1, pencolor, 20, 770, 773, 770)

            DrawString("Received", font7, Drawing.Color.Black, 25, 775, StringWriter)
            DrawString("Date Stamp", font7, Drawing.Color.Black, 25, 875, StringWriter)

            DrawLine(pen1, pencolor, 300, 770, 300, 1102)

            DrawString("Received", font7, Drawing.Color.Black, 305, 775, StringWriter)
            DrawString("Date Stamp", font7, Drawing.Color.Black, 305, 875, StringWriter)

            DrawLine(pen1, pencolor, 520, 770, 520, 1102)

            DrawString("Weight of Tonnage on Test:", font7, Drawing.Color.Black, 525, 773, StringWriter)
            'DrawString("..................................................................................................", font7, brush1, 520, 780, StringWriter)
            DrawString("Measurement on Tonnage on Test:", font7, Drawing.Color.Black, 525, 813, StringWriter)
            'DrawString("..................................................................................................", font7, brush1, 520, 800, StringWriter)
            DrawString("Certificate No. (if issued):", font7, Drawing.Color.Black, 525, 853, StringWriter)
            'DrawString("..................................................................................................", font7, brush1, 520, 820, StringWriter)
            'DrawString("..................................................................................................", font7, brush1, 520, 840, StringWriter)
            'DrawString("..................................................................................................", font7, brush1, 520, 860, StringWriter)

            DrawLine(pen1, pencolor, 20, 890, 773, 890)

            DrawString("Initials", font7, Drawing.Color.Black, 25, 900, StringWriter)
            DrawString("Initials", font7, Drawing.Color.Black, 305, 900, StringWriter)
            DrawString("Accepted", font7, Drawing.Color.Black, 525, 900, StringWriter)

            DrawLine(pen1, pencolor, 20, 915, 773, 915)

            DrawString("Reasons for Rejection", font7, Drawing.Color.Black, 25, 920, StringWriter)
            'DrawString("............................................................................................................", font7, brush1, 20, 925, StringWriter)
            'DrawString("............................................................................................................", font7, brush1, 20, 945, StringWriter)
            'DrawString("............................................................................................................", font7, brush1, 20, 965, StringWriter)
            'DrawString("............................................................................................................", font7, brush1, 20, 985, StringWriter)
            'DrawString("............................................................................................................", font7, brush1, 20, 1005, StringWriter)
            DrawString("Released", font7, Drawing.Color.Black, 305, 920, StringWriter)
            DrawString("I / We...................................................................................", font6, Drawing.Color.Black, 525, 927, StringWriter)
            DrawString(userName, arial8, Drawing.Color.Blue, 555, 920, StringWriter)
            DrawString("the Owner (or agents duly authorised by the owners)", font6, Drawing.Color.Black, 525, 939, StringWriter)
            DrawString("of the goods specified in this entry declare", font6, Drawing.Color.Black, 525, 951, StringWriter)
            DrawString("all the particulars given are true", font6, Drawing.Color.Black, 525, 963, StringWriter)

            DrawString("Initials", font7, Drawing.Color.Black, 25, 1018, StringWriter)
            DrawString("DATE STAMP", font7, Drawing.Color.Black, 305, 1018, StringWriter)

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfssignatures\sign1.png") Then
                Dim sign As Image = Image.GetInstance(signaturepath)
                sign.ScaleToFit(170, 41)
                sign.SetAbsolutePosition(525 * 0.75, 842 - 1025 * 0.75)
                ReleaseOrderPDF.Add(sign)
            End If

            DrawString("AUTHORISED SIGNATURE", font7, Drawing.Color.Black, 525, 1018, StringWriter)

            DrawLine(pen1, pencolor, 20, 1033, 773, 1033)

            DrawString("Certifying Officer", font7, Drawing.Color.Black, 25, 1087, StringWriter)
            DrawString("Initials", font7, Drawing.Color.Black, 305, 1087, StringWriter)
            DrawString(Now.ToString("dd MMM yyyy"), arial8, Drawing.Color.Blue, 555, 1080, StringWriter)
            DrawString("Date:.............................................", font7, Drawing.Color.Black, 525, 1087, StringWriter)


            ReleaseOrderPDF.AddCreator("C&F PRO | Cybermonk Software Development Limited")
            ReleaseOrderPDF.Close()

            Dim bytes As Byte() = memoryStream.ToArray()
            Return bytes
            memoryStream.Close()

        End Using
    End Function

    Shared Function ReleaseOrderEmail(ROPDFName As String, releaseOrderId As String, userName As String)
        Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
        Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
        Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
        Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
        Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

        Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
        Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)

        Dim small As New Font(customfont, 5)
        Dim font6 As New Font(customfont, 6)
        Dim font6b As New Font(customfontb, 6.4)
        Dim font7b As New Font(customfontb, 7.4)

        Dim font7 As New Font(customfont, 7)

        Dim font8 As New Font(customfontb, 8)
        Dim font8i As New Font(customfonti, 8)
        Dim font8b As New Font(customfontb, 8)
        Dim font9 As New Font(customfont, 9)
        Dim font11c As New Font(customfontc, 10.5)
        Dim font10b As New Font(customfontb, 10)

        Dim arial8 As New Font(customfont, 8)

        Dim FontMark As Font
        Dim Mark As String
        FontMark = New Font(customfontm, 14)
        Mark = "P"

        Dim brush1 As Drawing.Color = Drawing.Color.Black
        Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)
        'Dim PDFReader As PdfReader = Nothing 'Read File

        ' Document starts here

        Dim regdocpath As String = HttpContext.Current.Server.MapPath(".") & "\regdocs\" & ROPDFName & ".pdf"
        Dim doclogospath As String = HttpContext.Current.Server.MapPath(".") & "\cfslogos\cfproonlinelogo.png"
        Dim signaturepath As String = HttpContext.Current.Server.MapPath(".") & "\cfssignatures\sign1.png"
        Dim ReleaseOrderPDF As New Document(PageSize.A4, 0, 0, 0, 50)

        'New FileStream(regdocpath, FileMode.Create)

        Using memoryStream As New System.IO.MemoryStream()

            Dim PDFwriter As PdfWriter = PdfWriter.GetInstance(ReleaseOrderPDF, memoryStream)


            ReleaseOrderPDF.Open()
            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfslogos\cfproonlinelogo.png") Then
                Dim logo As Image = Image.GetInstance(doclogospath)
                logo.ScaleToFit(172, 43.35)
                logo.SetAbsolutePosition(205, 788)
                ReleaseOrderPDF.Add(logo)
            End If

            Dim sqlstr As String =
             "Select ReleaseOrderId,SerialNo,Importer," &
             "ImporterAddress, BillOfLadingNo," &
             "CustomsAssignNo, ManifestPage," &
             "ManifestDate, ImportLicenceNo," &
             "ShippingLine, CountryOfOrigin," &
             "CountryOfDestination, AcceptedValue," &
             "ValueinKES,ValueInWords,SupplierName," &
             "SupplierAddress,Buyer," &
             "DisposalCode,ReferenceNo," &
             "RotationNo,DateOfReport," &
             "VesselName,PortOfLoading," &
             "PortofDischarge,KindofPackage," &
             "Signatory,PortAccountNo," &
             "ReleaseOrderDate,CFSID, ID " &
             "From ReleaseOrders " &
             "Where ReleaseOrderId= '" & releaseOrderId & "'"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr, tmptable1, clsData.constr)
            Dim releaseOrderDv = New DataView(tmptable1)

            Dim sqlstr2 As String =
             "Select	UserID,RecordId," &
            "RecordID1, MarksNos,RecordDate, " &
            "DescriptionofGoods,[Weight]," &
            "CubicMeters,SeaFreightCharges,Id " &
            "From ReleaseOrderGoods " &
            "Where RecordId ='" & releaseOrderId & "'"

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim releaseOrderGoodsDv = New DataView(tmptable2)

            'logo added

            'Create line pens
            Dim pen As PdfContentByte = PDFwriter.DirectContent
            Dim pen1 As PdfContentByte = PDFwriter.DirectContent
            Dim pen2 As PdfContentByte = PDFwriter.DirectContent
            Dim pencolor

            pen.SetLineWidth(0)
            pen1.SetLineWidth(0.5)
            pen2.SetLineWidth(0.5)

            Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

            'DrawString("VAT No. XXXXXXXX", font7b, Drawing.Color.Black, 20, 40, StringWriter)
            DrawString("PIN No. XXXXXXXXXXX", font7b, Drawing.Color.Black, 20, 55, StringWriter)
            DrawString("RO #" & releaseOrderId, font7b, Drawing.Color.Black, 700, 55, StringWriter)
            DrawRectangle(pen1, pencolor, 20, 75, 753, 1027)

            DrawString("1. Importers Name Address", font7, Drawing.Color.Black, 25, 80, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Importer")) Then
                DrawString(releaseOrderDv(0)("Importer"), arial8, brush2, 25, 95, StringWriter)
            End If
            If Not IsDBNull(releaseOrderDv(0)("ImporterAddress")) Then
                DrawString(releaseOrderDv(0)("ImporterAddress"), arial8, brush2, 25, 110, StringWriter)
            End If

            DrawLine(pen1, pencolor, 20, 175, 420, 175)

            DrawString("6. Supplier's Name Address", font7, Drawing.Color.Black, 25, 180, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("SupplierName")) Then
                DrawString(releaseOrderDv(0)("SupplierName"), arial8, brush2, 25, 195, StringWriter)
            End If
            If Not IsDBNull(releaseOrderDv(0)("SupplierAddress")) Then
                DrawString(releaseOrderDv(0)("SupplierAddress"), arial8, brush2, 25, 210, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 245, 420, 245)

            DrawString("8. Clearing Agent's Name", font7, Drawing.Color.Black, 25, 250, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Signatory")) Then
                DrawString(releaseOrderDv(0)("Signatory"), arial8, brush2, 25, 265, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 315, 420, 315)

            DrawString("10. Buyer if not Importer", font7, Drawing.Color.Black, 25, 320, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("Buyer")) Then
                DrawString(releaseOrderDv(0)("Buyer"), arial8, brush2, 25, 335, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 355, 420, 355)

            Dim markPosX As Single = 0
            If Not IsDBNull(releaseOrderDv(0)("DisposalCode")) Then
                Dim dcode As String = UCase(releaseOrderDv(0)("DisposalCode"))
                If dcode = "ROAD" Then
                    markPosX = 25
                ElseIf dcode = "SEA" Then
                    markPosX = 125
                ElseIf dcode = "AIR" Then
                    markPosX = 225
                ElseIf dcode = "RAIL" Then
                    markPosX = 325
                Else
                    markPosX = 0
                End If
            End If

            DrawString("12. Disposal Code", font7, Drawing.Color.Black, 25, 360, StringWriter)
            DrawRectangle(pen1, pencolor, 20, 380, 30, 20)


            DrawString("ROAD", font8b, Drawing.Color.Black, 55, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 120, 380, 30, 20)
            DrawString("SEA", font8b, Drawing.Color.Black, 155, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 220, 380, 30, 20)
            DrawString("AIR", font8b, Drawing.Color.Black, 255, 385, StringWriter)
            DrawRectangle(pen1, pencolor, 320, 380, 30, 20)
            DrawString("RAIL", font8b, Drawing.Color.Black, 355, 385, StringWriter)

            If markPosX = 0 Then
                'Do nothing
            Else
                DrawString("P", FontMark, Drawing.Color.Blue, markPosX, 385, StringWriter)
            End If

            DrawLine(pen1, pencolor, 20, 400, 420, 400)

            DrawLine(pen1, pencolor, 220, 400, 220, 520)

            DrawString("14. Rotation Number", font7, Drawing.Color.Black, 25, 405, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("RotationNo")) Then
                DrawString(releaseOrderDv(0)("RotationNo"), arial8, brush2, 25, 420, StringWriter)
            End If
            DrawString("15. Date of Report", font7, Drawing.Color.Black, 225, 405, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("DateOfReport")) Then
                If Not releaseOrderDv(0)("DateOfReport") = "1/1/1800" Then
                    DrawString(CDate(releaseOrderDv(0)("DateOfReport")).ToString("dd MMM yyyy"), arial8, brush2, 225, 420, StringWriter)
                End If
            End If

            DrawLine(pen1, pencolor, 20, 440, 420, 440)

            DrawString("17. Vessel/Aircraft/Vehicle No.", font7, Drawing.Color.Black, 25, 445, StringWriter)
            '----------------------------------------------------vehicle/vessel,aircraft.......................................
            DrawString("18. Port of Loading", font7, Drawing.Color.Black, 225, 445, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortOfLoading")) Then
                DrawString(releaseOrderDv(0)("PortOfLoading"), arial8, brush2, 225, 460, StringWriter)
            End If
            DrawLine(pen1, pencolor, 20, 480, 420, 480)

            DrawString("20. Port of Discharge", font7, Drawing.Color.Black, 25, 485, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortOfDischarge")) Then
                DrawString(releaseOrderDv(0)("PortOfDischarge"), arial8, brush2, 25, 500, StringWriter)
            End If
            DrawString("21. Port Account No.", font7, Drawing.Color.Black, 225, 485, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("PortAccountNo")) Then
                DrawString(releaseOrderDv(0)("PortAccountNo"), arial8, brush2, 225, 500, StringWriter)
            End If
            '---------------------Upper Right Column that starts at item #2 and ends at item #19...--
            DrawLine(pen1, pencolor, 420, 75, 420, 520)
            DrawString("2. Bill of Lading /Airway Bill No.", font7, Drawing.Color.Black, 425, 80, StringWriter)
            DrawString("Delivery Sheet No.", font7, Drawing.Color.Black, 477, 93, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("BillOfLadingNo")) Then
                DrawString(releaseOrderDv(0)("BillOfLadingNo"), arial8, brush2, 425, 108, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 150, 773, 150)

            DrawString("4. Manifest endorsed", font7, Drawing.Color.Black, 425, 155, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ManifestPage")) Then
                DrawString(releaseOrderDv(0)("ManifestPage"), arial8, brush2, 465, 165, StringWriter)
            Else
                DrawString("5655", arial8, brush2, 465, 165, StringWriter)
            End If
            If Not IsDBNull(releaseOrderDv(0)("ManifestDate")) Then
                If Not releaseOrderDv(0)("ManifestDate") = "1/1/1800" Then
                    DrawString(CDate(releaseOrderDv(0)("ManifestDate")).ToString("dd MMM yyyy"), arial8, brush2, 520, 165, StringWriter)
                End If

            End If
            DrawString("Page No...........Date..................................", font7, Drawing.Color.Black, 425, 170, StringWriter)
            DrawString("Signature...................................................", font7, Drawing.Color.Black, 425, 196, StringWriter)
            DrawLine(pen1, pencolor, 420, 210, 597, 210)

            DrawString("7. Import License / Permit No.", font7, Drawing.Color.Black, 425, 215, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ImportLicenceNo")) Then
                DrawString(releaseOrderDv(0)("ImportLicenceNo"), arial8, brush2, 425, 227, StringWriter)
            End If
            DrawLine(pen1, pencolor, 597, 75, 597, 240)

            DrawString("3. Customs Assigned Number", font7, Drawing.Color.Black, 602, 80, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CustomsAssignNo")) Then
                DrawString(releaseOrderDv(0)("CustomsAssignNo"), arial8, brush2, 602, 95, StringWriter)
            End If
            'DrawLine(pen1, pencolor, 597, 135, 773, 135)

            'DrawString("5. M.P.R.O. SERIAL No.", font7, Drawing.Color.Black, 602, 140, StringWriter)
            'If Not IsDBNull(releaseOrderDv(0)("SerialNo")) Then
            '    DrawString(releaseOrderDv(0)("SerialNo"), arial8, brush2, 602, 155, StringWriter)
            'End If

            DrawLine(pen1, pencolor, 420, 240, 773, 240)

            DrawString("9. Shipping Line", font7, Drawing.Color.Black, 425, 245, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ShippingLine")) Then
                DrawString(releaseOrderDv(0)("ShippingLine"), arial8, brush2, 425, 260, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 285, 773, 285)

            DrawString("11. Country of Origin", font7, Drawing.Color.Black, 425, 290, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CountryOfOrigin")) Then
                DrawString(releaseOrderDv(0)("CountryOfOrigin"), arial8, brush2, 425, 305, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 325, 773, 325)

            DrawString("16. Country of Final Destination:", font7, Drawing.Color.Black, 425, 330, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("CountryOfDestination")) Then
                DrawString(releaseOrderDv(0)("CountryOfDestination"), arial8, brush2, 425, 345, StringWriter)
            End If
            DrawLine(pen1, pencolor, 597, 325, 597, 370)
            DrawString("Accepted Value:-", font7, Drawing.Color.Black, 602, 330, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("AcceptedValue")) Then
                DrawString(releaseOrderDv(0)("AcceptedValue"), arial8, brush2, 602, 345, StringWriter)
            End If
            DrawLine(pen1, pencolor, 420, 370, 773, 370)

            DrawString("19. Value (port only) Shs........................................................", font7, Drawing.Color.Black, 425, 375, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ValueinKES")) Then
                DrawString(releaseOrderDv(0)("ValueinKES"), arial8, brush2, 545, 373, StringWriter)
            End If
            DrawString("Words: ", font7b, Drawing.Color.Black, 425, 390, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 392, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 410, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 428, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 446, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 464, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 482, StringWriter)
            DrawString("......................................................................................................................", font7, brush1, 460, 500, StringWriter)
            If Not IsDBNull(releaseOrderDv(0)("ValueInWords")) Then


                Dim rect1 As Rectangle = New Rectangle(465 * 0.75, 842 - 0.75 * 520, 0.75 * 773, 842 - 0.75 * 380)

                Dim ct1 As ColumnText = New ColumnText(StringWriter)

                ct1.SetSimpleColumn(rect1)
                arial8.Color = BaseColor.BLUE
                ct1.AddElement(New Paragraph(releaseOrderDv(0)("ValueInWords"), arial8))
                ct1.Go()
            End If

            '----------------------Line above item #22....................----------------------------
            DrawLine(pen1, pencolor, 20, 520, 773, 520)

            DrawString("22. Marks and No's", font7, Drawing.Color.Black, 25, 525, StringWriter)

            DrawLine(pen1, pencolor, 200, 520, 200, 740)

            DrawString("23. Total No. and kind of packages in words", font7, Drawing.Color.Black, 205, 525, StringWriter)

            If releaseOrderGoodsDv.Count > 0 Then
                Dim y As Single = 585
                For count As Integer = 0 To releaseOrderGoodsDv.Count - 1 Step 1
                    If Not IsDBNull(releaseOrderGoodsDv(count)("MarksNos")) Then
                        DrawString(releaseOrderGoodsDv(count)("MarksNos"), arial8, brush2, 25, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("DescriptionofGoods")) Then
                        'DrawString(releaseOrderGoodsDv(count)("DescriptionofGoods"), arial8, brush2, 205, y + count * 30, StringWriter)
                        Dim rect4 As Rectangle = New Rectangle(205 * 0.75, 842 - 0.75 * (y + 15 + count * 30), 0.75 * 460, 842 - 0.75 * (y - 15 + count * 30))

                        Dim ct4 As ColumnText = New ColumnText(StringWriter)

                        ct4.SetSimpleColumn(rect4)
                        arial8.Color = BaseColor.BLUE
                        arial8.Size = 7
                        ct4.AddElement(New Paragraph(releaseOrderGoodsDv(count)("DescriptionofGoods"), arial8))
                        ct4.Go()
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("Weight")) Then
                        DrawString(releaseOrderGoodsDv(count)("Weight"), arial8, brush2, 465, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("CubicMeters")) Then
                        DrawString(releaseOrderGoodsDv(count)("CubicMeters"), arial8, brush2, 565, y + count * 30, StringWriter)
                    End If
                    If Not IsDBNull(releaseOrderGoodsDv(count)("SeaFreightCharges")) Then
                        DrawString(releaseOrderGoodsDv(count)("SeaFreightCharges"), arial8, brush2, 665, y + count * 30, StringWriter)
                    End If
                Next
            End If

            If Not IsDBNull(releaseOrderDv(0)("KindofPackage")) Then
                DrawString(releaseOrderDv(0)("KindofPackage"), arial8, brush2, 205, 537, StringWriter)
            End If
            DrawString("...........................................................................................", font7, Drawing.Color.Black, 220, 547, StringWriter)

            DrawLine(pen1, pencolor, 460, 520, 460, 740)

            DrawString("24. Weight", font7, Drawing.Color.Black, 465, 525, StringWriter)
            DrawString("Kg.", font7, Drawing.Color.Black, 480, 540, StringWriter)

            DrawLine(pen1, pencolor, 560, 520, 560, 740)

            DrawString("25. Cubic Meters", font7, Drawing.Color.Black, 565, 525, StringWriter)
            DrawString("(CBM)", font7, Drawing.Color.Black, 580, 540, StringWriter)

            DrawLine(pen1, pencolor, 660, 520, 660, 740)

            DrawString("27. Sea Freight", font7, Drawing.Color.Black, 665, 525, StringWriter)
            DrawString("including surcharges", font7, Drawing.Color.Black, 680, 540, StringWriter)

            DrawLine(pen1, pencolor, 20, 560, 773, 560)

            DrawString("26. Description of Goods", font7, Drawing.Color.Black, 205, 565, StringWriter)

            DrawLine(pen1, pencolor, 20, 740, 773, 740)

            DrawString("REVENUE", font7b, Drawing.Color.Black, 145, 753, StringWriter)
            DrawString("ACCOUNTS", font7b, Drawing.Color.Black, 360, 753, StringWriter)
            DrawString("OFFICE", font7b, Drawing.Color.Black, 620, 753, StringWriter)

            DrawLine(pen1, pencolor, 20, 770, 773, 770)

            DrawString("Received", font7, Drawing.Color.Black, 25, 775, StringWriter)
            DrawString("Date Stamp", font7, Drawing.Color.Black, 25, 875, StringWriter)

            DrawLine(pen1, pencolor, 300, 770, 300, 1102)

            DrawString("Received", font7, Drawing.Color.Black, 305, 775, StringWriter)
            DrawString("Date Stamp", font7, Drawing.Color.Black, 305, 875, StringWriter)

            DrawLine(pen1, pencolor, 520, 770, 520, 1102)

            DrawString("Weight of Tonnage on Test", font7, Drawing.Color.Black, 525, 773, StringWriter)
            DrawString("..................................................................................................", font7, brush1, 520, 780, StringWriter)
            DrawString("Measurement on Tonnage on Test", font7, Drawing.Color.Black, 525, 793, StringWriter)
            DrawString("..................................................................................................", font7, brush1, 520, 800, StringWriter)
            DrawString("Certificate No. (if issued)", font7, Drawing.Color.Black, 525, 813, StringWriter)
            DrawString("..................................................................................................", font7, brush1, 520, 820, StringWriter)
            DrawString("..................................................................................................", font7, brush1, 520, 840, StringWriter)
            DrawString("..................................................................................................", font7, brush1, 520, 860, StringWriter)

            DrawLine(pen1, pencolor, 20, 890, 773, 890)

            DrawString("Initials", font7, Drawing.Color.Black, 25, 900, StringWriter)
            DrawString("Initials", font7, Drawing.Color.Black, 305, 900, StringWriter)
            DrawString("Accepted", font7, Drawing.Color.Black, 525, 900, StringWriter)

            DrawLine(pen1, pencolor, 20, 915, 773, 915)

            DrawString("Reasons for Rejection", font7, Drawing.Color.Black, 25, 920, StringWriter)
            DrawString("............................................................................................................", font7, brush1, 20, 925, StringWriter)
            DrawString("............................................................................................................", font7, brush1, 20, 945, StringWriter)
            DrawString("............................................................................................................", font7, brush1, 20, 965, StringWriter)
            DrawString("............................................................................................................", font7, brush1, 20, 985, StringWriter)
            DrawString("............................................................................................................", font7, brush1, 20, 1005, StringWriter)
            DrawString("Released", font7, Drawing.Color.Black, 305, 920, StringWriter)
            DrawString("I / We...................................................................................", font6, Drawing.Color.Black, 525, 927, StringWriter)
            DrawString(userName, arial8, Drawing.Color.Blue, 555, 920, StringWriter)
            DrawString("the Owner (or agents duly authorised by the owners)", font6, Drawing.Color.Black, 525, 939, StringWriter)
            DrawString("of the goods specified in this entry declare", font6, Drawing.Color.Black, 525, 951, StringWriter)
            DrawString("all the particulars given are true", font6, Drawing.Color.Black, 525, 963, StringWriter)

            DrawString("Initials", font7, Drawing.Color.Black, 25, 1018, StringWriter)
            DrawString("DATE STAMP", font7, Drawing.Color.Black, 305, 1018, StringWriter)

            If File.Exists(HttpContext.Current.Server.MapPath(".") & "\cfssignatures\sign1.png") Then
                Dim sign As Image = Image.GetInstance(signaturepath)
                sign.ScaleToFit(170, 41)
                sign.SetAbsolutePosition(525 * 0.75, 842 - 1025 * 0.75)
                ReleaseOrderPDF.Add(sign)
            End If

            DrawString("AUTHORISED SIGNATURE", font7, Drawing.Color.Black, 525, 1018, StringWriter)

            DrawLine(pen1, pencolor, 20, 1033, 773, 1033)

            DrawString("Certifying Officer", font7, Drawing.Color.Black, 25, 1087, StringWriter)
            DrawString("Initials", font7, Drawing.Color.Black, 305, 1087, StringWriter)
            DrawString(Now.ToString("dd MMM yyyy"), arial8, Drawing.Color.Blue, 555, 1080, StringWriter)
            DrawString("Date:.............................................", font7, Drawing.Color.Black, 525, 1087, StringWriter)

            ReleaseOrderPDF.Close()

            Dim bytes As Byte() = memoryStream.ToArray()
            'Return bytes
            memoryStream.Close()
            'Dim mm As New MailMessage("sender@gmail.com", "wamalwa.silvanos@cybermonksd.com")
            'mm.Subject = "RELEASE ORDER PDF"
            'mm.Body = "RO PDF attached."
            'mm.Attachments.Add(New Attachment(New MemoryStream(bytes), ROPDFName))
            'mm.IsBodyHtml = True
            'Dim smtp As New SmtpClient()
            'smtp.Host = "smtp.gmail.com"
            'smtp.EnableSsl = True
            'Dim NetworkCred As New NetworkCredential()
            'NetworkCred.UserName = "wssilverpg@gmail.com"
            'NetworkCred.Password = "1236silver"
            'smtp.UseDefaultCredentials = True
            'smtp.Credentials = NetworkCred
            'smtp.Port = 587
            'smtp.Send(mm)
            Return bytes
        End Using
    End Function
End Class
