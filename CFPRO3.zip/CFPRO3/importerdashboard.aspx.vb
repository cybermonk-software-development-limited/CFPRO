﻿
Imports System.Configuration
Public Class importerdashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "importer", True)

            Call LoadAlerts()
            Call LoadImporters()
            Call LoadCFS()

            ComboSelectTop.SelectedIndex = 1

            Call LoadJobs(False)
        End If
    End Sub

    Private Sub LoadJobs(ExporttoExcel As Boolean)
        Try

            Dim SortBy As String = nSortOrder()


            Dim tmpstr2 As String

            Dim tmpid As Integer = -1




            If SortBy = "JobDate" Then
                tmpstr2 = "Or KeepVisible = 1 " & _
                            "Order By JobDate Desc;"

            ElseIf SortBy = "ReferenceNo" Then
                tmpstr2 = "Or KeepVisible = 1 " & _
                         "Order By ReferenceNo Desc;"

            ElseIf SortBy = "JobId" Then
                tmpstr2 = "Or KeepVisible = 1 " & " " & _
                              "Order By Id Desc;"
            End If


            Dim tmpstr As String = "Where ID > -1 " & tmpstr2


            Dim sqlstr, sqlstr1, sqlstr1a, sqlstr2 As String

            sqlstr = _
                    "Select Top " & ComboSelectTop.Text & " JobId, ReferenceNo," & _
                    "JobDate,ImporterID," & _
                    "BL,CFS,JobStatus," & _
                    "Weight,CBM," & _
                    "ShippingVessel,VesselETA," & _
                    "BerthingDate,LastSlingDate," & _
                    "CrossBorderDate,ContainerReturnDays," & _
                    "RemainingDays,DispatchDate,ReturnDate," & _
                    "DaysTaken,JobType," & _
                    "Quantity,Status," & _
                    "ContainerNos, Id " & _
                    "From Jobs " & _
                     tmpstr

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow, drow1 As DataRow
            Dim JobDate As String = "1-Jan-1900"
            If tmptable.Rows.Count > 0 Then
                Call clsSubs.NullChecker(tmptable, 0)
                drow = tmptable.Rows(tmptable.Rows.Count - 1)
                JobDate = drow("JobDate")
            End If

            sqlstr1 = "Select JobId, ContainerStatus,Id " &
                      "From  JobCargo " &
                        "Where Jobdate >= '" & JobDate & "' " & _
                        "And ContainerStatus <> '" & "Returned" & "' " &
                        "And ContainerStatus <> '" & "Damaged" & "' " & _
                        "Or KeepVisible = 1 "


            sqlstr1a = "Select JobId,ContainerNo," & _
                        "TEU, ContainerStatus,Id " & _
                        "From  JobCargo " & _
                        "Where Jobdate >= '" & JobDate & "' " & _
                        "Or KeepVisible = 1 "

            sqlstr2 = _
                    "Select JobId,Status, Date,Id " & _
                    "From JobProgress " & _
                    "Where Jobdate >= '" & JobDate & "' " & _
                    "Or KeepVisible = 1 " & _
                    "Order By Date Desc;"



            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim tmptable1a As New DataTable()
            Call clsData.TableData(sqlstr1a, tmptable1a, clsData.constr)
            Dim dv1 As New DataView(tmptable1a)


            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            'x.Label1.Text = "Computing Visibility..."
            'x.PBar1.Maximum = tmptable.Rows.Count
            'x.Button1.Visible = True




            Dim a, b, c As Integer

            Dim tmpdate As Date = Now
            Dim ts As TimeSpan
            Dim found As Boolean
            Dim tmpstr3() As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            Dim col1 As New DataColumn("JobDate1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("JobCount", Type.GetType("System.String"))
            Dim col3 As New DataColumn("JobView", Type.GetType("System.String"))
            Dim col4 As New DataColumn("VesselETA1", Type.GetType("System.String"))
            Dim col5 As New DataColumn("LastSlingDate1", Type.GetType("System.String"))
            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)

            Dim TEU As Double


            For Each drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)
                drow("ReferenceNo") = Mid(drow("ReferenceNo"), 1, 15)


                drow("JobDate1") = Format(drow("JobDate"), "dd MMM yyyy")
                drow("VesselETA1") = Format(drow("VesselETA"), "dd MMM yyyy")
                drow("LastSlingDate1") = Format(drow("LastSlingDate"), "dd MMM yyyy")

                drow("JobView") = "importerjobview.aspx?jobid=" & drow("JobID")

                drow("DaysTaken") = clsSubs.DaysTaken(drow("LastSlingDate"), drow("DispatchDate"))
                found = False
                tmpdate = Now

                If CDate(drow("BerthingDate")) = CDate("1/Jan/1800") Then
                    drow("RemainingDays") = 0
                Else
                    For Each drow1 In tmptable1.Rows
                        If drow("JobId") = drow1("JobId") Then
                            found = True
                            Exit For
                        End If
                    Next

                    If found Then
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    Else
                        tmpdate = drow("ReturnDate")
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    End If
                End If



                dv1.RowFilter = "JobId = " & "'" & drow("JobId") & "'"

                c = 0
                TEU = 0
                ReDim tmpstr3(c)
                For b = 0 To dv1.Count - 1
                    Call clsSubs.NullChecker1(dv1, b)

                    ReDim Preserve tmpstr3(c)
                    tmpstr3(c) = dv1(b)("ContainerNo")
                    c = c + 1

                    TEU = TEU + Val(dv1(b)("TEU"))
                Next

                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Quantity") = dv1.Count
                drow("TEU") = TEU


                dv2.RowFilter = "JobId = " & "'" & drow("JobId") & "'"
                dv2.Sort = "Date DESC"


                If dv2.Count > 0 Then
                    drow("Status") = dv2(0)("Status")
                End If


                a = a + 1

                drow("JobCount") = a

            Next
          
            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            If tmptable.Rows.Count > 8 Then
                PanelJobs.Height = 450
            Else
                PanelJobs.Height = Nothing
            End If

            LabelVisibilityCaption.Text = tmptable.Rows.Count & " Consignments: "


            DataList1.DataSource = tmptable
            DataList1.DataBind()


            'GridView1.DataSource = tmptable2
            'GridView1.DataBind()

            Call Calctotal(tmptable, "")


            'If ExporttoExcel Then
            '    'Get the data from database into datatable


            '    Dim excel As New ExcelPackage()
            '    Dim workSheet = excel.Workbook.Worksheets.Add("Jobs")
            '    Dim totalCols = GridJobs.Columns.Count
            '    Dim totalRows = GridJobs.Rows.Count

            '    For col1 As Integer = 1 To totalCols
            '        workSheet.Cells(1, col1).Value = GridJobs.Columns(col1 - 1).HeaderText
            '    Next


            '    Dim row1 As GridViewRow
            '    For row As Integer = 1 To totalRows
            '        row1 = GridJobs.Rows(row - 1)
            '        For col1 As Integer = 0 To totalCols - 1
            '            workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1).Text
            '        Next
            '    Next

            '    Using rng As ExcelRange = workSheet.Cells("A1:K1")
            '        rng.Style.Font.Bold = True
            '        rng.Style.Fill.PatternType = Style.ExcelFillStyle.Solid
            '        'Set Pattern for the background to Solid
            '        rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(79, 129, 189))
            '        'Set color to dark blue
            '        rng.Style.Font.Color.SetColor(Color.White)
            '    End Using

            '    Using memoryStream = New MemoryStream()
            '        Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            '        Response.AddHeader("content-disposition", "attachment;  filename=products.xlsx")
            '        excel.SaveAs(memoryStream)
            '        memoryStream.WriteTo(Response.OutputStream)
            '        Response.Flush()
            '        Response.[End]()
            '    End Using


            'End If

            LabelMessage1.Text = ""

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub




    Private Sub LoadImporters()
        Dim sqlstr As String = _
        "Select Importer From Importers " & _
        "Order By Importer Asc;"
        ComboImporters.Items.Add("(All)")
        Call clsData.PopCombo(ComboImporters, sqlstr, clsData.constr, 0)
    End Sub




    Private Sub LoadCFS()
        Dim sqlstr As String = _
        "Select CFS " & _
        "From CFS"
        ComboCFS.Items.Add("(All)")
        Call clsData.PopCombo(ComboCFS, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadAlerts()
        Dim sqlstr As String = _
        "Select AlertName " & _
        "From Alerts"
        ComboAlertTypes.Items.Add("(All)")
        Call clsData.PopCombo(ComboAlertTypes, sqlstr, clsData.constr, 0)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()

        Call LoadJobs(False)

    End Sub




    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try

            Dim dv As DataView = tmptable.DefaultView
            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsSubs.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")
            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Function nSortOrder() As String

        Select Case RadioButtonList1.SelectedIndex
            Case 0
                Return "JobDate"
            Case 1
                Return "ReferenceNo"
            Case 2
                Return "JobId"
            Case -1
                Return "JobDate"
        End Select

    End Function

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Protected Sub ComboSelectTop_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboSelectTop.SelectedIndexChanged
        Call LoadJobs(False)
    End Sub

    Protected Sub RadioButtonList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles RadioButtonList1.SelectedIndexChanged
        Call LoadJobs(False)

    End Sub
End Class