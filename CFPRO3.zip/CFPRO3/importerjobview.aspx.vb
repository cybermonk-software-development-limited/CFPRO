﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Public Class importerjobview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCfAgentCSDID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, LabelUserType.Text, True)

            Dim JobID As String = Request.QueryString("jobid")
            Call LoadJobIDS(JobID)
            Call LoadJob(JobID)


            If LabelUserType.Text = "importer" Then
                HyperLink1.Text = "My Consignments"
                HyperLink1.NavigateUrl = "importerdashboard.aspx"

                HyperLink2.Text = "Action Center"
                HyperLink2.NavigateUrl = "actioncenter.aspx"

            Else

                HyperLink1.Text = "Job Entry"
                HyperLink1.NavigateUrl = "jobentry.aspx"

                HyperLink2.Text = "Standard Visibility"
                HyperLink2.NavigateUrl = "jobstandardvisibility.aspx"

            End If

            LabelFromPageURL.Text = Page.Request.UrlReferrer.ToString
        End If

    End Sub


    Private Sub LoadJobIDS(JobId As String)

        Try

            Dim sqlstr As String = _
            "Select JobId From Jobs " & _
            "Order by JobId Asc; "

            ComboJobID.Items.Clear()
            Call clsData.PopCombo(ComboJobID, sqlstr, clsData.constr, 0)

            If JobId = "-1" Then
                If ComboJobID.Items.Count > 0 Then
                    ComboJobID.SelectedIndex = ComboJobID.Items.Count - 1
                    Call LoadJob(ComboJobID.SelectedItem.ToString)
                End If
            Else
                ComboJobID.Text = JobId
            End If

        Catch exp As Exception
            MsgBox(exp.Message & " " & exp.StackTrace)
        End Try

    End Sub
    Private Sub LoadJob(JobID As String)

        Dim CFS As String = ""
        Try
            Dim sqlstr As String = _
                    "Select JobId,ReferenceNo," & _
                    "JobDate,ClientID,Client," & _
                    "CFS,BL,BLCountry," & _
                    "Goods,DaysTaken," & _
                    "ShipStatus,ManifestNo," & _
                    "JobStatus,JobPersonnel," & _
                    "JobInvoiceNo,InvoiceParticulars," & _
                    "JobType,OrderNo,VesselETA,ShippingVessel," & _
                    "LastSlingDate,DispatchDate,ID " & _
                    "From Jobs " & _
                    "Where Jobid ='" & JobID & "'"

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                Call clsSubs.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                LabelRefNo.Text = drow("ReferenceNo")
                LabelJobDate.Text = Format(drow("JobDate"), "dd-MMM-yyyy")
                LabelVesseETA.Text = Format(drow("VesselETA"), "dd-MMM-yyyy")
                LabelManifestNo.Text = drow("ManifestNo")

                LabelVessel.Text = drow("ShippingVessel")
                LabelVesselStatus.Text = drow("ShipStatus")

                LabelBL.Text = drow("BL")
                LabelBLOrigin.Text = drow("BLCountry")
                LabelGoods.Text = drow("Goods")
                LabelOrderNo.Text = drow("OrderNo")

                cfs = drow("CFS")
                SetClient(JobID, drow("ClientID"), False)



                LabelDaysTaken.Text = drow("DaysTaken")
                LabelJobCount.Text = "Job " & ComboJobID.SelectedIndex + 1 & " of " & ComboJobID.Items.Count



                For Each col In tmptable.Columns
                    If drow(col.ColumnName.ToString) = "" Then
                        drow(col.ColumnName.ToString) = "-"
                    End If
                Next

            End If

        Catch exp As Exception

        Finally
            Call LoadJobCargo(JobID, CFS)
            Call LoadJobProgress(JobID)
        End Try

    End Sub


    Private Sub LoadJobCargo(JobID As String, CFS As String)

        Dim sqlstr As String = _
           "Select JobId,ContainerNo,Payload," & _
           "TEU,Weight,CBM," & _
           "VehicleNo,Transporter," & _
           "PortExitDate,ContainerStatus," & _
           "RemainingDays,ID " & _
           "From JobCargo " & _
           "Where JobID = '" & JobID & "' "


        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        Dim col As New DataColumn("PortExitDate1", Type.GetType("System.String"))
        Dim col1 As New DataColumn("CargoCount", Type.GetType("System.String"))
        Dim col2 As New DataColumn("CFS", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        tmptable.Columns.Add(col2)

        Dim a As Integer
        Dim drow As DataRow

        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)

            If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
            Else
                drow("PortExitDate1") = "-"
            End If

            a = a + 1
        Next



        If tmptable.Rows.Count = 0 Then
            drow = tmptable.NewRow
            drow("Payload") = ""
            tmptable.Rows.Add(drow)
        End If

        a = 0
        For Each drow In tmptable.Rows
            Call clsSubs.NullChecker(tmptable, a)
            drow("CargoCount") = a + 1
            drow("CFS") = CFS
            a = a + 1
        Next

        '  Call clsSubs.SetRemainingDays(tmptable, JobID)
        LabelCargoDetails.Text = "Container / Cargo & Transport : " & tmptable.Rows.Count & "  Items "
        If tmptable.Rows.Count < 5 Then
            PanelCargo.Height = Nothing
        Else
            PanelCargo.Height = 255
        End If

        DataList2.DataSource = tmptable
        DataList2.DataBind()



    End Sub



    Private Sub LoadJobProgress(JobID As String)
        Try


            Dim sqlstr As String = _
            "Select JobId,Status," & _
            "JobProgress.UserID,StaffName," & _
            "Date,JobStatusID, JobProgress.ID " & _
            "From JobProgress,Staff " & _
            "Where JobId = '" & JobID & "' " & _
            "And Staff.UserID = JobProgress.UserID " & _
            "Order By Date Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String = _
              "Select StatusID,Status " & _
              "From JobStatuses "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim dv As New DataView(tmptable1)




            Dim sqlstr2 As String = _
             "Select UserCSDID,CFPROuserID " & _
             "FROM CFPROAccountConnect " & _
             "Where  CFAgentCSDID = '" & LabelCfAgentCSDID.Text & "' "


            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim dv1 As New DataView(tmptable2)
           

            Dim a As Integer
            Dim col1 As New DataColumn("Date1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("UpdateCount", Type.GetType("System.String"))
            Dim col3 As New DataColumn("UserImageURL", Type.GetType("System.String"))
            Dim col4 As New DataColumn("JobStatus", Type.GetType("System.String"))
            Dim col5 As New DataColumn("ShowJobStatus", Type.GetType("System.Boolean"))
            Dim col6 As New DataColumn("UserIDImageURL", Type.GetType("System.String"))

            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)

            If tmptable.Rows.Count = 0 Then
                Dim drow As DataRow
                drow = tmptable.NewRow
                drow("Status") = ""
                tmptable.Rows.Add(drow)
            End If


            Dim UserImageURL As String = ""
            For Each drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)
                drow("Date1") = Format(drow("Date"), "dd MMM yyyy hh:mm tt")


                dv1.RowFilter = "CFPROuserID = '" & drow("UserID") & "' "

                If dv1.Count > 0 Then
                    If File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".png")) Then
                        UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".png"
                    ElseIf File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".jpg")) Then
                        UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".jpg"
                    Else
                        UserImageURL = "imageplaceholder.png"
                    End If
                Else
                    UserImageURL = "imageplaceholder.png"
                End If


                drow("UserImageURL") = UserImageURL
                drow("UserIDImageURL") = drow("UserID") & "|" & drow("UserImageURL")

                dv.RowFilter = "StatusID = '" & drow("JobStatusID") & "' "

                If dv.Count > 0 Then
                    drow("JobStatus") = "- Job Status: " & dv(0)("Status")
                End If

                a = a + 1

                drow("UpdateCount") = a & "."
            Next

            If tmptable.Rows.Count < 9 Then
                PanelUpdates.Height = Nothing
            Else
                PanelUpdates.Height = 600
                PanelCargo.Height = 255
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelUpdateCount.Text = "Status Updates - " & tmptable.Rows.Count

            LabelMessage1.Text = ""
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try


    End Sub

   

  


    Private Sub SetClient(JobID As String, ClientID As String, SaveClientID As Boolean)
        Try

            Dim sqlstr As String = _
                    "Select ClientID,Client,Box," & _
                    "Telephone,Town,Email,Id " & _
                    "From Clients " & _
                    "Where ClientID = '" & ClientID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsSubs.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String = _
                    Trim(drow("Client")) & "|" & _
                    drow("Box") & "|" & _
                    drow("Telephone") & "|" & _
                    drow("Town") & "|" & _
                    drow("Email")

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2() As String
                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)
                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                LabelClient.Text = Join(tmpstr2, vbCrLf)

                If SaveClientID Then
                    Dim sqlstr1 As String = _
                                "Select ClientID, Id " & _
                                "From Jobs " & _
                                "Where JobId ='" & JobID & "'"

                    Dim tmptable1 As New DataTable()
                    Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

                    If tmptable1.Rows.Count > 0 Then
                        drow = tmptable1.Rows(0)
                        drow("ClientID") = ClientID
                        Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)
                        '  Call SetStorageDemurrageData(JobID)

                    End If
                End If
            Else
                LabelClient.Text = ""
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub
    Protected Sub OnRowDataBound(sender As Object, e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridSearchResults, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub OnSelectedIndexChanged(sender As Object, e As EventArgs)
        Dim row As GridViewRow = GridSearchResults.Rows(GridSearchResults.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridSearchResults.Rows.Count - 1
            row = GridSearchResults.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridSearchResults.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub
    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        Call LoadJob(ComboJobID.Text)
    End Sub

    Private Sub Navigate(ByVal direction As String)

        Select Case direction

            Case "<<"
                If ComboJobID.Items.Count > 0 Then
                    ComboJobID.SelectedIndex = 0
                End If

            Case ">>"
                If ComboJobID.Items.Count > 0 Then
                    ComboJobID.SelectedIndex = ComboJobID.Items.Count - 1
                End If

            Case ">"
                If ComboJobID.SelectedIndex + 1 <= ComboJobID.Items.Count - 1 Then
                    ComboJobID.SelectedIndex = ComboJobID.SelectedIndex + 1
                End If

            Case "<"
                If ComboJobID.SelectedIndex - 1 >= 0 Then
                    ComboJobID.SelectedIndex = ComboJobID.SelectedIndex - 1
                End If
        End Select

        Call LoadJob(ComboJobID.Text)
    End Sub
    Protected Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        Navigate("<<")
    End Sub

    Protected Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        Navigate("<")
    End Sub

    Protected Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        Navigate(">")
    End Sub

    Protected Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Navigate(">>")
    End Sub


    
    Protected Sub ButtonGoBack1_Click(sender As Object, e As EventArgs) Handles ButtonGoBack1.Click
        Call GoBack()
    End Sub
   
    Private Sub GoBack()

        Dim backurl As String = ""
        If InStr(LabelFromPageURL.Text, "progress", CompareMethod.Text) > 0 Then
            backurl = "jobentry.aspx"
        Else
            backurl = LabelFromPageURL.Text
        End If

        Response.Redirect(backurl)
    End Sub

    Function CSDIDfromCFPROuserID(CFAgentCSDID, CFPROuserID) As String
        Dim sqlstr As String = _
              "Select UserCSDID " & _
              "FROM CFPROAccountConnect " & _
              "Where  CFAgentCSDID = '" & CFAgentCSDID & "' " & _
              "And CFPROuserID = '" & CFPROuserID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsSubs.NullChecker(tmptable, 0)
            Return drow("UserCSDID")
        Else
            Return ""
        End If


    End Function

    Private Sub Search()
        Try

            ' ModalPopupExtender1.Show()

            If Trim(TextSearch.Text) = "" Then
                LabelSearchMessage.Text = "Invalid Search String"
                LabelSearchMessage.ForeColor = Color.Red
                Exit Sub
            End If

            Dim SearchField As String
            If RadioButtonList1.Items(0).Selected Then
                SearchField = "JobId"
                Session("Searchitem") = "job"

            ElseIf RadioButtonList1.Items(1).Selected Then
                SearchField = "ReferenceNo"
                Session("Searchitem") = "reference"

            ElseIf RadioButtonList1.Items(2).Selected Then
                SearchField = "Client"
                Session("Searchitem") = "client"

            ElseIf RadioButtonList1.Items(4).Selected Then
                SearchField = "BL"
                Session("Searchitem") = "bl"

            ElseIf RadioButtonList1.Items(4).Selected Then
                SearchField = "IDFNo"
                Session("Searchitem") = "idf"

            ElseIf RadioButtonList1.Items(5).Selected Then
                SearchField = "ContainerNo"
                Session("Searchitem") = "container"


            ElseIf RadioButtonList1.Items(6).Selected Then
                SearchField = "VehicleNo"
                Session("Searchitem") = "vehicle"

            ElseIf RadioButtonList1.Items(7).Selected Then
                SearchField = "Transporter"
                Session("Searchitem") = "transporter"

            ElseIf RadioButtonList1.Items(8).Selected Then
                SearchField = "Driver"
                Session("Searchitem") = "driver"

            ElseIf RadioButtonList1.Items(9).Selected Then
                SearchField = "Telephone"
                Session("Searchitem") = "telephone"

            ElseIf RadioButtonList1.Items(10).Selected Then
                SearchField = "Email"
                Session("Searchitem") = "email"

            Else
                LabelSearchMessage.Text = "Please set item to search for"
                LabelSearchMessage.ForeColor = Color.Red
                Exit Sub
            End If

            Dim sqlstr As String = _
                           "Select ReferenceNo, Client," & _
                           "BL,ReferenceNo1," & _
                           "Importer,JobId, Id " & _
                           "From Jobs "


            Dim sqlstr1 As String


            If SearchField = "ReferenceNo" Then
                sqlstr1 = sqlstr & _
                " Where " & SearchField & " " & _
                "Like '%" & Trim(TextSearch.Text) & "%' " & _
                "Or ReferenceNo1 " & _
                "Like '%" & Trim(TextSearch.Text) & "%'" & _
                "Order by Id DESC;"

            ElseIf SearchField = "BL" Then
                sqlstr1 = sqlstr & _
                " Where " & SearchField & " " & _
                "Like '%" & Trim(TextSearch.Text) & "%' " & _
                "Or HouseBL " & _
                "Like '%" & Trim(TextSearch.Text) & "%'" & _
                "Order by Id DESC;"

            ElseIf SearchField = "Client" Then
                sqlstr1 = sqlstr & _
                " Where " & SearchField & " " & _
                "Like '%" & Trim(TextSearch.Text) & "%' " & _
                "Or Importer " & _
                "Like '%" & Trim(TextSearch.Text) & "%'" & _
                "Order by Id DESC;"

            Else
                sqlstr1 = sqlstr & _
                " Where " & SearchField & " " & _
                "Like '%" & Trim(TextSearch.Text) & "%' " & _
                "Order by Id DESC;"

            End If


            If RadioButtonList1.Items(5).Selected Then
                GridSearchResults.Columns(0).HeaderText = "Container No."
                GridSearchResults.Columns(1).HeaderText = "Vehicle No."
                GridSearchResults.Columns(2).HeaderText = "Reference No"


                sqlstr1 = _
                    "Select JobId,ContainerNo," & _
                    "VehicleNo,Driver," & _
                    "Transporter,Id " & _
                    "From JobCargo " & _
                    "Where " & SearchField & " " & _
                    "Like '%" & Trim(TextSearch.Text) & "%'" & _
                    "Order by Id DESC;"

            ElseIf RadioButtonList1.Items(4).Selected Then

                GridSearchResults.Columns(0).HeaderText = "Client"
                GridSearchResults.Columns(1).HeaderText = "IDF No."
                GridSearchResults.Columns(2).HeaderText = "BL No."

                sqlstr1 = _
                    "Select JobId,IDFNo, Id " & _
                    "From JobIDfs " & _
                    "Where " & SearchField & " " & _
                    "Like '%" & Trim(TextSearch.Text) & "%'" & _
                    "Order by Id DESC;"

            Else
                GridSearchResults.Columns(0).HeaderText = "Client"
                GridSearchResults.Columns(1).HeaderText = "BL No."
                GridSearchResults.Columns(2).HeaderText = "Reference No"
            End If



            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable, clsData.constr)


            Dim col As New DataColumn("ItemURL", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Item2", Type.GetType("System.String"))
            Dim col3 As New DataColumn("Item3", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)


            Dim Drow As DataRow
            Dim a As Integer



            For Each Drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)
                Dim tmpstr() As String = Drow(0).ToString.Split(vbCrLf)
                Dim tmpstr1() As String = Drow(1).ToString.Split(vbCrLf)
                Dim tmpstr2() As String = Drow(2).ToString.Split(vbCrLf)

                ReDim Preserve tmpstr(0), tmpstr1(0), tmpstr2(0)

                Drow("ItemURL") = "jobentry.aspx?jobid=" & (Drow("JobId"))
                Drow("Item1") = tmpstr(0)
                Drow("Item2") = tmpstr1(0)
                Drow("Item3") = tmpstr2(0)


                a = a + 1

            Next

            If tmptable.Rows.Count = 0 Then
                Drow = tmptable.NewRow
                Drow("ItemURL") = Nothing
                Drow("Item1") = "-"
                Drow("Item2") = "No results found for '" & TextSearch.Text & "'"
                tmptable.Rows.Add(Drow)
            End If

            If tmptable.Rows.Count < 10 Then
                GridSearchResults.Height = 20 + (24 * tmptable.Rows.Count)
            End If


            GridSearchResults.DataSource = tmptable
            GridSearchResults.DataBind()

            LabelSearchMessage.Text = tmptable.Rows.Count & " results found matching  '" & TextSearch.Text & "' "

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
 
    '<System.Web.Services.WebMethodAttribute, System.Web.Script.Services.ScriptMethodAttribute> _
    'Public Shared Function GetDynamicContent(contextKey As String) As String
    'end sub
    Private Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "staffdetails" Then
            Call StaffDetails(e.CommandArgument)
        End If
    End Sub
    Private Sub StaffDetails(UserIDImageURL As String)
        ModalPopupExtender1.Show()


        Dim tmpstr() As String = UserIDImageURL.Split("|")
        ReDim Preserve tmpstr(1)
        Dim sqlstr As String = _
           "SELECT  StaffName, JobDescription," & _
           "Department, Telephone, Email " & _
           "FROM Staff " & _
           "Where UserID  = '" & tmpstr(0) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsSubs.NullChecker(tmptable, 0)

            LabelStaffName.Text = drow("StaffName")
            LabelJobDescription.Text = drow("JobDescription")
            LabelTelephone.Text = drow("Telephone")
            LabelEmail.Text = drow("Email")



        End If

        If Not tmpstr(1) = "" Then
            ImageUserImage.ImageUrl = tmpstr(1)
        End If
    End Sub


    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs)
        '  ModalPopupExtender1.Show()
    End Sub

    Protected Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        ModalPopupExtender1.Hide()
    End Sub

    Protected Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click

    End Sub

    Private Sub DownloadCargoStatusPDF(fileName As String)
        Response.ClearContent()
        Response.ClearHeaders()
        Response.ContentType = "application/pdf"
        Response.AddHeader("Content-Disposition", "attachment; filename=" & fileName)
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Buffer = True
        Response.BinaryWrite(clsCargoStatusPDF.CargoStatusDoc(fileName, ComboJobID.SelectedValue, False))
        Response.End()
        Response.Flush()
        Response.Clear()
        Response.Close()

    End Sub

    Protected Sub ButtonDownloadPDF_Click(sender As Object, e As EventArgs) Handles ButtonDownloadPDF.Click
        Call DownloadCargoStatusPDF("Cargo Status" & Format(Now, "dd-MMM-yyyy hh:mm:ss tt") & ".pdf")
    End Sub

    Private Sub EmailCargoStatusPDF(fileName As String)
        Try
            clsCargoStatusPDF.CargoStatusEmail(fileName, ComboJobID.SelectedValue, False)
            LabelMessage1.BackColor = Color.Aqua
            LabelMessage1.Text = "Email sent successfully!"
        Catch ex As Exception
            LabelMessage1.Text = "failure" & ex.Message
        End Try
    End Sub

    Protected Sub ButtonEmailPDF_Click(sender As Object, e As EventArgs) Handles ButtonEmailPDF.Click
        'Call EmailCargoStatusPDF("Cargo Status" & Format(Now, "dd-MMM-yyyy hh:mm:ss tt") & ".pdf")
        Dim jobid As String = ""
        LoadSendMessage("sendmessage.aspx?jobid=" & jobid, " Send Message")
    End Sub


    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        Dim jobid As String = ""
        LoadSendMessage("sendmessage.aspx?jobid=" & jobid, " Send Message")
    End Sub

    Private Sub LoadSendMessage(funcsource As String, cfFunction As String)
        LabTitle.Text = cfFunction
        iframe1.Attributes("src") = funcsource
        ModalPopupExtender2.Show()
    End Sub

End Class