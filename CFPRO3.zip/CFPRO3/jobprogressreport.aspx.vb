﻿
Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing

Public Class jobprogressreport
    Inherits System.Web.UI.Page

    

   

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            Dim UserType As String = ""
            Dim External As Boolean

            If Not Request.Cookies("UserType") Is Nothing Then
                UserType = Request.Cookies("UserType").Value
                If UserType = "tracking" Then
                    External = False
                Else
                    External = True
                End If
            End If

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), External)
            End If

            Dim FromURL As String = ""
            If Not IsNothing(Page.Request.UrlReferrer) Then
                FromURL = Page.Request.UrlReferrer.ToString()
                LabelFromPageURL.Text = FromURL
            End If


            Dim JobID As String = Request.QueryString("jobid")
            Dim ClientID As String = Request.QueryString("clientid")
            Dim CFPROID As String = ""

            Call clsAuth.UserLoggedIn(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", False)


            If UserType = "tracking" Then
                If Not Request.Cookies("CFAgent") Is Nothing Then
                    Call clsAuth.AuthCFAgent(CFPROID, LabelCFAgent.Text, "", "", Image1.ImageUrl, "", False)
                    If LabelUser.Text = "Guest" Then
                        Image2.ImageUrl = "imageplaceholder.png"
                    End If

                End If
            End If



            LabelCFPROID.Text = CFPROID
            LabelJobID.Text = JobID
            LabelUserType.Text = UserType

            Call LoadJob(JobID, CFPROID)


            If Not UserType = "" Then

                If UserType = "importer" Then
                    LinkGoBack.Text = "< Go Back to My Consignments"
                    LinkGoBack1.Text = "< Go Back to My Consignments"
                    PanelTopMenu.Visible = False
                    PanelImpoterMenu.Visible = True
                    ButtonTextMessage.Visible = False


                ElseIf UserType = "tracking" Then
                    LinkGoBack.Text = "< Go Back to Tracking"
                    LinkGoBack1.Text = "< Go Back to Tracking"

                    PanelTopMenu.Visible = False
                    PanelImpoterMenu.Visible = False
                    ButtonTextMessage.Visible = False
                    ButtonInsure.Visible = False
                    ButtonJobDocuments.Visible = False
                    ButtonSendMessage.Visible = False
                    HyperLinkStart2.NavigateUrl = "tracking.aspx"

                ElseIf UserType = "cfagent" Then
                    LinkGoBack.Text = "< Go Back to Job Entry"
                    LinkGoBack1.Text = "< Go Back to Job Entry"

                    PanelTopMenu.Visible = True
                    PanelImpoterMenu.Visible = False
                End If
            Else
                LinkGoBack.Visible = False
                LinkGoBack1.Visible = False
            End If


            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"
            LabeliFrameBgStyle.Text = "background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position-y: center; background-position-x: center;"

        End If



    End Sub



    Private Sub LoadJob(JobID As String, CFPROID As String)

        Dim CFSID As String = ""
        Try
            Dim sqlstr As String = _
                    "Select JobId,ReferenceNo," & _
                    "JobDate,ClientID,ImporterID," & _
                    "CFSID,BL,BLCountry," & _
                    "Goods,ShipStatus,ManifestNo," & _
                    "InvoiceAmount,JobType,UserID, " &
                    "OrderNo,VesselID," & _
                    "DispatchDate,EntryNo,ID " & _
                    "From Jobs " & _
                    "Where JobID ='" & JobID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()

            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)

                Dim tmpstr() As String = clsShippingStorage.GetVessel(CFPROID, drow("VesselID"), LabelMessage1.Text)
                ReDim Preserve tmpstr(5)
                LabelVessel.Text = tmpstr(1)

                If Not CDate(tmpstr(3)) = CDate("1 Jan 1800") Then
                    LabelVesseETA.Text = tmpstr(3)
                End If


                LabelDaysTaken.Text = clsShippingStorage.DaysTaken(tmpstr(5), drow("DispatchDate")).ToString

                LabelRefNo.Text = drow("ReferenceNo")
                LabelJobDate.Text = Format(drow("JobDate"), "dd MMM yyyy")

                LabelManifestNo.Text = drow("ManifestNo")

                LabelVesselStatus.Text = drow("ShipStatus")

                LabelBL.Text = drow("BL")
                LabelBLOrigin.Text = drow("BLCountry")
                LabelGoods.Text = drow("Goods")
                LabelOrderNo.Text = drow("OrderNo")
                LabelClientID.Text = drow("ClientID")

                GetClient(CFPROID, drow("ClientID"))
                GetImporter(CFPROID, drow("ImporterID"))

                LabelEntryNo.Text = drow("EntryNo")

                LabelInsuranceCode.Text = JobID & "-" & CFPROID
                LabelInvoiceAmount.Text = Format(drow("InvoiceAmount"), "#,##0.00")

                LabelCFS.Text = GetCFS(drow("CFSID"), CFPROID)

                For Each col In tmptable.Columns
                    If drow(col.ColumnName.ToString) = "" Then
                        drow(col.ColumnName.ToString) = "-"
                    End If
                Next

            End If

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        Finally
            Call LoadJobCargo(JobID, CFPROID)
            Call LoadJobProgress(JobID, CFPROID)
        End Try

    End Sub

    Private Sub GetClient(CFPROID As String, ClientID As String)
        Try

            Dim sqlstr As String = _
                    "Select ClientID,Client,Box," & _
                    "Telephone,Town,Email,Id " & _
                    "From Clients " & _
                    "Where ClientID = '" & ClientID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String = _
                    Trim(drow("Client"))

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2() As String
                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)
                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                LabelClient.Text = Join(tmpstr2, vbCrLf)
            Else
                LabelClient.Text = ""
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Private Sub GetImporter(CFPROID As String, ImporterID As String)
        Try

            Dim sqlstr As String = _
                    "Select ImporterID,Importer," & _
                    "Telephone,Town,Email,Id " & _
                    "From Importers " & _
                    "Where ImporterID = '" & ImporterID & "' " & _
                    "And CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Dim drow As DataRow
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                drow = tmptable.Rows(0)
                Dim a As Integer
                Dim tmpstr As String = _
                    Trim(drow("Importer")) & "|" & _
                     drow("Telephone") & "|" & _
                     drow("Email")

                Dim tmpstr1() As String = tmpstr.Split("|")
                Dim tmpstr2() As String
                Dim b As Integer
                For a = 0 To tmpstr1.GetUpperBound(0)
                    If Not Trim(tmpstr1(a)) = "" Then
                        ReDim Preserve tmpstr2(b)
                        tmpstr2(b) = Trim(tmpstr1(a))
                        b = b + 1
                    End If
                Next

                LabelConsignee.Text = Join(tmpstr2, vbCrLf)


            Else
                LabelConsignee.Text = ""
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub


    Private Function GetCFS(CFSID As String, CFPROID As String) As String


        Dim sqlstr As String = _
                "Select CFS, ID " & _
                "From CFS " & _
                "Where CFSID = '" & CFSID & "' " & _
                "And CFPROID = '" & CFPROID & "' "

        Dim tmptable As New DataTable()
        Dim drow As DataRow
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            drow = tmptable.Rows(0)
            Return drow("CFS")
        End If

        Return ""
    End Function




    Private Sub LoadJobCargo(JobID As String, CFPROID As String)
        Try
            Dim sqlstr As String = _
               "Select JobId,ContainerNo," & _
               "Payload,TEU,Weight,CBM," & _
               "VehicleNo,TransporterID," & _
               "PortExitDate,ContainerStatus," & _
               "RemainingDays,ID " & _
               "From JobCargo " & _
               "Where JobID = '" & JobID & "' " & _
               "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String = _
                       "Select Transporter,TransporterID " & _
                       "From Transporters " & _
                       "Where CFPROID = '" & CFPROID & "' "


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)


            Dim a As Integer
            Dim drow As DataRow

            Dim col As New DataColumn("PortExitDate1", Type.GetType("System.String"))
            Dim col1 As New DataColumn("CargoCount", Type.GetType("System.String"))
            Dim col3 As New DataColumn("Transporter", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col3)


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Not CDate(drow("PortExitDate")) = CDate("1-Jan-1800") Then
                    drow("PortExitDate1") = Format(drow("PortExitDate"), "dd MMM yyyy")
                Else
                    drow("PortExitDate1") = "-"
                End If

                dv1.RowFilter = "TransporterID ='" & drow("TransporterID") & "' "

                If dv1.Count > 0 Then
                    drow("Transporter") = dv1(0)("Transporter")
                End If
                a = a + 1
            Next

            a = 0

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("CargoCount") = a + 1
                a = a + 1
            Next

            LabelCargoDetails.Text = "Container | Cargo & Transport : " & tmptable.Rows.Count & "  Items "

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("Payload") = ""
                tmptable.Rows.Add(drow)
            End If


            '  Call clsSubs.SetRemainingDays(tmptable, JobID)

            If tmptable.Rows.Count < 5 Then
                PanelCargo.Height = Nothing
            Else
                PanelCargo.Height = 255
            End If

            DataList2.DataSource = tmptable
            DataList2.DataBind()


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadJobProgress(JobID As String, CFPROID As String)
        Try


            Dim sqlstr As String = _
               "Select JobID,Status," & _
               "UserID,Date," & _
               "JobStatusID, ID " & _
               "From JobProgress " & _
               "Where JobID = '" & JobID & "' " &
               "And CFPROID = '" & CFPROID & "' " & _
               "Order By Date Desc;"


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String = _
              "Select ItemID,ItemDescription " & _
              "From KPIProgress"

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)




            Dim sqlstr2 As String = _
             "Select UserCSDID,CFPROuserID " & _
             "FROM CFPROAccountConnect " & _
             "Where  CFPROID = '" & CFPROID & "' "


            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)




            Dim sqlstr3 As String = _
             "Select UserID,UserNames " & _
             "From CFAgentUsers " & _
             "Where CFAgentUsers.CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)


            Dim a As Integer
            Dim col1 As New DataColumn("Date1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("UpdateCount", Type.GetType("System.String"))
            Dim col3 As New DataColumn("UserImageURL", Type.GetType("System.String"))
            Dim col4 As New DataColumn("JobStatus", Type.GetType("System.String"))
            Dim col5 As New DataColumn("ShowJobStatus", Type.GetType("System.Boolean"))
            Dim col6 As New DataColumn("UserIDImageURL", Type.GetType("System.String"))
            Dim col7 As New DataColumn("UserNames", Type.GetType("System.String"))

            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)

            If tmptable.Rows.Count = 0 Then
                Dim drow As DataRow
                drow = tmptable.NewRow
                drow("Status") = ""
                tmptable.Rows.Add(drow)
            End If


            Dim UserImageURL As String = ""
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                'drow("Date1") = Format(drow("Date"), "dd MMM yyyy hh:mm tt")
                dv1.RowFilter = "ItemID = '" & drow("JobStatusID") & "' "

                If dv1.Count > 0 Then
                    drow("JobStatus") = "- Job Status: " & dv1(0)("ItemDescription")
                End If


                dv2.RowFilter = "CFPROuserID = '" & drow("UserID") & "' "

                If dv2.Count > 0 Then
                    If File.Exists(Server.MapPath("~/userimages/" & dv2(0)("UserCSDID") & ".png")) Then
                        UserImageURL = "~/userimages/" & dv2(0)("UserCSDID") & ".png"
                    ElseIf File.Exists(Server.MapPath("~/userimages/" & dv2(0)("UserCSDID") & ".jpg")) Then
                        UserImageURL = "~/userimages/" & dv2(0)("UserCSDID") & ".jpg"
                    Else
                        UserImageURL = "imageplaceholder.png"
                    End If
                Else
                    UserImageURL = "imageplaceholder.png"
                End If


                drow("UserImageURL") = UserImageURL
                drow("UserIDImageURL") = drow("UserID") & "|" & drow("UserImageURL")




                dv3.RowFilter = "UserID = " & "'" & drow("UserID") & "'"

                If dv3.Count > 0 Then
                    drow("UserNames") = dv3(0)("UserNames")
                End If

                a = a + 1

                drow("UpdateCount") = a & "."
            Next

            If tmptable.Rows.Count <= 7 Then
                PanelUpdates.Height = Nothing
            Else
                PanelUpdates.Height = 595
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelUpdateCount.Text = "Status Updates - " & tmptable.Rows.Count

            Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, JobID, "", "", "", "jobdocuments", "")
            ButtonJobDocuments.Text = "Job Documents - " & DocumentCount


            LabelMessage1.Text = ""
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try


    End Sub

    Private Sub GoBack()

        Dim backurl As String = ""
        If InStr(LabelFromPageURL.Text, "progress", CompareMethod.Text) > 0 Or InStr(LabelFromPageURL.Text, "jobentry", CompareMethod.Text) > 0 Then
            backurl = "jobentry.aspx?jobid=" & Request.QueryString("jobid")
        Else
            backurl = LabelFromPageURL.Text
        End If

        Response.Redirect(backurl)
    End Sub

    Function CSDIDfromCFPROuserID(CFPROID, CFPROuserID) As String
        Dim sqlstr As String = _
              "Select UserCSDID " & _
              "FROM CFPROAccountConnect " & _
              "Where  CFPROID = '" & CFPROID & "' " & _
              "And CFPROuserID = '" & CFPROuserID & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)
            Return drow("UserCSDID")
        Else
            Return ""
        End If


    End Function


    Private Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "CFAgentUser" Then
            Call CFAgentUserDetails(e.CommandArgument)
        End If
    End Sub
    Private Sub CFAgentUserDetails(UserIDImageURL As String)
        ModalPopupExtender1.Show()


        Dim tmpstr() As String = UserIDImageURL.Split("|")
        ReDim Preserve tmpstr(1)
        Dim sqlstr As String = _
           "SELECT  UserNames, JobDescription," & _
           "Department, Telephone, Email " & _
           "FROM CFAgentUsers " & _
           "Where UserID  = '" & tmpstr(0) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            LabelUserNames.Text = drow("UserNames")
            LabelJobDescription.Text = drow("JobDescription")
            LabelTelephone.Text = drow("Telephone")
            LabelEmail.Text = drow("Email")

        End If

        If Not tmpstr(1) = "" Then
            ImageUserImage.ImageUrl = tmpstr(1)
        End If
    End Sub




    Protected Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        ModalPopupExtender1.Hide()
    End Sub

    Protected Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click


        Dim JobID As String = Request.QueryString("jobid")
        Dim CFPROUserCSDID As String = ""
        LoadSendMessage("sendmessage.aspx?jobid=" & JobID & "&SendToCSDID=" & CFPROUserCSDID, " Send Message")
        ModalPopupExtender2.Show()



    End Sub


    Protected Sub ButtonDownloadPDF_Click(sender As Object, e As EventArgs) Handles ButtonDownloadPDF.Click

        If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
            If Request.QueryString("loadedbyimporter") = "0" Then
                If Not clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00015") Then
                    LabelMessage.Text = "Action Not Allowed for User"""
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If

            ' Call DownloadCargoStatusPDF("Job Progress Report " & Format(Now, "dd MMM yyyy hh:mm:ss tt") & ".pdf")



            Dim JobProgressStatus As String =
                clsJobProgressStatusPDF.JobProgressStatus(Request.QueryString("jobid"), LabelCFPROID.Text)


            If File.Exists(Server.MapPath(JobProgressStatus)) Then
                LoadDialog(JobProgressStatus, "Job Progress Report ", 600, 900)
            End If


        End If

    End Sub


    Protected Sub ButtonSendMessage_Click(sender As Object, e As EventArgs) Handles ButtonSendMessage.Click
        Dim JobID As String = Request.QueryString("jobid")
        LoadSendMessage("sendmessage.aspx?jobid=" & JobID & "&filetype=jobdocuments&sendercsdid=" & LabelCSDID.Text & "&receivercsdid=" & LabelCFPROID.Text & "&CFPROID=" & LabelCFPROID.Text, "Send Message")

    End Sub

    Private Sub LoadSendMessage(page As String, title As String)

        If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
            If Request.QueryString("loadedbyimporter") = "0" Then
                If Not clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00016") Then
                    LabelMessage.Text = "User Not Allowed"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If
            End If
            LabTitle.Text = title
            iframe1.Attributes("src") = page
            ModalPopupExtender2.Show()
        End If


    End Sub


    Protected Sub LinkGoBack_Click(sender As Object, e As EventArgs) Handles LinkGoBack.Click
        Call GoBack()
    End Sub

    Protected Sub LinkGoBack0_Click(sender As Object, e As EventArgs) Handles LinkGoBack1.Click
        Call GoBack()
    End Sub

    Protected Sub ButtonJobDocuments_Click(sender As Object, e As EventArgs) Handles ButtonJobDocuments.Click

        Dim LoadedbByImporter As Integer = 0
        If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
            LoadedbByImporter = Request.QueryString("loadedbyimporter")
        End If

        Dim JobID As String = Request.QueryString("jobid")
        Call LoadDialog("documents.aspx?loadedbyimporter=0&jobid=" & JobID & "&loadedbyimporter=" & LoadedbByImporter, "Job Documents", 480, 820)

    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click

        Dim UserType As String = LabelUserType.Text
        Dim ReturnToUrl As String = ""
        If UserType = "tracking" Then
            Dim LoadedbByImporter As Integer = 0
            If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
                LoadedbByImporter = Request.QueryString("loadedbyimporter")
            End If
            Dim JobID As String = Request.QueryString("jobid")
            ReturnToUrl = "?jobid=" & JobID & "&loadedbyimporter=" & LoadedbByImporter

        End If

        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image2.ImageUrl, True, "jobprogressreport.aspx" & ReturnToUrl)

    End Sub

    Protected Sub ButtonGoBack4_Click(sender As Object, e As EventArgs) Handles ButtonInsure.Click
        Call LoadDialog("marineinsurancepurchase.aspx?clientid=" & LabelClientID.Text & "&insurablesum=" &
                 LabelInvoiceAmount.Text & "&consignmentcode=" & LabelInsuranceCode.Text, "Marine Insurance Purchase", 600, 900)
    End Sub

    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe2.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe2.Attributes("src") = pageurl
        ModalPopupExtender3.Show()
    End Sub
    Protected Sub ButtonEmailPDF_Click(sender As Object, e As EventArgs) Handles ButtonEmailPDF.Click

        If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
            If Request.QueryString("loadedbyimporter") = "0" Then
                If Not clsAuth.UserAllowed(LabelCFPROID.Text, LabelCFPROUserID.Text, "00015") Then
                    LabelMessage.Text = "Action Not Allowed for User"
                    LabelMessage.ForeColor = Color.Red
                    Exit Sub
                End If

            End If
            Call LoadEmailProgressPDF(LabelCFPROID.Text, LabelCFPROUserID.Text, LabelClientID.Text)
        End If
    End Sub

    Private Sub LoadEmailProgressPDF(CFPROID As String, UserID As String, ClientID As String)

        Call clsJobProgressStatusPDF.JobProgressStatus(Request.QueryString("jobid"), LabelCFPROID.Text)

        PanelEmailMessage.Visible = True
        ButtonEmailPDFReport.Visible = True
        Image7.Visible = False

        Dim sqlstr2 As String = _
        "SELECT  Client, Email " & _
        "FROM Clients " & _
        "Where CFPROID = '" & CFPROID & "' " &
        "And ClientID  = '" & ClientID & "' "

        Dim tmptable2 As New DataTable()
        Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

        If tmptable2.Rows.Count > 0 Then
            Dim drow2 As DataRow = tmptable2.Rows(0)
            Call clsData.NullChecker(tmptable2, 0)
            TextEmailAddress.Text = drow2("Email")
        End If

        Dim LoadedbByImporter As Integer = 0
        If Not IsNothing(Request.QueryString("loadedbyimporter")) Then
            LoadedbByImporter = Request.QueryString("loadedbyimporter")
        End If

        If LoadedbByImporter = 0 Then
            TextEmailMessage.Text = "Click below link to open your Cargo Progress Status Report."
        Else
            TextEmailMessage.Text = "Consignment progress status report."
        End If


        Dim EmailServer As Integer = clsEmail.CFAgentEmailServer(CFPROID)

        If EmailServer = 0 Then
            CheckDefaultEmailServer.Checked = True
            CheckDefaultEmailServer.Enabled = False

        ElseIf EmailServer = 1 Then
            CheckDefaultEmailServer.Checked = False
            CheckDefaultEmailServer.Enabled = True

        ElseIf EmailServer = 2 Then
            CheckDefaultEmailServer.Checked = True
            CheckDefaultEmailServer.Enabled = True
        End If

        ModalPopupExtender4.Show()

    End Sub
    Private Sub EmailProgressPDF(JobID As String, CFPROID As String, UserID As String, UserCSDID As String)
        Try

            Dim host As String = ""

            If InStr(Request.Url.ToString, "localhost:90", CompareMethod.Text) > 0 Then
                host = "http://localhost:90"
            ElseIf InStr(Request.Url.ToString, "172.16.254.10", CompareMethod.Text) > 0 Then
                host = "http://172.16.254.105:90"
            ElseIf InStr(Request.Url.ToString, "localhost:91", CompareMethod.Text) > 0 Then
                host = "http://www.cfproonline.com"
            Else
                host = "http://www.cfproonline.com"
            End If



            Dim CFAgentLogo As String = ""
            Dim UserImage As String = ""
            Dim CFAgentName As String = ""
            Dim CFAgentAddress As String = ""
            Dim CFAgentEmailAddress As String = ""

            Dim UserEmailAddress As String = ""
            Dim UserNames As String = ""
            Dim UserDepartment As String = ""
            Dim ClientEmailAddress As String = Trim(TextEmailAddress.Text)
            Dim ClientNames As String = LabelClient.Text

            If clsSubs.RemoteFileExists("http://www.cfproonline.com/userimages/" & UserCSDID & ".png") Then
                UserImage = "http://www.cfproonline.com/userimages/" & UserCSDID & ".png"
            ElseIf clsSubs.RemoteFileExists("http://www.cfproonline.com/userimages/" & UserCSDID & ".jpg") Then
                UserImage = "http://www.cfproonline.com/userimages/" & UserCSDID & ".jpg"
            Else
                UserImage = "http://www.cfproonline.com/userimages/000000000.png"
            End If


            Dim sqlstr As String =
            "Select CFAgentName, CFAgentAddress," &
            "EmailAddress, LogoURL " &
            "From CFPROAccounts " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                Call clsData.NullChecker(tmptable, 0)

                Dim tmpstr() As String = drow("LogoURL").ToString.Split(".")
                ReDim Preserve tmpstr(1)

                If clsSubs.RemoteFileExists("http://www.cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)) Then
                    CFAgentLogo = "http://www.cfproonline.com/cfagentimages/" & CFPROID & "." & tmpstr(1)
                Else
                    CFAgentLogo = "http://www.cfproonline.com/cfagentimages/000000000.png"
                End If


                CFAgentName = drow("CFAgentName")
                CFAgentAddress = drow("CFAgentAddress")
                CFAgentEmailAddress = drow("EmailAddress")
            End If


            Dim sqlstr1 As String = _
               "SELECT  UserNames, Email, Department " & _
               "FROM CFAgentUsers " & _
               "Where CFPROID = '" & CFPROID & "' " &
               "And UserID  = '" & UserID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            If tmptable1.Rows.Count > 0 Then
                Dim drow1 As DataRow = tmptable1.Rows(0)
                Call clsData.NullChecker(tmptable1, 0)

                UserEmailAddress = drow1("Email")
                UserNames = drow1("UserNames")
                UserDepartment = " - " & drow1("Department")
            Else
                UserNames = LabelUser.Text
            End If


            Dim ReportHeader As String = "Cargo Status Progress  Report"
            Dim ClientRefNo As String = ClientNames & " - Reference No: " & LabelRefNo.Text
            Dim Message As String = TextEmailMessage.Text
            Dim Signature As String = UserNames & " " & UserDepartment
            Dim Subject As String = "Cargo Progress Status  Report"


            Dim Reportlink As String = host & "/progressreportviewer.aspx?pdfprogressreport=" &
                HttpUtility.UrlEncode(clsEncr.EncryptString(host & "/progressreports/" & CFPROID & "/" & JobID & ".pdf"))


            Dim EmailBody As String = clsEmail.ProgressReportEmail(CFAgentLogo, UserImage, ReportHeader, ClientRefNo,
                            Message, Reportlink, Signature, CFAgentName, CFAgentAddress, Format(CDate(TodaysDate.Value), "dd MMM yyyy hh:mm tt"))

            Dim ErrMsg As String = ""

            If Not ClientEmailAddress = "" And InStr(ClientEmailAddress, "@", CompareMethod.Text) > 0 Then
                PanelEmailMessage.Visible = False
                ButtonEmailPDFReport.Visible = False
                Image7.Visible = True


                If UserEmailAddress = "" Then
                    UserEmailAddress = ClientEmailAddress
                    UserNames = ClientNames
                End If

                Dim SendResult As String =
              clsEmail.SendEmail(ClientEmailAddress, Subject, EmailBody, ClientNames,
                                                    UserEmailAddress, UserNames, True, CFPROID, CheckDefaultEmailServer.Checked)

                If SendResult = "Email Sent" Then
                    Image7.ImageUrl = "messagesent1.png"
                ElseIf SendResult = "Email Not Sent" Then
                    Image7.ImageUrl = "messagenotsent1.png"
                Else
                    Image7.ImageUrl = "error.png"
                    LabelMessage1.Text = SendResult
                End If
            Else
                Label43.Text = "Invalid Email Address"
                Label43.ForeColor = Color.Red
            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonEmailPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonEmailPDFReport.Click
        Call EmailProgressPDF(LabelJobID.Text, LabelCFPROID.Text, LabelCFPROUserID.Text, LabelCSDID.Text)
    End Sub

    Protected Sub ButtonCloseEmailPDFReport_Click(sender As Object, e As EventArgs) Handles ButtonCloseEmailPDFReport.Click
        ModalPopupExtender4.Hide()
    End Sub


    Protected Sub ButtonCloseDialog_Click(sender As Object, e As EventArgs) Handles ButtonCloseDialog.Click
        ModalPopupExtender3.Hide()
        If LabelDialogTitle.Text = "Job Documents" Then
            Dim JobID As String = Request.QueryString("jobid")
            Dim DocumentCount As Integer = clsDocuments.DocumentCount(LabelCFPROID.Text, JobID, "", "", "", "jobdocuments", "")
            ButtonJobDocuments.Text = "Job Documents - " & DocumentCount
        End If
    End Sub



    Protected Sub ButtonTextMessage_Click(sender As Object, e As EventArgs) Handles ButtonTextMessage.Click
        Dim JobID As String = Request.QueryString("jobid")
        Call LoadDialog("sendtextmessage.aspx?jobid=" & JobID, "Send Text Message / alert to Client", 340, 620)

    End Sub
End Class