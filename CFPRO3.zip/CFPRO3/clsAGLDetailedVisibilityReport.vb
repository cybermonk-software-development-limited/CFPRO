﻿Public Class clsAGLDetailedVisibilityReport

    Shared Function LoadJobs(CFPROID As String, Scope As String, DispatchDate As Boolean,
                       FromDate As String, ToDate As String, LoadedJobs As String,
                       MaxRecords As String, SortOrder As String, SortOrderIndex As Integer,
                       StorageStartDate As Boolean, CFPROUserID As String, Optional ByRef ErrMSg As String = Nothing) As DataView
        Try
            Dim Opdate As String


            If DispatchDate Then
                Opdate = "DispatchDate"
            Else
                Opdate = "JobDate"
            End If



            Dim tmpstr As String = ""
            Dim tmpstrA As String = ""

            If Not Scope = "(All)" Then
                tmpstr = " And Jobs." & Opdate & " >= '" & FromDate & "' " &
                          " And Jobs." & Opdate & " <= '" & ToDate & "' "

            Else
                tmpstr = " And ID > 0 "

            End If



            Select Case LoadedJobs

                Case "Open + Jobs Kept Visible"

                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "
                    tmpstrA = " And Jobs.CFPROID = '" & CFPROID & "'  And Jobs.KeepVisible = 1  "

                Case "Open Jobs"
                    tmpstr = tmpstr &
                             " And Jobs.JobStatus Not Like '%Closed%' "

                Case "All Jobs"
                    tmpstr = tmpstr

                Case "Closed Jobs"
                    tmpstr = tmpstr &
                                " And Jobs.JobStatus Like '%Closed%' "

                    'tmpstrC =
                    '   "And (Jobs.JobStatus Like '%Closed%'  " &
                    '   "Or JobProgress.KPIProgressID = '000026') " &
                    '   "And JobProgress.JobID = Jobs.JobID " &
                    '   "And JobProgress.CFPROID = '" & CFPROID & "' " &
                    '   "And JobProgress.Date  >= '" & TextFromDate.Text & "' " &
                    '   "And JobProgress.Date <= '" & TextToDate.Text & "' "

                Case "Jobs Kept Visible Only"
                    tmpstr = " And Jobs.KeepVisible = 1  "

            End Select

            Dim tmpstr1 As String = ""
            If clsAuth.OwnRecordsOnly(CFPROID, CFPROUserID) Then
                tmpstr1 = "And UserID = '" & CFPROUserID & "' "
            End If


            Dim sqlstr As String =
                    "Select Top " & MaxRecords & " " &
                    "JobID, ReferenceNo,ReferenceNo1," &
                    "JobDate, ClientID, " &
                    "ImporterID,AgentID," &
                    "CFSID, VesselID, ShippingLineID, " &
                    "CustomsSystem,BL,HouseBL," &
                    "OrderNo, Goods, Destination," &
                    "ShipperID,ReleasePersonnel," &
                    "ReleasedTo, ReleaseDate,TypeofEntry," &
                    "EntryRegistrationDate,EntryPassDate, EntryNo," &
                    "Declarant,DeclarationPersonnel," &
                    "ShippingPersonnel,ShipStatus," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,JobTypeID,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested," &
                    "ManifestNo,ExtensionEndDate," &
                    "RemainingExtensionDays,StatusID,JobStatus," &
                    "DocumentStatus,DocumentsLodgeDate,PortCharges," &
                    "PortChargesStatus,PortChargesPaidDate," &
                    "ReleaseOrderStatus,ReleaseOrderDate," &
                    "PortChargesCurrency,LoadingStatus,LoadingDate," &
                    "PickupOrderStatus,PickUpOrderDate," &
                    "PortStartDate,PortEndDate," &
                    "PortExpenses,PortStaff," &
                    "PortInvoiceNo,WareHouseRent, " &
                    "ShipStatus,ManifestNo,DeliveryOrderStatus," &
                    "DeliveryOrderCharges,DeliveryOrderDate,HandoverFees," &
                    "ContainerDeposit, ContainerDepositDate, " &
                    "ContainerRefundRequestDate,ContainerDepositRefund," &
                    "ContainerDepositRefundDate,ContainerDepositDeductions, " &
                    "ContainerDepositRemarks,ShippingPersonnel," &
                    "ShippingExpenses,ShippingStart,ShippingEnd, " &
                    "ModeofTransport,UserID,WeightUnit, ID " &
                    "From Jobs " &
                    "Where CFPROID = '" & CFPROID & "' "

            Dim sqlstrA As String

            sqlstrA = sqlstr & tmpstr & " " & tmpstr1
            Dim tmptable As New DataTable("DetailedVisibilityTable")
            Call clsData.TableData(sqlstrA, tmptable, clsData.constr)


            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrA = sqlstr & tmpstrA & " " & tmpstr1

                Dim tmptableA As New DataTable("DetailedVisibilityTable1")
                Call clsData.TableData(sqlstrA, tmptableA, clsData.constr)
                tmptable.Merge(tmptableA)
            End If

            Dim sqlstrB As String
            Dim sqlstr1 As String =
                 "Select JobCargo.JobID,Payload,ContainerNo," &
                  "JobCargo.TEU, JobCargo.CBM," &
                  "JobCargo.Weight, ContainerStatus," &
                  "PortExitDate,CrossBorderDate, " &
                  "ReturnDate,JobCargo.TransporterID,VehicleNo, " &
                  "ContainerStatusRemarks,DestinationArrivalDate," &
                  "DestinationDepot,JobCargo.ID " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID = '" & CFPROID & "' " &
                  "And Jobs.CFPROID = '" & CFPROID & "' " &
                  "And JobCargo.JobID = Jobs.JobID "

            sqlstrB = sqlstr1 & tmpstr
            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstrB, tmptable1, clsData.constr)


            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrB = sqlstr1 & tmpstrA

                Dim tmptable1A As New DataTable()
                Call clsData.TableData(sqlstrB, tmptable1A, clsData.constr)
                tmptable1.Merge(tmptable1A)
            End If

            Dim dv1 As New DataView(tmptable1)


            Dim sqlstr2 As String =
                        "Select CFS, CFSID " &
                        "From CFS " &
                        "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)


            Dim sqlstr3 As String =
                       "Select Vessel,VesselID, ETA," &
                       "BerthingDate, ExitDate, VoyageNo  " &
                       "From ShippingVessels " &
                       "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)

            Dim sqlstrC As String
            Dim sqlstr4 As String =
                       "Select JobProgress.JobID," &
                       "Status, Date " &
                       "From JobProgress,Jobs " &
                       "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                       "And Jobs.CFPROID = '" & CFPROID & "' " &
                       "And JobProgress.JobID = Jobs.JobID "


            sqlstrC = sqlstr4 & tmpstr & "Order By JobProgress.Date DESC "
            Dim tmptable4 As New DataTable()
            Call clsData.TableData(sqlstrC, tmptable4, clsData.constr)

            If LoadedJobs = "Open + Jobs Kept Visible" Then
                sqlstrC = sqlstr4 & tmpstrA & "Order By JobProgress.Date DESC "

                Dim tmptable4A As New DataTable()
                Call clsData.TableData(sqlstrC, tmptable4A, clsData.constr)
                tmptable4.Merge(tmptable4A)
            End If

            Dim dv4 As New DataView(tmptable4)



            Dim sqlstr5 As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable5 As New DataTable()
            Call clsData.TableData(sqlstr5, tmptable5, clsData.constr)
            Dim dv5 As New DataView(tmptable5)



            Dim sqlstr5a As String =
                "Select ClientID, Client " &
                     "From Clients " &
                     "Where CFPROID = '" & CFPROID & "' " &
                    "And IsAgent = 1 "

            Dim tmptable5a As New DataTable()
            Call clsData.TableData(sqlstr5a, tmptable5a, clsData.constr)
            Dim dv5a As New DataView(tmptable5a)


            Dim sqlstr6 As String =
                  "Select ImporterID, Importer " &
                  "From Importers " &
                  "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable6 As New DataTable()
            Call clsData.TableData(sqlstr6, tmptable6, clsData.constr)
            Dim dv6 As New DataView(tmptable6)


            Dim sqlstr7 As String =
                 "Select ShipperID, Shipper " &
                 "From Shippers " &
                 "Where CFPROID = '" & CFPROID & "' "
            Dim tmptable7 As New DataTable()
            Call clsData.TableData(sqlstr7, tmptable7, clsData.constr)
            Dim dv7 As New DataView(tmptable7)


            Dim sqlstr8 As String =
                 "Select ShippingLineID, ShippingLine," &
                 "LocalReturnDays, TransitReturnDays " &
                 "From ShippingLines " &
                 "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable8 As New DataTable()
            Call clsData.TableData(sqlstr8, tmptable8, clsData.constr)
            Dim dv8 As New DataView(tmptable8)

            Dim sqlstr9 As String =
           "Select UserID,UserNames " &
           "From CFAgentUsers " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable9 As New DataTable()
            Call clsData.TableData(sqlstr9, tmptable9, clsData.constr)
            Dim dv9 As New DataView(tmptable9)

            Dim sqlstr10 As String =
            "Select TransporterID,Transporter " &
            "From Transporters " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable10 As New DataTable()
            Call clsData.TableData(sqlstr10, tmptable10, clsData.constr)
            Dim dv10 As New DataView(tmptable10)

            Dim sqlstr11 As String =
            "Select JobTypeID,JobType " &
            "From JobTypes " &
            "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable11 As New DataTable()
            Call clsData.TableData(sqlstr11, tmptable11, clsData.constr)
            Dim dv11 As New DataView(tmptable11)



            Dim sqlstr12 As String =
                        "SELECT  KPIItemID, Jobs.JobID " &
                        "FROM  KPIProgressUpdates,Jobs " &
                        "Where KPIProgressUpdates.CFPROID = '" & CFPROID & "' " &
                        "And Jobs.CFPROID = '" & CFPROID & "' " &
                        "And KPIProgressUpdates.JobID = Jobs.JobID " &
                        "And KPIItemID = '000026' " &
                        tmpstr

            Dim tmptable12 As New DataTable()
            Call clsData.TableData(sqlstr12, tmptable12, clsData.constr)
            Dim dv12 As New DataView(tmptable12)

            Dim tmptablejobs As New DataTable


            Call clsDetailedVisibilityReport.CreateJobTableColumns(tmptablejobs)


            Dim portexitdate, crossborderdate, eta, lastsling, destinationdepot As String


            Dim cfs, vessel, voyageno, client, agent, importer, shipper,
                shippingline, jobpersonnel, transporter, jobtype, weightunit As String

            Dim vesseleta, berthingdate, exitdate As Date

            Dim CBM, Weight, TEU As Double
            Dim tmpdate As Date = Now


            Dim drow, drow1 As DataRow

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("ReferenceNo") = "No Jobs"
                tmptable.Rows.Add(drow)
            End If


            Dim nAllarrived As Boolean
            Dim nLatestCrossBorderDate, nLatestArrivalDate As Date
            Dim tmpstrsoc As String = ""
            Dim tmpstrtin As String = ""
            Dim nCFSStorage As String = ""

            Dim a, b, c, d, e As Integer

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)

                If Trim(drow("ReferenceNo")) = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If

                dv1.RowFilter = "JobID = '" & drow("JobID") & "' "
                dv4.RowFilter = "JobID = '" & drow("JobID") & "' "



                nAllarrived = clsDetailedVisibilityReport.AllArrived(dv1)

                nLatestCrossBorderDate = CDate("1-Jan-1800")
                nLatestArrivalDate = CDate("1-Jan-1800")

                nLatestCrossBorderDate = clsDetailedVisibilityReport.LatestCrossBorderDate(dv1)
                nLatestArrivalDate = clsDetailedVisibilityReport.LatestArrivalDate(dv1)

                cfs = ""
                vessel = ""
                vesseleta = CDate("1-Jan-1800")
                berthingdate = CDate("1-Jan-1800")
                exitdate = CDate("1-Jan-1800")
                voyageno = ""
                client = ""
                agent = ""
                importer = ""
                shipper = ""
                shippingline = ""
                voyageno = ""
                tmpstrsoc = ""
                tmpstrtin = ""
                jobpersonnel = ""
                jobtype = ""
                weightunit = ""

                If drow("WeightUnit") = "" Then
                    weightunit = "Kg"
                Else
                    weightunit = drow("WeightUnit")
                End If


                If drow("SOC") Then
                    tmpstrsoc = "SOC"
                Else
                    tmpstrsoc = ""
                End If




                d = c

                'row1

                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)

                drow1("JobUrl") = "jobentry.aspx?jobid=" & drow("JobID")
                drow1("Marker") = "Header"
                drow1("NoBreakRow") = 1

                dv2.RowFilter = "CFSID = '" & drow("CFSID") & "' "
                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                dv5.RowFilter = "ClientID = '" & drow("ClientID") & "' "
                dv5a.RowFilter = "ClientID = '" & drow("AgentID") & "' "
                dv6.RowFilter = "ImporterID = '" & drow("ImporterID") & "' "
                dv7.RowFilter = "ShipperID = '" & drow("ShipperID") & "' "
                dv8.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "
                dv9.RowFilter = "UserID = '" & drow("UserID") & "' "
                dv11.RowFilter = "JobTypeID = '" & drow("JobTypeID") & "' "
                dv12.RowFilter = "JobID = '" & drow("JobID") & "' "

                TEU = 0
                CBM = 0
                Weight = 0


                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)
                    CBM = CBM + dv1(b)("CBM")
                    Weight = Weight + dv1(b)("Weight")
                    TEU = TEU + Val(dv1(b)("TEU"))
                Next



                drow1("Weight") = Weight
                drow1("CBM") = CBM
                drow1("TEU") = TEU
                drow1("Quantity") = dv1.Count



                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    cfs = dv2(0)("CFS")
                End If

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)
                    vessel = dv3(0)("Vessel")
                    vesseleta = dv3(0)("ETA")
                    berthingdate = dv3(0)("BerthingDate")
                    exitdate = dv3(0)("ExitDate")
                    voyageno = dv3(0)("VoyageNo")
                End If


                If dv5.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    client = dv5(0)("Client")
                End If

                If dv5a.Count > 0 Then
                    Call clsData.NullChecker1(dv5, 0)
                    agent = dv5a(0)("Client")
                End If

                If dv6.Count > 0 Then
                    Call clsData.NullChecker1(dv6, 0)
                    importer = dv6(0)("Importer")
                End If


                If dv7.Count > 0 Then
                    Call clsData.NullChecker1(dv7, 0)
                    shipper = dv7(0)("Shipper")
                End If

                If dv8.Count > 0 Then
                    Call clsData.NullChecker1(dv8, 0)
                    shippingline = dv8(0)("ShippingLine")
                End If

                If dv9.Count > 0 Then
                    Call clsData.NullChecker1(dv9, 0)
                    jobpersonnel = dv9(0)("UserNames")
                End If

                If dv11.Count > 0 Then
                    Call clsData.NullChecker1(dv11, 0)
                    jobtype = dv11(0)("jobtype")
                End If



                drow1("References") = drow("ReferenceNo")
                drow1("Shipping") = shippingline
                drow1("ClientConsigneeShipper") = Mid(client, 1, 25)
                drow1("Transportation") = Format(Weight, "#,##0.#0") & weightunit & " : " & Format(CBM, "#,##0.#0") & "CbM"
                drow1("Entry") = "Type: " & drow("TypeofEntry")

                If CDate(drow("DeliveryOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DeliveryOrderStatus")
                Else
                    drow1("Customs") = "D.O:" & Format(drow("DeliveryOrderDate"), "dd MMM yyyy")
                End If

                If CDate(drow("PortChargesPaidDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("PortChargesStatus")
                Else
                    drow1("Port") = "Chgs:" & Format(drow("PortChargesPaidDate"), "dd MMM yyyy")
                End If



                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("Marker") = "Header"
                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")
                drow1("NoBreakRow") = 1

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")

                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("TIN") = tmpstrtin



                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = clsDetailedVisibilityReport.SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)
                drow1("Goods") = drow("Goods")



                If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1
                e = a


                'row2
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = drow("ReferenceNo1")
                drow1("ClientConsigneeShipper") = importer

                drow1("Transportation") = drow("ModeofTransport")

                If Not Trim(voyageno) = "" Then
                    voyageno = " / VOY:" & voyageno
                End If

                drow1("Shipping") = vessel & voyageno

                If Not CDate(drow("EntryRegistrationDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Lodg:" & Format(drow("EntryRegistrationDate"), "dd MMM yyyy")
                End If

                If CDate(drow("DocumentsLodgeDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = drow("DocumentStatus")
                Else
                    drow1("Customs") = "L.R:" & Format(drow("DocumentsLodgeDate"), "dd MMM yyyy")
                End If

                If CDate(drow("LoadingDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = drow("LoadingStatus")
                Else
                    drow1("Port") = "Load:" & Format(drow("LoadingDate"), "dd MMM yyyy")
                End If

                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")
                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = clsDetailedVisibilityReport.SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)
                drow1("Goods") = drow("Destination")

                If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                'row3
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1


                drow1("JobID") = drow("JobID")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("References") = "MBL: " & drow("BL") & " HBL: " & drow("HouseBL")
                drow1("ClientConsigneeShipper") = shipper
                drow1("Transportation") = drow("Destination")

                If Not CDate(vesseleta) = CDate("1-Jan-1800") Then
                    eta = "ETA:" & Format(vesseleta, "dd MMM yyyy")
                Else
                    eta = ""
                End If

                If Not CDate(exitdate) = CDate("1-Jan-1800") Then
                    lastsling = " / LS:" & Format(exitdate, "dd MMM yyyy")
                Else
                    lastsling = ""
                End If

                drow1("Shipping") = eta & lastsling

                If Not CDate(drow("EntryPassDate")) = CDate("1-Jan-1800") Then
                    drow1("Entry") = "Pass:" & Format(drow("EntryPassDate"), "dd MMM yyyy")
                End If

                If CDate(drow("ReleaseOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Customs") = cfs & " " & drow("ReleaseOrderStatus")
                Else
                    drow1("Customs") = cfs & " R.O: " & Format(drow("ReleaseOrderDate"), "dd MMM yyyy")
                End If


                If CDate(drow("PickUpOrderDate")) = CDate("1-Jan-1800") Then
                    drow1("Port") = "Pick: " & drow("PickupOrderStatus")
                Else
                    drow1("Port") = "Pick: " & Format(drow("PickUpOrderDate"), "dd MMM yyyy")
                End If

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = jobtype
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")
                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")

                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("SCT") = clsDetailedVisibilityReport.SCT(drow("CustomsSystem"))
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)
                drow1("Goods") = drow("ModeofTransport")

                If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1


                'row4
                drow1 = tmptablejobs.NewRow
                tmptablejobs.Rows.Add(drow1)
                drow1("NoBreakRow") = 1


                drow1("JobID") = drow("JobID")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")
                drow1("References") = "ENTRY NO: " & drow("EntryNo") & " / DECLARANT: " & drow("Declarant")


                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = jobtype
                drow1("JobDate") = drow("JobDate")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")

                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")


                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)



                If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If


                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1


                If StorageStartDate Then
                    nCFSStorage = clsDetailedVisibilityReport.CFSStorage(CFPROID, drow("ClientID"), drow("CFSID"), jobtype, drow("LastSlingDAte"))
                End If


                For b = 0 To dv1.Count - 1
                    Call clsData.NullChecker1(dv1, b)

                    If b <= 3 Then
                        drow1 = tmptablejobs.Rows(d + b)
                    Else
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1

                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("JobDate") = drow("JobDate")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = jobtype
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")

                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")


                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = clsDetailedVisibilityReport.SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")
                        drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)

                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If



                    drow1("Cargo") = dv1(b)("ContainerNo") & " " & dv1(b)("Payload") & " " & Format(dv1(b)("Weight"), "#,##0.00") & weightunit & " " & tmpstrsoc & " " & nCFSStorage

                    If Trim(dv1(b)("ContainerStatusRemarks")) = "" Then
                        drow1("CargoStatus") = dv1(b)("ContainerStatus")
                    Else
                        drow1("CargoStatus") = dv1(b)("ContainerStatusRemarks")
                    End If


                    If Not CDate(dv1(b)("PortExitDate")) = CDate("1-Jan-1800") Then
                        portexitdate = Format(dv1(b)("PortExitDate"), "dd MMM yyyy")
                    Else
                        portexitdate = ""
                    End If

                    If Not CDate(dv1(b)("CrossBorderDate")) = CDate("1-Jan-1800") Then
                        crossborderdate = Format(dv1(b)("CrossBorderDate"), "dd MMM yyyy")
                    Else
                        crossborderdate = ""
                    End If

                    If Not dv1(b)("DestinationDepot") = "" Then
                        destinationdepot = " | " & dv1(b)("DestinationDepot")
                    Else
                        destinationdepot = ""
                    End If

                    If InStr(jobtype, "Local", CompareMethod.Text) <> 0 Then
                        drow1("Checkpoints") = "MSA:" & portexitdate & destinationdepot
                    Else
                        drow1("Checkpoints") = "MSA:" & portexitdate & " | MLB:" & crossborderdate & destinationdepot
                    End If

                    transporter = ""
                    dv10.RowFilter = "TransporterID = '" & dv1(b)("TransporterID") & "' "

                    If dv10.Count > 0 Then
                        transporter = dv10(0)("Transporter")
                    End If

                    If Not Trim(transporter) = "" Then
                        transporter = " \ " & transporter
                    Else
                        transporter = ""
                    End If

                    drow1("Transporter") = dv1(b)("VehicleNo") & transporter

                    If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                        drow1("CrossBorderDate") = nLatestCrossBorderDate
                        drow1("CrossedBorder") = CBool(1)
                    Else
                        drow1("CrossBorderDate") = CDate("1-Jan-1800")
                        drow1("CrossedBorder") = CBool(0)
                    End If

                    If nAllarrived Then
                        drow1("DestinationArrivalDate") = nLatestArrivalDate
                        drow1("Arrived") = CBool(1)
                    Else
                        drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                        drow1("Arrived") = CBool(0)
                    End If

                Next


                For b = 0 To dv4.Count - 1
                    Call clsData.NullChecker1(dv4, b)
                    If b <= 3 Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b <= (dv1.Count - 1) Then
                        drow1 = tmptablejobs.Rows(d + b)

                    ElseIf b > (dv1.Count - 4) Then
                        drow1 = tmptablejobs.NewRow
                        tmptablejobs.Rows.Add(drow1)
                        drow1("NoBreakRow") = 1
                        drow1("JobId") = drow("JobId")
                        drow1("ClientID") = drow("ClientID")
                        drow1("AgentID") = drow("AgentID")
                        drow1("ImporterID") = drow("ImporterID")
                        drow1("ShipperID") = drow("ShipperID")
                        drow1("CFSID") = drow("CFSID")

                        drow1("CFS") = cfs
                        drow1("Vessel") = vessel
                        drow1("VesselETA") = vesseleta
                        drow1("VoyageNo") = voyageno
                        drow1("Client") = client
                        drow1("Agent") = agent
                        drow1("Importer") = importer
                        drow1("Shipper") = shipper
                        drow1("JobPersonnel") = jobpersonnel

                        drow1("JobType") = jobtype
                        drow1("JobStatus") = drow("JobStatus")
                        drow1("ShipStatus") = drow("ShipStatus")

                        drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                        drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                        drow1("PortStaff") = drow("PortStaff")
                        drow1("JobDate") = drow("JobDate")
                        drow1("ReferenceNo") = drow("ReferenceNo")
                        drow1("ReferenceNo1") = drow("ReferenceNo1")
                        drow1("BL") = drow("BL")

                        drow1("CustomsSystem") = drow("CustomsSystem")
                        drow1("SCT") = clsDetailedVisibilityReport.SCT(drow("CustomsSystem"))
                        drow1("KeepVisible") = drow("KeepVisible")
                        drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)

                        If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                            drow1("CrossBorderDate") = nLatestCrossBorderDate
                            drow1("CrossedBorder") = CBool(1)
                        Else
                            drow1("CrossBorderDate") = CDate("1-Jan-1800")
                            drow1("CrossedBorder") = CBool(0)
                        End If

                        If nAllarrived Then
                            drow1("DestinationArrivalDate") = nLatestArrivalDate
                            drow1("Arrived") = CBool(1)
                        Else
                            drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                            drow1("Arrived") = CBool(0)
                        End If



                        Call clsData.NullChecker(tmptablejobs, c)
                        c = c + 1
                    End If

                    drow1("JobDate") = drow("JobDate")
                    drow1("Status") = Format(dv4(b)("Date"), "dd MMM yyyy") & " - " & dv4(b)("Status")
                    'drow1("Highlight") = dv4(b)("Highlight")

                Next

                ' row 5
                drow1 = tmptablejobs.NewRow
                drow1("Marker") = "Break"
                drow1("NoBreakRow") = 0

                drow1("JobId") = drow("JobId")
                drow1("ClientID") = drow("ClientID")
                drow1("AgentID") = drow("AgentID")
                drow1("ImporterID") = drow("ImporterID")
                drow1("ShipperID") = drow("ShipperID")
                drow1("CFSID") = drow("CFSID")

                drow1("CFS") = cfs
                drow1("Vessel") = vessel
                drow1("VesselETA") = vesseleta
                drow1("VoyageNo") = voyageno
                drow1("Client") = client
                drow1("Agent") = agent
                drow1("Importer") = importer
                drow1("Shipper") = shipper
                drow1("JobPersonnel") = jobpersonnel

                drow1("JobType") = jobtype
                drow1("JobDate") = drow("JobDate")
                drow1("JobStatus") = drow("JobStatus")
                drow1("ShipStatus") = drow("ShipStatus")

                drow1("ShippingPersonnel") = drow("ShippingPersonnel")
                drow1("DeclarationPersonnel") = drow("DeclarationPersonnel")
                drow1("PortStaff") = drow("PortStaff")

                drow1("JobDate") = drow("JobDate")
                drow1("ReferenceNo") = drow("ReferenceNo")
                drow1("ReferenceNo1") = drow("ReferenceNo1")
                drow1("BL") = drow("BL")


                drow1("CustomsSystem") = drow("CustomsSystem")
                drow1("KeepVisible") = drow("KeepVisible")
                drow1("FileClosed") = clsDetailedVisibilityReport.FileClosed(dv12)



                If clsDetailedVisibilityReport.AllCrossedBorder(dv1, drow("JobID")) Then
                    drow1("CrossBorderDate") = nLatestCrossBorderDate
                    drow1("CrossedBorder") = CBool(1)
                Else
                    drow1("CrossBorderDate") = CDate("1-Jan-1800")
                    drow1("CrossedBorder") = CBool(0)
                End If

                If nAllarrived Then
                    drow1("DestinationArrivalDate") = nLatestArrivalDate
                    drow1("Arrived") = CBool(1)
                Else
                    drow1("DestinationArrivalDate") = CDate("1-Jan-1800")
                    drow1("Arrived") = CBool(0)
                End If

                tmptablejobs.Rows.Add(drow1)
                Call clsData.NullChecker(tmptablejobs, c)
                c = c + 1

                a = a + 1

            Next

            Dim dv As New DataView(tmptablejobs)


            Dim tmpstrSort As String


            If SortOrder = "Z-A" Then
                tmpstrSort = " DESC"
            Else
                tmpstrSort = " ASC"
            End If

            Dim SortBy As String = clsDetailedVisibilityReport.nSortOrder(SortOrderIndex)
            If SortBy = "JobDate" Then
                dv.Sort = "JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                dv.Sort = "ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                dv.Sort = "ID " & tmpstrSort

            ElseIf SortBy = "VesselETA" Then
                dv.Sort = "VesselETA " & tmpstrSort
            End If

            HttpContext.Current.Session("JobTableDetailed") = tmptablejobs

            Return dv


        Catch exp As Exception
            ErrMSg = exp.Message & exp.StackTrace
        End Try
    End Function

End Class
