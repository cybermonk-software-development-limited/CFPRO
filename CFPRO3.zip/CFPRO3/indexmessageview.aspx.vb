﻿Public Class indexmessageview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load




    End Sub


    Private Sub SignIn(emailaddress As String, password As String)
        Try

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Response.Cookies("CSDID").Value = (Request.QueryString("logintoken"))
            End If



        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


End Class