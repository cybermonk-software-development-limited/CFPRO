﻿Imports System.IO

Public Class progressupdates1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            If IsNothing(Request.Cookies("CFPROToken")) Then
                Call RegisterToken()
            ElseIf Request.Cookies("CFPROToken").Value = "" Then
                Call RegisterToken()
            End If

            Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

            'Call clsAuth.UserLoggedIn("", "", "", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, Image1.ImageUrl, True, "", True)

            Dim JobID As String = Request.QueryString("jobid")
            Call LoadJobProgress(JobID)

        End If

    End Sub


    Private Sub RegisterToken()
        Try

            If Not IsNothing(Request.QueryString("logintoken")) Then


                Response.Cookies("CFPROToken").Value = (Request.QueryString("logintoken"))
                Response.Cookies("CFPROToken").Expires = Now.AddHours(6)

                If Not IsNothing(Request.QueryString("gotooption")) Then
                    Response.Redirect(Request.QueryString("gotooption"))
                End If
            End If

        Catch exp As Exception
            'LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub LoadJobProgress(JobID As String)
        Try


            Dim sqlstr As String =
            "Select JobId,Status," &
            "JobProgress.UserID,StaffName," &
            "Date,JobStatusID, JobProgress.ID " &
            "From JobProgress,Staff " &
            "Where JobId = '" & JobID & "' " &
            "And Staff.UserID = JobProgress.UserID " &
            "Order By Date Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
              "Select StatusID,Status " &
              "From JobStatuses "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim dv As New DataView(tmptable1)




            Dim sqlstr2 As String =
             "Select UserCSDID,CFPROuserID " &
             "FROM CFPROAccountConnect " &
             "Where  CFAgentCSDID = '" & LabelCfAgentCSDID.Text & "' "


            Dim tmptable2 As New DataTable
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)

            Dim dv1 As New DataView(tmptable2)


            Dim a As Integer
            Dim col1 As New DataColumn("Date1", Type.GetType("System.String"))
            Dim col2 As New DataColumn("UpdateCount", Type.GetType("System.String"))
            Dim col3 As New DataColumn("UserImageURL", Type.GetType("System.String"))
            Dim col4 As New DataColumn("JobStatus", Type.GetType("System.String"))
            Dim col5 As New DataColumn("ShowJobStatus", Type.GetType("System.Boolean"))
            Dim col6 As New DataColumn("UserIDImageURL", Type.GetType("System.String"))

            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)

            If tmptable.Rows.Count = 0 Then
                Dim drow As DataRow
                drow = tmptable.NewRow
                drow("Status") = ""
                tmptable.Rows.Add(drow)
            End If


            Dim UserImageURL As String = ""
            For Each drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)
                drow("Date1") = Format(drow("Date"), "dd MMM yyyy hh:mm tt")


                dv1.RowFilter = "CFPROuserID = '" & drow("UserID") & "' "

                If dv1.Count > 0 Then
                    If File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".png")) Then
                        UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".png"
                    ElseIf File.Exists(Server.MapPath("~/userimages/" & dv1(0)("UserCSDID") & ".jpg")) Then
                        UserImageURL = "~/userimages/" & dv1(0)("UserCSDID") & ".jpg"
                    Else
                        UserImageURL = "imageplaceholder.png"
                    End If
                Else
                    UserImageURL = "imageplaceholder.png"
                End If


                drow("UserImageURL") = UserImageURL
                drow("UserIDImageURL") = drow("UserID") & "|" & drow("UserImageURL")

                dv.RowFilter = "StatusID = '" & drow("JobStatusID") & "' "

                If dv.Count > 0 Then
                    drow("JobStatus") = "- Job Status: " & dv(0)("Status")
                End If

                a = a + 1

                drow("UpdateCount") = a & "."
            Next

            If tmptable.Rows.Count < 9 Then
                PanelUpdates.Height = Nothing
            Else
                PanelUpdates.Height = 600
                'PanelCargo.Height = 255
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelUpdateCount.Text = "Status Updates - " & tmptable.Rows.Count

            LabelMessage1.Text = ""
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try


    End Sub
    Private Sub DataList1_ItemCommand(source As Object, e As DataListCommandEventArgs) Handles DataList1.ItemCommand
        If e.CommandName = "staffdetails" Then
            Call StaffDetails(e.CommandArgument)
        End If
    End Sub
    Private Sub StaffDetails(UserIDImageURL As String)
        ModalPopupExtender1.Show()


        Dim tmpstr() As String = UserIDImageURL.Split("|")
        ReDim Preserve tmpstr(1)
        Dim sqlstr As String =
           "SELECT  StaffName, JobDescription," &
           "Department, Telephone, Email " &
           "FROM Staff " &
           "Where UserID  = '" & tmpstr(0) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsSubs.NullChecker(tmptable, 0)

            LabelStaffName.Text = drow("StaffName")
            LabelJobDescription.Text = drow("JobDescription")
            LabelTelephone.Text = "<a href='tel:" & drow("Telephone") & "'>" & drow("Telephone") & "</a>"
            LabelEmail.Text = "<a href='mailto:" & drow("Email") & "'>" & drow("Email") & "</a>"



        End If

        If Not tmpstr(1) = "" Then
            ImageUserImage.ImageUrl = tmpstr(1)
        End If
    End Sub


    Protected Sub LinkButton2_Click(sender As Object, e As EventArgs)
        '  ModalPopupExtender1.Show()
    End Sub
    Protected Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        ModalPopupExtender1.Hide()
    End Sub

    Protected Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click

    End Sub

    'Protected Sub LinkButtonCFAgent_Click(sender As Object, e As EventArgs) Handles LinkButtonCFAgent.Click


    '    If IsNothing(Request.Cookies("CFPROToken")) Then
    '        If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
    '            Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=jobentry.aspx")
    '        Else
    '            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=jobentry.aspx")
    '        End If

    '    ElseIf Request.Cookies("CFPROToken").Value = "" Then
    '        If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
    '            Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=jobentry.aspx")
    '        Else
    '            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=jobentry.aspx")
    '        End If
    '    Else
    '        Response.Redirect("jobentry.aspx")
    '    End If



    'End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=index.aspx")
            Else
                Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
            End If
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
        End If
    End Sub

    'Protected Sub LinkButtonImporter1_Click(sender As Object, e As EventArgs) Handles LinkButtonImporter1.Click
    '    If IsNothing(Request.Cookies("CFPROToken")) Then
    '        If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
    '            Response.Redirect("http://localhost:84/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
    '        Else
    '            Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
    '        End If

    '    ElseIf Request.Cookies("CFPROToken").Value = "" Then
    '        If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
    '            Response.Redirect("http://localhost:84/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
    '        Else
    '            Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=mobile")
    '        End If
    '    Else
    '        Response.Redirect("cfproimportercfagents.aspx?importerdashboard=mobile")
    '    End If
    'End Sub

    'Protected Sub LinkButtonImporter_Click(sender As Object, e As EventArgs) Handles LinkButtonImporter.Click
    '    If IsNothing(Request.Cookies("CFPROToken")) Then
    '        If InStr(Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
    '            Response.Redirect("http://localhost:84/usersignin.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
    '        Else
    '            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
    '        End If

    '    ElseIf Request.Cookies("CFPROToken").Value = "" Then
    '        Response.Redirect("http://www.cybermonksd.com/usersignin1.aspx?gotooption=cfproimportercfagents.aspx?importerdashboard=normal")
    '    Else
    '        Response.Redirect("cfproimportercfagents.aspx?importerdashboard=normal")
    '    End If
    'End Sub

End Class