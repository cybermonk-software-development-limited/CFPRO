﻿Public Class declaration
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
           
            Dim CFPROID As String = ""
            Dim CFAgentUserName As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", CFAgentUserName, "", "", "", "", True, "", False)

            LabelCFPROID.Text = CFPROID
            TextDeclarant_AutoCompleteExtender.ContextKey = CFPROID


            Call LoadCFAgentUsers(CFPROID)

            Call LoadDeclaration(CFPROID, CFAgentUserName)
        End If
    End Sub



    Private Sub LoadCFAgentUsers(CFPROID As String)
        Dim sqlstr As String =
        "Select UserNames,UserID " &
        "From CFAgentusers " &
        "Where CFPROID ='" & CFPROID & "' "

        Call clsData.PopCombo(ComboPersonnel, sqlstr, clsData.constr, 0)

        ComboPersonnel.Items.Insert(0, "")

    End Sub



    Private Sub LoadDeclaration(CFPROID As String, CFAgentUserName As String)
        Dim JobId As String = Request.QueryString("jobId")
        Dim sqlstr As String =
                    "Select IDFNo,InvoiceNo," &
                    "InvoiceAmount,IDFType," &
                    "IDFAmount,IDFReceiptNo," &
                    "EntryNo,DutyAmount,ExtraDuty,Declarant," &
                    "DeclarationStart,DeclarationEnd," &
                    "CustomsPenalties,DeclarationPersonnel," &
                    "DeclarationExpenses,TypeofEntry,EntryStatus," &
                    "EntryRegistrationDate,EntryPassDate," &
                    "EntensionRequested,ExtensionStartDate," &
                    "ExtensionEndDate,RemainingExtensionDays," &
                    "EntryEntensionDays,ID " &
                    "From Jobs " &
                    "Where CFPROID ='" & CFPROID & "' " &
                    "And JobId ='" & JobId & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)



            ComboIDFType.Text = drow("IDFType")

            ComboEntryType.Text = drow("TypeofEntry")
            TextIdfAmount.Text = Format(drow("IDFAmount"), "#,##0.#0")
            TextIdfReceiptNo.Text = drow("IDFReceiptNo")
            TextIDFNos.Text = drow("IDFNo")

            TextInvoiceNo.Text = drow("InvoiceNo")
            TextInvoiceAmount.Text = Format(drow("InvoiceAmount"), "#,##0.#0")

            TextDutyAmount.Text = Format(drow("DutyAmount"), "#,##0.#0")
            TextExtraDuty.Text = Format(drow("ExtraDuty"), "#,##0.#0")
            TextCustomsPenalties.Text = Format(drow("CustomsPenalties"), "#,##0.#0")
            TextExpenses.Text = Format(drow("DeclarationExpenses"), "#,##0.#0")

            ComboEntryStatus.Text = drow("EntryStatus")
            TextEntryRegistrationDate.Text = Format(drow("EntryRegistrationDate"), "dd MMM yyyy")
            TextEntryPassDate.Text = Format(drow("EntryPassDate"), "dd MMM yyyy")
            TextEntryNo.Text = drow("EntryNo")

            TextExtensionStartDate.Text = Format(drow("ExtensionStartDate"), "dd MMM yyyy")
            TextExtensionEndDate.Text = Format(drow("ExtensionEndDate"), "dd MMM yyyy")
            TextRemainingExtensionDays.Text = drow("RemainingExtensionDays")



            CheckEntensionRequested.Checked = drow("EntensionRequested")

            TextStartDate.Text = Format(drow("DeclarationStart"), "dd MMM yyyy")
            TextExtensionEndDate.Text = Format(drow("DeclarationEnd"), "dd MMM yyyy")
            ComboPersonnel.Text = drow("DeclarationPersonnel")

            TextEntryEntensionDays.Text = drow("EntryEntensionDays")
            TextDeclarant.Text = drow("Declarant")

            If CDate(TextStartDate.Text) = CDate("1-Jan-1800") Then
                TextStartDate.Text = Format(Now, "dd MMM yyyy")
                ComboPersonnel.Text = CFAgentUserName
            End If


            Call ExtensionEndDate(TextExtensionStartDate.Text, TextEntryEntensionDays.Text)
        End If


    End Sub

    Private Sub ExtensionEndDate(ByVal ExtensionStartDate As Date, ByVal nEntryEntensionDays As String)
        If CDate(ExtensionStartDate) = CDate("1-Jan-1800") Then
            TextExtensionEndDate.Text = "01-Jan-1800"
        Else
            Dim tmpdate, tmpdate1 As Date
            tmpdate = ExtensionStartDate.AddDays(Val(nEntryEntensionDays))
            TextExtensionEndDate.Text = Format(tmpdate, "dd MMM yyyy")
            tmpdate1 = TextExtensionEndDate.Text
            TextRemainingExtensionDays.Text = CInt((tmpdate1.Subtract(CDate(Now)).TotalDays))
        End If
    End Sub

    Protected Sub TextDutyAmount_TextChanged(sender As Object, e As EventArgs) Handles TextDutyAmount.TextChanged

    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click
        Call SaveDeclaration(LabelCFPROID.Text)
    End Sub

    Private Sub SaveDeclaration(CFPROID As String)

        Try


            Dim JobId As String = Request.QueryString("jobId")

            Dim sqlstr As String =
            "Select IDFNo,InvoiceNo,InvoiceAmount,IDFType," &
            "IDFAmount,IDFReceiptNo," &
            "EntryNo,DutyAmount,ExtraDuty," &
            "Declarant,DeclarationStart,DeclarationEnd," &
            "CustomsPenalties,DeclarationPersonnel," &
            "DeclarationExpenses,TypeofEntry,EntryStatus," &
            "EntryRegistrationDate,EntryPassDate," &
            "EntensionRequested,ExtensionStartDate," &
            "ExtensionEndDate,RemainingExtensionDays," &
            "EntryEntensionDays,ID " &
            "From Jobs " &
            "Where CFPROID ='" & CFPROID & "' " &
            "And JobId ='" & JobId & "'"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)

                drow("IDFType") = ComboIDFType.Text
                drow("IDFAmount") = Trim(TextIdfAmount.Text)
                drow("IDFReceiptNo") = TextIdfReceiptNo.Text
                drow("DutyAmount") = Trim(TextDutyAmount.Text)
                drow("ExtraDuty") = Trim(TextExtraDuty.Text)
                drow("CustomsPenalties") = TextCustomsPenalties.Text
                drow("InvoiceNo") = Trim(TextInvoiceNo.Text)

                drow("IDFNo") = Trim(TextIDFNos.Text)
                drow("EntryNo") = Trim(TextEntryNo.Text)

                drow("TypeofEntry") = ComboEntryType.Text
                drow("EntryStatus") = ComboEntryStatus.Text
                drow("EntryRegistrationDate") = TextEntryRegistrationDate.Text
                drow("EntryPassDate") = TextEntryPassDate.Text
                drow("EntryNo") = Trim(TextEntryNo.Text)
                drow("ExtensionStartDate") = Trim(TextExtensionStartDate.Text)
                drow("ExtensionEndDate") = Trim(TextExtensionEndDate.Text)
                drow("RemainingExtensionDays") = Trim(TextRemainingExtensionDays.Text)

                drow("EntensionRequested") = CheckEntensionRequested.Checked
                drow("EntryEntensionDays") = Trim(TextEntryEntensionDays.Text)

                drow("Declarant") = UCase(Trim(TextDeclarant.Text))

                drow("DeclarationStart") = Trim(TextStartDate.Text)
                drow("DeclarationEnd") = TextExtensionEndDate.Text
                drow("DeclarationPersonnel") = ComboPersonnel.Text
                drow("DeclarationExpenses") = Trim(TextExpenses.Text)



                Dim InvoiceAmount As String = Trim(TextInvoiceAmount.Text)

                InvoiceAmount = InvoiceAmount.Replace(" ", "")
                InvoiceAmount = InvoiceAmount.Replace(",", "")
                TextInvoiceAmount.Text = Format(CDbl(InvoiceAmount), "#,##0.00")

                drow("InvoiceAmount") = TextInvoiceAmount.Text


                Call ExtensionEndDate(TextExtensionStartDate.Text, TextEntryEntensionDays.Text)

                Call clsData.SaveData("Jobs", tmptable, sqlstr, False, clsData.constr)

            End If

        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub


    <System.Web.Script.Services.ScriptMethod(),
  System.Web.Services.WebMethod()>
    Public Shared Function SearchDeclarant(ByVal prefixText As String, ByVal count As Integer, ByVal contextKey As String) As List(Of String)
        Return clsProgressUpdates.GetDeclarant(prefixText, count, contextKey)
    End Function


End Class