﻿Imports System.Web
Public Class MessageBox

    Shared Sub MessageBox(ByVal sMessage As String)
        Dim resp As HttpResponse
        Dim msg As String
        msg = "<script language='javascript'>"
        msg += "alert('" & sMessage & "');"
        msg += "<" & "/script>"
        resp.Write(msg)
    End Sub
End Class
