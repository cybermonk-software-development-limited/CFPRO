﻿

Imports System.Data
Imports System.Text
Imports System.IO
Imports OfficeOpenXml
Imports System.Drawing


Public Class storagedemmuragereport
    Inherits System.Web.UI.Page



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        If Not IsPostBack Then

            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If


            Call clsAuth.UserLoggedIn(LabelCSDID.Text, LabelCFAgentCFPROID.Text, LabelCFPROUserID.Text, LabelUser.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "cfagent", True)
            HyperLinkStart.NavigateUrl = "cfprodashboard.aspx"

            Call LoadAgents()
            Call LoadClients()
            Call LoadImporters()
            Call LoadShippers()
            Call LoadCFAgentUsers()
            Call LoadShipStatus()
            Call LoadJobStatuses()
            Call LoadJobTypes()
            Call LoadCFS()
            Call LoadJobTypes()

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text)

        End If

    End Sub


    Private Sub LoadJobs(Alljobs As Boolean, ByVal selectClients As Boolean, ByVal selectAgents As Boolean, dispatchdate As Boolean)
        Try
            Dim Opdate As String
            Dim SortBy As String = nSortOrder()

            If dispatchdate Then
                Opdate = "DispatchDate "
            Else

            End If

            Opdate = "JobDate"

            Dim tmpstr0, tmpstr1, tmpstr2 As String
            Dim tmpstrdate1, tmpstrdate2 As String
            Dim tmpid As Integer = -1

            tmpstrdate1 = "'" & TextFromDate.Text & "' "
            tmpstrdate2 = "'" & TextToDate.Text & "' "


            Dim tmpdatecri, tmpdatecri1 As String


            If Not Alljobs Then
                tmpdatecri = Opdate & " >= " & tmpstrdate1 &
                         " And " & Opdate & " <= " & tmpstrdate2

                tmpdatecri1 = "Jobdate >= " & tmpstrdate1 &
                    " And Jobdate <= " & tmpstrdate2

            Else
                tmpdatecri = "ID >= " & tmpid
                tmpdatecri1 = "ID >= " & tmpid
            End If

            Dim tmpkeepVisible As String
            tmpkeepVisible = " Or KeepVisible = 1 "


            If ComboLoadedJobs.Text = "Jobs Kept Visible" Then
                tmpkeepVisible = ""
            End If

            If selectAgents Or selectClients Then
                tmpkeepVisible = ""
            End If

            Select Case ComboLoadedJobs.Text
                Case "Active Jobs"
                    tmpstr0 = " JobStatus <> '" & "Closed" & "' " &
                                           " And " & tmpdatecri

                    If Not dispatchdate Then
                        tmpstr1 = " Where JobStatus <> '" & "Closed" & "' " &
                                           " And " & tmpdatecri &
                            tmpkeepVisible
                    Else
                        tmpstr1 = " Where JobStatus <> '" & "Closed" & "' " &
                            tmpkeepVisible
                    End If

                Case "Active + Closed Jobs"
                    tmpstr0 = tmpdatecri

                    If Not dispatchdate Then
                        tmpstr1 = " Where " & tmpdatecri1 &
                            tmpkeepVisible
                    Else
                        tmpstr1 = " " &
                            tmpkeepVisible
                    End If

                Case "Closed Jobs"
                    tmpstr0 = " JobStatus = '" & "Closed" & "' " &
                                           " And " & tmpdatecri &
                            tmpkeepVisible

                    If Not dispatchdate Then
                        tmpstr1 = " Where JobStatus = '" & "Closed" & "' " &
                                           " And " & tmpdatecri1 &
                            tmpkeepVisible
                    Else
                        tmpstr1 = " Where JobStatus = '" & "Closed" & "' " &
                            tmpkeepVisible
                    End If

                Case "Jobs Kept Visible"

                    tmpstr0 = "  KeepVisible = 1 "
                    tmpstr1 = "Where  KeepVisible = 1"

                    If Not dispatchdate Then
                        tmpstr1 = " Where " & tmpdatecri1 &
                            tmpkeepVisible
                    Else
                        tmpstr1 = " " &
                            tmpkeepVisible
                    End If

            End Select



            Dim tmpstrClientsAgents As String

            If selectClients Then
                Dim tmpstrSel(), tmpclients() As String
                tmpstrSel = clsSubs.SelectedClients()

                Dim n As Integer
                If Not IsNothing(tmpstrSel) Then
                    ReDim Preserve tmpclients(n)
                    LabelVisibilityCaption.Text = "Clients: " & Join(tmpstrSel, ", ")
                    For n = 0 To tmpstrSel.GetUpperBound(0)
                        ReDim Preserve tmpclients(n)
                        If n = 0 Then
                            tmpclients(n) = "Client Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                              " And " & tmpstr0
                        Else
                            tmpclients(n) = "Or Client Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                             " And " & tmpstr0
                        End If
                    Next
                    tmpstrClientsAgents = Join(tmpclients, " ")
                    GoTo skipagent
                Else
                    LabelMessage1.Text = "No Clients Selected."
                    Exit Sub
                End If
            Else
                tmpstrClientsAgents = tmpstr0
            End If



            If selectAgents Then
                Dim tmpstrSel(), tmpAgents() As String
                tmpstrSel = clsSubs.SelectedAgents()
                Dim n As Integer
                If Not IsNothing(tmpstrSel) Then
                    ReDim Preserve tmpAgents(n)
                    LabelVisibilityCaption.Text = "Agents: " & Join(tmpstrSel, ", ")

                    For n = 0 To tmpstrSel.GetUpperBound(0)
                        ReDim Preserve tmpAgents(n)
                        If n = 0 Then
                            tmpAgents(n) = "Agent Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                              " And " & tmpstr0
                        Else
                            tmpAgents(n) = "Or Agent Like " & " '%" & Trim(tmpstrSel(n)) & "%' " &
                            " And " & tmpstr0
                        End If
                    Next
                    tmpstrClientsAgents = Join(tmpAgents, " ")
                Else
                    LabelMessage1.Text = "No Agents Selected."
                    Exit Sub
                End If
            Else
                tmpstrClientsAgents = tmpstr0
            End If

skipagent:
            Dim tmpstrSort As String


            If ComboSortOrder.Text = "Z-A" Then
                tmpstrSort = " DESC;"
            Else
                tmpstrSort = " ASC;"
            End If


            If SortBy = "JobDate" Then
                tmpstr2 = tmpkeepVisible &
                            "Order By JobDate " & tmpstrSort

            ElseIf SortBy = "ReferenceNo" Then
                tmpstr2 = tmpkeepVisible &
                         "Order By ReferenceNo " & tmpstrSort

            ElseIf SortBy = "JobId" Then
                tmpstr2 = tmpkeepVisible & " " &
                              "Order By Id " & tmpstrSort
            End If


            Dim tmpstr As String = "Where " & tmpstrClientsAgents &
                  " " & tmpstr2


            Dim sqlstr, sqlstr1, sqlstr1a, sqlstr2, sqlstr3 As String
            sqlstr =
                    "Select JobId, ReferenceNo," &
                    "JobDate,Agent,Client,Importer," &
                    "CustomsSystem, BL,CFS,OrderNo,Goods," &
                    "LastSlingDate,Shipper,JobStatus," &
                    "JobPersonnel,Weight,CBM," &
                    "ReleasePersonnel,ReleasedTo, " &
                    "ReleaseDate,DeclarationPersonnel," &
                    "ShippingPersonnel,ShipStatus," &
                    "ShippingVessel,VesselETA," &
                    "BerthingDate,ReturnDate," &
                    "CrossBorderDate,ContainerReturnDays," &
                    "VerificationPersonnel,RegistrationPersonnel," &
                    "PortStaff,RemainingDays," &
                    "DaysTaken,JobType,SOC,KeepVisible," &
                    "DispatchDate,EntensionRequested,ManifestNo," &
                    "ExtensionEndDate,RemainingExtensionDays," &
                    "Quantity,Status," &
                    "ContainerNos, Id " &
                    "From Jobs " &
                     tmpstr

            sqlstr1 = "Select JobId," &
                    "ContainerStatus,Id " &
                    "From JobCargo " &
                     tmpstr1 & " " &
                    "And ContainerStatus <> '" & "Returned" & "' " &
                    "And ContainerStatus <> '" & "Damaged" & "' "

            sqlstr1a = "Select JobId," &
                        "ContainerNo, TEU, ContainerStatus,Id " &
                        "From JobCargo " &
                        tmpstr1

            sqlstr2 =
                    "Select JobId,Status, ID " &
                    "From JobProgress " &
                    tmpstr1 & " " &
                    "Order By Date Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            'Dim tmptableA As New DataTable()
            'Call clsData.TableData(sqlstr3, tmptableA, clsData.constr)

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim tmptable1a As New DataTable()
            Call clsData.TableData(sqlstr1a, tmptable1a, clsData.constr)
            Dim dv As New DataView(tmptable1a)


            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv1 As New DataView(tmptable2)


            'x.Label1.Text = "Computing Visibility..."
            'x.PBar1.Maximum = tmptable.Rows.Count
            'x.Button1.Visible = True



            Dim drow, drow1 As DataRow
            Dim a, b, c As Integer

            Dim tmpdate As Date = Now
            Dim ts As TimeSpan
            Dim found As Boolean
            Dim tmpdate3 As Date
            Dim tmpstr3() As String

            Dim col As New DataColumn("TEU", Type.GetType("System.Double"))
            tmptable.Columns.Add(col)

            Dim TEU As Double
            Dim tmpclient() As String
            For Each drow In tmptable.Rows
                Call clsSubs.NullChecker(tmptable, a)

                tmpclient = drow("Client").ToString.Split(vbCrLf)
                ReDim Preserve tmpclient(0)
                drow("Client") = Mid(tmpclient(0), 1, 20)


                If CheckAddJobDatetoRef.Checked Then
                    drow("ReferenceNo") = drow("ReferenceNo") & " : " & Format(drow("JobDate"), "dd.MMM.yyyy")
                End If

                drow("DaysTaken") = clsSubs.DaysTaken(drow("LastSlingDate"), drow("DispatchDate"))
                found = False
                tmpdate = Now

                If CDate(drow("BerthingDate")) = CDate("1/Jan/1800") Then
                    drow("RemainingDays") = 0
                Else
                    For Each drow1 In tmptable1.Rows
                        If drow("JobId") = drow1("JobId") Then
                            found = True
                            Exit For
                        End If
                    Next

                    If found Then
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    Else
                        tmpdate = drow("ReturnDate")
                        ts = tmpdate.Subtract(drow("BerthingDate"))
                        drow("RemainingDays") = drow("ContainerReturnDays") - (ts.Days + 1)
                    End If
                End If



                If Not CDate(drow("ExtensionEndDate")) = CDate("1-Jan-1800") Then
                    tmpdate3 = drow("ExtensionEndDate")
                    drow("RemainingExtensionDays") = CInt((tmpdate3.Subtract(CDate(Now)).TotalDays))
                Else
                    drow("RemainingExtensionDays") = "0"
                End If


                dv.RowFilter = "JobId = " & "'" & drow("JobId") & "'"

                c = 0
                TEU = 0
                ReDim tmpstr3(c)
                For b = 0 To dv.Count - 1
                    Call clsSubs.NullChecker1(dv, b)

                    ReDim Preserve tmpstr3(c)
                    tmpstr3(c) = dv(b)("ContainerNo")
                    c = c + 1

                    TEU = TEU + Val(dv(b)("TEU"))
                Next

                drow("ContainerNos") = Join(tmpstr3, " ")
                drow("Quantity") = dv.Count
                drow("TEU") = TEU



                'dv1.RowFilter = "JobId = '" & drow("JobId") & "' "

                'If dv1.Count > 0 Then
                '    drow("Status") = dv1(0)("Status")
                'End If

                For Each drow1 In tmptable2.Rows
                    If drow("JobId") = drow1("JobId") Then
                        drow("Status") = drow1("Status")
                        Exit For
                    End If
                Next


                a = a + 1
                '  x.PBar1.Value = x.PBar1.Value + 1


            Next

            'If tmptable.Rows.Count = 0 Then
            '    drow = tmptable.NewRow
            '    drow("ReferenceNo") = "No Jobs"
            '    tmptable.Rows.Add(drow)
            'End If


            If tmptable.Rows.Count > 10 Then
                PanelJobs.Height = 300
            Else
                GridJobs.Height = 20 + (tmptable.Rows.Count * 20)
                PanelJobs.Height = Nothing
            End If



            'If Not dispatchdate Then
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'Else
            '    LabelVisibilityCaption.Text = tmptable.Rows.Count & " DISPATCHED Jobs: " & _
            '                     TextFromDate.Text & " | " & TextToDate.Text
            'End If

            Call Calctotal(tmptable, "")

            If CheckSelectedAgents.Checked Then
                ComboAgents.Text = "(Selected Agents)"
            ElseIf ComboAgents.Text = "(Selected Agents)" Then
                ComboAgents.Text = ""
            End If

            If CheckSelectedClients.Checked Then
                ComboClients.Text = "(Selected Clients)"
            ElseIf ComboClients.Text = "(Selected Clients)" Then
                ComboClients.Text = ""
            End If

            GridJobs.DataSource = tmptable
            GridJobs.DataBind()





        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ExportToExcel()

        Dim excel As New ExcelPackage()
        Dim workSheet = excel.Workbook.Worksheets.Add("Sheet1")
        Dim totalCols = GridJobs.Columns.Count
        Dim totalRows = GridJobs.Rows.Count

        For col1 As Integer = 2 To totalCols + 1
            workSheet.Cells(5, col1).Value = GridJobs.Columns(col1 - 2).HeaderText
        Next

        workSheet.Cells("B3:L3").Merge = True
        workSheet.Cells("B4:L4").Merge = True

        workSheet.Cells("B3:L3").Style.Font.Size = 14
        workSheet.Cells("B4:L4").Style.Font.Size = 9
        workSheet.Cells("B3:L4").Style.Font.Bold = True

        workSheet.Cells(3, 2).Value = LabelCFAgent.Text & " - Job Visibility Report - Standard"
        workSheet.Cells(4, 2).Value = LabelVisibilityCaption.Text

        Dim row1 As GridViewRow
        Dim row As Integer
        For row = 5 To totalRows + 4
            row1 = GridJobs.Rows(row - 5)
            For col1 As Integer = 1 To totalCols
                workSheet.Cells(row + 1, col1 + 1).Value = row1.Cells(col1 - 1).Text
                If row1.Cells(col1 - 1).Text = "&nbsp;" Then
                    workSheet.Cells(row + 1, col1 + 1).Value = ""
                End If
            Next


        Next

        Using rng As ExcelRange = workSheet.Cells("B5:L" & GridJobs.Rows.Count + 5)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Hair
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.AutoFitColumns()
            rng.Style.Font.Size = 9
        End Using

        Using rng As ExcelRange = workSheet.Cells("B3:L5")
            rng.Style.Font.Bold = True
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
        End Using

        'TOTALS

        row = row + 1

        Using rng As ExcelRange = workSheet.Cells("B" & row & ":L" & row)
            rng.Style.Border.Top.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Left.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Right.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.Bottom.Style = Style.ExcelBorderStyle.Thin
            rng.Style.Border.BorderAround(Style.ExcelBorderStyle.Thin)
            rng.Style.Font.Size = 10
            rng.Style.Font.Bold = True
            rng.Style.HorizontalAlignment = Style.ExcelHorizontalAlignment.Right
        End Using

        workSheet.Cells("C" & row & ":D" & row).Merge = True
        workSheet.Cells("E" & row & ":F" & row).Merge = True
        workSheet.Cells("G" & row & ":I" & row).Merge = True
        workSheet.Cells("J" & row & ":K" & row).Merge = True

        workSheet.Cells("C" & row).Value = "Total Weight: " & TextWeight.Text & "(Kgs)"
        workSheet.Cells("E" & row).Value = "Total CBM: " & TextTotalCbm.Text & "Cb.M"
        workSheet.Cells("G" & row).Value = "Total TEU: " & TextTotalQty.Text
        workSheet.Cells("J" & row).Value = "Total Qty: " & TextTotalTeu.Text

        'END TOTALS

        'FOOTER IMAGE

        Dim imagePath As String = Server.MapPath(".") & "\ReportStamp.png"
        If IO.File.Exists(imagePath) Then
            Using img As System.Drawing.Image = Image.FromFile(imagePath)
                workSheet.Drawings.AddPicture("picture1", img)
                workSheet.Drawings.Item("picture1").SetPosition(row + 1, 0, 1, 0)
            End Using
        End If

        Using memoryStream = New MemoryStream()
            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            Response.AddHeader("content-disposition", "attachment;  filename=" & "Jobs Visibility Report " & Format(Now, "dd-MMM-yyyy hh:mm tt") & ".xlsx")
            excel.SaveAs(memoryStream)
            memoryStream.WriteTo(Response.OutputStream)
            Response.Flush()
            Response.[End]()
        End Using
    End Sub
    Private Sub LoadAgents()
        Dim sqlstr As String =
        "Select Agent From Agents " &
        "Order By Agent Asc;"
        ComboAgents.Items.Add("(All)")
        Call clsData.PopCombo(ComboAgents, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadClients()
        Dim sqlstr As String =
        "Select Client From Clients " &
        "Order By Client Asc;"
        ComboClients.Items.Add("(All)")
        Call clsData.PopCombo(ComboClients, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadImporters()
        Dim sqlstr As String =
        "Select Importer From Importers " &
        "Order By Importer Asc;"
        ComboImporters.Items.Add("(All)")
        Call clsData.PopCombo(ComboImporters, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadShippers()
        Dim sqlstr As String =
        "Select Shipper From Shippers " &
        "Order By Shipper Asc;"
        ComboShippers.Items.Add("(All)")
        Call clsData.PopCombo(ComboShippers, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadCFAgentUsers()
        Dim sqlstr As String =
        "Select UserNames From CFAgentUsers"
        ComboCFAgentUsers.Items.Add("(All)")
        Call clsData.PopCombo(ComboCFAgentUsers, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadShipStatus()
        Dim sqlstr As String =
        "Select Status from ShipStatus"
        ComboShipStatus.Items.Add("(All)")
        Call clsData.PopCombo(ComboShipStatus, sqlstr, clsData.constr, 0)
    End Sub

    Private Sub LoadJobStatuses()
        Dim sqlstr As String =
         "Select Status " &
         "From JobStatuses "
        ComboJobStatus.Items.Add("(All)")
        Call clsData.PopCombo(ComboJobStatus, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadJobTypes()
        Dim sqlstr As String =
         "Select JobType " &
         "From JobTypes "
        ComboJobType.Items.Add("(All)")
        Call clsData.PopCombo(ComboJobType, sqlstr, clsData.constr, 0)
    End Sub


    Private Sub LoadCFS()
        Dim sqlstr As String =
        "Select CFS " &
        "From CFS"
        ComboCFS.Items.Add("(All)")
        Call clsData.PopCombo(ComboCFS, sqlstr, clsData.constr, 0)
    End Sub



    Protected Sub ButtonGoToJob_Click(sender As Object, e As EventArgs) Handles ButtonGoToJob.Click
        If GridJobs.SelectedValue Is Nothing Then
            LabelMessage3.ForeColor = Color.Tomato
            LabelMessage3.Text = "Please select an item"
        Else
            Call GotoJob()
        End If
    End Sub
    Private Sub GotoJob()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("jobentry.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call RefreshData()
    End Sub
    Private Sub RefreshData()
        'Dim a As Integer = GridJobs.SelectedValue.ToString
        'Dim selected As Boolean
        'If a >= 0 Then
        '    selected = GridJobs.SelectedIndex
        'End If

        Call ClearFilters()
        Call LoadJobs(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked)


        '  GridJobs.SelectedIndex = a

    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelJobs.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    GoTo skip
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    GoTo skip
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    GoTo skip
                End If

                If cont.ID = "CheckSelectedClients" Then
                    GoTo skip
                End If

                If cont.ID = "CheckShowBL" Then
                    GoTo skip
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    GoTo skip
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    GoTo skip
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If
skip:
        Next
    End Sub

    Private Sub PreDefine(ByVal Selection As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            CheckDispatchDate.Enabled = True

            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""
                    CheckDispatchDate.Checked = False
                    CheckDispatchDate.Enabled = False

                    Call ClearFilters()
                    Call LoadJobs(True, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last 3 months"

                    Dim tmpstr(12) As String
                    tmpstr(1) = "Jan"
                    tmpstr(2) = "Feb"
                    tmpstr(3) = "Mar"
                    tmpstr(4) = "Apr"
                    tmpstr(5) = "May"
                    tmpstr(6) = "Jun"
                    tmpstr(7) = "Jul"
                    tmpstr(8) = "Aug"
                    tmpstr(9) = "Sep"
                    tmpstr(10) = "Oct"
                    tmpstr(11) = "Nov"
                    tmpstr(12) = "Dec"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd-MMM-yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd-MMM-yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadJobs(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked)




        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ApplyDates()
    End Sub

    Private Sub ApplyDates()
        Call ClearFilters()
        Call LoadJobs(False, CheckSelectedClients.Checked, CheckSelectedAgents.Checked, CheckDispatchDate.Checked)
    End Sub

    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try

            Dim dv As DataView = tmptable.DefaultView
            Dim a As Integer
            Dim Qty, TEU, Weight, CBM As Double


            For a = 0 To dv.Count - 1
                Call clsSubs.NullChecker1(dv, a)

                Qty = Qty + dv(a)("Quantity")
                Weight = Weight + dv(a)("Weight")
                CBM = CBM + dv(a)("CBM")
                TEU = TEU + dv(a)("TEU")
            Next

            TextTotalQty.Text = Format(Qty, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextTotalCbm.Text = Format(CBM, "#,##0.00")
            TextTotalTeu.Text = Format(TEU, "#,##0.00")

            Dim tmpstr As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr = "All Jobs In System" & " (" & ComboLoadedJobs.Text & " )"
            End If

            If LabelVisibilityCaption.Text = "" And tmpcaption1 = "" Then
                If Not CheckDispatchDate.Checked Then
                    LabelVisibilityCaption.Text = dv.Count & " Jobs: " &
                                     TextFromDate.Text & " | " & tmpstr
                Else
                    LabelVisibilityCaption.Text = dv.Count & " DISPATCHED JOBS: " &
                                     TextFromDate.Text & " | " & tmpstr
                End If

            Else
                If Not CheckDispatchDate.Checked Then
                    LabelVisibilityCaption.Text = dv.Count & " Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                Else
                    LabelVisibilityCaption.Text = dv.Count & " DISPATCHED Jobs: " & " " & tmpcaption1 & " | " & tmpstr
                End If

            End If
        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub




    Private Sub ComboPredefine_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text)
    End Sub

    Private Sub CompoundFilter(ByVal Agent As Boolean, ByVal Client As Boolean, ByVal Importer As Boolean,
                                ByVal Shipper As Boolean, ByVal ShipStatus As Boolean,
                                ByVal JobType As Boolean, ByVal JobStatus As Boolean,
                                ByVal CFS As Boolean, ByVal EntensionRequested As Boolean,
                                ByVal OmitDispatched As Boolean, ByVal OmitCrossedBorder As Boolean,
                                ByVal CustomsSystem As Boolean, ByVal CFAgentUser As Boolean)

        Try

            Dim tmpstr(0), tmpstr1(0), tmpstrSel(0), tmpstrSel1(0) As String

            Dim a, b As Integer
            Dim dv As DataView = GridJobs.DataSource
            dv.Sort = Nothing
            dv.RowFilter = Nothing

            If Agent Then
                If Not CheckSelectedAgents.Checked Then
                    ReDim Preserve tmpstr(a), tmpstr1(a)
                    tmpstr(a) = "Agent Like " & "'%" & Trim(ComboAgents.Text) & "%' "
                    tmpstr1(a) = "Agent: " & ComboAgents.Text
                    b = b + 1
                End If

            End If


            If Client Then
                a = a + 1

                If Not CheckSelectedClients.Checked Then
                    ReDim Preserve tmpstr(a), tmpstr1(a)
                    If b = 0 Then
                        tmpstr(a) = "Client Like " & "'%" & Trim(ComboClients.Text) & "%' "
                    Else
                        tmpstr(a) = "And Client Like " & "'%" & Trim(ComboClients.Text) & "%' "
                    End If

                    tmpstr1(a) = "Client: " & ComboClients.Text
                    b = b + 1
                End If

            End If

            If Importer Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "Importer Like " & "'%" & Trim(ComboImporters.Text) & "%' "
                Else
                    tmpstr(a) = " And Importer Like " & "'%" & ComboImporters.Text & "%' "
                End If

                tmpstr1(a) = "Consignee: " & ComboImporters.Text
                b = b + 1
            End If

            If Shipper Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "Shipper Like " & "'%" & Trim(ComboShippers.Text) & "%' "
                Else
                    tmpstr(a) = " And Shipper Like " & "'%" & ComboShippers.Text & "%' "
                End If

                tmpstr1(a) = "Shipper: " & ComboShippers.Text
                b = b + 1
            End If

            If ShipStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "ShipStatus Like " & "'%" & Trim(ComboShipStatus.Text) & "%' "
                Else
                    tmpstr(a) = " And ShipStatus Like " & "'%" & ComboShipStatus.Text & "%' "
                End If

                tmpstr1(a) = "ShipStatus: " & ComboShipStatus.Text
                b = b + 1
            End If

            If JobType Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobType Like " & "'" & Trim(ComboJobType.Text) & "%' "
                Else
                    tmpstr(a) = " And JobType Like " & "'" & ComboJobType.Text & "%' "
                End If

                tmpstr1(a) = "JobType: " & ComboJobType.Text
                b = b + 1
            End If

            If JobStatus Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus Like " & "'" & Trim(ComboJobStatus.Text) & "%' "
                Else
                    tmpstr(a) = " And JobStatus Like " & "'" & ComboJobStatus.Text & "%' "
                End If

                tmpstr1(a) = "Job Status: " & ComboJobStatus.Text
                b = b + 1
            End If


            If CFS Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CFS Like " & "'%" & Trim(ComboCFS.Text) & "%' "
                Else
                    tmpstr(a) = " And CFS Like " & "'%" & ComboCFS.Text & "%' "
                End If

                tmpstr1(a) = "CFS: " & ComboCFS.Text
                b = b + 1
            End If

            If EntensionRequested Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "EntensionRequested = " & "" & EntensionRequested & ""
                Else
                    tmpstr(a) = " And EntensionRequested = " & "" & EntensionRequested & ""
                End If

                tmpstr1(a) = "EXTENSION REQUESTED: " & CBool(EntensionRequested)
                b = b + 1
            End If

            If OmitDispatched Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Dispatched" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Dispatched" & "' "
                End If

                tmpstr1(a) = "NOT DISPATCHED: " & CBool(OmitDispatched)
                b = b + 1
            End If


            If OmitCrossedBorder Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobStatus <> '" & "Crossed Border" & "' "
                Else
                    tmpstr(a) = " And JobStatus <> '" & "Crossed Border" & "' "
                End If

                tmpstr1(a) = "NOT CROSSED BORDER: " & CBool(OmitCrossedBorder)
                b = b + 1
            End If

            If CustomsSystem Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "CustomsSystem Like " & "'%" & Trim(ComboCustomsSystem.Text) & "%' "
                Else
                    tmpstr(a) = " CustomsSystem CFS Like " & "'%" & ComboCustomsSystem.Text & "%' "
                End If

                tmpstr1(a) = "CUSTOMS SYSTEM: " & ComboCustomsSystem.Text
                b = b + 1
            End If



            If CFAgentUser Then
                a = a + 1
                ReDim Preserve tmpstr(a), tmpstr1(a)
                If b = 0 Then
                    tmpstr(a) = "JobPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or ShippingPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or PortStaff Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%'"

                Else
                    tmpstr(a) = " And JobPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or ShippingPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or DeclarationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or VerificationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or PortStaff Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%' " &
                                "Or RegistrationPersonnel Like " & "'%" & Trim(ComboCFAgentUsers.Text) & "%'"

                End If

                tmpstr1(a) = "By: " & ComboCFAgentUsers.Text
                b = b + 1

            End If

            Dim tmpstr2 = Join(tmpstr, " ")
            Dim tmpstr3 = Join(tmpstr1, ", ")

            dv.RowFilter = tmpstr2
            If Not CheckDispatchDate.Checked Then
                LabelVisibilityCaption.Text = dv.Count & " Jobs: " & tmpstr3 & " | " & TextFromDate.Text & " to " & TextToDate.Text & ""
            Else
                LabelVisibilityCaption.Text = dv.Count & " DISPATCHED Jobs: " & tmpstr3 & " | " & TextFromDate.Text & " to " & TextToDate.Text & ""
            End If

            'Call Calctotal(tm)

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "AdvFilter")
        End Try
    End Sub


    Private Sub JobProgressUpdates()
        If Not IsNothing(GridJobs.SelectedValue.ToString) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString)
        End If

    End Sub


    Protected Sub ButtonSelectAgents_Click(sender As Object, e As EventArgs) Handles ButtonSelectAgents.Click
        Call SelectAgents()
    End Sub

    Private Sub SelectAgents()
        Response.Redirect("selectedclients.aspx")

    End Sub


    Protected Sub ButtonSelectClients_Click(sender As Object, e As EventArgs) Handles ButtonSelectClients.Click
        Call SelectClients()
    End Sub

    Private Sub SelectClients()
        Response.Redirect("selectedclients.aspx")
    End Sub


    Protected Sub ButtonDeclaration_Click(sender As Object, e As EventArgs) Handles ButtonDeclaration.Click
        Call Declaration()
    End Sub
    Private Sub Declaration()
        If Not IsNothing(GridJobs.SelectedValue.ToString()) Then
            Response.Redirect("progressupdates.aspx?jobid=" & GridJobs.SelectedValue.ToString())
        End If

    End Sub




    Private Sub ComboLoadedJobs_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboLoadedJobs.SelectedIndexChanged
        Static x As Boolean
        If x Then
            Call RefreshData()
        End If
        x = True
    End Sub






    Private Sub AppendJobDate(Append As Boolean)
        Dim dv As DataView = GridJobs.DataSource
        If Not IsNothing(dv) Then
            Dim a As Integer
            Dim tmpstr(1)
            For a = 0 To dv.Count - 1
                tmpstr = dv(a)("ReferenceNo").ToString.Split(":")
                ReDim Preserve tmpstr(1)
                If Append Then
                    dv(a)("ReferenceNo") = Trim(tmpstr(0)) & " : " & Format(dv(a)("JobDate"), "dd.MMM.yyyy")
                Else
                    dv(a)("ReferenceNo") = Trim(tmpstr(0))
                End If
            Next


        End If
    End Sub

    Private Sub SaveSettings()
        Dim tmptable As New DataTable()
        Call clsData.TableData("", tmptable, clsData.constr)
        Dim drow As DataRow = tmptable.Rows(0)
        drow("SortJobsBy") = ComboSortOrder.Text
        drow("SortOrder") = nSortOrder()
        drow("AddJobDatetoRef") = CheckAddJobDatetoRef.Checked

        Call clsData.SaveData("Environment", tmptable, "", False, clsData.constr)
    End Sub


    Private Function nSortOrder() As String
        If RadioSortByJobDate.Checked Then
            Return "JobDate"
        ElseIf RadioSortByRefNo.Checked Then
            Return "ReferenceNo"
        ElseIf RadioSortByJobId.Checked Then
            Return "JobId"
        Else
            Return "JobDate"
        End If
    End Function
    Protected Sub CheckSelectedAgents_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSelectedAgents.CheckedChanged
        If CheckSelectedAgents.Checked Then
            CheckSelectedAgents.Checked = Not CheckSelectedClients.Checked
        End If
    End Sub

    Protected Sub CheckSelectedClients_CheckedChanged(sender As Object, e As EventArgs) Handles CheckSelectedClients.CheckedChanged
        If CheckSelectedClients.Checked Then
            CheckSelectedClients.Checked = Not CheckSelectedAgents.Checked
        End If
    End Sub

    Protected Sub RadioButtonSortJobId_CheckedChanged(sender As Object, e As EventArgs) Handles RadioSortByJobId.CheckedChanged
        Call nSortOrder()
    End Sub


    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click

        Call ExportToExcel()
    End Sub



    Protected Sub GridJobs_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridJobs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridJobs, "Select$" & e.Row.RowIndex)
        End If
    End Sub

End Class

