﻿Public Class index
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'Call clsSubs.isMobileBrowser()

        If Not IsPostBack Then

            Try
                LabelMessage1.Text = ""

                If IsNothing(Request.Cookies("CFPROToken")) Then
                    Call RegisterToken()
                End If

                'Response.Cookies("CFAgent").Expires = Now.AddHours(-1)

                Dim UserType As String = ""

                If Not Request.Cookies("UserType") Is Nothing Then
                    UserType = Request.Cookies("UserType").Value
                End If


                Call clsAuth.UserLogin("", "", LabelCFPROUserID.Text, LabelUserNames.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, UserType, False,,,,,, LabelUserNames.Text)

                Dim host As String = Request.Url.Host
                If InStr(host, "cfpro", CompareMethod.Text) > 0 Then
                    host = "http://" & host
                Else
                    host = "http://" & host & ":84/"
                End If


                HyperGetCFPRO.NavigateUrl = host & "productstart.aspx?productid=00004"
                HyperCFPRODesktop.NavigateUrl = host & "cfprodesktop.aspx"


                LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"


            Catch ex As Exception
                LabelMessage1.Text = ex.Message & ex.StackTrace
            End Try

        End If


    End Sub

    Private Sub RegisterToken()

        If Not IsNothing(Request.QueryString("logintoken")) Then
            Call clsAuth.SignInOut("Sign Out", LabelUserNames.Text, Image1.ImageUrl, False, "index.aspx")
            Call clsAuth.LoginToken(Request.QueryString("logintoken"), False, LabelMessage1.Text, TodaysDate.Value)

        End If
    End Sub

    Protected Sub LinkButtonImporter_Click(sender As Object, e As EventArgs) Handles LinkButtonImporter.Click

        Response.Cookies("UserType").Value = "importer"

        If IsNothing(Request.Cookies("CFPROToken")) Then
            Response.Redirect(clsAuth.UserAuthURL("cfprodashboard.aspx", TodaysDate.Value))
        Else
            Response.Redirect("cfprodashboard.aspx")
        End If

    End Sub

    Protected Sub LinkButtonCFAgent_Click(sender As Object, e As EventArgs) Handles LinkButtonCFAgent.Click

        Response.Cookies("TodaysDate").Value = TodaysDate.Value

        Response.Cookies("UserType").Value = "cfagent"


        If IsNothing(Request.Cookies("CFPROToken")) Then
            Response.Redirect(clsAuth.UserAuthURL("cfprodashboard.aspx", TodaysDate.Value))
        Else
            Response.Redirect("cfprodashboard.aspx")
        End If

    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Response.Cookies("UserType").Value = "guest"
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUserNames.Text, Image1.ImageUrl, True, "index.aspx")
    End Sub


    Protected Sub LinkButtonTransporter_Click(sender As Object, e As EventArgs) Handles LinkButtonTransporter.Click

        Response.Cookies("UserType").Value = "transporter"

        If IsNothing(Request.Cookies("CFPROToken")) Then
            Response.Redirect(clsAuth.UserAuthURL("cfprodashboard.aspx", TodaysDate.Value))
        Else
            Response.Redirect("cfprodashboard.aspx")
        End If
    End Sub


    Protected Sub LinkButtonInsurer_Click(sender As Object, e As EventArgs) Handles LinkButtonInsurer.Click

        If IsNothing(Request.Cookies("CFPROToken")) Then
            Response.Redirect("marinecargoinsurance.aspx")
        Else
            Response.Cookies("UserType").Value = "insurer"
            Response.Redirect("marinecargoinsurance.aspx")
        End If
    End Sub

End Class