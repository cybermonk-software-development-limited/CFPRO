﻿
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.IO
Imports System.Net

Public Class clsProgressUpdates


    Shared Sub CreateAccountKpiSettings(CFPROID As String, ByRef tmptable1 As DataTable)
        Dim sqlstr As String =
          "SELECT SortOrder, ItemID," &
          "ItemDescription, MaxDays," &
          "PreAlertDays, PostAlertDays," &
          "DayCount, Remarks," &
          "RemarksDesc, CFPROID,ID " &
          "FROM  KPIProgress " &
          "Where CFPROID = '0' "



        Dim tmptable As New DataTable()

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim drow, drow1 As DataRow
        Dim col As DataColumn
        If tmptable.Rows.Count > 0 Then

            For Each drow In tmptable.Rows
                drow1 = tmptable1.NewRow

                For Each col In tmptable.Columns
                    If Not col.ColumnName.ToString = "ID" Then
                        drow1(col.ColumnName.ToString) = drow(col.ColumnName.ToString)
                    End If
                Next

                drow1("CFPROID") = CFPROID
                tmptable1.Rows.Add(drow1)

            Next
        End If

        Call clsData.SaveData("KPIProgress", tmptable1, sqlstr, False, clsData.constr)

    End Sub



    Shared Sub UpdateKPIProgress(CFPROID As String, JobID As String, KPIItemID As String, ByRef KPIProgressID As String, StatuUdate As String,
                                 Updatedate As String, UserID As String, ID As Integer, Edit As Boolean, Delete As Boolean, ByRef ErrMsg As String)

        Try


            Dim sqlstr As String =
              "SELECT  KPIProgressID,JobID, " &
              "KPIItemID,AlertID, UpdateDate," &
              "LastProcessed, LastSeen," &
              "CFPROID,ID " &
              "FROM KPIProgressUpdates " &
              "Where KPIProgressID ='" & KPIProgressID & "' " &
              "Order by ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow


            If Not Edit Then
                KPIProgressID = GetKPIProgressID()
                drow = tmptable.NewRow
                drow("KPIProgressID") = KPIProgressID
                drow("CFPROID") = CFPROID
                drow("JobID") = JobID
                tmptable.Rows.Add(drow)
            Else
                If tmptable.Rows.Count > 0 Then
                    drow = tmptable.Rows(0)
                End If
            End If

            drow("KPIItemID") = KPIItemID
            drow("UpdateDate") = Updatedate


            Call clsData.SaveData("KPIProgressUpdates", tmptable, sqlstr, False, clsData.constr)


            Call SaveProgressUpdate(CFPROID, JobID, ID, KPIProgressID, StatuUdate, Updatedate, UserID, Delete, ErrMsg)

            Call UpdateOverallJobStatus(CFPROID, JobID, KPIItemID)


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub
    Shared Function UpdateExists(CFPROID As String, JobID As String, KPIItemID As String, Updatedate As String, ErrMsg As String) As Boolean

        Try


            Dim sqlstr As String =
              "SELECT   UpdateDate,ID " &
              "FROM KPIProgressUpdates " &
              "Where KPIProgressID ='" & CFPROID & "' " &
              "And JobID ='" & JobID & "' " &
              "And KPIItemID ='" & KPIItemID & "' " &
              "Order by ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            Dim drow As DataRow



            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
                If CDate(drow("UpdateDate")) = CDate(Updatedate) Then
                    Return True
                End If
            End If

            Return False


        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function


    Shared Function UpdateOverallJobStatus(CFPROID As String, JobID As String, KPIItemID As String) As String

        Dim sqlstr1 As String =
                        "SELECT JobStatus,  ID " &
                         "From Jobs " &
                         "Where CFPROID ='" & CFPROID & "' " &
                         "And JobID = '" & JobID & "' "

        Dim tmptable1 As New DataTable()
        Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

        If KPIItemID = "000026" Then

            If tmptable1.Rows.Count > 0 Then
                Dim drow1 As DataRow = tmptable1.Rows(0)
                drow1("JobStatus") = "FILE CLOSED"
                Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)
            End If


            Dim sqlstr2 As String =
                        "SELECT Status, CFPROID, ID " &
                         "From CFAgentJobStatus " &
                         "Where CFPROID ='" & CFPROID & "' " &
                         "And Status = 'FILE CLOSED' "

            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)


            If tmptable2.Rows.Count = 0 Then
                Dim drow2 As DataRow = tmptable2.NewRow
                drow2("CFPROID") = CFPROID
                drow2("Status") = "File Closed"
                tmptable2.Rows.Add(drow2)
                Call clsData.SaveData("CFAgentJobStatus", tmptable2, sqlstr2, False, clsData.constr)
            End If

            Return "File Closed"
        Else
            If tmptable1.Rows.Count > 0 Then

                Dim JobStatus As String
                Call clsData.NullChecker(tmptable1, 0)
                Dim drow1 As DataRow = tmptable1.Rows(0)
                If drow1("JobStatus").Contains("close") Then
                    drow1("JobStatus") = "Active"
                    JobStatus = "Active"
                Else
                    JobStatus = drow1("JobStatus")
                End If

                If Trim(drow1("JobStatus")) = "" Then
                    drow1("JobStatus") = "Active"
                    JobStatus = "Active"
                End If

                Call clsData.SaveData("Jobs", tmptable1, sqlstr1, False, clsData.constr)
                Return JobStatus
            Else
                Return ""
            End If

        End If

    End Function


    Shared Sub SaveProgressUpdate(CFPROID As String, JobID As String, ID As Integer, KPIProgressID As String,
                                                StatuUpdate As String, Updatedate As String, UserID As String, Delete As Boolean, ByRef ErrMsg As String)
        Try


            Dim sqlstr As String =
              "Select JobId,Status,Date," &
              "RecordStatus,UserID," &
              "KPIProgressID,KeepVisible," &
              "CFPROID,ID " &
              "From JobProgress " &
              "Where JobID = '" & JobID & "' " &
              "And CFPROID = '" & CFPROID & "' " &
              "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            If Delete Then
                If tmptable.Rows.Count > 0 Then
                    drow = tmptable.Rows(0)
                    drow.Delete()
                    GoTo Save
                End If
            End If

            If tmptable.Rows.Count = 0 Then
                drow = tmptable.NewRow
                drow("JobID") = JobID
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            Else
                drow = tmptable.Rows(0)
            End If


            drow("Status") = StatuUpdate

            If IsDate(Updatedate) Then
                drow("Date") = Updatedate
            End If



            drow("UserID") = UserID
            drow("KPIProgressID") = KPIProgressID
Save:

            Call clsData.SaveData("JobProgress", tmptable, sqlstr, Delete, clsData.constr)

            If Delete Then
                Call DeleteKPIProgressUpdate(CFPROID, JobID, KPIProgressID)
            End If



        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Sub


    Shared Sub DeleteKPIProgressUpdate(CFPROID As String, JobID As String, KPIProgressID As String)

        Dim sqlstr As String =
          "SELECT ID " &
          "FROM KPIProgressUpdates " &
          "Where KPIProgressID = '" & KPIProgressID & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()
            Call clsData.SaveData("KPIProgressUpdates", tmptable, sqlstr, True, clsData.constr)
        End If

    End Sub




    Shared Function GetStatusUpdate(ByVal prefixText As String, ByVal count As Integer) As List(Of String)

        Try

            Dim CFPROID As String = ""
            Call clsAuth.AuthCFAgent(CFPROID, "", "", "", "", "", False)

            Dim sqlstr As String =
                "SELECT  Distinct Top 4 Status " &
                "FROM JobProgress " &
                "Where CFPROID = '" & CFPROID & "' " &
                "And Status Like + @SearchText + '%'  " &
                "Order by Status Asc;"

            Dim Conn As SqlConnection = New SqlConnection
            Dim Connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, Connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            Connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim StatusUpdate As List(Of String) = New List(Of String)

            While Reader1.Read
                If Not IsDBNull(Reader1("Status")) Then
                    StatusUpdate.Add(AjaxControlToolkit.AutoCompleteExtender _
               .CreateAutoCompleteItem(Reader1("Status"), 0))
                End If
            End While

            Connection1.Close()

            Return StatusUpdate

        Catch ex As Exception
        End Try


    End Function
    Shared Function GetKPI(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Try

            Dim CFPROID As String = ""
            Call clsAuth.AuthCFAgent(CFPROID, "", "", "", "", "", False)

            Dim sqlstr As String =
                "SELECT  Distinct Top 4 ItemDescription, ItemID " &
                "FROM KPIProgress " &
                "Where CFPROID = '" & CFPROID & "' " &
                "And ItemDescription Like  '%' + @SearchText + '%'  " &
                "Order by ItemDescription Asc;"

            Dim Conn As SqlConnection = New SqlConnection
            Dim Connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, Connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            Connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim KPI As List(Of String) = New List(Of String)

            While Reader1.Read
                If Not IsDBNull(Reader1("ItemDescription")) Then
                    KPI.Add(AjaxControlToolkit.AutoCompleteExtender _
               .CreateAutoCompleteItem(Reader1("ItemDescription"), Reader1("ItemID")))
                End If
            End While

            Connection1.Close()

            Return KPI

        Catch ex As Exception
        End Try
    End Function
    Shared Function GetKPIProgressID(Optional ByRef ErrMsg As String = "") As String
        Try

            Dim tmpKPIProgressID As Integer

            Dim sqlstr As String =
             "Select Top 1 ID " &
             "From KPIProgressUpdates " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpKPIProgressID = drow("ID")
                tmpKPIProgressID = tmpKPIProgressID + 1
                tmpstr = Format(tmpKPIProgressID, "00000000#")
            Else
                tmpstr = Format(tmpKPIProgressID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            ErrMsg = exp.Message & exp.StackTrace
        End Try
    End Function

    Shared Function StatusUpdateText(JobID As String, ClientID As String, AdditionalMessage As String, ErrMsg As String) As String
        Try
            Dim CFAgentName As String = ""
            Dim CFPROID As String = ""

            Call clsAuth.AuthCFAgent(CFPROID, CFAgentName, "", "", "", "", False)
            If CFAgentName.Length > 25 Then
                CFAgentName = Trim(Mid(CFAgentName, 1, 25))
            End If

            Dim host As String = HttpContext.Current.Request.Url.Host.ToString


            If host.Contains("localhost") Then
                host = host & ":90"
            ElseIf clsAuth.IsIPAdress(host) Then
                host = host & ":90"
            End If



            Dim sqlstr As String =
                     "Select  JobID,ReferenceNo, " &
                     "ReferenceNo1,JobDate, ID " &
                     "From Jobs " &
                     "Where JobID = '" & JobID & "' " &
                     "And CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim sqlstr1 As String =
                        "Select Top 1 JobID," &
                        "Status, UserID, Date," &
                        "KPIProgressID, ID " &
                        "From JobProgress " &
                        "Where JobID = '" & JobID & "' " &
                        "And CFPROID = '" & CFPROID & "' " &
                        "Order By Date Desc;"


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                Dim RefNos As String = ""
                If Not drow("ReferenceNo") = "" Then
                    RefNos = drow("ReferenceNo")
                End If

                If Not drow("ReferenceNo1") = "" Then
                    RefNos = RefNos & ", " & drow("ReferenceNo1")
                End If

                If Not Trim(RefNos) = "" Then
                    RefNos = ". Job Ref No: " & RefNos
                End If

                host = "http://" & host & "/tracking.aspx?cfproid=" &
                         HttpUtility.UrlEncode(clsEncr.EncryptString(CFPROID)) & "&refno=" & drow("ReferenceNo")


                If tmptable1.Rows.Count > 0 Then
                    Dim drow1 As DataRow = tmptable1.Rows(0)
                    Call clsData.NullChecker(tmptable1, 0)

                    Dim UserDet() As String = GetUserDetails(CFPROID, drow1("UserID"))
                    ReDim Preserve UserDet(1)

                    Dim ClientDet() As String = GetClientDetails(CFPROID, ClientID)
                    ReDim Preserve ClientDet(1)

                    If Not AdditionalMessage = "" Then
                        AdditionalMessage = vbCrLf & vbCrLf & AdditionalMessage & vbCrLf & vbCrLf
                    End If

                    Return "Attn: " & ClientDet(1) & RefNos & " UPDATE: " & drow1("Status") & ". (" &
                        Format(drow1("Date"), "dd MMM yyyy HH:mm") & "). Call " & UCase(CFAgentName) & " . " &
                        UserDet(0) & " - " & UserDet(1) & AdditionalMessage &
                        "TRACK: " & TinyShortURL(host, ErrMsg)

                Else
                    Return "No Status Update"
                End If
            Else
                Return "No Job Update"
            End If

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
            Return ex.Message
        End Try

    End Function
    Shared Function CargoStatusUpdate(CFPROID As String, JobID As String, UserID As String, AdditionalMessage As String,
                                      nDateToday As String, ErrMsg As String) As String
        Try
            Dim host As String = HttpContext.Current.Request.Url.Host.ToString
            If host.Contains("localhost") Then
                host = host & ":90"
            ElseIf clsAuth.IsIPAdress(host) Then
                host = host & ":90"
            End If


            Dim sqlstr As String =
                         "Select  Jobs.ShipperID,Shipper," &
                         "ReferenceNo  " &
                         "From Jobs,Shippers " &
                         "Where Jobs.JobID = '" & JobID & "' " &
                         "And Jobs.ShipperID = Shippers.ShipperID " &
                         "And Jobs.CFPROID = '" & CFPROID & "' " &
                         "And Shippers.CFPROID = '" & CFPROID & "' "


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
                         "Select  JobID,ContainerNo," &
                         "Payload, PortExitDate,  " &
                         "CrossBorderDate, ID " &
                         "From JobCargo " &
                         "Where JobID = '" & JobID & "' " &
                         "And CFPROID = '" & CFPROID & "' "


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim CargoStatus As String
            Dim ContainerNos(0) As String

            Dim UserDetails() As String = GetUserDetails(CFPROID, UserID)

            If Not IsDate(nDateToday) Then
                nDateToday = Format(Now, "dd MMM yyyy")
            Else
                nDateToday = Format(CDate(clsSubs.AbsoluteDateTime(nDateToday)), "dd MMM yyyy")
            End If

            Dim a, b As Integer
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                CargoStatus = drow("Shipper") & vbCrLf
                CargoStatus = CargoStatus & "Loaded From Mombasa: "

                For Each drow1 In tmptable1.Rows
                    Call clsData.NullChecker(tmptable1, a)
                    If Not CDate(drow1("PortExitDate")) = CDate("1-Jan-1800") Then
                        If CDate(drow1("PortExitDate")) = CDate(nDateToday) Then
                            ReDim Preserve ContainerNos(b)
                            ContainerNos(b) = drow1("ContainerNo")
                        End If
                        b = b + 1
                    End If
                    a = a + 1
                Next


                If Not IsNothing(ContainerNos(0)) Then
                    CargoStatus = CargoStatus & Join(ContainerNos, ", ") & vbCrLf
                Else
                    CargoStatus = CargoStatus & "0 " & vbCrLf
                End If


                CargoStatus = CargoStatus & "Pending: " & tmptable1.Rows.Count - b & vbCrLf

                CargoStatus = CargoStatus & "Enquiries: " & UserDetails(0) & vbCrLf & vbCrLf

                If Not AdditionalMessage = "" Then
                    AdditionalMessage = AdditionalMessage & vbCrLf & vbCrLf
                End If

                CargoStatus = CargoStatus & AdditionalMessage & "Track: " &
                              TinyShortURL("http://" & host & "/tracking.aspx?cfproid=" &
                              HttpUtility.UrlEncode(clsEncr.EncryptString(CFPROID)) & "&refno=" & drow("ReferenceNo"), ErrMsg)

            Else
                CargoStatus = "No Cargo Movement Update"

            End If

            Return CargoStatus
        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
            Return ex.Message
        End Try

    End Function

    Shared Function GetUserDetails(CFPROID As String, UserID As String) As String()

        Dim sqlstr As String =
            "Select UserNames,Telephone " &
            "From CFAgentUsers " &
            "Where  CFPROID= '" & CFPROID & "' " &
            "And UserID = '" & UserID & "'"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim UserDetails(1) As String
        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)
            UserDetails(0) = Trim(drow("Telephone"))
            UserDetails(1) = Trim(drow("UserNames"))

            UserDetails(0) = Trim(UserDetails(0).Replace(" ", ""))

            If UserDetails(0).StartsWith("0") Then
                UserDetails(0) = "+254" & Mid(UserDetails(0), 2, UserDetails(0).Length)
            End If

            If UserDetails(1).Length > 25 Then
                UserDetails(1) = Trim(Mid(UserDetails(1), 1, 25))
            End If

        End If

        If Trim(UserDetails(0)) = "Not Available" Then
            UserDetails(0) = "Not Available"
        End If

        If Trim(UserDetails(1)) = "Not Available" Then
            UserDetails(1) = "Not Available"
        End If

        Return UserDetails

    End Function

    Shared Function GetClientDetails(CFPROID As String, ClientID As String) As String()

        Dim sqlstr As String =
            "Select Client,Telephone,ID " &
            "From Clients " &
            "Where  CFPROID= '" & CFPROID & "' " &
            "And  ClientID= '" & ClientID & "'"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim ClientDetails(1) As String
        If tmptable.Rows.Count > 0 Then

            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)

            Dim sqlstr1 As String =
            "Select Telephone  " &
            "From TelephoneNos " &
            "Where  CFPROID= '" & CFPROID & "' " &
            "And OwnerType = 'client' " &
            "And  OwnerID = '" & drow("ID") & "'"


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)



            ClientDetails(0) = Trim(drow("Telephone"))
            ClientDetails(1) = Trim(drow("Client"))

            ClientDetails(0) = Trim(ClientDetails(0).Replace(" ", ""))

            If ClientDetails(0).StartsWith("0") Then
                ClientDetails(0) = "+254" & Mid(ClientDetails(0), 2, ClientDetails(0).Length)
            End If


            Dim a As Integer
            Dim ClientPhones(0) As String

            For Each drow1 In tmptable1.Rows
                Call clsData.NullChecker(tmptable1, a)
                ReDim Preserve ClientPhones(a)
                ClientPhones(a) = drow1("Telephone")

                ClientPhones(a) = Trim(ClientPhones(a).Replace(" ", ""))
                If ClientPhones(a).StartsWith("0") Then
                    ClientPhones(a) = "+254" & Mid(ClientPhones(a), 2, ClientPhones(a).Length)
                End If

                a = a + 1

            Next

            If Not IsNothing(ClientPhones(0)) Then
                ClientDetails(0) = ClientDetails(0) & ", " & Join(ClientPhones, ", ")
            End If


            If ClientDetails(1).Length > 25 Then
                ClientDetails(1) = Trim(Mid(ClientDetails(1), 1, 25))
            End If
        End If

        If Trim(ClientDetails(0)) = "Not Available" Then
            ClientDetails(0) = "Not Available"
        End If

        If Trim(ClientDetails(1)) = "Not Available" Then
            ClientDetails(1) = "Not Available"
        End If

        Return ClientDetails

    End Function

    Shared Function GetImporterDetails(CFPROID As String, ImporterID As String) As String()

        Dim sqlstr As String =
            "Select Importer,Telephone,ID " &
            "From Importers " &
            "Where  CFPROID= '" & CFPROID & "' " &
            "And  ImporterID= '" & ImporterID & "'"


        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)




        Dim ImporterDetails(1) As String

        If tmptable.Rows.Count > 0 Then
            Call clsData.NullChecker(tmptable, 0)
            Dim drow As DataRow = tmptable.Rows(0)


            Dim sqlstr1 As String =
            "Select Telephone  " &
            "From TelephoneNos " &
            "Where  CFPROID= '" & CFPROID & "' " &
            "And OwnerType = 'importer' " &
            "And  OwnerID = '" & drow("ID") & "'"


            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            ImporterDetails(0) = Trim(drow("Telephone"))
            ImporterDetails(1) = Trim(drow("Importer"))

            ImporterDetails(0) = Trim(ImporterDetails(0).Replace(" ", ""))

            If ImporterDetails(0).StartsWith("0") Then
                ImporterDetails(0) = "+254" & Mid(ImporterDetails(0), 2, ImporterDetails(0).Length)
            End If

            Dim a As Integer
            Dim ImporterPhones(0) As String
            For Each drow1 In tmptable1.Rows
                Call clsData.NullChecker(tmptable1, a)
                ReDim Preserve ImporterPhones(a)

                ImporterPhones(a) = drow1("Telephone")

                ImporterPhones(a) = Trim(ImporterPhones(a).Replace(" ", ""))
                If ImporterPhones(a).StartsWith("0") Then
                    ImporterPhones(a) = "+254" & Mid(ImporterPhones(a), 2, ImporterPhones(a).Length)
                End If

                a = a + 1

            Next

            If Not IsNothing(ImporterPhones(0)) Then
                ImporterDetails(0) = ImporterDetails(0) & ", " & Join(ImporterPhones, ", ")
            End If

            If ImporterDetails(1).Length > 25 Then
                ImporterDetails(1) = Trim(Mid(ImporterDetails(1), 1, 25))
            End If
        End If

        If Trim(ImporterDetails(0)) = "Not Available" Then
            ImporterDetails(0) = "Not Available"
        End If

        If Trim(ImporterDetails(1)) = "Not Available" Then
            ImporterDetails(1) = "Not Available"
        End If


        Return ImporterDetails

    End Function

    Shared Function TinyShortURL(ByVal url As String, ErrMsg As String) As String
        Dim tinyUrl As String = url
        Try
            Dim address As System.Uri = New System.Uri("http://tinyurl.com/api-create.php?url=" & url)
            Dim client As System.Net.WebClient = New System.Net.WebClient()
            tinyUrl = client.DownloadString(address)


        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try
        Return tinyUrl
    End Function

    Shared Function GoogleShortURL(ByVal url As String, ErrMsg As String)

        Dim shortUrl As String = url
        Try
            Dim mykey As String = "AIzaSyBZ1U4niVzpE7wcSvP1N0LjaJGFHkPhdbs"
            Dim httpWebRequest = CType(WebRequest.Create("https://www.googleapis.com/urlshortener/v1/url?key=" & mykey), HttpWebRequest)
            httpWebRequest.ContentType = "application/json"
            httpWebRequest.Method = "POST"

            Using streamWriter = New StreamWriter(httpWebRequest.GetRequestStream())
                Dim json As String = "{""longUrl"":""" & url & """}"
                streamWriter.Write(json)
            End Using

            Dim httpResponse = CType(httpWebRequest.GetResponse(), HttpWebResponse)

            Using streamReader = New StreamReader(httpResponse.GetResponseStream())
                Dim responseText = streamReader.ReadToEnd()
                shortUrl = Regex.Match(responseText, """id"": ?""(?<id>.+)""").Groups("id").Value
            End Using

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

        Return shortUrl
    End Function



    Shared Sub Track(CFPROID As String, SearchStr As String, ByRef RadioButtonList1 As RadioButtonList, UserType As String, ByRef LabelMessage As Label)
        LabelMessage.ForeColor = Color.Black

        SearchStr = (Trim(SearchStr))
        Dim SearchField As String = ""
        Dim sqlstr As String =
                           "Select  Jobs.JobID From Jobs "

        Dim tmpstr As String = ""


        Select Case RadioButtonList1.SelectedIndex

            Case 0
                SearchField = "Container No."
                tmpstr = ",JobCargo " &
                                 "Where ContainerNo = '" & SearchStr & "' " &
                                  "And JobCargo.CFPROID = Jobs.CFPROID " &
                                  "And JobCargo.JobID = Jobs.JobID "

            Case 1
                SearchField = "BL No."
                tmpstr = "Where BL Like '%" & SearchStr & "%' " &
                    "Or HouseBL Like '%" & SearchStr & "%' "

            Case 2
                SearchField = "Reference No."
                tmpstr = "Where ReferenceNo = '" & SearchStr & "' "

            Case 3

                SearchField = "Entry No."
                tmpstr = "Where EntryNo = '" & SearchStr & "' "

            Case 4
                SearchField = "IDF No."
                tmpstr = "Where IDFNo = '" & SearchStr & "' "

        End Select

        If clsSubs.CleanSql(SearchStr) Then
            sqlstr = sqlstr & tmpstr &
                "And Jobs.CFPROID = '" & clsEncr.DecryptString(CFPROID) & "' " &
                "Order by Jobs.ID DESC;"

            Dim tmptable As New DataTable("Search")
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then

                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable(0)

                Dim host As String = HttpContext.Current.Request.Url.Host

                If InStr(host, "localhost") > 0 Or clsAuth.IsIPAdress(host) Then
                    host = host & ":90"
                End If

                host = "http://" & host

                Dim isinternal As String = ""

                If Not IsNothing(HttpContext.Current.Request.QueryString("internal")) Then
                    If HttpContext.Current.Request.QueryString("internal") = "1" Then
                        isinternal = "&internal=1"
                    End If
                End If


                Dim SearchedItem As String = RadioButtonList1.SelectedIndex & "|" & SearchStr
                HttpContext.Current.Response.Cookies("SearchedItem").Value = SearchedItem
                HttpContext.Current.Response.Cookies("SearchedItem").Expires = Now.AddDays(30)

                HttpContext.Current.Response.Redirect(host & "/progressreport.aspx?loadedbyimporter=1&jobid=" & drow("JobID") &
                                   isinternal & "&usertype=" & UserType & "&cfproid=" & HttpUtility.UrlEncode(CFPROID) &
                                                      "&searcheditem=" & HttpUtility.UrlEncode(clsEncr.EncryptString(SearchedItem)))
            Else
                LabelMessage.Text = "No Consignment with " & SearchField & " '" & SearchStr & "' Found."
                LabelMessage.ForeColor = Color.Red
            End If
        Else
            LabelMessage.Text = "Invalid " & SearchField & " '" & SearchStr & "'"
            LabelMessage.ForeColor = Color.Red
        End If

    End Sub



    Shared Function GetDeclarant(ByVal prefixText As String, ByVal count As Integer, ByVal CFPROID As String) As List(Of String)

        Try

            Dim sqlstr As String =
                "SELECT  Distinct Top 4 Declarant " &
                "FROM Jobs " &
                "Where CFPROID = '" & CFPROID & "' " &
                "And Declarant Like + @SearchText + '%'  " &
                "Order by Declarant Asc;"

            Dim Conn As SqlConnection = New SqlConnection
            Dim Connection1 As New SqlConnection(clsData.constr)
            Dim Reader1 As SqlDataReader
            Dim Command1 As New SqlCommand(sqlstr, Connection1)
            Command1.Parameters.AddWithValue("@SearchText", prefixText)

            Connection1.Open()

            Reader1 = Command1.ExecuteReader
            Dim Declarant As List(Of String) = New List(Of String)

            While Reader1.Read
                If Not IsDBNull(Reader1("Declarant")) Then
                    Declarant.Add(AjaxControlToolkit.AutoCompleteExtender _
               .CreateAutoCompleteItem(Reader1("Declarant"), 0))
                End If
            End While

            Connection1.Close()

            Return Declarant

        Catch ex As Exception
            Return Nothing
        End Try

        Return Nothing


    End Function



End Class
