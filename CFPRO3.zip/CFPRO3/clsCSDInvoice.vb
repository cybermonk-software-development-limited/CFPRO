﻿'-------------------------------------------------------------------------------------|
'                                   IMPORTANT !!!                                    -|
'-------------------------------------------------------------------------------------|
'Invoice Class by Cybermonk Software Developent Limited                              -|
'InvoicePDF(InvoicePDFName As String, headerTmp As DataTable, detailTmp As DataTable,-|
'documentType As String)                                                             -|
'headerTmp Fields include:InvoiceHeader,ClientName,Address,Phone,City,Email,         -|
'InvoiceDate, InvoiceNo,PIN,VATNo,SubTotal,TotalTax,Total,Paid,AmountDue             -|
'detailTmp Fields include:Particulars,Quantity,Rate,Discount,Total                   -|
'-------------------------------------------------------------------------------------|



'-------------------------------------------------------------------------------------|
'Here we include asll the libraries we will require                                  -|
'-------------------------------------------------------------------------------------|
Imports System.IO

Imports iTextSharp.text
Imports iTextSharp.text.pdf

Public Class clsCSDInvoice

    Friend Shared sqlstrInvoice, sqlstrInvoice1

    Friend Shared BatchInvoices As Boolean
    Friend Shared DvInvoice, DvInvoice1 As DataView
    Private Shared Sub DrawLine(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, x2 As Single, y2 As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        x2 = x2 * 0.75
        y2 = y2 * 0.75
        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x2, 842 - y2)
        contentByte.Stroke()
    End Sub
    Private Shared Sub DrawRectangle(ByRef contentByte As PdfContentByte, x1 As Single, y1 As Single, width As Single, height As Single)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        width = width * 0.75
        height = height * 0.75
        contentByte.MoveTo(x1, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - y1)
        contentByte.LineTo(x1 + width, 842 - (y1 + height))
        contentByte.LineTo(x1, 842 - (y1 + height))
        'Path closed And stroked
        contentByte.ClosePathStroke()
    End Sub

    Private Shared Sub DrawString(ByVal nString As String, ByRef font As Font, color As Drawing.Color, x1 As Single, y1 As Single, ByRef contentByte As PdfContentByte)
        x1 = x1 * 0.75
        y1 = y1 * 0.75
        Dim fnt As Single = font.Size * 0.75
        contentByte.SetRGBColorFill(color.R, color.G, color.B)
        contentByte.BeginText()
        contentByte.SetFontAndSize(font.BaseFont, font.Size)
        contentByte.SetTextMatrix(x1, 842 - (y1 + fnt))
        contentByte.ShowText(nString)
        contentByte.EndText()
    End Sub

    Shared Function InvoicePDF(CFPROID As String, InvoicePDFName As String,
                               headerTmp As DataTable, detailTmp As DataTable, Optional ByRef ErrMsg As String = Nothing) As String

        '-------------------------------------------------------------------------------------|
        'Here we initialize the data items, fonts and other attributes we will use on our pdf-|
        '-------------------------------------------------------------------------------------|
        Try



            Dim fontpath As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arial.ttf"
            Dim fontpath1 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\arialbd.ttf"
            Dim fontpath2 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\cour.ttf"
            Dim fontpath3 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\ariali.ttf"
            Dim fontpath4 As String = HttpContext.Current.Server.MapPath(".") & "\docfonts\WINGDNG2.ttf"

            Dim customfont As BaseFont = BaseFont.CreateFont(fontpath, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontb As BaseFont = BaseFont.CreateFont(fontpath1, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontc As BaseFont = BaseFont.CreateFont(fontpath2, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfonti As BaseFont = BaseFont.CreateFont(fontpath3, BaseFont.CP1252, BaseFont.EMBEDDED)
            Dim customfontm As BaseFont = BaseFont.CreateFont(fontpath4, BaseFont.CP1252, BaseFont.EMBEDDED)


            Dim font6b As New Font(customfontb, 6)
            Dim font7b As New Font(customfontb, 7.4)

            Dim font7 As New Font(customfont, 7)

            Dim font8 As New Font(customfontb, 8)
            Dim font8i As New Font(customfonti, 8)
            Dim font8b As New Font(customfontb, 8)
            Dim font9 As New Font(customfont, 9)
            Dim font9b As New Font(customfontb, 9)
            Dim font11c As New Font(customfontc, 10.5)
            Dim font10b As New Font(customfontb, 10)
            Dim font22b As New Font(customfontb, 22)

            Dim drf As New Drawing.StringFormat()

            Dim brush1 As Drawing.Color = Drawing.Color.Black
            Dim brush2 As Drawing.Color = Drawing.Color.FromArgb(0, 0, 255)




            'Header and Footer Variables
            Dim invoiceHeader, addresseeName, address, phone, city, email, addressee(), invoiceDate, invoiceNo, PIN, VATNo As String
            Dim subTotal, totalTax, total, paid, amountDue, amountInWords As String

            If headerTmp.Rows.Count > 0 Then
                clsData.NullChecker(headerTmp, 0)
                Dim drow As DataRow = headerTmp.Rows(0)
                invoiceHeader = drow("InvoiceHeader")
                addresseeName = drow("ClientName")
                address = drow("Address")
                phone = drow("Phone")
                city = drow("City")
                email = drow("Email")
                invoiceDate = drow("InvoiceDate")
                invoiceNo = drow("InvoiceNo")
                PIN = drow("PIN")
                VATNo = drow("VATNo")
                subTotal = drow("SubTotal")
                totalTax = drow("TotalTax")
                total = drow("Total")
                paid = drow("Paid")
                amountDue = drow("AmountDue")
            Else
                invoiceHeader = ""
                addresseeName = ""
                address = ""
                phone = ""
                city = ""
                email = ""
                invoiceDate = ""
                invoiceNo = ""
                PIN = ""
                VATNo = ""
                subTotal = ""
                totalTax = ""
                total = ""
                paid = ""
                amountDue = ""
            End If
            addressee = {addresseeName, address, phone, city, email}
            amountInWords = clsSubs.AmountInWords(amountDue)

            'Document starts here

            Dim doclogospath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp"
            Dim docfooterpath As String = HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp"
            Dim InvoicePDFDoc As New Document(PageSize.A4, 0, 0, 0, 10)

            Using memoryStream As New System.IO.MemoryStream()
                Dim PDFwriter As PdfWriter = PDFwriter.GetInstance(InvoicePDFDoc, memoryStream)

                Dim logo As Image = Image.GetInstance(doclogospath)
                Dim footer As Image = Image.GetInstance(docfooterpath)
                InvoicePDFDoc.Open()



                'Create line pens
                Dim pen As PdfContentByte = PDFwriter.DirectContent
                Dim pen1 As PdfContentByte = PDFwriter.DirectContent
                Dim pen2 As PdfContentByte = PDFwriter.DirectContent
                Dim pen3 As PdfContentByte = PDFwriter.DirectContent

                pen.SetRGBColorStroke(195, 195, 195)
                pen1.SetRGBColorStroke(195, 195, 195)
                pen2.SetRGBColorStroke(0, 0, 0)
                pen3.SetRGBColorStroke(0, 0, 0)

                pen.SetLineWidth(0)
                pen1.SetLineWidth(0.5F)
                pen2.SetLineWidth(0.5F)

                Dim StringWriter As PdfContentByte = PDFwriter.DirectContent

                DvInvoice1 = New DataView(detailTmp)

                If File.Exists(HttpContext.Current.Server.MapPath(".") & "\doclogos\cfprologo.bmp") Then
                    logo.ScaleToFit(695, 60)
                    logo.SetAbsolutePosition(0, 780)
                    InvoicePDFDoc.Add(logo)
                Else
                    DrawString("CYBERMONK SOFTWARE DEVELOPMENT LIMITED", font22b, brush1, 50, 50, StringWriter)
                End If


                DrawString(invoiceHeader, font22b, brush1, 50, 145, StringWriter)
                'Client 
                DrawString("TO:", font8, brush1, 55, 185, StringWriter)
                Dim addressYPos As Single = 200
                For a As Integer = 0 To addressee.Count - 1 Step 1
                    If addressee(a) = "" Then
                        Continue For
                    End If
                    DrawString(addressee(a), font9b, brush1, 55, addressYPos, StringWriter)
                    addressYPos += 16
                Next
                'End Client

                'Header Details
                DrawString("Date:", font9, brush1, 355, 205, StringWriter)
                DrawString(invoiceDate, font9b, brush1, 485, 205, StringWriter)
                DrawString("Invoice No.:", font9, brush1, 355, 225, StringWriter)
                DrawString(invoiceNo, font9b, brush1, 485, 225, StringWriter)
                DrawString("PIN:", font9, brush1, 355, 245, StringWriter)
                DrawString(PIN, font9b, brush1, 485, 245, StringWriter)
                DrawString("VAT No:", font9, brush1, 355, 265, StringWriter)
                DrawString(VATNo, font9b, brush1, 485, 265, StringWriter)

                'End header details

                'Invoice Particulars
                DrawLine(StringWriter, 50, 323, 700, 323)
                DrawString("Item", font9b, brush1, 55, 328, StringWriter)
                DrawString("Description", font9b, brush1, 105, 328, StringWriter)
                DrawString("Qty", font9b, brush1, 380, 328, StringWriter)
                DrawString("Rate", font9b, brush1, 480, 328, StringWriter)
                DrawString("Disc", font9b, brush1, 540, 328, StringWriter)
                DrawString("Total (KSh)", font9b, brush1, 620, 328, StringWriter)

                DrawLine(StringWriter, 50, 343, 700, 343)

                Dim y1 As Single = 348

                If detailTmp.Rows.Count > 0 Then
                    For cnt As Integer = 0 To detailTmp.Rows.Count - 1 Step 1
                        Call clsData.NullChecker(detailTmp, cnt)
                        Dim drow As DataRow = detailTmp.Rows(cnt)
                        DrawString(cnt + 1 & ".", font9, brush1, 60, y1, StringWriter)
                        DrawString(drow("Particulars"), font9, brush1, 105, y1, StringWriter)
                        DrawString(drow("Quantity"), font9, brush1, 380, y1, StringWriter)
                        DrawString(drow("Rate"), font9, brush1, 480, y1, StringWriter)
                        DrawString(drow("Discount"), font9, brush1, 540, y1, StringWriter)
                        DrawString(drow("Total"), font9, brush1, 620, y1, StringWriter)
                        y1 += 20
                    Next
                Else
                    DrawString("0.", font9, brush1, 60, y1, StringWriter)
                    DrawString("No Items found", font9, brush1, 105, y1, StringWriter)
                End If

                'End Invoice Particulars

                'Footer Details
                Dim sixLinesStart As Single = 868
                For a As Integer = 0 To 5
                    DrawLine(StringWriter, 50, sixLinesStart + a * 20, 700, sixLinesStart + a * 20)
                Next

                DrawString("SUB TOTAL:", font9b, brush1, 480, 871, StringWriter)
                DrawString(subTotal, font9b, brush1, 620, 871, StringWriter)
                DrawString("TOTAL TAX:", font9b, brush1, 480, 891, StringWriter)
                DrawString(totalTax, font9b, brush1, 620, 891, StringWriter)
                DrawString("TOTAL:", font9b, brush1, 480, 911, StringWriter)
                DrawString(total, font9b, brush1, 620, 911, StringWriter)
                DrawString("Less Paid:", font9, brush1, 480, 931, StringWriter)
                DrawString(paid, font9b, brush1, 620, 931, StringWriter)
                DrawString("AMOUNT DUE:", font9b, brush1, 480, 951, StringWriter)
                DrawString(amountDue, font9b, brush1, 620, 951, StringWriter)
                DrawString("Amount in Words:", font9, brush1, 100, 971, StringWriter)
                DrawString(amountInWords, font9b, brush1, 100, 986, StringWriter)

                DrawString("Customer Signature:", font9, brush1, 100, 1051, StringWriter)
                DrawString("Name of Signatory:", font9, brush1, 400, 1051, StringWriter)
                'End Footer Details

                If File.Exists(HttpContext.Current.Server.MapPath(".") & "\doclogos\footer.bmp") Then
                    footer.ScaleToFit(695, 40)
                    footer.SetAbsolutePosition(0, 0)
                    InvoicePDFDoc.Add(footer)
                End If

                InvoicePDFDoc.Close()
                Dim bytes As Byte() = memoryStream.ToArray()


                Dim InvoicePath As String = HttpContext.Current.Server.MapPath(".") & "\invoices"

                If Not Directory.Exists(InvoicePath) Then
                    Directory.CreateDirectory(InvoicePath)
                End If

                If Not Directory.Exists(InvoicePath & "\" & CFPROID) Then
                    Directory.CreateDirectory(InvoicePath & "\" & CFPROID)
                End If


                Dim nInvoicePDF As String = InvoicePath & "\" & CFPROID & "\" & InvoicePDFName & ".pdf"


                If File.Exists(nInvoicePDF) Then
                    File.Delete(nInvoicePDF)
                End If


                ' Write out PDF from memory stream. 
                Using fs As FileStream = File.Create(nInvoicePDF)
                    fs.Write(bytes, 0, CInt(bytes.Length))
                End Using


                memoryStream.Close()
                Return "~/invoices/" & CFPROID & "/" & InvoicePDFName & ".pdf"

            End Using

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Function

End Class
