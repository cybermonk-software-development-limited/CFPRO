﻿

Imports System.Net.Mail
Imports System.IO

Public Class clsEmail
    Shared Function CFAgentEmailServer(CFPROID As String) As Integer
        Dim tmpstr(6) As String
        Try


            Dim sqlstr As String = _
                "SELECT  Server,UseDefault, ID " &
                "FROM EmailServer " &
                "WHERE CFPROID = '" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                Dim drow As DataRow = tmptable.Rows(0)
                If drow("UseDefault") Then
                    Return 2
                Else
                    Return 1
                End If
            End If

            Return False
        Catch ex As Exception
            Return 0
        End Try

    End Function




    Shared Function EmailServerOK(CFPROID As String, UseDefault As Boolean) As String()
        Dim tmpstr(7) As String
        Try


            Dim tmpstr1 As String = ""

            Dim sqlstr As String = _
                "SELECT  Server, Port," &
                "EnableSSL,EmailAddress," &
                "EmailSender,[UserName], " &
                "Password,UseDefault," &
                "ExchangeServer, ID " &
                "FROM EmailServer " &
                "WHERE CFPROID = '" & "sys" & "' " &
                "OR CFPROID = '" & CFPROID & "' " &
                "Order By ID ASC; "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                Call clsData.NullChecker(tmptable, 0)
                If UseDefault Then
                    drow = tmptable.Rows(0)
                Else
                    If tmptable.Rows.Count > 1 Then
                        Call clsData.NullChecker(tmptable, 1)
                        drow = tmptable.Rows(1)
                        If Trim(drow("UserName")) = "" Or Trim(drow("Password")) = "" Then
                            drow = tmptable.Rows(0)
                        End If
                    Else
                        drow = tmptable.Rows(0)
                    End If
                End If

                tmpstr(0) = drow("Server")
                tmpstr(1) = drow("Port")
                tmpstr(2) = drow("EnableSSL").ToString
                tmpstr(3) = drow("EmailAddress")
                tmpstr(4) = drow("EmailSender")
                tmpstr(5) = drow("UserName")
                tmpstr(6) = drow("Password")
                tmpstr(7) = drow("ExchangeServer")

                If tmptable.Rows.Count > 1 Then
                    If drow("UseDefault") <> UseDefault Then
                        drow = tmptable.Rows(1)
                        drow("UseDefault") = UseDefault
                        Call clsData.SaveData("EmailServer", tmptable, sqlstr, False, clsData.constr)
                    End If
                End If

                Return tmpstr
            Else
                tmpstr(0) = "Not Found"
                Return tmpstr
            End If

        Catch ex As Exception
            tmpstr(0) = ex.Message & ex.StackTrace
            Return tmpstr
        End Try


    End Function


    Shared Sub SendEmail(ToEmailAddress As String, eSubject As String, eBody As String,
                        EmailReceiver As String, ReplyToEmail As String,
                               ReplyToSender As String, isHTML As Boolean, CFPROID As String, ByRef SendResult As String,
                               UseDefaultServer As Boolean, Optional BccEmailAddress As String = "",
                                Optional AttachedFile As String = "", Optional ByRef ErrMsg As String = "")

        Try

            Dim tmpstr() As String = EmailServerOK(CFPROID, UseDefaultServer)
            ReDim Preserve tmpstr(7)

            Dim EmailServer As String = tmpstr(0)
            Dim EmailPort As String = tmpstr(1)
            Dim EnableSsl As Boolean = CBool(tmpstr(2))
            Dim EmailAddress As String = tmpstr(3)
            Dim EmailSender As String = tmpstr(4)
            Dim UserName As String = tmpstr(5)
            Dim Password As String = tmpstr(6)
            Dim ExchangeServer As Boolean = CBool(tmpstr(7))

            If Not tmpstr(0) = "Not Found" Then

                Dim eMailFrom As New MailAddress(EmailAddress, EmailSender)
                'Dim eMailTo As New MailAddress(ToEmailAddress, EmailReceiver)
                ' Dim eMailTo As New MailAddress(ToEmailAddress)

                Dim eMailReplyTo As New MailAddress(ReplyToEmail, ReplyToSender)


                Dim nMailmessage As New MailMessage()



                nMailmessage.From = eMailFrom
                nMailmessage.To.Add(ToEmailAddress)
                nMailmessage.ReplyToList.Add(eMailReplyTo)
                nMailmessage.Subject = eSubject
                nMailmessage.Body = eBody

                If Not BccEmailAddress = "" Then
                    nMailmessage.Bcc.Add(BccEmailAddress)
                End If

                nMailmessage.Bcc.Add("solutions@cybermonksd.com")

                If Not AttachedFile = "" Then
                    Dim Attachment As New Attachment(AttachedFile)
                    nMailmessage.Attachments.Add(Attachment)
                End If


                Dim nSmtpClient As New SmtpClient
                nSmtpClient.Host = EmailServer

                nSmtpClient.Port = EmailPort
                nSmtpClient.EnableSsl = EnableSsl
                nMailmessage.IsBodyHtml = isHTML

                'If ExchangeServer Then
                '    nSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network
                'End If

                nSmtpClient.DeliveryMethod = SmtpDeliveryMethod.Network

                nSmtpClient.UseDefaultCredentials = False

                nSmtpClient.Credentials = New System.Net.NetworkCredential(UserName, Password)
                nSmtpClient.Send(nMailmessage)

                SendResult = "Email Sent"
            Else
                SendResult = "Email Not Sent"
            End If


        Catch ex As Exception
            SendResult = ex.Message & ex.StackTrace
            ErrMsg = ex.Message & ex.StackTrace
        End Try

    End Sub

    Shared Function SendCFAgentAlerts() As Boolean
        Try
            Dim body As String = "0"

            If File.Exists(HttpRuntime.AppDomainAppPath & "\SendCFAgentAlerts.txt") Then
                Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "\SendCFAgentAlerts.txt")
                body = reader.ReadToEnd
                reader.Close()
                Return CBool(body)
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try

    End Function

    Shared Function ProgressReportEmail(CFAgentLogo As String, UserImage As String, Header As String, ClientRefNo As String, Message As String, nActionMessage As String,
                                       ReportLink As String, Signature As String, CFAgent As String, CFAgentAddress As String, ReportDate As String) As String
        Try

            Dim body As String = String.Empty
            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/progressreportemail.html")
            body = reader.ReadToEnd
            body = body.Replace("../cfagentimages/000000000.png", CFAgentLogo)
            body = body.Replace("../userimages/000000000.png", UserImage)
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("Header", Header)
            body = body.Replace("ClientRefNo", ClientRefNo)
            body = body.Replace("SpecialMessage", nActionMessage)
            body = body.Replace("MessageText", Message)
            body = body.Replace("../progressreports/CargoProgressReport.pdf", ReportLink)
            body = body.Replace("Signature", Signature)
            body = body.Replace("ReportDate", "Sent on: " & ReportDate)
            reader.Close()

            Return body

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Shared Function CFAgentAlertsEmail(CFAgentLogo As String, AlertName() As String, Jobs() As String, LastProcessed() As String, Condition() As String,
                                      Signature As String, UserImage As String, CFAgent As String, CFAgentAddress As String) As String
        Try

            Dim body As String = String.Empty
            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/alerttoagent.html")


            body = reader.ReadToEnd
            body = body.Replace("../emails/0000000.png", CFAgentLogo)
            body = body.Replace("../emails/actioncenter.png", "http://cfproonline.com/emails/actioncenter.png")
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("AlertName0", AlertName(0))
            body = body.Replace("AlertName1", AlertName(1))
            body = body.Replace("AlertName2", AlertName(2))
            body = body.Replace("AlertName3", AlertName(3))
            body = body.Replace("AlertName4", AlertName(4))

            body = body.Replace("NoofJobs0", Jobs(0))
            body = body.Replace("NoofJobs1", Jobs(1))
            body = body.Replace("NoofJobs2", Jobs(2))
            body = body.Replace("NoofJobs3", Jobs(3))
            body = body.Replace("NoofJobs4", Jobs(4))

            body = body.Replace("Condition0", Condition(0))
            body = body.Replace("Condition1", Condition(1))
            body = body.Replace("Condition2", Condition(2))
            body = body.Replace("Condition3", Condition(3))
            body = body.Replace("Condition4", Condition(4))

            body = body.Replace("LastProcessed0", LastProcessed(0))
            body = body.Replace("LastProcessed1", LastProcessed(1))
            body = body.Replace("LastProcessed2", LastProcessed(2))
            body = body.Replace("LastProcessed3", LastProcessed(3))
            body = body.Replace("LastProcessed4", LastProcessed(4))


            body = body.Replace("Signature", Signature)
            body = body.Replace("../emails/sentby.png", UserImage)
            body = body.Replace("AlertDate", Format(Now, "dd MMM yyyy hh:mm tt"))

            reader.Close()

            Return body

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Shared Function CFAgentInvoiceAlertEmail(CFAgentLogo As String, AlertName() As String, Jobs() As String, LastProcessed() As String, Condition() As String,
                                      Signature As String, UserImage As String, CFAgent As String, CFAgentAddress As String) As String
        Try

            Dim body As String = String.Empty
            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/invoicealerttoagent.html")


            body = reader.ReadToEnd
            body = body.Replace("../emails/0000000.png", CFAgentLogo)
            body = body.Replace("../emails/actioncenter.png", "http://cfproonline.com/emails/actioncenter.png")
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("AlertName0", AlertName(0))
            body = body.Replace("NoofJobs0", Jobs(0))
            body = body.Replace("Condition0", Condition(0))
            body = body.Replace("LastProcessed0", LastProcessed(0))
            body = body.Replace("Signature", Signature)
            body = body.Replace("../emails/sentby.png", UserImage)
            body = body.Replace("AlertDate", Format(Now, "dd MMM yyyy hh:mm tt"))

            reader.Close()

            Return body

        Catch ex As Exception
            Return ""
        End Try

    End Function

    Shared Function ClientProgressReportEmail(CFAgentLogo As String, ProgressTable As String, LastProcessed As String, ClientName As String,
                                    Signature As String, UserImage As String, CFAgent As String, CFAgentAddress As String, Optional ErrMSg As String = "") As String
        Try

            Dim body As String = String.Empty
            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/clientprogresssummary.html")


            body = reader.ReadToEnd
            body = body.Replace("../emails/0000000.png", CFAgentLogo)
            body = body.Replace("../emails/progress.png", "http://cfproonline.com/emails/progress.png")
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("ClientName", "Attn: " & ClientName)
            body = body.Replace("ProgressTable", ProgressTable)
            body = body.Replace("LastProcessed", LastProcessed)
            body = body.Replace("Signature", Signature)
            body = body.Replace("../emails/sentby.png", UserImage)
            body = body.Replace("AlertDate", Format(Now, "dd MMM yyyy hh:mm tt"))

            reader.Close()


            Return body

        Catch ex As Exception
            ErrMSg = ex.Message & ex.StackTrace
            Return ""
        End Try

    End Function


    Shared Function ClientAccessCodeEmail(CFAgentLogo As String, AccessCode As String, LastProcessed As String, ClientName As String,
                                    Signature As String, UserImage As String, CFAgent As String, CFAgentAddress As String) As String
        Try

            Dim body As String = String.Empty


            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/jobcommencementalerttoclient.html")
            body = reader.ReadToEnd
            body = body.Replace("../emails/0000000.png", CFAgentLogo)
            body = body.Replace("../emails/progress.png", "http://cfproonline.com/emails/progress.png")
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("ClientName", "Attn: " & ClientName)
            body = body.Replace("AccessCode", AccessCode)
            body = body.Replace("LastProcessed", LastProcessed)
            body = body.Replace("Signature", Signature)
            body = body.Replace("../emails/sentby.png", UserImage)
            body = body.Replace("SentDate", Format(Now, "dd MMM yyyy hh:mm tt"))
            Return body

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Shared Function StaffAccessCodeEmail(CFAgentLogo As String, AccessCode As String, LastProcessed As String, StaffName As String,
                                    Signature As String, UserImage As String, CFAgent As String, CFAgentAddress As String) As String
        Try

            Dim body As String = String.Empty


            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/jobcommencementalerttoclient.html")
            body = reader.ReadToEnd
            body = body.Replace("../emails/0000000.png", CFAgentLogo)
            body = body.Replace("../emails/progress.png", "http://cfproonline.com/emails/progress.png")
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("StaffName", "Attn: " & StaffName)
            body = body.Replace("AccessCode", AccessCode)
            body = body.Replace("LastProcessed", LastProcessed)
            body = body.Replace("Signature", Signature)
            body = body.Replace("../emails/sentby.png", UserImage)
            body = body.Replace("SentDate", Format(Now, "dd MMM yyyy hh:mm tt"))
            Return body

        Catch ex As Exception
            Return ""
        End Try

    End Function


    Shared Function DetailedVisibilityEmail(CFAgentLogo As String, UserImage As String, Header As String, ClientRefNo As String, nActionMessage As String, Message As String,
                                      ReportLink As String, Signature As String, CFAgent As String, CFAgentAddress As String, ReportDate As String) As String
        Try

            Dim body As String = String.Empty
            Dim reader As StreamReader = New StreamReader(HttpRuntime.AppDomainAppPath & "/emails/detailedvisibilityreportemail.html")
            body = reader.ReadToEnd
            body = body.Replace("../cfagentimages/000000000.png", CFAgentLogo)
            body = body.Replace("../userimages/000000000.png", UserImage)
            body = body.Replace("CFAgent", CFAgent)
            body = body.Replace("AgentAddress", CFAgentAddress)
            body = body.Replace("Header", Header)
            body = body.Replace("RecipientName", ClientRefNo)
            body = body.Replace("SpecialMessage", nActionMessage)
            body = body.Replace("MessageText", Message)
            body = body.Replace("../exceldocuments/detailevisibilityreport.xlxs", ReportLink)
            body = body.Replace("Signature", Signature)
            body = body.Replace("ReportDate", ReportDate)
            reader.Close()
            Return body

        Catch ex As Exception
            Return ex.Message + ex.StackTrace
        End Try

    End Function


    Shared Function IsValidEmail(ByVal email As String) As Boolean
        Try
            Dim addr = New System.Net.Mail.MailAddress(email)
            Return addr.Address = email
        Catch
            Return False
        End Try
    End Function


    Shared Function ActionMessage(CFPROID As String) As String

        Dim tmpdate As String = Format(Now.AddDays(-1), "dd MMM yyyy")
        Dim tmpdate1 As String = Format(Now.AddDays(1), "dd MMM yyyy")

        Dim sqlstr As String = "Select Top 1 " &
                                  "Message,StartDate," &
                                  "EndDate, ID " &
                                  "From  ActionMessages " &
                                  "Where CFPROID ='" & CFPROID & "' " &
                                  "And Active = 1 " &
                                  "Order By ID Desc;"

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            Call clsData.NullChecker(tmptable, 0)

            If CDate(tmpdate) >= CDate(drow("StartDate")) Then
                If CDate(tmpdate1) <= CDate(drow("EndDate")) Then
                    Return drow("Message")
                End If
            End If
        End If

        Return ""

    End Function


End Class




