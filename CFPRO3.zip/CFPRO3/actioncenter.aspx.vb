﻿Imports System.Drawing
Public Class actioncenter
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin(LabelCSDID.Text, CFPROID, LabelCFPROUserID.Text, LabelUserNames.Text, LabelCFAgent.Text, LinkSignIn.Text, Image2.ImageUrl, Image1.ImageUrl, True, "", True, , , , LabelAlertCount.Text, LabelMessageCount.Text)
            LabelCFPROID.Text = CFPROID


            Dim host As String = HttpContext.Current.Request.Url.ToString

            If host.Contains("localhost") Or host.Contains("172.16.254") Or host.Contains("154") Or host.Contains("197") Then
                ButtonEmailActionAlerts.Visible = True
                ComboAlertType1.Visible = True

            ElseIf LabelUserNames.Text.Contains("Michael Mulela") Then
                ButtonEmailActionAlerts.Visible = True
                ComboAlertType1.Visible = True

            Else
                ButtonEmailActionAlerts.Visible = False
                ComboAlertType1.Visible = False
            End If




            Call LoadActionCenter(CFPROID, "")

            HyperLinkStart1.NavigateUrl = "importerdashboard.aspx"

            If Session("UserType") = "importer" Then
                PanelTopMenu.Visible = False
                PanelImporterMenu.Visible = True
            Else
                PanelTopMenu.Visible = True
                PanelImporterMenu.Visible = False
            End If

            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"

        End If
    End Sub

    Private Sub LoadActionCenter(CFPROID As String, AlertID As String)
        Try

            Dim SearchStr As String = Trim(TextSearchAlerts.Text)
            Dim tmpstr As String = ""


            If Not SearchStr = "" Then
                If AlertID = "" Then
                    tmpstr = "Where AlertName Like '%" & SearchStr & "%' "
                Else
                    tmpstr = "Where Alerts.AlertID = '" & AlertID & "' "
                End If
            Else
                If Not AlertID = "" Then
                    tmpstr = "Where Alerts.AlertID = '" & AlertID & "' "
                End If
            End If

            Dim sqlstr As String =
                "SELECT  AlertID, AlertName, AlertType," &
                     "Condition,RequiredAction," &
                     "Criticality, ID " &
                     "FROM Alerts " &
                      tmpstr &
                     "Order By Criticality Asc, AlertID Asc ;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)



            Dim sqlstr1 As String =
                     "SELECT  AlertID," &
                      "JobCount, LastProcessed " &
                     "FROM AccountAlerts " &
                     "Where CFPROID = '" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim dv1 As New DataView(tmptable1)

            Dim col As New DataColumn("ItemCount", Type.GetType("System.String"))
            Dim col1 As New DataColumn("Item", Type.GetType("System.String"))
            Dim col2 As New DataColumn("JobCount", Type.GetType("System.Int32"))
            Dim col3 As New DataColumn("JobCount1", Type.GetType("System.String"))
            Dim col4 As New DataColumn("AlertIDAndName", Type.GetType("System.String"))
            Dim col5 As New DataColumn("BackColor", Type.GetType("System.String"))
            Dim col6 As New DataColumn("EnableJobs", Type.GetType("System.Boolean"))
            Dim col7 As New DataColumn("LastProcessed", Type.GetType("System.String"))
            Dim col8 As New DataColumn("ProcessText", Type.GetType("System.String"))
            Dim col9 As New DataColumn("ShowSendButton", Type.GetType("System.Boolean"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)
            tmptable.Columns.Add(col6)
            tmptable.Columns.Add(col7)
            tmptable.Columns.Add(col8)
            tmptable.Columns.Add(col9)

            Dim tmpstr2(4) As String

            tmpstr2(0) = "critical0"
            tmpstr2(1) = "critical1"
            tmpstr2(2) = "critical2"
            tmpstr2(3) = "critical3"
            tmpstr2(4) = "critical4"

            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                ' drow("ItemCount") = a + 1 & "."

                dv1.RowFilter = "AlertID ='" & drow("AlertID") & "' "
                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    If dv1(0)("JobCount") >= 0 Then
                        drow("JobCount") = dv1(0)("JobCount")
                        drow("JobCount1") = dv1(0)("JobCount") & " Jobs"
                        drow("EnableJobs") = True
                        drow("LastProcessed") = "Last Processed: " & Format(dv1(0)("LastProcessed"), "dd MMM yyyy hh mm tt")


                        If dv1(0)("alertID") = "0015" Then
                            drow("ShowSendButton") = True
                            drow("ProcessText") = "Process"

                        ElseIf dv1(0)("alertID") = "0019" Then
                            drow("ProcessText") = "Process & Send"
                            drow("JobCount1") = dv1(0)("JobCount") & " Reports"
                            drow("EnableJobs") = False

                        ElseIf dv1(0)("alertID") = "0020" Then
                            drow("ShowSendButton") = True
                            drow("JobCount1") = dv1(0)("JobCount") & " Reports"
                            drow("EnableJobs") = False
                            drow("ProcessText") = "Process"

                        Else
                            drow("ProcessText") = "Process"
                            drow("ShowSendButton") = False
                        End If
                    Else
                        drow("ProcessText") = "Process"
                        drow("JobCount") = dv1(0)("JobCount")
                        drow("EnableJobs") = False
                    End If

                Else
                    drow("EnableJobs") = False
                    drow("JobCount1") = drow("JobCount") & " Jobs"
                End If

                drow("AlertIDAndName") = drow("AlertID") & "|" & drow("AlertName")
                drow("BackColor") = tmpstr2(Val(drow("Criticality")) - 1)


                a = a + 1

            Next

            Dim dv As New DataView(tmptable)


            If SearchStr = "" Then
                If ComboAlertType.SelectedIndex = 0 Then
                    dv.RowFilter = "JobCount > 0 "

                    If dv.Count = 0 Then
                        dv.RowFilter = Nothing
                    End If

                ElseIf ComboAlertType.SelectedIndex = 1 Then

                    dv.RowFilter = Nothing
                Else
                    dv.RowFilter = "AlertType = " & ComboAlertType.SelectedIndex & " "
                End If

                tmpstr = " Action  Alerts (" & ComboAlertType.SelectedItem.Text & ")"
            Else
                tmpstr = " Action  Alerts found matching '" & SearchStr & "' "
            End If

            a = 0
            For a = 0 To dv.Count - 1
                Call clsData.NullChecker1(dv, a)
                dv(a)("ItemCount") = a + 1 & "."
            Next

            LabelActionCenterFilter.Text = dv.RowFilter
            LabelActionCenterSort.Text = dv.Sort
            Session("ActionCenterTable") = tmptable


            LabelActionCount.Text = dv.Count & tmpstr

            Dim FromDate As String = ""
            Dim ToDate As String = ""
            Call clsActionCenter.LastOneMonth(FromDate, ToDate)
            LabelPeriod.Text = "(" & Format(CDate(FromDate), "dd MMM yyyy") & "  -  " & Format(CDate(ToDate), "dd MMM yyyy") & ")"

            DataList1.DataSource = dv
            DataList1.DataBind()

            ' LabelMessage1.Text = ""

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub


    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUserNames.Text, Image2.ImageUrl, True)
    End Sub


    Protected Sub TextActionAlerts_TextChanged(sender As Object, e As EventArgs) Handles TextSearchAlerts.TextChanged
        Call LoadActionCenter(LabelCFPROID.Text, AlertIDField.Value)
    End Sub

    <System.Web.Script.Services.ScriptMethod(), _
System.Web.Services.WebMethod()> _
    Public Shared Function SearchAlerts(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return clsActionCenter.GetAlerts(prefixText, count)
    End Function

    <System.Web.Script.Services.ScriptMethod(), _
System.Web.Services.WebMethod()> _
    Public Shared Function SearchJobs(ByVal prefixText As String, ByVal count As Integer) As List(Of String)
        Return clsActionCenter.GetJobs(prefixText, count)
    End Function
    Protected Sub ButtonClearFilter_Click(sender As Object, e As EventArgs) Handles ButtonClearFilter.Click
        AlertIDField.Value = ""
        TextSearchAlerts.Text = ""
        Call LoadActionCenter(LabelCFPROID.Text, AlertIDField.Value)
    End Sub

    Protected Sub ButtonClearFilter0_Click(sender As Object, e As EventArgs) Handles ButtonSearchAlerts.Click
        AlertIDField.Value = ""
        Call LoadActionCenter(LabelCFPROID.Text, "")
    End Sub


    Protected Sub ComboAlertType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboAlertType.SelectedIndexChanged
        Call LoadActionCenter(LabelCFPROID.Text, "")
    End Sub

    Protected Sub ButtonProcessAlert_Click(sender As Object, e As EventArgs)

        Dim Button As Button = CType(sender, Button)
        Select Case Button.CommandArgument.ToString()
            Case "0001"
                Button.Text = clsActionCenter.ProcessProgressUpdateStatus(LabelCFPROID.Text)

            Case "0002"
                Button.Text = clsActionCenter.ProcessMissingShippingInformation(LabelCFPROID.Text)

            Case "0003"
                Button.Text = clsActionCenter.ProcessReceivedJobDocuments(LabelCFPROID.Text)

            Case "0008"
                Button.Text = clsActionCenter.ProcessStorageandDemurrage(LabelCFPROID.Text, LabelMessage1.Text)

            Case "0012"
                Button.Text = clsActionCenter.ProcessStorageandDemurrage(LabelCFPROID.Text, LabelMessage1.Text)


            Case "0015"
                Button.Text = clsActionCenter.ProcessCFAgentInvoices(LabelCFPROID.Text, LabelMessage1.Text)

            Case "0020"
                Button.Text = clsActionCenter.ProcessDetailedVisibilityReports(LabelCFPROID.Text, LabelMessage1.Text)

            Case "0019"
                Button.Text = clsActionCenter.ProcessClientProgressReportEmail(LabelCFPROID.Text, LabelMessage1.Text)

        End Select

        Call LoadActionCenter(LabelCFPROID.Text, "")
    End Sub


    Protected Sub ButtonSendReports_Click(sender As Object, e As EventArgs)
        Dim Button As Button = CType(sender, Button)
        Select Case Button.CommandArgument.ToString()

            Case "0015"
                Call clsActionCenter.ProcessCFAgentInvoices(LabelCFPROID.Text, LabelMessage1.Text)
                Button.Text = clsActionCenter.ProcessCFAgentInvoiceAlertEmails(LabelCFPROID.Text)

            Case "0020"
                Call clsActionCenter.ProcessDetailedVisibilityReports(LabelCFPROID.Text, LabelMessage1.Text)
                Button.Text = clsActionCenter.ProcessDetailedVisibilityEmails(LabelCFPROID.Text)

            Case "0019"
                Button.Text = clsActionCenter.ProcessClientProgressReportEmail(LabelCFPROID.Text, LabelMessage1.Text)

        End Select


    End Sub
    Protected Sub ButtonEmailActionAlerts_Click(sender As Object, e As EventArgs) Handles ButtonEmailActionAlerts.Click

        If ComboAlertType1.SelectedItem.Text = "Data Alerts" Then

            ButtonEmailActionAlerts.Text = clsActionCenter.ProcessCFAgentAlertSummaryEmails(LabelCFPROID.Text, LabelMessage1.Text)

        ElseIf ComboAlertType1.SelectedItem.Text = "Invoice Alerts" Then
            ButtonEmailActionAlerts.Text = clsActionCenter.ProcessCFAgentInvoiceAlertEmails(LabelCFPROID.Text, LabelMessage1.Text)

        ElseIf ComboAlertType1.SelectedItem.Text = "Detailed Visibility Reports" Then
            ' ButtonEmailActionAlerts.Text = clsActionCenter.ProcessDetailedVisibilityEmails(LabelCFPROID.Text, LabelMessage1.Text)
            LabelMessage2.Text = clsActionCenter.ProcessDetailedVisibilityEmails(LabelCFPROID.Text)

        ElseIf ComboAlertType1.SelectedItem.Text = "Progress Updates" Then
            ButtonEmailActionAlerts.Text = clsActionCenter.ProcessClientProgressReportEmail(LabelCFPROID.Text, LabelMessage1.Text)

        End If

    End Sub

    Protected Sub LinkAlertJobs_Click(sender As Object, e As EventArgs)
        Dim linkbutton As LinkButton = CType(sender, LinkButton)
        Dim tmpstr() As String = linkbutton.CommandArgument.Split("|")

        ReDim Preserve tmpstr(1)
        LabelAlertID.Text = tmpstr(0)
        LabelAlertName.Text = tmpstr(1)

        Session("AlertID") = tmpstr(0)


        Call LoadAlertedJobs(LabelCFPROID.Text, tmpstr(0), tmpstr(1), "")

        If ScreenHeight.Value > 768 And ScreenHeight.Value <= 900 Then
            ModalPopupExtender1.Y = 80
        ElseIf ScreenHeight.Value > 900 Then
            ModalPopupExtender1.Y = 140
        Else
            ModalPopupExtender1.Y = -1
        End If


    End Sub

    Private Sub LoadAlertedJobs(CFPROID As String, AlertID As String, AlertName As String, JobID As String)
        Try
            Dim ReferenceNo As String = Trim(TextSearchJob.Text)
            Dim tmpstr As String = ""

            If Not ReferenceNo = "" Then
                If JobID = "" Then
                    tmpstr = "And (ReferenceNo Like '%" & ReferenceNo & "%' " &
                        "Or ReferenceNo1 Like '%" & ReferenceNo & "%') "
                Else
                    tmpstr = "And AlertJobs.JobID = '" & JobID & "' "
                End If
            Else
                If Not JobID = "" Then
                    tmpstr = "Where AlertJobs.JobID = '" & JobID & "' "
                End If
            End If


            Dim sqlstr As String =
                              "SELECT  AlertID, Jobs.ClientID, " &
                              "ReferenceNo, ReferenceNo1, JobDate," &
                              "AlertReason, AlertJobs.JobID " &
                              "FROM  AlertJobs " &
                              "Left Join Jobs on AlertJobs.JobID = Jobs.JobID " &
                              "Where AlertJobs.CFPROID ='" & CFPROID & "' " &
                              "And Jobs.CFPROID ='" & CFPROID & "' " &
                              "And AlertID = '" & AlertID & "' " &
                              tmpstr &
                              "Order By JobDate Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim sqlstr1 As String =
                 "SELECT  Client, ClientID " &
                 "From Clients " &
                 "Where  CFPROID ='" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)

            Dim FromDate As String = ""
            Dim ToDate As String = ""
            Call clsActionCenter.LastOneMonth(FromDate, ToDate)
            Dim tmpstr2 = "And JobDate >= '" & FromDate & "' And JobDate <= '" & ToDate & "' "

            Dim sqlstr2 As String = _
                      "Select TOP 1 WITH TIES " &
                      "JobProgress.JobID, Date, Status " &
                      "From JobProgress,Jobs " &
                      "Where JobProgress.CFPROID = '" & CFPROID & "' " &
                      "And Jobs.CFPROID = '" & CFPROID & "' " &
                      "And JobProgress.JobID = Jobs.JobID " &
                      tmpstr2 &
                      "ORDER BY ROW_NUMBER() OVER(PARTITION BY JobProgress.JobID ORDER BY [Date] DESC)"


            Dim tmptable2 As New DataTable()
            Call clsData.TableData(sqlstr2, tmptable2, clsData.constr)
            Dim dv2 As New DataView(tmptable2)



            Dim col As New DataColumn("ItemCount", Type.GetType("System.String"))
            Dim col1 As New DataColumn("JobURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col3 As New DataColumn("ProgressUpdate", Type.GetType("System.String"))
            Dim col4 As New DataColumn("ShowReason", Type.GetType("System.Boolean"))
            Dim col5 As New DataColumn("StartDate", Type.GetType("System.String"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            tmptable.Columns.Add(col2)
            tmptable.Columns.Add(col3)
            tmptable.Columns.Add(col4)
            tmptable.Columns.Add(col5)

            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ItemCount") = a + 1 & "."
                drow("StartDate") = Format(drow("JobDate"), "dd MMM yyyy")

                dv1.RowFilter = "ClientID = '" & drow("ClientID") & "'"

                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    drow("Client") = dv1(0)("Client")
                End If

                dv2.RowFilter = "JobID = '" & drow("JobID") & "'"

                If dv2.Count > 0 Then
                    Call clsData.NullChecker1(dv2, 0)
                    drow("ProgressUpdate") = Format(dv2(0)("Date"), "dd MMM yyyy") & " - " & dv2(0)("Status")
                End If

                If drow("ReferenceNo") = "" Then
                    drow("ReferenceNo") = "No Reference"
                End If


                If drow("AlertReason") = "" Then
                    drow("ShowReason") = 0
                Else
                    drow("ShowReason") = 1
                End If

                If Not drow("ReferenceNo1") = "" Then
                    drow("ReferenceNo") = Trim(drow("ReferenceNo") & "  " & drow("ReferenceNo1"))
                End If


                drow("JobURL") = "jobentry.aspx?jobid=" & drow("JobID")
                a = a + 1
            Next


            If Not ReferenceNo = "" Then
                LabelAlertedJobsTitle.Text = tmptable.Rows.Count & " Jobs Found Matching '" & ReferenceNo & "' (" & AlertName & ")"
                LabelJobID.Text = JobID
            Else
                LabelAlertedJobsTitle.Text = tmptable.Rows.Count & " Jobs (" & AlertName & ")"
            End If

            Session("AlertedJobsTable") = tmptable

            DataList2.DataSource = tmptable
            DataList2.DataBind()

            ModalPopupExtender1.Show()


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try

    End Sub



    Protected Sub TextSearchJob_TextChanged(sender As Object, e As EventArgs) Handles TextSearchJob.TextChanged
        Call LoadAlertedJobs(LabelCFPROID.Text, LabelAlertID.Text, LabelAlertName.Text, JobIDField.Value)
        ModalPopupExtender1.Show()
    End Sub

    Protected Sub ButtonSearchJobs_Click(sender As Object, e As EventArgs) Handles ButtonSearchJobs.Click
        Call LoadAlertedJobs(LabelCFPROID.Text, LabelAlertID.Text, LabelAlertName.Text, "")

    End Sub

    Protected Sub ButtonExportAlertedJobstoExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportAlertedJobstoExcel.Click
        Call ExportAlertedJobsToExcel()

    End Sub


    Private Sub ExportActionCenterToExcel(Optional ByRef ErrMsg As String = Nothing)

        Try

            Dim tmpfields(5) As String

            tmpfields(0) = "ItemCount"
            tmpfields(1) = "AlertName"
            tmpfields(2) = "Condition"
            tmpfields(3) = "RequiredAction"
            tmpfields(4) = "JobCount1"
            tmpfields(5) = "LastProcessed"




            Dim tmpcols(5) As String
            tmpcols(0) = "Item"
            tmpcols(1) = "Alert"
            tmpcols(2) = "Condition"
            tmpcols(3) = "Required Action"
            tmpcols(4) = "No of Jobs"
            tmpcols(5) = "Last Processed"



            Dim tmptable As New DataTable("ActionCenterTable")
            tmptable = DirectCast(HttpContext.Current.Session("ActionCenterTable"), DataTable)


            Dim Filename As String = LabelCFAgent.Text & " Action Center "
            Dim ReportTitle As String = " Action Center"
            Dim ReportCaption As String = ComboAlertType.SelectedItem.Text & " " & LabelPeriod.Text

            Call clsExportToExcel.ExportToExcel(LabelCFPROID.Text, LabelActionCenterFilter.Text, LabelActionCenterSort.Text, Filename,
                                                ReportTitle, ReportCaption, False, Nothing, 0, "", tmpfields, tmpcols, tmptable, False)



        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try


    End Sub

    Private Sub ExportAlertedJobsToExcel(Optional ByRef ErrMsg As String = Nothing)

        Try


            Dim col As New DataColumn("ItemCount", Type.GetType("System.String"))
            Dim col1 As New DataColumn("JobURL", Type.GetType("System.String"))
            Dim col2 As New DataColumn("Client", Type.GetType("System.String"))
            Dim col3 As New DataColumn("ProgressUpdate", Type.GetType("System.String"))
            Dim col4 As New DataColumn("ShowReason", Type.GetType("System.Boolean"))
            Dim col5 As New DataColumn("StartDate", Type.GetType("System.String"))


            Dim tmpfields(5) As String

            tmpfields(0) = "ItemCount"
            tmpfields(1) = "ReferenceNo"
            tmpfields(2) = "Client"
            tmpfields(3) = "AlertReason"
            tmpfields(4) = "ProgressUpdate"
            tmpfields(5) = "ReferenceNo1"


            Dim tmpcols(5) As String
            tmpcols(0) = "Item"
            tmpcols(1) = "Reference No."
            tmpcols(2) = "Client"
            tmpcols(3) = "Alert Reason"
            tmpcols(4) = "Progress Update"
            tmpcols(5) = "Reference No1."

            Dim tmptable As New DataTable("AlertedJobsTable")
            tmptable = DirectCast(HttpContext.Current.Session("AlertedJobsTable"), DataTable)


            Dim Filename As String = LabelCFAgent.Text & " Action Center Alerts"
            Dim ReportTitle As String = " Action Center Alerts"
            Dim ReportCaption As String = LabelAlertedJobsTitle.Text & " " & LabelPeriod.Text

            Call clsExportToExcel.ExportToExcel(LabelCFPROID.Text, "", "", Filename,
                                                ReportTitle, ReportCaption, False, Nothing, 0, "", tmpfields, tmpcols, tmptable, False)

            ModalPopupExtender1.Show()

        Catch ex As Exception
            ErrMsg = ex.Message & ex.StackTrace
        End Try


    End Sub

    Protected Sub ButtonExportActionCentertoExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportActionCentertoExcel.Click
        Call ExportActionCenterToExcel()
    End Sub


    Private Sub LoadDialog(pageurl As String, pagetitle As String, ByVal height As Integer, ByVal width As Integer)
        PanelDialog.Attributes("style") = "height:" & height + 75 & "px;width:" & width + 5 & "px;"
        iframe1.Attributes("style") = "height:" & height & "px;width:" & width & "px; background-image: url('loading.gif'); background-repeat: no-repeat; background-attachment: inherit; background-position: center;"
        LabelDialogTitle.Text = pagetitle
        iframe1.Attributes("src") = pageurl

        ModalPopupExtender4.Show()
    End Sub

    Protected Sub ButtonActionMessage_Click(sender As Object, e As EventArgs) Handles ButtonActionMessage.Click
        Call LoadDialog("actionmessages.aspx", "Action Messages", 550, 820)
    End Sub


End Class