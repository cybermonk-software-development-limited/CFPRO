﻿Imports System.Drawing

Public Class goodsdescription
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
           
            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadGoodsDescriptions(CFPROID, "")

        End If

    End Sub

    Private Sub LoadGoodsDescriptions(ByVal CFPROID As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr = "And Description Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "SELECT Description, CFPROID, ID " &
                                    "From  GoodsDescriptions " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                       tmpstr &
                                    "Order By ID Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            GridGoodsDescriptions.DataSource = tmptable
            GridGoodsDescriptions.DataBind()


            If Not Trim(SearchStr) = "" Then
                LabelCaption.Text = tmptable.Rows.Count & "  Goods Descriptions Found matching '" & SearchStr & "'"
            Else
                LabelCaption.Text = tmptable.Rows.Count & "  Goods Descriptions"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridGoodsDescriptions_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridGoodsDescriptions.SelectedIndexChanged
        Dim row As GridViewRow = GridGoodsDescriptions.Rows(GridGoodsDescriptions.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridGoodsDescriptions.Rows.Count - 1
            row = GridGoodsDescriptions.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridGoodsDescriptions.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingGoodsDescriptions_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridGoodsDescriptions.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridGoodsDescriptions, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditGoodsDescriptions(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditGoodsDescriptions(CFPROID As String, Edit As Boolean)
        Try

            If Edit Then
                If GridGoodsDescriptions.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please SELECT Description."
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit Goods Description"
                Dim ID As Integer = GridGoodsDescriptions.SelectedValue
                Dim sqlstr As String = "SELECT Description,ID " &
                                        "From  GoodsDescriptions " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    TextAddEdit.Text = drow("Description")
                End If

            Else
                LabelAddEdit.Text = "Add  Goods Description"
                TextAddEdit.Text = ""

            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditGoodsDescriptions(LabelCFPROID.Text, False)
    End Sub

    Protected Sub ButtonSave_Click(sender As Object, e As EventArgs) Handles ButtonSave.Click

        Dim Edit As Boolean
        If InStr(LabelAddEdit.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveGoodsDescriptions(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveGoodsDescriptions(CFPROID As String, Edit As Boolean)

        Dim ID As Integer = -1

        If Not Edit Then
            If GoodsDescriptionsExists(CFPROID, TextAddEdit.Text) Then
                Exit Sub
            End If
        End If

        Try

            If Edit Then
                If GridGoodsDescriptions.SelectedIndex >= 0 Then
                    ID = GridGoodsDescriptions.SelectedValue
                End If
            End If


            Dim sqlstr As String = "SELECT Description, CFPROID, ID " &
                                    "From  GoodsDescriptions " &
                                    "Where CFPROID ='" & CFPROID & "' " &
                                    "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                tmptable.Rows.Add(drow)
            End If

            drow("Description") = Trim(UCase(TextAddEdit.Text))


            Call clsData.SaveData("GoodsDescriptions", tmptable, sqlstr, False, clsData.constr)

            Call LoadGoodsDescriptions(CFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Private Function GoodsDescriptionsExists(CFPROID As String, GoodsDescriptions As String) As Boolean


        Dim sqlstr As String = "SELECT Description " &
                                "From  GoodsDescriptions " &
                                "Where CFPROID ='" & CFPROID & "' " &
                                "And GoodsDescriptions = '" & Trim(GoodsDescriptions) & "' "

        Dim tmptable As New DataTable()
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Return True
        Else
            Return False
        End If


    End Function
    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridGoodsDescriptions.SelectedIndex >= 0 Then
            Call PromptDeleteGoodsDescriptions(GridGoodsDescriptions.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please SELECT Description to remove."
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteGoodsDescriptions(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridGoodsDescriptions.Rows(GridGoodsDescriptions.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " ?"
        ButtonDelete.Visible = True



        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteGoodsDescriptions(GridGoodsDescriptions.SelectedValue)
    End Sub
    Private Sub DeleteGoodsDescriptions(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From GoodsDescriptions  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("GoodsDescriptions", tmptable, sqlstr, True, clsData.constr)

            Call LoadGoodsDescriptions(LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub

    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadGoodsDescriptions(LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadGoodsDescriptions(LabelCFPROID.Text, "")
    End Sub



End Class