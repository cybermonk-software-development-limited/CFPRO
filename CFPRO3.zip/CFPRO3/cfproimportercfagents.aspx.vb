﻿Public Class cfproimportercfagents
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If clsData.constr = "" Then
                clsData.constr = clsEncr.constr
            End If

            Call clsSubs.CheckAndSetUser("", LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, True)

            Call LoadClientCFAgents()
        End If

    End Sub


    Private Sub LoadClientCFAgents()
        Dim sqlstr As String = _
            "Select CFAgentID, ClientID," & _
            "CFAgent,CFAgentAddress,ID " & _
            "FROM ClientCFAgents " & _
            "Where  ClientID = '" & "0000000" & "' "

        Dim tmptable As New DataTable
        Call clsData.TableData(sqlstr, tmptable, clsData.constr)

        Dim col As New DataColumn("ImporterDashBoard", Type.GetType("System.String"))
        Dim col1 As New DataColumn("ImageURL", Type.GetType("System.String"))

        tmptable.Columns.Add(col)
        tmptable.Columns.Add(col1)
        Dim a As Integer

        Dim importerdashboard As String = Request.QueryString("importerdashboard")

        Dim imageurl As String = ""
        For Each drow In tmptable.Rows
            clsSubs.NullChecker(tmptable, a)

            If IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentID") & ".jpg") Then
                imageurl = "~/cfagentimages/" & drow("CFAgentID") & ".jpg"
            ElseIf IO.File.Exists(Server.MapPath(".") & "\cfagentimages\" & drow("CFAgentID") & ".png") Then
                imageurl = "~/cfagentimages/" & drow("CFAgentID") & ".png"
            Else
                imageurl = "~/cfagentimages/0000000.png"
            End If

            drow("ImageURL") = imageurl

            If importerdashboard = "normal" Then
                drow("ImporterDashBoard") = "importerdashboard.aspx"
            Else
                drow("ImporterDashBoard") = "importerdashboard1.aspx"
            End If

            a = a + 1
        Next


        If tmptable.Rows.Count < 10 Then
            GridCFAgents.Height = 75 * tmptable.Rows.Count
        End If

        GridCFAgents.DataSource = tmptable
        GridCFAgents.DataBind()



    End Sub


    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        If LinkSignIn.Text = "Sign In" Then
            Response.Redirect("http://www.cybermonksd.com/usersignin.aspx?gotooption=index.aspx")
        Else
            Response.Cookies("CFPROToken").Value = ""
            Response.Cookies("CFPROToken").Expires = Now.AddDays(-1)
            LabelUser.Text = "Guest"
            LinkSignIn.Text = "Sign In"
            Image1.ImageUrl = "imageplaceholder.png"
            Response.Redirect("index.aspx")
        End If
    End Sub

    Protected Sub ButtonNew_Click(sender As Object, e As EventArgs) Handles ButtonNew.Click
        Call SaveClientCFAgent()
    End Sub

    Private Sub SaveClientCFAgent()

    End Sub

End Class