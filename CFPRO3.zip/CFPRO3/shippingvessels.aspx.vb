﻿Imports System.Drawing

Public Class shippingvessels
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                ButtonDownloadExcel.Visible = False
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)
            LabelCFPROID.Text = CFPROID

            Call LoadVessels(False, CFPROID, "")

        End If

    End Sub

    Private Sub LoadVessels(ByVal IncludeInActive As Boolean, ByVal CFPROID As String, SearchStr As String)

        Try

            Dim tmpstr As String = ""
            If Not IncludeInActive Then
                tmpstr = "And Active = " & 1 & " "
            End If


            Dim tmpstr1 As String = ""
            If Not Trim(SearchStr) = "" Then
                tmpstr1 = "And Vessel Like '%" & Trim(SearchStr) & "%' or VoyageNo Like '%" & Trim(SearchStr) & "%' "
            End If

            Dim sqlstr As String = "Select Top 200 " &
                              "VesselID,Vessel,VoyageNo," &
                              "ShippingLine,ETA," &
                              "BerthingDate,ExitDate," &
                              "Active,ID " &
                              "From  ShippingVessels " &
                              "Where CFPROID ='" & CFPROID & "' " &
                              tmpstr & tmpstr1 &
                              "Order By ETA Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)

                    If CDate(drow("ETA")) = CDate("1-Jan-1800") Then
                        drow("ETA") = DBNull.Value
                    End If

                    If CDate(drow("BerthingDate")) = CDate("1-Jan-1800") Then
                        drow("BerthingDate") = DBNull.Value
                    End If

                    If CDate(drow("ExitDate")) = CDate("1-Jan-1800") Then
                        drow("ExitDate") = DBNull.Value
                    End If

                    a = a + 1
                Next
            End If

            Session("VesselsTable") = tmptable
            GridShippingVessels.DataSource = tmptable
            GridShippingVessels.DataBind()



            If Not Trim(SearchStr) = "" Then
                LabelVesselsCaption.Text = tmptable.Rows.Count & " Vessels found matching  '" & TextSearch.Text & "' "
            Else
                LabelVesselsCaption.Text = tmptable.Rows.Count & " Vessels"
            End If


        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub

    Protected Sub GridShippingVessels_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridShippingVessels.SelectedIndexChanged
        Dim row As GridViewRow = GridShippingVessels.Rows(GridShippingVessels.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")


        For a As Integer = 0 To GridShippingVessels.Rows.Count - 1
            row = GridShippingVessels.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridShippingVessels.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next
    End Sub

    Protected Sub GridShippingVessels_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridShippingVessels.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridShippingVessels, "Select$" & e.Row.RowIndex)
        End If
    End Sub

    Protected Sub ButtonEditVessel_Click(sender As Object, e As EventArgs) Handles ButtonEditVessel.Click
        Call AddEditvessel(LabelCFPROID.Text, True)
    End Sub

    Private Sub AddEditvessel(CFPROID As String, edit As Boolean)
        Try



            If edit Then
                If GridShippingVessels.SelectedIndex < 0 Then
                    LabelMessage.Text = "Please Select a Vessel From the List"
                    Exit Sub
                End If

                LabelAddEditVessel.Text = "Edit Vessel"
                Dim ID As Integer = GridShippingVessels.SelectedValue
                Dim sqlstr As String = "SELECT VesselID,Vessel,VoyageNo," &
                                        "ShippingLine,ETA," &
                                        "BerthingDate,ExitDate," &
                                        "Active, ID " &
                                        "From  ShippingVessels " &
                                        "Where CFPROID ='" & CFPROID & "' " &
                                        "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)


                    TextVesselName.Text = drow("Vessel")
                    TextVoyageNo.Text = drow("VoyageNo")
                    TextVesselETA.Text = Format(drow("ETA"), "dd MMM yyyy")
                    TextBerthingDate.Text = Format(drow("BerthingDate"), "dd MMM yyyy")
                    TextExitDate.Text = Format(drow("ExitDate"), "dd MMM yyyy")
                    CheckActive.Checked = drow("Active")

                End If

            Else
                LabelAddEditVessel.Text = "Add Vessel"
                TextVesselName.Text = ""
                TextVoyageNo.Text = ""
                TextVesselETA.Text = ""
                TextBerthingDate.Text = ""
                TextExitDate.Text = ""
                CheckActive.Checked = True
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonAddVessel_Click(sender As Object, e As EventArgs) Handles ButtonAddVessel.Click
        Call AddEditvessel(LabelCFPROID.Text, False)
    End Sub

    Protected Sub CheckActiveVessels_CheckedChanged(sender As Object, e As EventArgs) Handles CheckActiveVessels.CheckedChanged
        Call LoadVessels(CheckActiveVessels.Checked, LabelCFPROID.Text, "")

    End Sub

    Protected Sub ButtonSaveVessel_Click(sender As Object, e As EventArgs) Handles ButtonSaveVessel.Click
        Dim Edit As Boolean
        If InStr(LabelAddEditVessel.Text, "Edit") > 0 Then
            Edit = True
        End If
        Call SaveVessel(LabelCFPROID.Text, Edit)
    End Sub

    Private Sub SaveVessel(CFPROID As String, Edit As String)

        Try
            Dim ID As Integer = -1

            If Edit Then
                If GridShippingVessels.SelectedIndex >= 0 Then
                    ID = GridShippingVessels.SelectedValue
                End If
            End If

            Dim tmpstr(5) As String
            tmpstr(0) = Trim(UCase(TextVesselName.Text))
            tmpstr(1) = Trim(TextVoyageNo.Text)
            tmpstr(2) = Trim(TextVesselETA.Text)
            tmpstr(3) = Trim(TextBerthingDate.Text)
            tmpstr(4) = Trim(TextExitDate.Text)
            tmpstr(5) = CheckActive.Checked.ToString

            Call clsShippingStorage.SaveVessel(CFPROID, tmpstr, "", ID, "")

            Call LoadVessels(CheckActive.Checked, CFPROID, TextSearch.Text)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridShippingVessels.SelectedIndex >= 0 Then
            Call PromptDeleteVessel(GridShippingVessels.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage.Text = "Please Select a Vessel From the List"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteVessel(ID As Integer, CFPROID As String)


        Dim row As GridViewRow = GridShippingVessels.Rows(GridShippingVessels.SelectedIndex)

        LabelDeleteMessage.Text = "Delete " & row.Cells(1).Text & " - Voyage No:" & row.Cells(2).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteVessel(GridShippingVessels.SelectedValue)
    End Sub
    Private Sub DeleteVessel(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From ShippingVessels  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("ShippingVessels", tmptable, sqlstr, True, clsData.constr)

            Call LoadVessels(CheckActive.Checked, LabelCFPROID.Text, TextSearch.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Protected Sub ButtonSearch_Click(sender As Object, e As EventArgs) Handles ButtonSearch.Click
        Call LoadVessels(False, LabelCFPROID.Text, TextSearch.Text)
    End Sub

    Protected Sub ButtonRefresh_Click(sender As Object, e As EventArgs) Handles ButtonRefresh.Click
        Call LoadVessels(False, LabelCFPROID.Text, "")
    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonDownloadExcel.Click


        Dim Fields(6) As String
        Fields(0) = "VesselID"
        Fields(1) = "Vessel"
        Fields(2) = "VoyageNo"
        Fields(3) = "ETA"
        Fields(4) = "BerthingDate"
        Fields(5) = "ExitDate"
        Fields(6) = "Active"


        Dim Fields1(6) As String
        Fields1(0) = "Vessel ID"
        Fields1(1) = "Vessel Name"
        Fields1(2) = "Voyage No"
        Fields1(3) = "ETA"
        Fields1(4) = "Berthing Date"
        Fields1(5) = "Last Sling / Exit Date"
        Fields1(6) = "Active"


        Dim tmptable As New DataTable("VesselsTable")
        tmptable = DirectCast(Session("VesselsTable"), DataTable)

        Call clsExportToExcel.ExportToExcel("", "", "", "Vessels", "Vessels",
                                            LabelVesselsCaption.Text, False, Nothing, 0, "", Fields, Fields1, tmptable, False)






    End Sub
End Class