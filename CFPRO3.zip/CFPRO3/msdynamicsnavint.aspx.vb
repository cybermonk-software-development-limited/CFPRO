﻿
Imports System.Drawing
Public Class msdynamicsnavint
    Inherits System.Web.UI.Page




    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""
            Dim CFPROUserID As String = ""
            Dim CFAgentName As String = ""
            Call clsAuth.UserLogin("", CFPROID, CFPROUserID, "", CFAgentName, "", "", "", True, "cfagent", True)

            LabelCFPROID.Text = CFPROID
            LabelDetails.Text = "Add / Edit MS Dynamics NAV URL setting for Companies here."

            Call LoadDynamicsNAVUrls(CFPROID)
        End If
    End Sub




    Private Sub LoadDynamicsNAVUrls(ByVal CFPROID As String)

        Try


            Dim sqlstr As String =
                "SELECT  DynamicsNAVUrl, CompanyName," &
                "DynamicsNAVUrls.CompanyID," &
                "UserName, DynamicsNAVUrls.ID " &
                "FROM DynamicsNAVUrls, Companies " &
                "Where DynamicsNAVUrls.CFPROID ='" & CFPROID & "' " &
                "And Companies.CFPROID ='" & CFPROID & "' " &
                "And DynamicsNAVUrls.CompanyID = Companies.CompanyID " &
                "Order By DynamicsNAVUrls.ID Desc "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)
            LabelCaption.Text = tmptable.Rows.Count & " MS DynamicsNAV URL Settings"

            Dim a As Integer
            Dim drow As DataRow


            If tmptable.Rows.Count = 0 Then

                drow = tmptable.NewRow
                drow("CompanyName") = "No Settings"
                tmptable.Rows.Add(drow)
            End If

            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                a = a + 1
            Next

            GridNAVSettings.DataSource = tmptable
            GridNAVSettings.DataBind()

        Catch exp As Exception
            LabelMessage1.Text = exp.Message
        End Try
    End Sub


    Protected Sub ButtonAdd_Click(sender As Object, e As EventArgs) Handles ButtonAdd.Click
        Call AddEditDynamicsNAVUrl(LabelCFPROID.Text, False)
    End Sub
    Protected Sub GridNAVSettings_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridNAVSettings.SelectedIndexChanged
        Dim row As GridViewRow = GridNAVSettings.Rows(GridNAVSettings.SelectedIndex)
        row.BackColor = ColorTranslator.FromHtml("#FFE9B9")

        For a As Integer = 0 To GridNAVSettings.Rows.Count - 1
            row = GridNAVSettings.Rows(a)
            If row.BackColor = ColorTranslator.FromHtml("#FFE9B9") Then
                If Not a = GridNAVSettings.SelectedIndex Then
                    row.BackColor = ColorTranslator.FromHtml("#FDFDFD")
                    row.ToolTip = "Click to select"
                End If
            End If
        Next

    End Sub

    Protected Sub GridNAVSettings_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridNAVSettings.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridNAVSettings, "Select$" & e.Row.RowIndex)
        End If
    End Sub
    Protected Sub ButtonEdit_Click(sender As Object, e As EventArgs) Handles ButtonEdit.Click
        Call AddEditDynamicsNAVUrl(LabelCFPROID.Text, True)
    End Sub
    Private Sub AddEditDynamicsNAVUrl(CFPROID As String, Edit As Boolean)
        Try

            Call clsAccounts.LoadCompanies(CFPROID, ComboCompanies, LabelMessage1.Text)
            ComboCompanies.Items.Insert(0, "(Select Company)")

            If Edit Then
                If GridNAVSettings.SelectedIndex < 0 Then
                    LabelMessage3.Text = "Please Select Company"
                    Exit Sub
                End If

                LabelAddEdit.Text = "Edit MS DynamicsNAV URL"
                Dim ID As Integer = GridNAVSettings.SelectedValue

                Dim sqlstr As String =
                   "SELECT CompanyID,DynamicsNAVUrl," &
                   "UserName,Password, " &
                   "CFPROID, ID " &
                   "FROM DynamicsNAVUrls " &
                   "Where CFPROID ='" & CFPROID & "' " &
                   "And ID = " & ID & " "

                Dim tmptable As New DataTable()
                Call clsData.TableData(sqlstr, tmptable, clsData.constr)



                If tmptable.Rows.Count > 0 Then
                    Dim drow As DataRow = tmptable.Rows(0)
                    Call clsData.NullChecker(tmptable, 0)
                    ComboCompanies.SelectedValue = drow("CompanyID")
                    TextDynamicsNAVUrl.Text = drow("DynamicsNAVUrl")
                    TextUserName.Text = drow("UserName")
                    TextPassword.Text = drow("Password")
                End If

            Else
                LabelAddEdit.Text = "Add MS DynamicsNAV URL "
                ComboCompanies.SelectedIndex = 0
                TextDynamicsNAVUrl.Text = ""
            End If

            ModalPopupExtender2.Show()
        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSave0_Click(sender As Object, e As EventArgs) Handles ButtonSave0.Click
        Call SaveDynamicsNAVUrl(LabelCFPROID.Text)
    End Sub

    Private Sub SaveDynamicsNAVUrl(CFPROID As String)

        Try

            Dim ID As Integer = -1

            If LabelAddEdit.Text.Contains("Edit") Then
                ID = GridNAVSettings.SelectedValue
            End If

            Dim sqlstr As String =
               "SELECT CompanyID, DynamicsNAVUrl, " &
               "CFPROID,UserName,Password, ID " &
               "FROM DynamicsNAVUrls " &
               "Where CFPROID ='" & CFPROID & "' " &
               "And ID = " & ID & " "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow
            If tmptable.Rows.Count > 0 Then
                drow = tmptable.Rows(0)
            Else
                drow = tmptable.NewRow
                drow("CFPROID") = CFPROID
                drow("CompanyID") = GetCompanyID()
                tmptable.Rows.Add(drow)
            End If

            drow("CompanyID") = ComboCompanies.SelectedValue
            drow("DynamicsNAVUrl") = Trim(TextDynamicsNAVUrl.Text)
            drow("UserName") = Trim(TextUserName.Text)
            drow("Password") = clsEncr.EncryptString(Trim(TextPassword.Text))


            Call clsData.SaveData("DynamicsNAVUrls", tmptable, sqlstr, False, clsData.constr)

            Call LoadDynamicsNAVUrls(CFPROID)

            ModalPopupExtender2.Hide()

        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub


    Protected Sub ButtonRemove_Click(sender As Object, e As EventArgs) Handles ButtonRemove.Click

        If GridNAVSettings.SelectedIndex >= 0 Then
            Call PromptDeleteCompanies(GridNAVSettings.SelectedValue, LabelCFPROID.Text)
        Else
            LabelMessage3.Text = "No Selection"
            Exit Sub
        End If

    End Sub
    Private Sub PromptDeleteCompanies(ID As Integer, CFPROID As String)
        Dim row As GridViewRow = GridNAVSettings.Rows(GridNAVSettings.SelectedIndex)

        LabelDeleteMessage.Text = "Delete URL Setting " & row.Cells(0).Text & " ?"
        ButtonDelete.Visible = True

        ModalPopupExtender3.Show()

    End Sub

    Protected Sub ButtonDelete_Click(sender As Object, e As EventArgs) Handles ButtonDelete.Click
        Call DeleteCompanies(GridNAVSettings.SelectedValue)
    End Sub
    Private Sub DeleteCompanies(ID As Integer)

        Dim sqlstr As String = _
                 "Select  ID " & _
                  "From DynamicsNAVUrls  " & _
                  "Where ID = " & ID & " "

        Dim tmptable As New DataTable

        Call clsData.TableData(sqlstr, tmptable, clsData.constr)


        If tmptable.Rows.Count > 0 Then
            Dim drow As DataRow = tmptable.Rows(0)
            drow.Delete()

            Call clsData.SaveData("DynamicsNAVUrls", tmptable, sqlstr, True, clsData.constr)

            Call LoadDynamicsNAVUrls(LabelCFPROID.Text)

        End If
        ModalPopupExtender3.Hide()

    End Sub



    Private Function GetCompanyID() As String
        Try

            Dim tmpCompanyID As Integer

            Dim sqlstr As String =
             "Select top 1 ID " &
             "From Companies " &
             "Order By ID Desc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmpstr As String
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow = tmptable.Rows(0)
                tmpCompanyID = drow("ID")
                tmpCompanyID = tmpCompanyID + 1
                tmpstr = Format(tmpCompanyID, "00000000#")
            Else
                tmpstr = Format(tmpCompanyID, "00000000#")
            End If

            Return tmpstr & "-" & clsSubs.GetRandomNo

        Catch exp As Exception
            MsgBox(exp.Message & exp.StackTrace, , "GetCompanyID")
        End Try
    End Function


End Class