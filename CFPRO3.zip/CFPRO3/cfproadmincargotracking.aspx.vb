﻿Public Class cfproadmincargotracking
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load



        If Not IsPostBack Then


            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If


            Call clsAuth.UserLogin(LabelCSDID.Text, "", LabelCFPROUserID.Text, LabelUser.Text, "", LinkSignIn.Text, Image1.ImageUrl, "", False, "", True)


            If IsNothing(Request.Cookies("CSDAdmin")) Then
                Response.Redirect("index.aspx")
            Else
                Try
                    If Not Request.Cookies("CSDAdmin").Value = 1 Then
                        Response.Redirect("index.aspx")
                    End If
                Catch ex As Exception
                    Response.Redirect("index.aspx")
                End Try

            End If



            If InStr(HttpContext.Current.Request.Url.ToString, "localhost", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://localhost:84/adminproducts.aspx"
            ElseIf InStr(HttpContext.Current.Request.Url.ToString, "172.16.254", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://172.16.254.105:84/adminproducts.aspx"

            ElseIf InStr(HttpContext.Current.Request.Url.ToString, "cfproonline.com", CompareMethod.Text) > 0 Then
                HyperLinkHome.NavigateUrl = "http://cybermonksd.com/adminproducts.aspx"
            End If

            Call LoadCFAgents()
            Call LoadPayloads()

            ComboPredefine.SelectedIndex = 5

            Call PreDefine(ComboPredefine.Text, "")
            LabelFooter.Text = "Copyright © " & Format(Now, "yyyy") & " Cybermonk Software Development"


        End If

    End Sub

    Protected Sub ComboCFAgents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboCFAgents.SelectedIndexChanged
        Call LoadContainers(ComboCFAgents.SelectedValue, ComboPayloads.Text)
    End Sub

    Private Sub LoadContainers(CFPROID As String, Payload As String)

        Try

            Dim tmpstr As String = ""
            Dim tmpstr2 As String = ""


            If Not CFPROID = "(All)" Then
                tmpstr = "And Jobs.CFPROID = '" & CFPROID & "' "
                tmpstr2 = "Where CFPROID = '" & CFPROID & "' "
            End If

            If Not Payload = "(All)" Then
                tmpstr = tmpstr & " And Payload = '" & Payload & "' "
            End If

            Dim tmpstr1 As String = ""

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr1 = "And Jobs.JobDate >= '" & TextFromDate.Text & "' " &
                  "And Jobs.Jobdate <= '" & TextToDate.Text & "' "
            End If


            Dim sqlstr As String =
                  "Select JobCargo.JobId,ContainerNo," &
                  "JobCargo.Weight,JobCargo.CBM,VehicleNo,TrailerNo," &
                  "TransporterID,JobCargo.PortExitDate," &
                  "JobCargo.CrossBorderDate,ContainerStatus," &
                  "BorderDispatchDate,DestinationArrivalDate," &
                  "OffLoadDate,DestinationDispatchDate," &
                  "JobCargo.ReturnDate," &
                  "JobCargo.RemainingDays," &
                  "JobCargo.Payload," &
                  "T812No,CustomsSealNo,TEU,T1No," &
                  "JobCargo.Demurrage as DemurrageCharges," &
                  "InterchangeNo, JobCargo.Destination, DestinationDepot, " &
                  "SpecialCargoType, ContainerStatusRemarks, " &
                  "ReturnVehicleNo, DeliveryNoteNo, JobCargo.Id, " &
                  "Jobs.AgentID, Jobs.ClientID, Jobs.ClientID, " &
                  "Jobs.ImporterID,ShipperID," &
                  "Jobs.ShippingLineID, VesselID, SOC," &
                  "Jobs.JobStatus,Jobs.KeepVisible,DispatchDate," &
                  "BL,HouseBL,BLCountry,ManifestNo,Jobs.JobDate," &
                  "ReferenceNo,ReferenceNo1," &
                  "Jobs.ID as ID1," &
                  "Jobs.ReleaseOrderStatus, Jobs.JobType," &
                  "DocumentsReceivedDate, ContainerDepositDate," &
                  "PortChargesPaidDate, LoadingDate " &
                  "From JobCargo, Jobs " &
                  "Where JobCargo.CFPROID  = Jobs.CFPROID " &
                  "And Jobs.JobID  = JobCargo.JobId " &
                   tmpstr & " " & tmpstr1


            Dim sqlstr1 As String =
                       "Select ShippingLine, ShippingLineID, ID " &
                       "From ShippingLines " &
                       tmpstr2



            Dim sqlstr3 As String =
                    "Select Vessel,VesselID, ETA," &
                    "BerthingDate, ExitDate  " &
                    "From ShippingVessels " &
                    tmpstr2


            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)
            Dim dv1 As New DataView(tmptable1)

            Dim tmptable3 As New DataTable()
            Call clsData.TableData(sqlstr3, tmptable3, clsData.constr)
            Dim dv3 As New DataView(tmptable3)



            Dim col1 As New DataColumn("ShippingLine", Type.GetType("System.String"))
            tmptable.Columns.Add(col1)

            Dim col2 As New DataColumn("Vessel", Type.GetType("System.String"))
            tmptable.Columns.Add(col2)


            Dim col3 As New DataColumn("VesselETA", Type.GetType("System.DateTime"))
            tmptable.Columns.Add(col3)

            Dim col4 As New DataColumn("BerthingDate", Type.GetType("System.DateTime"))
            tmptable.Columns.Add(col4)

            Dim col5 As New DataColumn("LastSlingDate", Type.GetType("System.DateTime"))
            tmptable.Columns.Add(col5)

            Dim col6 As New DataColumn("DaysTaken", Type.GetType("System.Double"))
            tmptable.Columns.Add(col6)


            Dim a As Integer
            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)
                drow("ContainerNo") = Mid(Trim(drow("ContainerNo")), 1, 25)

                dv1.RowFilter = "ShippingLineID = '" & drow("ShippingLineID") & "' "

                If dv1.Count > 0 Then
                    Call clsData.NullChecker1(dv1, 0)
                    drow("ShippingLine") = dv1(0)("ShippingLine")
                End If


                dv3.RowFilter = "VesselID = '" & drow("VesselID") & "' "

                If dv3.Count > 0 Then
                    Call clsData.NullChecker1(dv3, 0)

                    drow("Vessel") = dv3(0)("Vessel")
                    drow("VesselETA") = Format(dv3(0)("ETA"), "dd MMM yyyy")
                    drow("BerthingDate") = Format(dv3(0)("BerthingDate"), "dd MMM yyyy")
                    drow("LastSlingDate") = Format(dv3(0)("ExitDate"), "dd MMM yyyy")
                    drow("DaysTaken") = clsShippingStorage.DaysTaken(dv3(0)("ExitDate"), drow("DispatchDate"))
                End If
                a = a + 1
            Next



            Call Calctotal(tmptable, " - " & ComboCFAgents.SelectedItem.ToString)

            Session("AdContainerControlTable") = tmptable

            GridCargo.DataSource = tmptable
            GridCargo.DataBind()

            If tmptable.Rows.Count >= 10 Then
                PanelCargo.Height = 350
            Else
                PanelCargo.Height = Nothing
            End If

            Dim tmpstr3 As String

            If Not ComboPredefine.Text = "(All)" Then
                tmpstr3 = TextFromDate.Text & " - " & TextToDate.Text & " " & " (" & ComboLoadedJobs.Text & " )"
            Else
                tmpstr3 = "Containers In System" & " (" & ComboLoadedJobs.Text & " )"
            End If


            If Not CFPROID = "(All)" Then
                tmpstr3 = tmpstr3 & " For '" & ComboCFAgents.SelectedItem.ToString
            End If

            If Not Payload = "(All)" Then
                tmpstr3 = tmpstr3 & " Payload: " & Payload
            End If


            LabelReportCaption.Text = tmptable.Rows.Count & " Containers: " & tmpstr3


        Catch ex As Exception
            LabelMessage1.Text = ex.Message & ex.StackTrace
        End Try
    End Sub


    Private Sub Calctotal(tmptable As DataTable, ByVal tmpcaption1 As String)
        Try


            Dim a As Integer
            Dim TEU, Weight, CBM As Double


            For Each drow In tmptable.Rows
                Call clsData.NullChecker(tmptable, a)



                Weight = Weight + drow("Weight")
                CBM = CBM + drow("CBM")
                TEU = TEU + Val(drow("TEU"))
                a = a + 1
            Next
            TextQuantity.Text = Format(tmptable.Rows.Count, "#,##0.00")
            TextWeight.Text = Format(Weight, "#,##0.00")
            TextCBM.Text = Format(CBM, "#,##0.00")
            TextTEU.Text = Format(TEU, "#,##0.00")


        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try

    End Sub

    Private Sub LoadCFAgents()
        Dim sqlstr As String =
        "Select CFAgentName,CFPROID From CFPROAccounts " &
        "Order By CFAgentName Asc;"

        ComboCFAgents.Items.Clear()
        Call clsData.PopComboWithValue(ComboCFAgents, sqlstr, clsData.constr, 0, 1)
        ComboCFAgents.Items.Insert(0, "(All)")



    End Sub


    Private Sub LoadPayloads()
        Dim sqlstr As String =
        "Select Distinct Payload From Payloads " &
        "Order By Payload Asc;"

        ComboPayloads.Items.Clear()
        Call clsData.PopCombo(ComboPayloads, sqlstr, clsData.constr, 0)
        ComboPayloads.Items.Insert(0, "(All)")

    End Sub


    Protected Sub GridCargo_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridCargo.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes("onclick") = Page.ClientScript.GetPostBackClientHyperlink(GridCargo, "Select$" & e.Row.RowIndex)
        End If
    End Sub


    Private Sub PreDefine(ByVal Selection As String, CFPROID As String)
        Try
            Dim tmpdate, tmpdate1, tmpdate2 As DateTime
            tmpdate = Format(Now, "MMM/dd/yyyy hh:mm:ss tt")

            Dim days As Integer = Date.DaysInMonth(tmpdate.Year, tmpdate.Month)
            Dim a As Integer = tmpdate.DayOfWeek
            Dim b As Integer = tmpdate.Day

            Dim tmpstr(12) As String
            tmpstr(1) = "Jan"
            tmpstr(2) = "Feb"
            tmpstr(3) = "Mar"
            tmpstr(4) = "Apr"
            tmpstr(5) = "May"
            tmpstr(6) = "Jun"
            tmpstr(7) = "Jul"
            tmpstr(8) = "Aug"
            tmpstr(9) = "Sep"
            tmpstr(10) = "Oct"
            tmpstr(11) = "Nov"
            tmpstr(12) = "Dec"


            Select Case LCase(Selection)

                Case "(all)"
                    TextFromDate.Text = ""
                    TextToDate.Text = ""


                    Call ClearFilters()
                    Call LoadContainers(ComboCFAgents.SelectedValue, ComboPayloads.Text)

                    Exit Sub

                Case "today"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate1 = tmpdate
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "yesterday"
                    tmpdate2 = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate2.AddSeconds(-1)
                    tmpdate = tmpdate.AddDays(-1)
                    tmpdate1 = CDate(tmpdate.Date)

                Case "this week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last week"
                    b = tmpdate.DayOfWeek
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = tmpdate.AddDays(-7)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(6)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "this month"
                    Call clsSubs.GetcurrentMonth(tmpdate1, tmpdate2)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last month"
                    b = tmpdate.Day
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate = tmpdate.AddMonths(-1)
                    b = Date.DaysInMonth(tmpdate.Year, tmpdate.Month) - 1
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(b)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate


                Case "last 1 month"
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-1)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "last 2 months"

                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-2)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2

                Case "last 3 months"


                    tmpdate = CDate(tmpdate.Date)
                    tmpdate2 = tmpdate
                    tmpdate = tmpdate.AddMonths(-3)
                    b = tmpdate.Month
                    tmpdate1 = CDate("1/" & tmpstr(b) & "/" & tmpdate.Year)
                    tmpdate2 = CDate(tmpdate2.Date)
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)
                    tmpdate2 = tmpdate2


                Case "this year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b - 1) * -1)
                    tmpdate1 = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddDays(364)
                    tmpdate = CDate(tmpdate.Date)
                    tmpdate = tmpdate.AddHours(23)
                    tmpdate = tmpdate.AddMinutes(59)
                    tmpdate = tmpdate.AddSeconds(59)
                    tmpdate2 = tmpdate

                Case "last year"
                    b = tmpdate.DayOfYear
                    tmpdate = tmpdate.AddDays((b) * -1)
                    tmpdate = CDate(tmpdate.Date)

                    tmpdate2 = tmpdate
                    tmpdate2 = tmpdate2.AddHours(23)
                    tmpdate2 = tmpdate2.AddMinutes(59)
                    tmpdate2 = tmpdate2.AddSeconds(59)


                    tmpdate = tmpdate.AddDays(364 * -1)
                    tmpdate1 = CDate(tmpdate.Date)

            End Select



            TextFromDate.Text = Format(tmpdate1, "dd MMM yyyy hh:mm tt")
            TextToDate.Text = Format(tmpdate2, "dd MMM yyyy hh:mm tt")

            Call ClearFilters()
            Call LoadContainers(ComboCFAgents.SelectedValue, ComboPayloads.Text)

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub

    Private Sub ClearFilters()
        Dim cont As Control
        For Each cont In PanelFilters.Controls
            If TypeOf cont Is CheckBox Then
                If cont.ID = "CheckDispatchDate" Then
                    Continue For
                End If

                If cont.ID = "CheckIncludeClosedJobs" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedAgents" Then
                    Continue For
                End If

                If cont.ID = "CheckSelectedClients" Then
                    Continue For
                End If

                If cont.ID = "CheckShowBL" Then
                    Continue For
                End If

                If cont.ID = "CheckShowExtensionDays" Then
                    Continue For
                End If

                If cont.ID = "CheckAddJobDatetoRef" Then
                    Continue For
                End If

                DirectCast(cont, CheckBox).Checked = False

            End If

        Next
    End Sub


    Protected Sub ButtonApplyDates_Click(sender As Object, e As EventArgs) Handles ButtonApplyDates.Click
        Call ClearFilters()
        Call LoadContainers(ComboCFAgents.SelectedValue, ComboPayloads.Text)
    End Sub

    Protected Sub ComboPredefine_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPredefine.SelectedIndexChanged
        Call PreDefine(ComboPredefine.Text, ComboCFAgents.SelectedValue)
    End Sub

    Protected Sub ComboPayload_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPayloads.SelectedIndexChanged
        Call LoadContainers(ComboCFAgents.SelectedValue, ComboPayloads.Text)
    End Sub

    Protected Sub ButtonExportToExcel_Click(sender As Object, e As EventArgs) Handles ButtonExportToExcel.Click


        Dim Totals(5) As String

        Totals(0) = "Total Weight: " & TextWeight.Text & " (Kgs)"
        Totals(1) = "Total CBM: " & TextCBM.Text & " Cb.M"
        Totals(2) = "Total TEU: " & TextTEU.Text
        Totals(3) = "Total Qty: " & TextQuantity.Text


        Dim Fields(10) As String
        Fields(0) = "ContainerNo"
        Fields(1) = "Payload"
        Fields(2) = "JobType"
        Fields(3) = "ShippingLine"
        Fields(4) = "BerthingDate"
        Fields(5) = "PortExitDate"
        Fields(6) = "CrossBorderDate"
        Fields(7) = "ReturnDate"
        Fields(8) = "ContainerStatus"
        Fields(9) = "RemainingDays"
        Fields(10) = "ReturnDate"

        Dim tmptable As DataTable = Session("AdContainerControlTable")
        Call clsExportToExcel.ExportToExcel("", "", "", "CSD Admin Cargo Tracking", "CSD Admin Cargo Tracking",
                                            LabelReportCaption.Text, True, Totals, 0, LabelMessage1.Text, Fields, Nothing, tmptable, False)
    End Sub

    Protected Sub LinkSignIn_Click(sender As Object, e As EventArgs) Handles LinkSignIn.Click
        Call clsAuth.SignInOut(LinkSignIn.Text, LabelUser.Text, Image1.ImageUrl, True)
    End Sub



End Class