﻿Public Class receiveddocuments
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""


            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)

            Dim JobID As String = ""
            Dim JobTypeID As String = ""

            JobID = Request.QueryString("jobid")
            JobTypeID = Request.QueryString("jobtypeid")
            TodaysDate.Value = Request.QueryString("todaysdate")
            
            LabelCFPROID.Text = CFPROID
            LabelJobID.Text = JobID
            LabelJobTypeID.Text = JobTypeID


            Call LoadReceivedJobDocuments(CFPROID, JobTypeID, JobID)

        End If
    End Sub

    Private Sub LoadReceivedJobDocuments(CFPROID As String, JobTypeID As String, JobID As String)

        Try

            Dim sqlstr As String =
               "SELECT  DocumentType, JobTypeDocuments.DocumentTypeID " &
               "From  JobTypeDocuments, DocumentTypes " &
               "Where JobTypeDocuments.CFPROID ='" & CFPROID & "' " &
               "And DocumentTypes.CFPROID = JobTypeDocuments.CFPROID " &
               "And DocumentTypes.DocumentTypeID = JobTypeDocuments.DocumentTypeID " &
               "And JobTypeDocuments.JobTypeID ='" & JobTypeID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            Dim col As New DataColumn("ConfirmDate", Type.GetType("System.String"))
            Dim col1 As New DataColumn("IsReceived", Type.GetType("System.Boolean"))

            tmptable.Columns.Add(col)
            tmptable.Columns.Add(col1)
            Dim a As Integer
            If tmptable.Rows.Count > 0 Then
                Dim drow As DataRow
                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                Next
            End If

            Dim sqlstr1 As String =
                "SELECT JobID, DocumentTypeID," &
                "CFPROID, ConfirmDate,ID " &
                "FROM JobDocumentsReceived " &
                "Where JobID ='" & JobID & "' " &
                "And JobTypeID ='" & JobTypeID & "' " &
                "And CFPROID ='" & CFPROID & "' "

            Dim tmptable1 As New DataTable()
            Call clsData.TableData(sqlstr1, tmptable1, clsData.constr)

            Dim b, c As Integer
            If tmptable.Rows.Count > 0 Then

                a = 0

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    b = 0
                    For Each drow1 In tmptable1.Rows
                        Call clsData.NullChecker(tmptable1, b)
                        If drow("DocumentTypeID") = drow1("DocumentTypeID") Then
                            drow("ConfirmDate") = "Confirmed on:  " & Format(drow1("ConfirmDate"), "dd MMM yyyy")
                            drow("IsReceived") = 1
                            c = c + 1
                            Exit For
                        End If
                        b = b + 1
                    Next
                    a = a + 1
                Next
            End If

            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelDocumenTypeCount.Text = c & " / " & DataList1.Items.Count & " Document Types"

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveJobTypeDocuments_Click(sender As Object, e As EventArgs) Handles ButtonSaveJobTypeDocuments.Click
        Call SaveJobDocumentsReceived(LabelCFPROID.Text, LabelJobTypeID.Text, LabelJobID.Text)

    End Sub


    Protected Sub CheckDocumentType_CheckedChanged(sender As Object, e As EventArgs)

        Dim chkbox As CheckBox
        Dim a As Integer

        For Each item As DataListItem In DataList1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                chkbox = TryCast(item.FindControl("CheckDocumentType"), CheckBox)

                If chkbox IsNot Nothing Then
                    If chkbox.Checked Then
                        a = a + 1
                    End If
                End If

            End If
        Next

        LabelDocumenTypeCount.Text = a & " / " & DataList1.Items.Count & " Document Types"


    End Sub
    Private Sub SaveJobDocumentsReceived(CFPROID As String, JobTypeID As String, JobID As String)

        Try

            Dim sqlstr As String =
              "SELECT JobID, DocumentTypeID," &
              "CFPROID,JobTypeID, ConfirmDate,ID " &
              "FROM JobDocumentsReceived " &
              "Where JobID ='" & JobID & "' " &
              "And JobTypeID ='" & JobTypeID & "' " &
              "And CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            Dim chkbox As CheckBox
            Dim fieldDocTypeID As HiddenField
            Dim found As Boolean
            Dim a As Integer

            For Each item As DataListItem In DataList1.Items

                If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                    chkbox = DirectCast(item.FindControl("CheckDocumentType"), CheckBox)
                    fieldDocTypeID = DirectCast(item.FindControl("FieldDocumentTypeID"), HiddenField)

                    found = False
                    If chkbox IsNot Nothing Then

                        For Each drow In tmptable.Rows
                            If Not drow.RowState = DataRowState.Deleted Then
                                Call clsData.NullChecker(tmptable, a)
                                If drow("DocumentTypeID") = fieldDocTypeID.Value Then
                                    If Not chkbox.Checked Then
                                        drow.Delete()
                                    Else
                                        found = True
                                    End If
                                    Exit For
                                End If
                            End If

                        Next
                        If Not found Then
                            If chkbox.Checked Then

                                Dim ConfirmDate As DateTime

                                If Not IsDate(TodaysDate.Value) Then
                                    ConfirmDate = Format(Now, "MMM d yyyy hh:mm tt")
                                    TodaysDate.Value = Format(Now, "MMM d yyyy hh:mm tt")
                                Else
                                    ConfirmDate = clsSubs.AbsoluteDateTime(TodaysDate.Value)
                                End If

                                Dim drow1 As DataRow = tmptable.NewRow
                                drow1("CFPROID") = CFPROID
                                drow1("DocumentTypeID") = fieldDocTypeID.Value
                                drow1("JobTypeID") = JobTypeID
                                drow1("JobID") = JobID

                                drow1("ConfirmDate") = ConfirmDate
                                tmptable.Rows.Add(drow1)
                            End If
                        End If

                    End If
                End If
            Next

            Call clsData.SaveData("JobDocumentsReceived", tmptable, sqlstr, True, clsData.constr)


            Call LoadReceivedJobDocuments(LabelCFPROID.Text, LabelJobTypeID.Text, LabelJobID.Text)


        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

End Class