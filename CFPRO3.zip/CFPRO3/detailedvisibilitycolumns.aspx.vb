﻿Public Class detailedvisibilitycolumns
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then

            If Not IsNothing(Request.QueryString("logintoken")) Then
                Call clsAuth.LoginToken(Request.QueryString("logintoken"), True)
            End If

            Dim CFPROID As String = ""


            Call clsAuth.UserLogin("", CFPROID, "", "", "", "", "", "", True, "cfagent", True)


            LabelCFPROID.Text = CFPROID


            Call LoadDetailedVisibilityColumns(CFPROID)

        End If
    End Sub

    Private Sub LoadDetailedVisibilityColumns(CFPROID As String)

        Try


            Dim sqlstr As String =
               "SELECT ColumnName, ColumnText," &
               "Show, CFPROID, SortOrder, ID " &
               "FROM  DetailedVisibilityReportColumns " &
                "Where CFPROID ='" & CFPROID & "' " &
               "Order By SortOrder Asc;"

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)

            If tmptable.Rows.Count = 0 Then
                Call clsDetailedVisibilityReport.CreateDetailedVisibilityColumns(CFPROID, tmptable)

                Dim tmptable1 As New DataTable()
                Call clsData.TableData(sqlstr, tmptable1, clsData.constr)
                tmptable = tmptable1
            End If


            Dim a, b As Integer
            If tmptable.Rows.Count > 0 Then

                For Each drow In tmptable.Rows
                    Call clsData.NullChecker(tmptable, a)
                    If drow("Show") Then
                        b = b + 1
                    End If
                    a = a + 1
                Next
            End If


            DataList1.DataSource = tmptable
            DataList1.DataBind()

            LabelColumnCount.Text = b & " / " & DataList1.Items.Count & " Columns Selected"

        Catch exp As Exception
            LabelMessage1.Text = exp.Message & exp.StackTrace
        End Try
    End Sub
    Protected Sub ButtonSaveVisibilityColumns_Click(sender As Object, e As EventArgs) Handles ButtonSaveVisibilityColumns.Click
        Call SaveDetailedVisibilityColumns(LabelCFPROID.Text)

    End Sub


    Protected Sub CheckDocumentType_CheckedChanged(sender As Object, e As EventArgs)

        Dim chkbox As CheckBox
        Dim a As Integer

        For Each item As DataListItem In DataList1.Items
            If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                chkbox = TryCast(item.FindControl("CheckShowColumn"), CheckBox)

                If chkbox IsNot Nothing Then
                    If chkbox.Checked Then
                        a = a + 1
                    End If
                End If

            End If
        Next

        LabelColumnCount.Text = a & " / " & DataList1.Items.Count & " Columns Selected"


    End Sub
    Private Sub SaveDetailedVisibilityColumns(CFPROID As String)

        Try

            Dim sqlstr As String =
               "SELECT ColumnText, Show, ID " &
               "FROM  DetailedVisibilityReportColumns " &
               "Where CFPROID ='" & CFPROID & "' "

            Dim tmptable As New DataTable()
            Call clsData.TableData(sqlstr, tmptable, clsData.constr)


            Dim drow As DataRow

            Dim chkbox As CheckBox
            Dim nColumnID As HiddenField
            Dim a As Integer

            For Each item As DataListItem In DataList1.Items
                If item.ItemType = ListItemType.Item OrElse item.ItemType = ListItemType.AlternatingItem Then
                    chkbox = DirectCast(item.FindControl("CheckShowColumn"), CheckBox)
                    nColumnID = DirectCast(item.FindControl("ColumnID"), HiddenField)

                    If chkbox IsNot Nothing Then
                        a = 0
                        For Each drow In tmptable.Rows
                            Call clsData.NullChecker(tmptable, a)
                            If drow("ID") = nColumnID.Value Then
                                drow("Show") = chkbox.Checked
                                Exit For
                            End If
                            a = a + 1
                        Next

                    End If
                End If
            Next

            Call clsData.SaveData("DetailedVisibilityReportColumns", tmptable, sqlstr, False, clsData.constr)


            Call LoadDetailedVisibilityColumns(LabelCFPROID.Text)


        Catch ex As Exception
            LabelMessage1.Text = ex.Message + ex.StackTrace
        End Try
    End Sub

End Class